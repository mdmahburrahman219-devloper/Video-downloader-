# Storage, Theme and Browser Tabs update

## Storage behavior

- Sync to gallery defaults to OFF for new installs.
- Sync ON writes video media through `MediaStore.Video.Media` to `DCIM/Video downloader/`, and publishes it only after the copy is complete.
- Sync OFF uses the persisted Storage Access Framework folder grant when configured. The selected folder must be named `Video downloader`; the intended location is `Internal Storage/Video downloader/`.
- Android 11+ does not allow an app to request the internal-storage root itself through `ACTION_OPEN_DOCUMENT_TREE`. Create `Video downloader` once in the device file manager, then open Settings > Download > Connect Video downloader folder and select that folder. This keeps the app within scoped-storage rules and avoids `MANAGE_EXTERNAL_STORAGE`.
- If no SAF folder grant exists, the code attempts a direct shared-root write. If Android blocks it, the download is saved through `MediaStore.Downloads` under `Download/Video downloader/` as a safe fallback rather than failing or using the video collection with an invalid `Download/` path.
- Private Downloads continue to use app-private storage.

## Theme behavior

- System default: Light when the system is light; AMOLED black when the system is dark.
- Light: white surfaces.
- AMOLED black: `#000000` background and surfaces with subtle near-black cards.
- Normal dark: `#121212` background with elevated dark-grey surfaces.
- Theme selection is persisted in DataStore and applies globally through `MaterialTheme`.

## Tabs screen

- Removed the fixed blue gradient and fixed card colors.
- Tabs, Private, search, card surfaces, selected state, empty state and floating action button now use the global Material color scheme.
- Reduced preview height and tightened spacing to improve the two-column tab grid.

## Verification note

This source archive does not contain the Gradle wrapper scripts/JAR and the current build environment has no Android SDK configured. A full Android Gradle build could therefore not be run here. Please import the project into Android Studio/Code Assist and run `:app:assembleDebug` before installing.
