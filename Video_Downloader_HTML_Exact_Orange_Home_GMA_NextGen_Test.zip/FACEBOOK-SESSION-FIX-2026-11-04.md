# Facebook signed-in session download stabilization — 2026-11-04

## Changes

- Restored `BrowserViewModel.onMetaVideoCandidate()` for Meta progressive MP4 and HLS candidates. A previous DASH pause had an unconditional early return at the top of this callback, which unintentionally disabled all Meta video candidates from that callback.
- Paused only DASH candidates from the Meta callback; MP4/HLS continue through the existing extraction and selection path.
- Disabled inline Meta DASH manifest ingestion while DASH is paused. The DASH parser/catalog/store sources remain in the project for a later re-enable.
- Added a final selection guard so DASH candidates cannot be offered as downloadable choices while the service's DASH execution branch is disabled.
- `HttpDownloader` now flushes WebView's cookie store before reading URL-scoped cookies for the actual request. Cookies remain scoped to the media URL host; Facebook cookies are not forwarded to unrelated CDN domains.
- `HttpDownloader` now rejects HTML/JSON/XML login/error payloads returned with HTTP 200 instead of saving them as tiny corrupt video files. The temporary file is removed on this invalid response.

## Safety boundaries

- No Facebook passwords are read or stored.
- Cookies are not logged and are not forwarded to unrelated hosts.
- TikTok-specific extraction code was not edited.
- Other site-specific handlers were not edited.
- DASH implementation code was retained; execution remains disabled in `DownloadService`.

## Validation status

- Source-level review completed for the edited Kotlin paths.
- Android Gradle build was not run in this environment because the archive does not include `gradlew`/`gradlew.bat` and no Gradle executable is installed here.
- Runtime verification still requires installing the build on an Android device and testing Facebook Reels while signed in, plus a TikTok regression test.
