# HLS downloader — Path A changes

This update keeps the existing custom Kotlin downloader rather than replacing it with Media3.

## Implemented

1. **Fragmented MP4 HLS:** supports common fMP4 playlists with one stable `EXT-X-MAP` initialization section.
2. **Byte ranges:** parses explicit and implicit `EXT-X-BYTERANGE` offsets and validates `206`/`Content-Range`; if a server ignores Range with `200`, reads/skips the requested offset and saves only the requested length.
3. **Standard AES-128:** supports `METHOD=AES-128` + `KEYFORMAT=identity`, explicit or sequence-derived IVs, accessible HTTP(S) keys, and encrypted map data when an explicit IV is present. It does not bypass DRM, `SAMPLE-AES`, or non-identity formats.
4. **Separate audio rendition:** parses `EXT-X-MEDIA:TYPE=AUDIO`, associates audio groups with variants, persists the chosen audio playlist URL, captures audio/video feeds together and remuxes both tracks.
5. **Segment-timeline remuxing:** media segments are opened one at a time and each sample is placed on the cumulative `EXTINF` timeline. MPEG-TS/fMP4 timestamp resets no longer get treated as a continuous clock. Only overlapping leading samples at a segment boundary are dropped instead of shifting later segments forward; the sample order inside a segment is preserved for B-frame codecs. This prevents repeated timestamp corrections from inflating duration and causing gradual audio/video drift. Invalid/zero `EXTINF` values fail explicitly instead of creating a corrupt timeline.
6. **Live / resume:** refreshes live playlists until `ENDLIST` or the 30-minute capture cap, stores completed segments and resume metadata, expires stale resume states after 24 hours and rejects a live resume when the media sequence clearly restarted backwards.

## Explicit compatibility boundaries

- Multiple changing `EXT-X-MAP` initialization sections within one media playlist are rejected rather than creating a likely-corrupt MP4.
- Codec changes, complex discontinuity-heavy fMP4, unsupported Android codec/container combinations, and malformed server Range responses can still fail.
- `SAMPLE-AES`, non-identity key formats and DRM/license-protected media are unsupported; this project intentionally does not bypass DRM.
- Live HLS is a bounded capture, not an infinite recording. Current cap is 30 minutes per download.
- Network access requiring browser-session cookies may still fail in the custom HLS transfer engine because HLS segment/key requests use the source URL's User-Agent and Referer, not a copied cookie jar.

## Verification performed for this archive

- Source-level Kotlin syntax scan: no parser errors found in the changed Kotlin files.
- `HlsPlaylistParser.kt` and `HlsSegmentTimeline.kt` standalone Kotlin compilation: passed.
- A synthetic 34-minute/204-segment test of the pure timestamp normalizer passed, including restarted PTS clocks and an overlapping segment boundary. This does **not** replace a real BongoBD media test.
- English/Bangla XML parsing and ZIP integrity checks: passed.
- Full Android Gradle build, Room/KSP code generation, the project test suite and real-device playback/remux: **not run** because this environment has no Gradle executable or Android SDK, and the source export omitted Gradle wrapper scripts/JAR. Generate the wrapper as described in `GRADLE-EXPORT.md`, then run `./gradlew assembleDebug test` on a machine with JDK and Android SDK 36.
