# Popup metadata and size accuracy update

- The quality popup now uses a compact white surface with a darker background scrim, a duration badge on the thumbnail, and no duplicate duration / HLS support notice under the quality cards.
- The thumbnail row no longer includes the extra checkbox; the selected quality and Download action remain explicit.
- Exact file sizes are taken from `Content-Length` or the total value in `Content-Range`. A `206 Partial Content` response's one-byte `Content-Length` is never mistaken for the full file size.
- The HLS duration parsed from a VOD media playlist is preserved instead of being overwritten with a null duration from the master playlist.
- A VOD HLS duration comes from the sum of its `EXTINF` segment durations when the page/player did not provide duration metadata.
- A generated MP4's exact output size cannot be guaranteed before HLS segments are downloaded and muxed. Before download, HLS card sizes remain estimates and are marked with a short `≈`; after the actual output file is produced, its measured byte length is written to the completed-download record.
- Live HLS playlists are not assigned a total VOD duration from their moving segment window.

- Finished and progress cards use each download's own duration metadata; the hard-coded `00:31` demo duration is removed. If Android cannot read a real local duration, no invented duration is shown.
- Completed records store the duration read from the final local file; an unreadable/unknown local duration clears provisional source duration instead of preserving a potentially incorrect value.
- Byte labels use B/KB/MB/GB units, so tiny transfers do not round to `0.00 MB` and large files do not display unnecessarily large MB counts.
