# Settings UI Polish — 2026-11-06

## Changes

- Corrected Settings content spacing/inset handling so the introductory text and first section begin clearly below the top app bar.
- Moved **Customize Home** into the **Appearance** section and removed its duplicate entry from **Browser**.
- Removed the redundant **Connect download folder** row and its document-tree picker logic. The primary **Download location** setting remains available.
- Reduced the animated bottom-navigation selection bubble from 56dp to 46dp, scaled the selected icon down, and softened the shadow/notch proportions.
- Moved the selected destination badge outside the clipped circle and resized count badges to preserve full visibility, including `99+`.
- Preserved the existing routes, screen content, download behavior, and prior Phase 1–4 updates.

## Validation

- Confirmed the earlier `BrowserHistoryScreen.kt` `Modifier.background` import is present.
- Confirmed the earlier `CompletedScreen.kt` Material 3 `Surface` import is present.
- ZIP integrity and source-level checks are performed on this export. A full Android Gradle build was not run in this environment.
