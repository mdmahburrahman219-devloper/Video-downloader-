# Video Downloader — Gradle export notes

This is a CodeAssist-exported Gradle project. The original archive included `gradle/wrapper/gradle-wrapper.properties` but not `gradlew`, `gradlew.bat`, or `gradle-wrapper.jar`; therefore the wrapper must be regenerated before command-line `./gradlew` commands can run.

## Project build configuration
- Android Gradle Plugin: 8.13.0
- Kotlin Android / Compose plugins: 2.4.0
- Gradle distribution configured in wrapper properties: 8.13
- KSP: 2.3.12
- WebView integration uses the Android platform `android.webkit` APIs; the unused AndroidX WebKit dependency was removed during this audit.
- Room compiler is now configured through KSP (rather than `compileOnly`) so Room can generate its DAO/database implementations.

## Release optimization
- Release builds now enable R8 minification and resource shrinking.
- AGP 8.13 optimized resource shrinking is enabled through `android.r8.optimizedResourceShrinking=true`.
- The app's active dependencies are declared directly in `app/build.gradle.kts`; the unused generated version catalog was removed.

## Build setup
Use JDK 17 or a compatible newer JDK and Android SDK 36. With Gradle installed, run `gradle wrapper --gradle-version 8.13` once, then `./gradlew assembleDebug` and `./gradlew test`.

The source was not fully built in the environment where this archive was prepared: it had neither an installed Gradle executable nor an Android SDK. JavaScript syntax, XML parsing, and the pure Kotlin HLS parser compile/smoke checks passed; they are not a substitute for a real Android build, Room/KSP code generation, or device playback test. See `AUTO-DETECTION-UPDATE.md` for the updated detection flow and device test checklist.
