# Browser performance, context menu and tab overview update

This revision improves the existing browser rather than replacing the downloader architecture.

## What changed

- Added a conservative IntersectionObserver-based guard for muted autoplay/loop preview videos. Off-screen preview videos are paused and only videos paused by the guard are candidates to resume when visible again. Ordinary non-muted user-controlled videos are intentionally not targeted.
- Debounced media DOM rescans. Unrelated page mutations no longer trigger the full media scan; resource-timing scans are rate-limited.
- Added long-press actions for HTTP/HTTPS link, video, and image targets: open in a new tab, open in a background tab, share, copy URL, and download image/video where a usable URL is available.
- Added image MIME/extension handling and routes downloaded images to the Pictures media collection. Finished images open with a compatible image viewer where available.
- Replaced the old tab overview with an Opera-inspired card grid, `Tabs` / `Private` sections, tab search, a `Clear all` pill, close buttons on cards, captured page previews, and a bottom-right floating plus. The app's regular bottom navigation is hidden while the overview is open.
- Keeps the tab overview open when the final card is closed and avoids displaying normal history shortcuts on the private-tab home page.

## Private tab limitation

The `Private` tab section is app-level private browsing: pages opened there are not added to browser history and bookmarks. It currently shares Android WebView's cookie/session store with regular tabs and is **not** a separate incognito profile. Do not treat it as credential/session isolation.

## Validation

- JavaScript syntax checked with Node.js for both the page media sniffer and the preview-performance guard.
- Source references for media candidate types and actions checked against the project's current model.
- The archive should be checked with `zip -T` after packaging.
- A full Android/Compose build and interactive device test must still be run in Android Studio or CodeAssist with the project's Gradle wrapper regenerated and Android SDK 36 installed. This environment does not include the Android SDK or Gradle wrapper, so no successful APK build is claimed here.

## Suggested device test checklist

1. Open a long feed containing many autoplay video previews and scroll down/up repeatedly. Confirm normal playback remains available for non-muted videos and off-screen muted previews stop consuming playback resources.
2. Long-press a link, video, image and image link. Check every displayed action works with that target type.
3. Open multiple tabs, switch between them, close selected/non-selected cards, use Search and Clear all, then create a new tab with the floating plus.
4. Visit history/bookmarks and confirm pages opened in the `Private` section are not inserted there; remember that cookies are shared in this revision.
5. Re-run the previous download/HLS/Audio-Video sync smoke tests to ensure browser work did not regress the downloader.
