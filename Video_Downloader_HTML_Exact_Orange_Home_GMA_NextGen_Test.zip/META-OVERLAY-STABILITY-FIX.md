# Facebook / Instagram / Threads overlay correction

This update is scoped to the existing Meta overlay pipeline. Other websites continue to use the existing generic detection and download flow.

## Changes

- Excludes small near-square UI images (profile/comment avatars, reaction artwork and small action icons) from image Download Buttons.
- Preserves the friend-request card exception so profile images inside Add Friend / Confirm / Accept cards remain eligible.
- Prevents a Reel poster from being treated as a downloadable video. Reel poster actions resolve an associated rendered video element, matching poster URL, nearby video element, or explicit video data attribute. If the page does not expose a matching video URL, the app reports that instead of downloading the thumbnail or guessing another feed video.
- Story visuals are treated as video when a matching rendered video source is available; image stories remain image downloads.
- Maintains a WeakMap association between each media element and its own Download Button. Off-screen buttons are hidden, not removed/recreated; disconnected DOM nodes are cleaned up. A reused Reel player element therefore keeps the same button at the same action-rail position while its current media source changes.
- Hides neighbouring/previous/next large Reel surfaces when less than 62% of their area is visible, avoiding stray buttons on partially visible adjacent players.
- Aligns a large vertical Reels player button near the right-side comment/action rail.
- Re-evaluates video media after `loadedmetadata`, `emptied`, `play` and `pause` events without waiting for playback to begin.

## Validation performed

- JavaScript extracted from `PlatformMediaOverlayScript.JAVASCRIPT`: `node --check` passed.
- Changed Kotlin overlay and bridge sources: compiled with `kotlinc` using minimal Android/WebView and TikTok symbol stubs.
- Android Gradle build and live Facebook/Instagram/Threads testing were not available in this environment (no Android SDK / Gradle wrapper JAR).

## Manual device test checklist

1. Facebook feed: no buttons on Create Story (+), post author avatars, comment avatars, reactions, or small UI artwork. Post images and videos retain buttons.
2. Facebook Reels: one button on the active large Reel, aligned with the right-side comment rail; adjacent partially visible Reel cards do not show stray buttons.
3. Reels card grid: every clearly visible Reel card has its own button; tapping it must resolve the video, never its thumbnail.
4. Stories: video stories resolve to video; image stories resolve to original image.
5. Comments: avatar images have no button; actual attached photos remain downloadable.
6. Friend requests: profile images within Add Friend / Confirm / Accept cards remain eligible.
7. Repeat the same cases on Instagram and Threads.
8. Verify other sites continue to use their old detection path.
