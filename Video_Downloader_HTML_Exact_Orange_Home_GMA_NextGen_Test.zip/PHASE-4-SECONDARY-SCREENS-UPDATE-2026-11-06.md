# Phase 4 — Settings & Secondary Screens — 2026-11-06

This update builds on the Phase 3 archive and polishes secondary screens without changing the download engine or Room schema.

## Settings
- Rebuilt Settings as a consistent, theme-aware card layout with grouped Appearance, Downloads, Browser, and General sections.
- Moved the app-wide accent palette selector into Settings > Appearance. The selected palette continues to drive the app-wide Material 3 theme through the existing preference.
- Retained the Light, Normal Dark, AMOLED, and System theme choices.
- Preserved download location editing and the Storage Access Framework folder picker, including the existing requirement to select the `Video downloader` folder.
- Preserved Wi-Fi-only, gallery sync, ad blocking, search engine/custom URL, clear cache, clear cookies, clear history, and language actions.
- Added a working Settings > About & Privacy navigation entry.
- Moved recently visited and Quick Access visibility preferences into Customize Home to avoid duplicate controls.

## Customize Home
- Removed duplicate global theme and accent controls from this screen.
- Kept Home-only section visibility and background choices.
- Simplified Quick Access management to add-by-URL and remove only; website name is derived from the host and the favicon is loaded automatically.
- Removed manual rename, reorder, and restore-default controls from this settings page.

## Shared website identity, History and Bookmarks
- Added a reusable `WebsiteFavicon` component using the website host and a neutral globe fallback when no favicon loads.
- Removed emoji and gradient placeholders from History/Bookmarks rows in favor of the shared favicon treatment.
- Added search to History and Bookmarks, count summaries, improved empty states, card rows, and menu actions.
- Added add-bookmark from History, with URL de-duplication using existing DAO methods.
- Added clear-all bookmarks confirmation and retained open/share/copy/delete behavior.
- No Room schema migration was added.

## Download Details
- Reorganized details into File information, Source & storage, and Activity cards.
- Added readable byte formatting, status labels, a progress summary, timestamps, duration/segment information, and copy actions for relevant values.
- Source URL display is sanitized to omit query strings and fragments; copying still copies the actual source URL.

## Offline Player
- Removed non-functional Playlist and Discover controls and fake Equalizer/Aspect-ratio toast actions.
- Added functional Fit, Stretch-to-fill, and Zoom-to-fill display modes using Media3 `PlayerView.resizeMode`.
- Corrected Auto Rotate to use sensor orientation when enabled and restore system orientation when disabled.
- Updated the mute action label to reflect its current state.
- Kept ExoPlayer setup, decoder fallback, playback speed, seek, pause/play, lock, and lifecycle release behavior intact.

## About & Privacy
- Rebuilt the page with consistent information cards and a runtime app version label.
- Preserved usage notice and technical boundaries, while avoiding unsupported claims about source-site availability.

## Scope protection
- No downloader engine, extraction engine, browser detection scripts, download service, storage pipeline, or Room entity/schema was changed in this phase.
- `HistoryBookmarksViewModel` uses only existing DAO queries (`deleteBookmarkByUrl` and `insertBookmark`) for URL de-duplication.

## Validation
- Kotlin parser pass on the Phase 4 modified Kotlin files reported no syntax-level diagnostics. The parser was run without Android/Compose dependencies, so unresolved AndroidX references are expected in that standalone check.
- The archive is compared with Phase 3 to record the exact changed files and then ZIP integrity is checked.
- A full Android Gradle build and device/emulator rendering test cannot be performed in this environment because the project archive does not include a Gradle wrapper executable/JAR and no Android SDK/Gradle toolchain is configured.
