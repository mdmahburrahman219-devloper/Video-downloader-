package com.mahabub.downloder

import com.mahabub.downloder.model.MediaCandidate
import com.mahabub.downloder.model.PlatformSource
import com.mahabub.downloder.model.StreamType
import com.mahabub.downloder.storage.SocialMediaFileName
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SocialMediaFileNameTest {
    @Test
    fun instagramVideoUsesPlatformPrefixAndThirteenDigits() {
        val candidate = video(PlatformSource.INSTAGRAM)
        val name = SocialMediaFileName.forVideo(candidate)!!
        assertTrue(Regex("^instagram_[1-9][0-9]{12}\\.mp4$").matches(name))
    }

    @Test
    fun facebookVideoUsesFacebookPrefix() {
        val name = SocialMediaFileName.forVideo(video(PlatformSource.FACEBOOK))!!
        assertTrue(Regex("^facebook_[1-9][0-9]{12}\\.mp4$").matches(name))
    }

    @Test
    fun tiktokRetainsExistingTitleBasedName() {
        assertNull(SocialMediaFileName.forVideo(video(PlatformSource.TIKTOK)))
    }

    @Test
    fun imageCandidateKeepsExistingImageName() {
        val image = video(PlatformSource.INSTAGRAM).copy(mimeType = "image/jpeg")
        assertNull(SocialMediaFileName.forVideo(image))
    }

    @Test
    fun hlsUsesMp4OutputExtension() {
        val hls = video(PlatformSource.THREADS).copy(
            streamType = StreamType.HLS,
            mimeType = "application/vnd.apple.mpegurl"
        )
        val name = SocialMediaFileName.forVideo(hls)!!
        assertTrue(Regex("^threads_[1-9][0-9]{12}\\.mp4$").matches(name))
    }

    @Test
    fun generatedNumberIsExactlyThirteenDigits() {
        val generated = SocialMediaFileName.forVideo(video(PlatformSource.REDDIT))!!
        val digits = generated.substringAfter('_').substringBefore('.')
        assertEquals(13, digits.length)
        assertTrue(digits.all(Char::isDigit))
    }

    private fun video(platform: PlatformSource) = MediaCandidate(
        id = "test-id",
        url = "https://cdn.example/video.mp4",
        title = "A very long sample title",
        mimeType = "video/mp4",
        sourcePlatform = platform,
        streamType = StreamType.PROGRESSIVE
    )
}
