package com.mahabub.downloder

import com.mahabub.downloder.extractor.HlsPlaylistParser
import org.junit.Assert.*
import org.junit.Test

class HlsPlaylistParserAdvancedTest {
    @Test
    fun parsesQuotedMasterAttributesAndSeparateAudioRendition() {
        val master = """
            #EXTM3U
            #EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID="aud",NAME="English, Stereo",DEFAULT=YES,AUTOSELECT=YES,URI="audio/en.m3u8"
            #EXT-X-STREAM-INF:BANDWIDTH=3200000,AVERAGE-BANDWIDTH=2700000,RESOLUTION=1920x1080,CODECS="avc1.640028,mp4a.40.2",AUDIO="aud"
            video/1080.m3u8
        """.trimIndent()

        val parsed = HlsPlaylistParser.parseMaster(master, "https://media.example/live/master.m3u8")
        assertEquals(1, parsed.variants.size)
        assertEquals("1920x1080", parsed.variants.single().resolution)
        assertEquals(2700000L, parsed.variants.single().bandwidth)
        assertEquals("aud", parsed.variants.single().audioGroupId)
        assertEquals("https://media.example/live/audio/en.m3u8", parsed.audioRenditions.single().url)
        assertEquals("English, Stereo", parsed.audioRenditions.single().name)
    }

    @Test
    fun parsesByteRangesImplicitOffsetsAndMap() {
        val playlist = """
            #EXTM3U
            #EXT-X-MEDIA-SEQUENCE:40
            #EXT-X-MAP:URI="media.mp4",BYTERANGE="1000@0"
            #EXTINF:4.0,
            #EXT-X-BYTERANGE:500@1000
            media.mp4
            #EXTINF:4.0,
            #EXT-X-BYTERANGE:500
            media.mp4
            #EXT-X-ENDLIST
        """.trimIndent()
        val parsed = HlsPlaylistParser.parseMediaPlaylist(playlist, "https://media.example/vod/index.m3u8")
        assertTrue(parsed.isEndList)
        assertEquals(40L, parsed.mediaSequence)
        assertEquals(2, parsed.segments.size)
        assertEquals(1000L, parsed.segments[0].byteRange?.offset)
        assertEquals(500L, parsed.segments[0].byteRange?.length)
        assertEquals(1500L, parsed.segments[1].byteRange?.offset)
        assertEquals("https://media.example/vod/media.mp4", parsed.segments[0].initMap?.uri)
        assertEquals(1000L, parsed.segments[0].initMap?.byteRange?.offset)
        assertEquals(1000L, parsed.segments[0].initMap?.byteRange?.length)
    }

    @Test
    fun sumsVODSegmentDurationsForReliableDurationMetadata() {
        val playlist = """
            #EXTM3U
            #EXT-X-PLAYLIST-TYPE:VOD
            #EXTINF:6.006,
            seg-1.ts
            #EXTINF:6.006,
            seg-2.ts
            #EXTINF:4.250,
            seg-3.ts
            #EXT-X-ENDLIST
        """.trimIndent()

        val parsed = HlsPlaylistParser.parseMediaPlaylist(playlist, "https://media.example/vod/index.m3u8")
        assertTrue(parsed.isEndList)
        assertEquals(16.262, parsed.segments.sumOf { it.durationSeconds }, 0.001)
    }

    @Test
    fun parsesAes128IvAndMediaSequence() {
        val playlist = """
            #EXTM3U
            #EXT-X-MEDIA-SEQUENCE:9
            #EXT-X-KEY:METHOD=AES-128,URI="../keys/key.bin",IV=0x00000000000000000000000000000011
            #EXTINF:5.0,
            seg.ts
            #EXT-X-ENDLIST
        """.trimIndent()
        val parsed = HlsPlaylistParser.parseMediaPlaylist(playlist, "https://media.example/vod/index.m3u8")
        val segment = parsed.segments.single()
        assertEquals(9L, segment.sequence)
        assertEquals("AES-128", segment.key?.method)
        assertEquals("https://media.example/keys/key.bin", segment.key?.uri)
        assertEquals(16, segment.key?.iv?.size)
        assertEquals(0x11.toByte(), segment.key?.iv?.last())
    }

    @Test
    fun eventPlaylistWithoutEndListIsRecognizedAsLiveCandidate() {
        val playlist = """
            #EXTM3U
            #EXT-X-PLAYLIST-TYPE:EVENT
            #EXT-X-TARGETDURATION:6
            #EXTINF:6.0,
            seg-1.ts
        """.trimIndent()
        val parsed = HlsPlaylistParser.parseMediaPlaylist(playlist, "https://media.example/event/index.m3u8")
        assertFalse(parsed.isEndList)
        assertEquals("EVENT", parsed.playlistType)
        assertEquals(6.0, parsed.targetDurationSeconds, 0.01)
        assertEquals(1, parsed.segments.size)
    }

    @Test
    fun sequenceIvUsesUnsignedSequenceInLastEightBytes() {
        val iv = HlsPlaylistParser.sequenceIv(257)
        assertEquals(16, iv.size)
        assertEquals(0.toByte(), iv[0])
        assertEquals(1.toByte(), iv[14])
        assertEquals(1.toByte(), iv[15])
    }
}
