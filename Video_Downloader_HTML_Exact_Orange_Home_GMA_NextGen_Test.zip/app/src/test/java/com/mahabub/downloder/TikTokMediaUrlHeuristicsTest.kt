package com.mahabub.downloder

import com.mahabub.downloder.browser.TikTokMediaUrlHeuristics
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TikTokMediaUrlHeuristicsTest {
    @Test
    fun recognizesExtensionlessTikTokVideoCdnUrl() {
        assertTrue(
            TikTokMediaUrlHeuristics.isLikelyVideoResource(
                "https://v16-webapp-prime.tiktok.com/video/tos/useast2a/tos-useast2a-ve-0068/abc/?a=1&mime_type=video_mp4&x-expires=999999"
            )
        )
    }

    @Test
    fun recognizesObjTosExtensionlessVideoResource() {
        assertTrue(
            TikTokMediaUrlHeuristics.isLikelyVideoResource(
                "https://v16.byteoversea.com/obj/tos-useast2a/opaque-resource?mime_type=video_mp4&video_id=123456"
            )
        )
    }

    @Test
    fun recognizesExplicitVideoMimeOnByteDanceCdn() {
        assertTrue(
            TikTokMediaUrlHeuristics.isLikelyVideoResource(
                "https://v16m-default.akamaized.net/opaque/signed-resource?mime_type=video_mp4&video_id=123456"
            )
        )
    }

    @Test
    fun recognizesTikTokMediaVideoHvc1UrlWithSignedQuery() {
        assertTrue(
            TikTokMediaUrlHeuristics.isLikelyVideoResource(
                "https://v19-webapp-prime.us.tiktok.com/video/tos/useast2a/tos-useast2a-v-0037/file/media-video-hvc1/?a=1988&bt=1530&mime_type=video_mp4&expire=1786145694&signature=abc"
            )
        )
    }

    @Test
    fun ignoresTikTokImageAndSegmentResources() {
        assertFalse(
            TikTokMediaUrlHeuristics.isLikelyVideoResource(
                "https://p16-sign-va.tiktokcdn.com/tos-maliva-p-0068/cover.webp?a=1"
            )
        )
        assertFalse(
            TikTokMediaUrlHeuristics.isLikelyVideoResource(
                "https://v16-webapp-prime.tiktok.com/video/tos/useast2a/segment-001.ts?mime_type=video_mp4"
            )
        )
    }

    @Test
    fun ignoresOrdinaryTikTokPageAndUnrelatedHost() {
        assertFalse(TikTokMediaUrlHeuristics.isLikelyVideoResource("https://www.tiktok.com/@creator/video/123456"))
        assertFalse(TikTokMediaUrlHeuristics.isLikelyVideoResource("https://example.com/video/tos/file?mime_type=video_mp4"))
        assertFalse(TikTokMediaUrlHeuristics.isLikelyVideoResource("https://tiktokcdn.evil.com/video/tos/file?mime_type=video_mp4"))
        assertFalse(TikTokMediaUrlHeuristics.isLikelyVideoResource("not-a-url"))
    }
}
