package com.mahabub.downloder

import com.mahabub.downloder.model.MediaCandidate
import com.mahabub.downloder.model.MediaCandidateGrouping
import com.mahabub.downloder.model.MediaSelectionRouting
import com.mahabub.downloder.model.MediaVideoGroup
import com.mahabub.downloder.model.StreamType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class MediaSelectionRoutingTest {
    private fun group(id: String, vararg qualities: String): MediaVideoGroup {
        val candidates = qualities.mapIndexed { index, quality ->
            val height = quality.removeSuffix("p").toIntOrNull() ?: 480
            MediaCandidate(
                id = "$id-$index",
                url = "https://cdn.example.test/$id-$quality.m3u8",
                title = id,
                mimeType = "application/vnd.apple.mpegurl",
                sourcePageUrl = "https://site.example.test/watch/123",
                streamType = StreamType.HLS,
                qualityLabel = quality,
                resolution = "1920x$height",
                videoGroupId = id
            )
        }
        val grouped = MediaCandidateGrouping.group(candidates).single()
        return grouped.copy(id = id, title = id)
    }

    @Test
    fun multipleVideoGroupsWithOneResolutionEachShowTheDetectedList() {
        val groups = listOf(group("first", "720p"), group("second", "480p"))
        assertTrue(MediaSelectionRouting.shouldShowDetectedList(groups))
    }

    @Test
    fun ifAnyVideoGroupHasMultipleResolutionsOpenQualityPopupDirectly() {
        val groups = listOf(group("first", "720p", "480p"), group("second", "360p"))
        assertFalse(MediaSelectionRouting.shouldShowDetectedList(groups))
    }

    @Test
    fun aSingleVideoOpensDirectlyEvenWithOneResolution() {
        assertFalse(MediaSelectionRouting.shouldShowDetectedList(listOf(group("only", "720p"))))
    }

    @Test
    fun preferredGroupIsTheOneWithTheMostDistinctQualityOptions() {
        val oneQuality = group("one", "720p")
        val threeQualities = group("three", "1080p", "720p", "480p")
        assertEquals("three", MediaSelectionRouting.preferredGroup(listOf(oneQuality, threeQualities))?.title)
    }
}
