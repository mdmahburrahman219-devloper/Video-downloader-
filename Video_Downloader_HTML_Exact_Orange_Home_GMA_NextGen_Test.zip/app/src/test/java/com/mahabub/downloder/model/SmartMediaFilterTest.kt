package com.mahabub.downloder.model

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SmartMediaFilterTest {
    private val page = "https://example.test/watch"

    private fun candidate(
        id: String,
        groupId: String,
        quality: String,
        duration: Double? = 600.0,
        size: Long? = 24L * 1024L * 1024L,
        pageUrl: String = page,
        platform: PlatformSource = PlatformSource.GENERIC_WEB
    ) = MediaCandidate(
        id = id,
        url = "https://cdn.example.test/$id.m3u8",
        title = "Test video",
        mimeType = "application/vnd.apple.mpegurl",
        sourcePageUrl = pageUrl,
        sourcePlatform = platform,
        streamType = StreamType.HLS,
        isDirectDownload = false,
        durationSeconds = duration,
        thumbnailUrl = "https://cdn.example.test/poster.jpg",
        resolution = quality.removeSuffix("p").let { "1920x$it" },
        videoGroupId = groupId,
        qualityLabel = quality,
        estimatedSizeBytes = size,
        sizeIsEstimated = true
    )

    @Test
    fun `filters low resolutions but preserves 144p and 180p`() {
        val options = listOf("100p", "144p", "180p", "240p").mapIndexed { index, label ->
            candidate("q$index", "main-player", label, size = (20L + index) * 1024L * 1024L)
        }

        val result = SmartMediaFilter.apply(options, page)
        val visibleLabels = result.visibleGroups.single().candidates.map { MediaCandidateGrouping.qualityLabel(it) }.toSet()

        assertEquals(setOf("144p", "180p", "240p"), visibleLabels)
        assertTrue(result.filteredItems.any { item -> item.candidates.any { it.qualityLabel == "100p" } })
    }

    @Test
    fun `filters short and small logical videos only when multiple groups exist`() {
        val shortSmall = candidate("small", "short-player", "720p", duration = 150.0, size = 8L * 1024L * 1024L)
        val longLarge = candidate("large", "long-player", "720p", duration = 600.0, size = 80L * 1024L * 1024L)

        val result = SmartMediaFilter.apply(listOf(shortSmall, longLarge), page)

        assertEquals(listOf("large"), result.visibleGroups.flatMap { it.candidates }.map { it.id })
        val excluded = result.filteredItems.first { it.candidates.any { candidate -> candidate.id == "small" } }
        assertTrue(excluded.reasons.any { it.contains("Duration under 3 minutes") })
        assertTrue(excluded.reasons.any { it.contains("File size below 12 MB") })
    }

    @Test
    fun `most quality options wins and other group remains reviewable`() {
        val mainOptions = listOf("1080p", "720p", "480p", "360p", "240p").mapIndexed { index, label ->
            candidate("main$index", "main-player", label, size = (30L + index) * 1024L * 1024L)
        }
        val alternative = candidate("alternative", "alternative-player", "720p", size = 40L * 1024L * 1024L)

        val result = SmartMediaFilter.apply(mainOptions + alternative, page)

        assertEquals(1, result.visibleGroups.size)
        assertEquals(5, result.visibleGroups.single().candidates.size)
        assertTrue(result.filteredItems.any { item -> item.candidates.any { it.id == "alternative" } })
    }

    @Test
    fun `social media bypasses every smart filter`() {
        val social = candidate(
            id = "social-short-small-100p",
            groupId = "instagram-player",
            quality = "100p",
            duration = 20.0,
            size = 1L * 1024L * 1024L,
            pageUrl = "https://www.instagram.com/reel/example/",
            platform = PlatformSource.INSTAGRAM
        )

        val result = SmartMediaFilter.apply(listOf(social), "https://www.instagram.com/reel/example/")

        assertTrue(result.isSocialMediaBypass)
        assertEquals(1, result.visibleGroups.single().candidates.size)
        assertTrue(result.filteredItems.isEmpty())
    }
    @Test
    fun `filters raw 100p label even when no actual dimensions were returned`() {
        val suspicious = candidate("raw100", "player", "240p", duration = 420.0, size = 40L * 1024L * 1024L).copy(
            url = "https://cdn.example.test/100p.m3u8",
            resolution = null,
            qualityLabel = "100p"
        )
        val normal = candidate("normal240", "player", "240p", duration = 420.0, size = 40L * 1024L * 1024L)
        val result = SmartMediaFilter.apply(listOf(suspicious, normal), page)
        assertTrue(result.filteredItems.any { item -> item.candidates.any { it.id == "raw100" } })
        assertTrue(result.visibleGroups.flatMap { it.candidates }.none { it.id == "raw100" })
    }

    @Test
    fun `social domain URL bypasses filters even when platform is generic`() {
        val social = candidate(
            id = "x-small-100p",
            groupId = "x-player",
            quality = "100p",
            duration = 45.0,
            size = 1L * 1024L * 1024L,
            pageUrl = "https://x.com/example/status/123",
            platform = PlatformSource.GENERIC_WEB
        )
        val result = SmartMediaFilter.apply(listOf(social), "https://x.com/example/status/123")
        assertTrue(result.isSocialMediaBypass)
        assertTrue(result.filteredItems.isEmpty())
    }

    @Test
    fun `keeps the requested 144p and 180p exceptions visible as quality labels`() {
        val options = listOf("144p", "180p", "240p").mapIndexed { index, label ->
            candidate("exception$index", "main-player", label, duration = 420.0, size = 40L * 1024L * 1024L).copy(resolution = null)
        }
        val result = SmartMediaFilter.apply(options, page)
        val labels = result.visibleGroups.single().candidates.map { MediaCandidateGrouping.qualityLabel(it) }.toSet()
        assertTrue("180p should remain a visible label", "180p" in labels)
        assertTrue("144p should remain a visible label", "144p" in labels)
        assertTrue("240p should remain a visible label", "240p" in labels)
    }

    @Test
    fun `source filename quality beats active player dimensions for alternate variants`() {
        val false1080Label = candidate("variant100", "shared-player", "1080p", duration = 420.0, size = 40L * 1024L * 1024L).copy(
            url = "https://cdn.example.test/100p.m3u8",
            resolution = "1920x1080",
            qualityLabel = "1080p"
        )
        val real240 = candidate("variant240", "shared-player", "240p", duration = 420.0, size = 40L * 1024L * 1024L).copy(
            url = "https://cdn.example.test/240p.m3u8",
            resolution = "1920x1080",
            qualityLabel = "1080p"
        )

        assertEquals("100p", MediaCandidateGrouping.qualityLabel(false1080Label))
        assertEquals("240p", MediaCandidateGrouping.qualityLabel(real240))

        val result = SmartMediaFilter.apply(listOf(false1080Label, real240), page)
        assertTrue(result.filteredItems.any { item -> item.candidates.any { it.id == "variant100" } })
        assertTrue(result.visibleGroups.flatMap { it.candidates }.none { it.id == "variant100" })
        assertTrue(result.visibleGroups.flatMap { it.candidates }.any { it.id == "variant240" })
    }

    @Test
    fun `filename dimensions beat active player dimensions`() {
        val candidate = candidate("res480", "shared-player", "1080p").copy(
            url = "https://cdn.example.test/850x480.mp4.m3u8",
            resolution = "1920x1080",
            qualityLabel = "1080p"
        )
        assertEquals("480p", MediaCandidateGrouping.qualityLabel(candidate))
    }

}
