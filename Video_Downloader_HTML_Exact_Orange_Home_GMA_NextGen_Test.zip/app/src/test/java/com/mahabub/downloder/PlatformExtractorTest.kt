package com.mahabub.downloder

import com.mahabub.downloder.extractor.ExtractorUtils
import com.mahabub.downloder.extractor.FacebookExtractor
import com.mahabub.downloder.extractor.InstagramExtractor
import com.mahabub.downloder.extractor.PinterestExtractor
import com.mahabub.downloder.extractor.RedditExtractor
import com.mahabub.downloder.extractor.TwitterXExtractor
import com.mahabub.downloder.extractor.ThreadsExtractor
import okhttp3.OkHttpClient
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PlatformExtractorTest {

    private val client = OkHttpClient()

    @Test
    fun testPlatformMatches_Instagram() {
        val extractor = InstagramExtractor(client)
        assertTrue(extractor.matches("https://www.instagram.com/reel/C12345/"))
        assertTrue(extractor.matches("https://instagram.com/p/B98765/"))
        assertTrue(extractor.matches("https://www.instagram.com/stories/user/123/"))
        assertTrue(extractor.matches("https://www.instagram.com/share/reel/ABC123/"))
        assertFalse(extractor.matches("https://instagram.com/explore/"))
        assertFalse(extractor.matches("https://instagram.com/accounts/login/"))
        assertFalse(extractor.matches("ftp://instagram.com/reel/C12345/"))
        assertFalse(extractor.matches("https://example.com/instagram.com/"))
    }

    @Test
    fun testPlatformMatches_ThreadsComAndLegacyNet() {
        val extractor = ThreadsExtractor(client)
        assertTrue(extractor.matches("https://www.threads.com/@user/post/abc"))
        assertTrue(extractor.matches("https://www.threads.net/@user/post/abc"))
        assertFalse(extractor.matches("https://example.com/threads.com/post/abc"))
    }

    @Test
    fun testPlatformMatches_TwitterX() {
        val extractor = TwitterXExtractor(client)
        assertTrue(extractor.matches("https://twitter.com/user/status/123456"))
        assertTrue(extractor.matches("https://x.com/user/status/789012"))
        assertFalse(extractor.matches("https://threads.net/"))
    }

    @Test
    fun testExtractMetaTag_parsesOpenGraph() {
        val sampleHtml = """
            <!DOCTYPE html>
            <html>
            <head>
                <meta property="og:title" content="Amazing Vacation Video" />
                <meta property="og:video" content="https://cdn.example.com/video.mp4" />
                <meta property="og:image" content="https://cdn.example.com/thumb.jpg" />
            </head>
            <body></body>
            </html>
        """.trimIndent()

        val title = ExtractorUtils.extractTitle(sampleHtml)
        val videoUrl = ExtractorUtils.extractMetaTag(sampleHtml, "og:video")
        val image = ExtractorUtils.extractMetaTag(sampleHtml, "og:image")

        assertEquals("Amazing Vacation Video", title)
        assertEquals("https://cdn.example.com/video.mp4", videoUrl)
        assertEquals("https://cdn.example.com/thumb.jpg", image)
    }
}
