package com.mahabub.downloder.extractor

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class FacebookDashVariantParserTest {
    @Test
    fun createsSelectableRepresentationsAndRetainsAudio() {
        val mpd = """
            <MPD xmlns="urn:mpeg:dash:schema:mpd:2011" type="static" mediaPresentationDuration="PT12S">
              <Period duration="PT12S">
                <AdaptationSet id="video" contentType="video" mimeType="video/mp4">
                  <SegmentTemplate timescale="1000" initialization="init-\$RepresentationID\$.m4s" media="v-\$RepresentationID\$-\$Number\$.m4s" duration="4000" startNumber="1"/>
                  <Representation id="v480" bandwidth="320000" width="854" height="480" codecs="avc1.4d401e"/>
                  <Representation id="v720" bandwidth="800000" width="1280" height="720" codecs="avc1.4d401f"/>
                </AdaptationSet>
                <AdaptationSet id="audio" contentType="audio" mimeType="audio/mp4">
                  <SegmentTemplate timescale="1000" initialization="a-init.m4s" media="a-\$Number\$.m4s" duration="4000" startNumber="1"/>
                  <Representation id="a128" bandwidth="128000" codecs="mp4a.40.2"/>
                </AdaptationSet>
              </Period>
            </MPD>
        """.trimIndent()

        val variants = FacebookDashVariantParser.createVariants(mpd, 12.0)

        assertEquals(listOf("480p", "720p"), variants.map { it.qualityLabel })
        variants.forEach { variant ->
            assertTrue(variant.manifestText.contains("id=\"a128\""))
            val videoIds = listOf("v480", "v720").filter { id ->
                variant.manifestText.contains("id=\"$id\"")
            }
            assertEquals(1, videoIds.size)
            assertNotNull(variant.estimatedSizeBytes)
            assertTrue(variant.estimatedSizeBytes!! > 0L)
        }
    }

    @Test
    fun rejectsDrmManifest() {
        val drm = """
            <MPD xmlns="urn:mpeg:dash:schema:mpd:2011"><Period>
              <AdaptationSet contentType="video" mimeType="video/mp4">
                <ContentProtection schemeIdUri="urn:uuid:test"/>
                <Representation id="v720" bandwidth="800000" width="1280" height="720"/>
              </AdaptationSet>
            </Period></MPD>
        """.trimIndent()
        assertTrue(FacebookDashVariantParser.createVariants(drm, 12.0).isEmpty())
    }
}
