package com.mahabub.downloder

import com.mahabub.downloder.db.DownloadEntity
import com.mahabub.downloder.model.DownloadStatus
import com.mahabub.downloder.model.PlatformSource
import com.mahabub.downloder.model.StreamType
import org.junit.Assert.assertEquals
import org.junit.Test

class DownloadStateTransitionTest {

    @Test
    fun testProgressCalculation_progressive() {
        val entity = DownloadEntity(
            id = "test-1",
            sourceUrl = "https://example.com/video.mp4",
            sourcePageUrl = "https://example.com",
            sourcePlatform = PlatformSource.DIRECT,
            streamType = StreamType.PROGRESSIVE,
            fileName = "video.mp4",
            mimeType = "video/mp4",
            totalBytes = 1000L,
            downloadedBytes = 500L,
            status = DownloadStatus.DOWNLOADING
        )

        assertEquals(0.5f, entity.progressFraction, 0.001f)
        assertEquals(50, entity.progressPercent)
    }

    @Test
    fun testProgressCalculation_hlsSegments() {
        val entity = DownloadEntity(
            id = "test-2",
            sourceUrl = "https://example.com/stream.m3u8",
            sourcePageUrl = "https://example.com",
            sourcePlatform = PlatformSource.GENERIC_WEB,
            streamType = StreamType.HLS,
            fileName = "stream.mp4",
            mimeType = "video/mp4",
            totalSegments = 20,
            completedSegments = 15,
            status = DownloadStatus.DOWNLOADING
        )

        assertEquals(0.75f, entity.progressFraction, 0.001f)
        assertEquals(75, entity.progressPercent)
    }

    @Test
    fun testProgressPercent_clampedBetween0And100() {
        val entityOverflow = DownloadEntity(
            id = "test-3",
            sourceUrl = "https://example.com/video.mp4",
            sourcePageUrl = null,
            sourcePlatform = PlatformSource.DIRECT,
            streamType = StreamType.PROGRESSIVE,
            fileName = "video.mp4",
            mimeType = "video/mp4",
            totalBytes = 100L,
            downloadedBytes = 150L,
            status = DownloadStatus.COMPLETED
        )

        assertEquals(100, entityOverflow.progressPercent)
    }
}
