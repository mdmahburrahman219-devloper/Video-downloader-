package com.mahabub.downloder

import com.mahabub.downloder.extractor.HlsPlaylistParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class HlsPlaylistParserTest {
    @Test
    fun parsesResolutionsAndResolvesRelativeVariantUrls() {
        val master = """
            #EXTM3U
            #EXT-X-VERSION:3
            #EXT-X-STREAM-INF:BANDWIDTH=2500000,RESOLUTION=1280x720
            hls-720p-a1.m3u8
            #EXT-X-STREAM-INF:BANDWIDTH=900000,RESOLUTION=640x360
            /streams/hls-360p-b2.m3u8
        """.trimIndent()

        val variants = HlsPlaylistParser.parseMasterPlaylist(master, "https://cdn.example/video/master.m3u8")

        assertEquals(2, variants.size)
        assertEquals("1280x720", variants[0].resolution)
        assertEquals("https://cdn.example/video/hls-720p-a1.m3u8", variants[0].url)
        assertEquals("https://cdn.example/streams/hls-360p-b2.m3u8", variants[1].url)
    }

    @Test
    fun mediaPlaylistIsNotTreatedAsAQualityList() {
        val media = """
            #EXTM3U
            #EXTINF:5.0,
            segment001.ts
            #EXTINF:5.0,
            segment002.ts
            #EXT-X-ENDLIST
        """.trimIndent()

        assertTrue(HlsPlaylistParser.parseMasterPlaylist(media, "https://cdn.example/media.m3u8").isEmpty())
    }
}
