package com.mahabub.downloder

import com.mahabub.downloder.browser.PlatformMediaOverlayScript
import com.mahabub.downloder.model.PlatformSource
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PlatformMediaOverlayScriptTest {

    @Test
    fun recognizesOnlySupportedMetaPageHosts() {
        assertEquals(PlatformSource.FACEBOOK, PlatformMediaOverlayScript.platformForUrl("https://m.facebook.com/watch/?v=123"))
        assertEquals(PlatformSource.INSTAGRAM, PlatformMediaOverlayScript.platformForUrl("https://www.instagram.com/stories/user/123/"))
        assertEquals(PlatformSource.THREADS, PlatformMediaOverlayScript.platformForUrl("https://www.threads.com/@user/post/abc"))
        assertEquals(PlatformSource.THREADS, PlatformMediaOverlayScript.platformForUrl("https://www.threads.net/@user/post/abc"))
        assertEquals(null, PlatformMediaOverlayScript.platformForUrl("https://example.com/facebook.com/video.mp4"))
        assertEquals(null, PlatformMediaOverlayScript.platformForUrl("javascript:alert(1)"))
    }

    @Test
    fun identifiesSinglePostLinksWithoutMatchingHomeFeeds() {
        assertTrue(PlatformMediaOverlayScript.isSingleMediaPostUrl("https://www.facebook.com/reel/123"))
        assertTrue(PlatformMediaOverlayScript.isSingleMediaPostUrl("https://www.instagram.com/p/abc/"))
        assertTrue(PlatformMediaOverlayScript.isSingleMediaPostUrl("https://www.threads.com/@user/post/abc"))
        assertFalse(PlatformMediaOverlayScript.isSingleMediaPostUrl("https://www.facebook.com/"))
        assertFalse(PlatformMediaOverlayScript.isSingleMediaPostUrl("https://www.instagram.com/explore/"))
    }

    @Test
    fun limitsOverlayActionsToKnownPlatformMediaHosts() {
        assertTrue(PlatformMediaOverlayScript.isAllowedMediaUrl(PlatformSource.FACEBOOK, "https://scontent.xx.fbcdn.net/media.jpg"))
        assertTrue(PlatformMediaOverlayScript.isAllowedMediaUrl(PlatformSource.INSTAGRAM, "https://cdninstagram.com/media.webp"))
        assertTrue(PlatformMediaOverlayScript.isAllowedMediaUrl(PlatformSource.THREADS, "https://scontent.xx.fbcdn.net/media.mp4"))
        assertFalse(PlatformMediaOverlayScript.isAllowedMediaUrl(PlatformSource.FACEBOOK, "https://evil.example/media.mp4"))
        assertFalse(PlatformMediaOverlayScript.isAllowedMediaUrl(PlatformSource.INSTAGRAM, "javascript:alert(1)"))
    }
    @Test
    fun platformOverlayFiltersUiAvatarsAndKeepsElementButtonIdentity() {
        assertTrue(PlatformMediaOverlayScript.JAVASCRIPT.contains("function isExcludedUiImage"))
        assertTrue(PlatformMediaOverlayScript.JAVASCRIPT.contains("isFriendRequestCard"))
        assertTrue(PlatformMediaOverlayScript.JAVASCRIPT.contains("button.hidden = true"))
        assertTrue(PlatformMediaOverlayScript.JAVASCRIPT.contains("var MAX_BUTTONS = 500"))
    }

    @Test
    fun reelAndStoryPosterActionsDoNotDownloadThePosterAsVideo() {
        assertTrue(PlatformMediaOverlayScript.JAVASCRIPT.contains("function getVideoUrlForVisual"))
        assertTrue(PlatformMediaOverlayScript.JAVASCRIPT.contains("posterTarget"))
        assertTrue(PlatformMediaOverlayScript.JAVASCRIPT.contains("visibleRatio < 0.62"))
    }

}
