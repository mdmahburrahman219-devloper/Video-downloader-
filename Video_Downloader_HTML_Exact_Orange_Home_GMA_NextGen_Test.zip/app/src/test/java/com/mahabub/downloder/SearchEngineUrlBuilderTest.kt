package com.mahabub.downloder

import com.mahabub.downloder.browser.SearchEngineUrlBuilder
import org.junit.Assert.assertEquals
import org.junit.Test

class SearchEngineUrlBuilderTest {
    @Test
    fun eachConfiguredEngineBuildsItsOwnSearchUrl() {
        val query = "hello world"
        val expected = mapOf(
            "Google" to "https://www.google.com/search?q=hello+world",
            "Ask" to "https://www.ask.com/web?q=hello+world",
            "Bing" to "https://www.bing.com/search?q=hello+world",
            "Yahoo" to "https://search.yahoo.com/search?p=hello+world",
            "StartPage" to "https://www.startpage.com/sp/search?query=hello+world",
            "StartPage (Mobile)" to "https://www.startpage.com/do/m/mobilesearch?query=hello+world",
            "DuckDuckGo (Privacy)" to "https://duckduckgo.com/?q=hello+world",
            "DuckDuckGo Lite (Privacy)" to "https://lite.duckduckgo.com/lite/?q=hello+world",
            "Baidu (Chinese)" to "https://www.baidu.com/s?wd=hello+world",
            "Yandex (Russian)" to "https://yandex.com/search/?text=hello+world"
        )
        expected.forEach { (engine, url) ->
            assertEquals(engine, url, SearchEngineUrlBuilder.build(query, engine))
        }
    }

    @Test
    fun customTemplateUsesEncodedQuery() {
        assertEquals(
            "https://example.org/search?q=video+download",
            SearchEngineUrlBuilder.build("video download", "Custom URL", "https://example.org/search?q=%s")
        )
    }

    @Test
    fun invalidCustomTemplateFallsBackToGoogle() {
        assertEquals(
            "https://www.google.com/search?q=test",
            SearchEngineUrlBuilder.build("test", "Custom URL", "javascript:alert(%s)")
        )
    }
}
