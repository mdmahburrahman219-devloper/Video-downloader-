package com.mahabub.downloder

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.net.URI

class HlsParsingTest {

    @Test
    fun testEncryptionDetection_detectsExtXKey() {
        val encryptedPlaylist = """
            #EXTM3U
            #EXT-X-VERSION:3
            #EXT-X-KEY:METHOD=AES-128,URI="https://example.com/key.bin"
            #EXTINF:10.0,
            segment_01.ts
        """.trimIndent()

        var isEncrypted = false
        for (line in encryptedPlaylist.lines()) {
            if (line.startsWith("#EXT-X-KEY") && !line.contains("METHOD=NONE")) {
                isEncrypted = true
                break
            }
        }
        assertTrue(isEncrypted)
    }

    @Test
    fun testEncryptionDetection_allowsMethodNone() {
        val clearPlaylist = """
            #EXTM3U
            #EXT-X-VERSION:3
            #EXT-X-KEY:METHOD=NONE
            #EXTINF:10.0,
            segment_01.ts
        """.trimIndent()

        var isEncrypted = false
        for (line in clearPlaylist.lines()) {
            if (line.startsWith("#EXT-X-KEY") && !line.contains("METHOD=NONE")) {
                isEncrypted = true
                break
            }
        }
        assertFalse(isEncrypted)
    }

    @Test
    fun testRelativeUrlResolution() {
        val baseUrl = "https://cdn.example.com/videos/stream/playlist.m3u8"
        val relative = "segments/seg_001.ts"
        val resolved = URI(baseUrl).resolve(relative).toString()
        assertEquals("https://cdn.example.com/videos/stream/segments/seg_001.ts", resolved)

        val rootRelative = "/root/seg_002.ts"
        val resolvedRoot = URI(baseUrl).resolve(rootRelative).toString()
        assertEquals("https://cdn.example.com/root/seg_002.ts", resolvedRoot)
    }

    @Test
    fun testSegmentExtinfDurationParsing() {
        val playlist = """
            #EXTM3U
            #EXT-X-TARGETDURATION:10
            #EXTINF:9.009,
            seg1.ts
            #EXTINF:8.500,
            seg2.ts
        """.trimIndent()

        val segments = mutableListOf<Double>()
        for (line in playlist.lines()) {
            if (line.startsWith("#EXTINF:")) {
                val dur = line.substringAfter(":").substringBefore(",").trim().toDoubleOrNull() ?: 0.0
                segments.add(dur)
            }
        }

        assertEquals(2, segments.size)
        assertEquals(9.009, segments[0], 0.001)
        assertEquals(8.500, segments[1], 0.001)
    }
}
