package com.mahabub.downloder

import com.mahabub.downloder.storage.SafeFileName
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SafeFileNameTest {

    @Test
    fun testFilenameSanitization_removesIllegalCharacters() {
        val raw = "My Video: Episode 1? *<cool>|.mp4"
        val sanitized = SafeFileName.sanitize(raw, "mp4")
        assertFalse(sanitized.contains(":"))
        assertFalse(sanitized.contains("?"))
        assertFalse(sanitized.contains("<"))
        assertFalse(sanitized.contains(">"))
        assertFalse(sanitized.contains("|"))
        assertTrue(sanitized.endsWith(".mp4"))
    }

    @Test
    fun testFilenameSanitization_removesPathTraversal() {
        val dangerous = "../../../etc/passwd.mp4"
        val sanitized = SafeFileName.sanitize(dangerous, "mp4")
        assertFalse(sanitized.contains(".."))
        assertFalse(sanitized.contains("/"))
    }

    @Test
    fun testExtensionFromMime_recognizesTypes() {
        assertEquals("mp4", SafeFileName.getExtensionFromMime("video/mp4"))
        assertEquals("webm", SafeFileName.getExtensionFromMime("video/webm"))
        assertEquals("mp3", SafeFileName.getExtensionFromMime("audio/mpeg"))
        assertEquals("m4a", SafeFileName.getExtensionFromMime("audio/mp4"))
        assertEquals("mp4", SafeFileName.getExtensionFromMime("application/vnd.apple.mpegurl"))
    }

    @Test
    fun testEmptyFilename_generatesFallback() {
        val sanitized = SafeFileName.sanitize("", "mp4")
        assertTrue(sanitized.startsWith("video_"))
        assertTrue(sanitized.endsWith(".mp4"))
    }

    @Test
    fun longJapaneseFilenameIsLimitedByUtf8Bytes() {
        val sanitized = SafeFileName.sanitize("「クレヨンしんちゃん」".repeat(40) + ".mp4", "mp4")
        val base = sanitized.substringBeforeLast('.')
        assertTrue(base.toByteArray(Charsets.UTF_8).size <= 120)
        assertTrue(sanitized.endsWith(".mp4"))
    }

    @Test
    fun filenameDoesNotSplitEmojiSurrogatePairs() {
        val sanitized = SafeFileName.sanitize("🎬".repeat(80) + ".mp4", "mp4")
        assertTrue(sanitized.endsWith(".mp4"))
        assertFalse(sanitized.contains("\uFFFD"))
        assertTrue(sanitized.substringBeforeLast('.').toByteArray(Charsets.UTF_8).size <= 120)
    }

}
