package com.mahabub.downloder.extractor

import com.mahabub.downloder.model.PlatformSource
import com.mahabub.downloder.model.StreamType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class InstagramMediaParserTest {

    @Test
    fun prefersDirectMp4OverHigherRankedHlsAndIgnoresDash() {
        val html = """
            <!doctype html><html><head>
              <meta property="og:title" content="Sample Reel" />
              <meta property="og:video" content="https://scontent.cdninstagram.com/v/t50/clip.m3u8?token=abc" />
            </head><body>
              <script type="application/json">
                {"video_dash_manifest":"https://scontent.cdninstagram.com/v/t50/clip.mpd?token=abc",
                 "video_versions":[{"type":101,"url":"https://scontent.cdninstagram.com/v/t50/clip.mp4?token=abc"}]}
              </script>
            </body></html>
        """.trimIndent()

        val candidate = MetaMediaPageParser.extract(
            html = html,
            pageUrl = "https://www.instagram.com/reel/ABC123/",
            platform = PlatformSource.INSTAGRAM
        )

        assertEquals("https://scontent.cdninstagram.com/v/t50/clip.mp4?token=abc", candidate?.url)
        assertEquals(StreamType.PROGRESSIVE, candidate?.streamType)
    }

    @Test
    fun ignoresDashOnlyPageWhenDashIsPaused() {
        val html = """
            <!doctype html><html><head><meta property="og:title" content="Sample Reel" /></head>
            <body><script type="application/json">
              {"video_dash_manifest":"https://scontent.cdninstagram.com/v/t50/clip.mpd?token=abc"}
            </script></body></html>
        """.trimIndent()

        val candidate = MetaMediaPageParser.extract(
            html = html,
            pageUrl = "https://www.instagram.com/reel/ABC123/",
            platform = PlatformSource.INSTAGRAM
        )

        assertNull(candidate)
    }

    @Test
    fun selectsHlsWhenNoProgressiveStreamIsPresent() {
        val html = """
            <!doctype html><html><head>
              <meta property="og:video" content="https://scontent.cdninstagram.com/v/t50/clip.m3u8?token=abc" />
            </head></html>
        """.trimIndent()

        val candidate = MetaMediaPageParser.extract(
            html = html,
            pageUrl = "https://www.instagram.com/reel/ABC123/",
            platform = PlatformSource.INSTAGRAM
        )

        assertEquals(StreamType.HLS, candidate?.streamType)
    }

    @Test
    fun rejectsUnrelatedHostForInstagramMediaCandidate() {
        val html = """
            <!doctype html><html><head>
              <meta property="og:video" content="https://unrelated.example/video.mp4" />
            </head></html>
        """.trimIndent()

        val candidate = MetaMediaPageParser.extract(
            html = html,
            pageUrl = "https://www.instagram.com/reel/ABC123/",
            platform = PlatformSource.INSTAGRAM
        )

        assertNull(candidate)
    }

    @Test
    fun candidateKeepsSourcePlatformAndReferer() {
        val html = """
            <!doctype html><html><head>
              <meta property="og:video" content="https://scontent.cdninstagram.com/v/t50/clip.mp4?token=abc" />
            </head></html>
        """.trimIndent()

        val pageUrl = "https://www.instagram.com/p/ABC123/"
        val candidate = MetaMediaPageParser.extract(html, pageUrl, PlatformSource.INSTAGRAM)

        assertEquals(PlatformSource.INSTAGRAM, candidate?.sourcePlatform)
        assertEquals(pageUrl, candidate?.referer)
        assertTrue(candidate?.isDirectDownload == true)
    }
}
