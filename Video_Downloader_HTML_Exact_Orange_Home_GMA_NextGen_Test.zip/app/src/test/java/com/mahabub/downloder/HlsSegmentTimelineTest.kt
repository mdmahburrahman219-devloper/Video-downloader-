package com.mahabub.downloder

import com.mahabub.downloder.downloader.HlsSegmentTimeline
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class HlsSegmentTimelineTest {
    @Test
    fun `restarted segment PTS maps to cumulative playlist time without duration inflation`() {
        val segmentCount = 204 // 34 minutes at ten seconds per segment
        val segmentDurationUs = 10_000_000L
        val frameStepUs = 40_000L
        var lastWrittenUs: Long? = null

        repeat(segmentCount) { segmentIndex ->
            // Each segment deliberately begins at a different raw PTS clock, as broken TS streams do.
            val rawBaseUs = if (segmentIndex % 2 == 0) 3_600_000_000L else 0L
            var frame = 0L
            while (frame < segmentDurationUs) {
                val normalized = HlsSegmentTimeline.normalize(
                    segmentTimelineStartUs = segmentIndex * segmentDurationUs,
                    rawSampleTimeUs = rawBaseUs + frame,
                    firstSampleTimeUs = rawBaseUs
                )
                if (!HlsSegmentTimeline.overlapsPreviousSample(normalized, lastWrittenUs)) {
                    assertTrue(lastWrittenUs == null || normalized > lastWrittenUs!!)
                    lastWrittenUs = normalized
                }
                frame += frameStepUs
            }
        }

        val expectedTimelineUs = segmentCount * segmentDurationUs
        assertTrue(lastWrittenUs!! < expectedTimelineUs)
        assertTrue(expectedTimelineUs - lastWrittenUs!! <= frameStepUs)
    }

    @Test
    fun `overlapping boundary sample is dropped instead of moving the next segment forward`() {
        val lastFromPreviousSegmentUs = 9_980_000L
        val nextSegmentStartUs = 9_960_000L
        val overlappingSampleUs = HlsSegmentTimeline.normalize(
            segmentTimelineStartUs = nextSegmentStartUs,
            rawSampleTimeUs = 40_000L,
            firstSampleTimeUs = 20_000L
        )
        assertTrue(HlsSegmentTimeline.overlapsPreviousSample(overlappingSampleUs, lastFromPreviousSegmentUs))
        assertFalse(HlsSegmentTimeline.overlapsPreviousSample(10_020_000L, lastFromPreviousSegmentUs))
    }
}
