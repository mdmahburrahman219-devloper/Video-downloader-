package com.mahabub.downloder

import com.mahabub.downloder.model.MediaCandidate
import com.mahabub.downloder.model.MediaCandidateGrouping
import com.mahabub.downloder.model.MediaDetectionSource
import com.mahabub.downloder.model.StreamType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MediaCandidateGroupingTest {

    private fun candidate(
        url: String,
        title: String,
        confidence: Int = 70,
        playing: Boolean = false,
        ad: Boolean = false,
        groupId: String? = null,
        quality: String? = null,
        poster: String? = null,
        duration: Double? = 120.0
    ) = MediaCandidate(
        id = url,
        url = url,
        title = title,
        mimeType = if (url.contains("m3u8")) "application/vnd.apple.mpegurl" else "video/mp4",
        sourcePageUrl = "https://site.example/watch/abc",
        streamType = if (url.contains("m3u8")) StreamType.HLS else StreamType.PROGRESSIVE,
        detectionSource = MediaDetectionSource.DOM_VIDEO,
        detectionConfidence = confidence,
        isPlaying = playing,
        isLikelyAd = ad,
        videoGroupId = groupId,
        qualityLabel = quality,
        thumbnailUrl = poster,
        durationSeconds = duration
    )

    @Test
    fun qualityTaggedHlsAlternativesAreGroupedAndSorted() {
        val low = candidate("https://cdn.example/watch/clip-360p-8a712.m3u8", "clip-360p-8a712", quality = "360p")
        val high = candidate("https://cdn.example/watch/clip-720p-4b3d2.m3u8", "clip-720p-4b3d2", quality = "720p")

        val groups = MediaCandidateGrouping.group(listOf(low, high))

        assertEquals(1, groups.size)
        assertEquals(2, groups.single().candidates.size)
        assertEquals("720p", MediaCandidateGrouping.qualityLabel(groups.single().primary))
    }

    @Test
    fun genericHlsQualityNamesInSameMediaDirectoryAreGrouped() {
        val low = candidate("https://cdn.example/watch/abc/hls-360p-8a712.m3u8", "hls-360p-8a712", quality = "360p")
        val high = candidate("https://cdn.example/watch/abc/hls-480p-4b3d2.m3u8", "hls-480p-4b3d2", quality = "480p")

        val groups = MediaCandidateGrouping.group(listOf(low, high))

        assertEquals(1, groups.size)
        assertEquals(2, groups.single().candidates.size)
        assertEquals("480p", MediaCandidateGrouping.qualityLabel(groups.single().primary))
    }

    @Test
    fun knownAdCandidateIsHiddenWhenNonAdCandidateExists() {
        val ad = candidate("https://ads.example/vast/ad-video.mp4", "ad-video.mp4", ad = true)
        val main = candidate("https://cdn.example/watch/main.mp4", "Main Video", playing = true)

        val defaultGroups = MediaCandidateGrouping.group(listOf(ad, main))
        val allGroups = MediaCandidateGrouping.group(listOf(ad, main), includeLikelyAds = true)

        assertEquals(1, defaultGroups.size)
        assertEquals("Main Video", defaultGroups.single().title)
        assertEquals(2, allGroups.size)
    }

    @Test
    fun unrelatedVideosAreNotGroupedOnlyBecauseTheyShareThePage() {
        val first = candidate("https://cdn.example/a/clip-one.mp4", "The Page", groupId = "player-1")
        val second = candidate("https://cdn.example/b/clip-two.mp4", "The Page", groupId = "player-2")

        val groups = MediaCandidateGrouping.group(listOf(first, second))

        assertEquals(2, groups.size)
        assertTrue(groups.all { it.title.contains("Video") || it.title == "The Page" })
    }

    @Test
    fun duplicateCandidateUrlsAreDeduplicated() {
        val first = candidate("https://cdn.example/clip.mp4", "Clip")
        val duplicate = first.copy(id = "duplicate-id", url = "https://cdn.example/clip.mp4#fragment")

        val groups = MediaCandidateGrouping.group(listOf(first, duplicate))

        assertEquals(1, groups.size)
        assertEquals(1, groups.single().candidates.size)
    }
    @Test
    fun samePlayerSourcesStillGroupWhenMetadataArrivesForOnlySomeSources() {
        val early = candidate(
            "https://cdn.example/stream/master.m3u8", "master.m3u8",
            groupId = "player-1", poster = null, duration = null, quality = null
        )
        val enriched = candidate(
            "https://cdn.example/stream/240p.m3u8", "The actual video title",
            groupId = "player-1", poster = "https://cdn.example/poster.jpg", duration = 428.0, quality = "240p"
        )

        val groups = MediaCandidateGrouping.group(listOf(early, enriched))

        assertEquals(1, groups.size)
        assertEquals(2, groups.single().candidates.size)
    }

    @Test
    fun duplicateQualityUrlsCollapseToOneQualityOption() {
        val lowA = candidate(
            "https://cdn.example/a/clip-480p-a.m3u8", "Clip", groupId = "player-1", quality = "480p"
        )
        val lowB = candidate(
            "https://cdn.example/b/clip-480p-b.m3u8", "Clip", groupId = "player-1", quality = "480p", confidence = 85
        )
        val high = candidate(
            "https://cdn.example/a/clip-720p.m3u8", "Clip", groupId = "player-1", quality = "720p"
        )

        val groups = MediaCandidateGrouping.group(listOf(lowA, lowB, high))

        assertEquals(1, groups.size)
        assertEquals(2, groups.single().candidates.size)
        assertEquals(listOf("720p", "480p"), groups.single().candidates.map(MediaCandidateGrouping::qualityLabel))
    }

    @Test
    fun actualResolutionOverridesIncorrectInferredLabel() {
        val wrongGuess = candidate(
            "https://cdn.example/clip.m3u8", "Clip", groupId = "player-1", quality = "1080p"
        ).copy(resolution = "854x240")

        assertEquals("240p", MediaCandidateGrouping.qualityLabel(wrongGuess))
    }

    @Test
    fun pageTitleOrParentDirectoryDoesNotInventResolution() {
        val candidate = candidate(
            "https://cdn.example/1080p/720p/master.m3u8", "1080p title · 720p",
            groupId = "player-1", quality = null, poster = null, duration = null
        )

        assertEquals("Auto", MediaCandidateGrouping.qualityLabel(candidate))
    }

}
