package com.mahabub.downloder.extractor

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class InlineDashManifestStoreHostTest {
    @Test
    fun acceptsFacebookPageAndMediaCdnHosts() {
        assertTrue(InlineDashManifestStore.isHostOrSubdomain("facebook.com", "facebook.com"))
        assertTrue(InlineDashManifestStore.isHostOrSubdomain("www.facebook.com", "facebook.com"))
        assertTrue(InlineDashManifestStore.isHostOrSubdomain("video.xx.fbcdn.net", "fbcdn.net"))
        assertTrue(InlineDashManifestStore.isHostOrSubdomain("scontent.xx.fbsbx.com", "fbsbx.com"))
    }

    @Test
    fun rejectsLookalikeAndUnrelatedHosts() {
        assertFalse(InlineDashManifestStore.isHostOrSubdomain("evilfacebook.com", "facebook.com"))
        assertFalse(InlineDashManifestStore.isHostOrSubdomain("facebook.com.evil.test", "facebook.com"))
        assertFalse(InlineDashManifestStore.isHostOrSubdomain("fbcdn.net.attacker.test", "fbcdn.net"))
    }
}
