package com.mahabub.downloder.downloader

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import androidx.media3.common.C
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.dash.DashUtil
import androidx.media3.exoplayer.dash.DashWrappingSegmentIndex
import androidx.media3.exoplayer.dash.DashSegmentIndex
import androidx.media3.exoplayer.dash.manifest.DashManifestParser
import androidx.media3.exoplayer.dash.manifest.Representation
import android.webkit.CookieManager
import com.mahabub.downloder.extractor.ExtractorUtils
import com.mahabub.downloder.extractor.HlsPlaylistParser
import com.mahabub.downloder.model.AppError
import com.mahabub.downloder.model.MediaQuality
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileInputStream
import java.io.ByteArrayInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.CipherInputStream
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec
import java.nio.ByteBuffer

/**
 * HLS downloader implemented without a bundled FFmpeg binary.
 * Supports VOD and bounded live capture, MPEG-TS and common single-init-map fMP4,
 * byte-range resources, identity AES-128 encryption, external audio renditions,
 * and resumable segment caching. DRM and SAMPLE-AES are intentionally unsupported.
 */
class HlsDownloader(private val okHttpClient: OkHttpClient) {

    data class HlsVariant(val bandwidth: Long, val resolution: String?, val url: String)
    data class HlsSegment(val url: String, val durationSeconds: Double)

    private data class StoredSegment(
        val segment: HlsPlaylistParser.Segment,
        val file: File,
        val cacheScope: String
    )

    private data class CapturedPlaylist(
        val playlistUrl: String,
        val media: HlsPlaylistParser.MediaPlaylist,
        val segments: List<StoredSegment>
    )

    private data class ResumeState(
        val mode: String,
        val fingerprint: String,
        val updatedAtMillis: Long,
        val segments: List<HlsPlaylistParser.Segment>
    )

    private data class SourceTrack(
        val segments: List<StoredSegment>,
        val includeAudio: Boolean,
        val includeVideo: Boolean
    )

    /** One source playlist's currently-open media segment while remuxing on the playlist timeline. */
    private data class SegmentReader(
        val sourceIndex: Int,
        val source: SourceTrack,
        val segmentIndex: Int,
        val timelineStartUs: Long,
        val segmentFile: File,
        val extractor: MediaExtractor,
        val trackMap: Map<Int, Int>,
        val baseTimeUs: Long,
        var firstSamplePending: Boolean = true
    )

    private data class RequestContext(
        val referer: String?,
        val userAgent: String,
        val useWebViewCookies: Boolean
    )

    companion object {
        /** Live streams are captured for at most this duration per download task. */
        const val MAX_LIVE_CAPTURE_SECONDS: Long = 30 * 60L
        private const val MAX_RESUME_STATE_AGE_MS = 24 * 60 * 60 * 1000L
        private const val MIN_LIVE_POLL_MS = 1_000L
        private const val MAX_LIVE_POLL_MS = 10_000L
    }

    suspend fun download(
        manifestUrl: String,
        tempDir: File,
        outputMp4File: File,
        preferredQuality: MediaQuality,
        audioPlaylistUrl: String? = null,
        referer: String? = null,
        userAgent: String? = null,
        useWebViewCookies: Boolean = false,
        onProgress: suspend (
            completedSegments: Int,
            totalSegments: Int,
            downloadedBytes: Long,
            speedBytesPerSec: Long
        ) -> Unit,
        onConverting: suspend () -> Unit = {}
    ): File = withContext(Dispatchers.IO) {
        if (!tempDir.exists() && !tempDir.mkdirs() && !tempDir.isDirectory) {
            throw AppError.FileWriteError("Could not create HLS temporary directory")
        }
        outputMp4File.parentFile?.let { parent ->
            if (!parent.exists() && !parent.mkdirs() && !parent.isDirectory) {
                throw AppError.FileWriteError("Could not create output directory")
            }
        }
        if (outputMp4File.exists() && !outputMp4File.delete()) {
            throw AppError.FileWriteError("Could not replace previous temporary MP4 file")
        }

        val cacheDir = File(tempDir, "segments")
        if (!cacheDir.exists() && !cacheDir.mkdirs() && !cacheDir.isDirectory) {
            throw AppError.FileWriteError("Could not create resumable HLS cache")
        }
        val sourceDir = File(tempDir, "sources")
        if (!sourceDir.exists() && !sourceDir.mkdirs() && !sourceDir.isDirectory) {
            throw AppError.FileWriteError("Could not create HLS source directory")
        }

        val requestContext = RequestContext(
            referer = referer?.takeIf { it.isNotBlank() },
            userAgent = userAgent?.takeIf { it.isNotBlank() } ?: ExtractorUtils.USER_AGENT,
            useWebViewCookies = useWebViewCookies
        )

        try {
            if (manifestUrl.substringBefore('?').substringBefore('#').endsWith(".mpd", true)) {
                throw AppError.UnsupportedMedia
            }

            val firstText = fetchText(manifestUrl, requestContext)
            if (!firstText.trimStart().startsWith("#EXTM3U")) {
                if (firstText.contains("<MPD", ignoreCase = true)) throw AppError.UnsupportedMedia
                throw AppError.PlaylistParseError("The URL did not return a valid HLS playlist")
            }

            validateSessionKeys(firstText)
            val master = HlsPlaylistParser.parseMaster(firstText, manifestUrl)
            val selectedVariant = chooseVariant(master.variants, preferredQuality)
            val videoPlaylistUrl = selectedVariant?.url ?: manifestUrl
            val videoInitialText = if (videoPlaylistUrl == manifestUrl) firstText else fetchText(videoPlaylistUrl, requestContext)
            val videoInitial = parseMediaPlaylist(videoInitialText, videoPlaylistUrl)

            val masterAudioUrl = selectedVariant?.audioGroupId?.let { group ->
                master.audioRenditions.filter { it.groupId == group && it.url != null }
                    .sortedWith(compareByDescending<HlsPlaylistParser.AudioRendition> { it.isDefault }
                        .thenByDescending { it.isAutoselect })
                    .firstOrNull()?.url
            }
            // A URL from MediaExtractionRepository is already a selected variant; retain its
            // separate audio rendition URL in the candidate/download entity metadata.
            val resolvedAudioPlaylistUrl = audioPlaylistUrl?.takeIf { it.isNotBlank() } ?: masterAudioUrl
            val audioInitialText = resolvedAudioPlaylistUrl?.let { fetchText(it, requestContext) }
            val audioInitial = if (resolvedAudioPlaylistUrl != null && audioInitialText != null) {
                parseMediaPlaylist(audioInitialText, resolvedAudioPlaylistUrl)
            } else null

            // Avoid accidental expansion of ad/redirect pages into unbounded work.
            if (videoInitial.segments.isEmpty()) {
                throw AppError.PlaylistParseError("No media segments found in the video playlist")
            }

            val captureStart = System.currentTimeMillis()
            val captureDeadline = captureStart + MAX_LIVE_CAPTURE_SECONDS * 1000L
            val progressMutex = Mutex()
            var completedSegments = 0
            var totalSegments = videoInitial.segments.size + (audioInitial?.segments?.size ?: 0)
            val hasLiveFeed = (!videoInitial.isEndList && !videoInitial.playlistType.equals("VOD", true)) ||
                (audioInitial != null && !audioInitial.isEndList && !audioInitial.playlistType.equals("VOD", true))
            var downloadedBytes = 0L
            var lastProgressAt = System.currentTimeMillis()
            var bytesSinceProgress = 0L

            suspend fun reportProgress(segmentsFound: Int, newlyDownloadedBytes: Long) {
                progressMutex.withLock {
                    completedSegments++
                    totalSegments = maxOf(
                        totalSegments,
                        segmentsFound,
                        completedSegments + if (hasLiveFeed) 1 else 0
                    )
                    downloadedBytes += newlyDownloadedBytes
                    bytesSinceProgress += newlyDownloadedBytes
                    val now = System.currentTimeMillis()
                    val elapsed = (now - lastProgressAt).coerceAtLeast(1L)
                    val speed = if (elapsed >= 750L) bytesSinceProgress * 1000L / elapsed else 0L
                    if (elapsed >= 750L || completedSegments >= totalSegments) {
                        onProgress(completedSegments, totalSegments, downloadedBytes, speed)
                        lastProgressAt = now
                        bytesSinceProgress = 0L
                    }
                }
            }

            // If the selected video variant has a separate audio URI, capture both feeds concurrently
            // so a live recording uses the same time window for audio and video.
            val captured = coroutineScope {
                val videoJob = async {
                    capturePlaylist(
                        playlistUrl = videoPlaylistUrl,
                        initialText = videoInitialText,
                        cacheDir = cacheDir,
                        requestContext = requestContext,
                        captureDeadlineMillis = captureDeadline,
                        onSegmentReady = { count, bytes -> reportProgress(count, bytes) }
                    )
                }
                val audioJob = if (resolvedAudioPlaylistUrl != null && audioInitialText != null) {
                    async {
                        capturePlaylist(
                            playlistUrl = resolvedAudioPlaylistUrl,
                            initialText = audioInitialText,
                            cacheDir = cacheDir,
                            requestContext = requestContext,
                            captureDeadlineMillis = captureDeadline,
                            onSegmentReady = { count, bytes -> reportProgress(count, bytes) }
                        )
                    }
                } else null
                videoJob.await() to audioJob?.await()
            }

            val videoCaptured = captured.first
            val audioCaptured = captured.second
            if (videoCaptured.segments.isEmpty()) throw AppError.PlaylistParseError("No video segments were downloaded")
            if (audioCaptured != null && audioCaptured.segments.isEmpty()) {
                throw AppError.PlaylistParseError("The selected external audio playlist contains no downloaded segments")
            }

            // Segment downloads are complete. From here the task is preparing/remuxing media,
            // not transferring bytes; expose a separate Converting state to the UI.
            onConverting()

            val sourceTracks = mutableListOf(
                SourceTrack(
                    segments = videoCaptured.segments,
                    includeAudio = audioCaptured == null,
                    includeVideo = true
                )
            )
            if (audioCaptured != null) {
                sourceTracks += SourceTrack(
                    segments = audioCaptured.segments,
                    includeAudio = true,
                    includeVideo = false
                )
            }

            currentCoroutineContext().ensureActive()
            remuxSourcesToMp4(sourceTracks, outputMp4File, tempDir, requestContext)
            if (!outputMp4File.isFile || outputMp4File.length() <= 0L) {
                throw AppError.MuxingFailed("The MP4 output is empty")
            }
            // A minimal size check catches many invalid/truncated outputs before the UI reports success.
            if (!hasMp4Ftyp(outputMp4File)) {
                throw AppError.MuxingFailed("The output does not look like a valid MP4 container")
            }

            tempDir.deleteRecursively()
            outputMp4File
        } catch (ce: CancellationException) {
            // Keep only completed segment cache files so a later retry can reuse them.
            outputMp4File.delete()
            throw ce
        } catch (ae: AppError) {
            outputMp4File.delete()
            throw ae
        } catch (e: Exception) {
            outputMp4File.delete()
            throw AppError.MuxingFailed(e.message ?: "HLS download / remux failed")
        }
    }

    /**
     * Downloads a bounded, static, non-DRM DASH presentation and remuxes its demuxed audio/video
     * tracks with the exact same FFmpeg-free MediaExtractor/MediaMuxer path used by HLS.
     * HLS parsing/downloading is not changed by this method.
     */
    @OptIn(UnstableApi::class)
    suspend fun downloadDash(
        manifestUrl: String,
        tempDir: File,
        outputMp4File: File,
        preferredQuality: MediaQuality,
        referer: String? = null,
        userAgent: String? = null,
        useWebViewCookies: Boolean = false,
        onProgress: suspend (
            completedSegments: Int,
            totalSegments: Int,
            downloadedBytes: Long,
            speedBytesPerSec: Long
        ) -> Unit,
        onConverting: suspend () -> Unit = {},
        inlineManifestText: String? = null,
        selectedVideoRepresentationIndex: Int? = null,
        selectedAudioRepresentationIndex: Int? = null,
        audioOnly: Boolean = false
    ): File = withContext(Dispatchers.IO) {
        if (!tempDir.exists() && !tempDir.mkdirs() && !tempDir.isDirectory) {
            throw AppError.FileWriteError("Could not create DASH temporary directory")
        }
        outputMp4File.parentFile?.let { parent ->
            if (!parent.exists() && !parent.mkdirs() && !parent.isDirectory) {
                throw AppError.FileWriteError("Could not create DASH output directory")
            }
        }
        if (outputMp4File.exists() && !outputMp4File.delete()) {
            throw AppError.FileWriteError("Could not replace previous DASH output")
        }

        val requestContext = RequestContext(
            referer = referer?.takeIf { it.isNotBlank() },
            userAgent = userAgent?.takeIf { it.isNotBlank() } ?: ExtractorUtils.USER_AGENT,
            useWebViewCookies = useWebViewCookies
        )
        val cacheDir = File(tempDir, "dash-segments")
        if (!cacheDir.exists() && !cacheDir.mkdirs() && !cacheDir.isDirectory) {
            throw AppError.FileWriteError("Could not create DASH segment cache")
        }

        try {
            val manifestText = inlineManifestText?.takeIf { it.isNotBlank() }
                ?: fetchDashText(manifestUrl, requestContext)
            if (!manifestText.contains("<MPD", ignoreCase = true)) {
                throw AppError.PlaylistParseError("The URL did not return a DASH MPD manifest")
            }
            if (Regex("(?i)<!DOCTYPE|<!ENTITY").containsMatchIn(manifestText)) {
                throw AppError.PlaylistParseError("DASH manifest contains disallowed XML declarations")
            }
            if (Regex("<ContentProtection\\b", RegexOption.IGNORE_CASE).containsMatchIn(manifestText)) {
                // Do not attempt to bypass DRM or protected stream access.
                throw AppError.ProtectedMedia
            }

            val manifest = try {
                DashManifestParser().parse(Uri.parse(manifestUrl), ByteArrayInputStream(manifestText.toByteArray(Charsets.UTF_8)))
            } catch (e: Exception) {
                throw AppError.PlaylistParseError("DASH manifest could not be parsed: ${e.message ?: "invalid MPD"}")
            }
            if (manifest.dynamic || manifest.periodCount != 1) {
                throw AppError.UnsupportedMedia
            }
            val period = manifest.getPeriod(0)
            val periodDurationUs = manifest.getPeriodDurationUs(0).takeIf { it > 0L && it != C.TIME_UNSET }
                ?: manifest.durationMs.takeIf { it > 0L && it != C.TIME_UNSET }?.times(1_000L)
                ?: throw AppError.PlaylistParseError("DASH presentation duration is missing")

            val videoRepresentations = period.adaptationSets
                .filter { it.type == C.TRACK_TYPE_VIDEO }
                .flatMap { it.representations }
                .filter { (it.format.sampleMimeType ?: "").startsWith("video/") }
            val audioRepresentations = period.adaptationSets
                .filter { it.type == C.TRACK_TYPE_AUDIO }
                .flatMap { it.representations }
                .filter { (it.format.sampleMimeType ?: "").startsWith("audio/") }

            if (!audioOnly && videoRepresentations.isEmpty()) {
                throw AppError.PlaylistParseError("DASH manifest has no supported video representation")
            }
            if (audioOnly && audioRepresentations.isEmpty()) {
                throw AppError.PlaylistParseError("DASH manifest has no supported audio representation")
            }

            val videoRepresentation = if (audioOnly) null else selectedVideoRepresentationIndex
                ?.let { videoRepresentations.getOrNull(it) }
                ?: chooseDashVideoRepresentation(videoRepresentations, preferredQuality)
            val audioRepresentation = selectedAudioRepresentationIndex
                ?.let { audioRepresentations.getOrNull(it) }
                ?: audioRepresentations.maxByOrNull { it.format.averageBitrate.coerceAtLeast(0) }
            if (!audioOnly && videoRepresentation == null) throw AppError.UnsupportedMedia

            // Some MPDs expose SegmentTemplate indexes directly; SegmentBase/SIDX MPDs expose
            // only an index byte range. Ask Media3 to load that range when no direct index exists.
            val videoIndex = videoRepresentation?.let {
                resolveDashIndex(it, C.TRACK_TYPE_VIDEO, requestContext)
            }
            if (!audioOnly && videoIndex == null) throw AppError.UnsupportedMedia
            val audioIndex = audioRepresentation?.let {
                resolveDashIndex(it, C.TRACK_TYPE_AUDIO, requestContext)
            }
            if (audioRepresentation != null && audioIndex == null) throw AppError.UnsupportedMedia
            if (audioOnly && audioRepresentation == null) throw AppError.UnsupportedMedia
            val totalSegments = (videoIndex?.let { countDashSegments(it, periodDurationUs) } ?: 0) +
                (audioIndex?.let { countDashSegments(it, periodDurationUs) } ?: 0)
            if (totalSegments !in 1..10_000) throw AppError.UnsupportedMedia

            var completedSegments = 0
            var downloadedBytes = 0L
            val startedAt = System.currentTimeMillis()
            suspend fun reportSegment(file: File) {
                completedSegments++
                downloadedBytes += file.length().coerceAtLeast(0L)
                val elapsed = (System.currentTimeMillis() - startedAt).coerceAtLeast(1L)
                onProgress(
                    completedSegments,
                    totalSegments,
                    downloadedBytes,
                    downloadedBytes * 1_000L / elapsed
                )
            }

            val videoTrack = if (videoRepresentation != null) {
                downloadDashRepresentation(
                    manifestUrl = manifestUrl,
                    representation = videoRepresentation,
                    segmentIndex = videoIndex ?: throw AppError.UnsupportedMedia,
                    periodDurationUs = periodDurationUs,
                    cacheDir = cacheDir,
                    requestContext = requestContext,
                    trackLabel = "video",
                    onSegmentDownloaded = ::reportSegment
                )
            } else null
            val audioTrack = audioRepresentation?.let {
                downloadDashRepresentation(
                    manifestUrl = manifestUrl,
                    representation = it,
                    segmentIndex = audioIndex ?: throw AppError.UnsupportedMedia,
                    periodDurationUs = periodDurationUs,
                    cacheDir = cacheDir,
                    requestContext = requestContext,
                    trackLabel = "audio",
                    onSegmentDownloaded = ::reportSegment
                )
            }

            if (videoTrack != null && videoTrack.segments.isEmpty()) {
                throw AppError.PlaylistParseError("DASH video has no media segments")
            }
            if (audioTrack != null && audioTrack.segments.isEmpty()) {
                throw AppError.PlaylistParseError("DASH audio has no media segments")
            }

            onConverting()
            val sources = mutableListOf<SourceTrack>()
            if (videoTrack != null) {
                sources += SourceTrack(
                    segments = videoTrack.segments,
                    includeAudio = audioTrack == null,
                    includeVideo = true
                )
            }
            if (audioTrack != null) {
                sources += SourceTrack(
                    segments = audioTrack.segments,
                    includeAudio = true,
                    includeVideo = false
                )
            }
            if (sources.isEmpty()) throw AppError.PlaylistParseError("DASH has no downloadable tracks")
            currentCoroutineContext().ensureActive()
            remuxSourcesToMp4(sources, outputMp4File, tempDir, requestContext)
            if (!outputMp4File.isFile || outputMp4File.length() <= 0L || !hasMp4Ftyp(outputMp4File)) {
                throw AppError.MuxingFailed("DASH remux did not produce a valid MP4 file")
            }
            tempDir.deleteRecursively()
            outputMp4File
        } catch (ce: CancellationException) {
            outputMp4File.delete()
            throw ce
        } catch (error: AppError) {
            outputMp4File.delete()
            throw error
        } catch (error: Exception) {
            outputMp4File.delete()
            throw AppError.MuxingFailed(error.message ?: "DASH download/remux failed")
        }
    }

    @OptIn(UnstableApi::class)
    private fun chooseDashVideoRepresentation(
        representations: List<Representation>,
        quality: MediaQuality
    ): Representation {
        val sorted = representations.sortedWith(
            compareBy<Representation> { it.format.height.coerceAtLeast(0) }
                .thenBy { it.format.peakBitrate.coerceAtLeast(it.format.averageBitrate).coerceAtLeast(0) }
        )
        return when (quality) {
            MediaQuality.HIGHEST -> sorted.last()
            MediaQuality.DATA_SAVER -> sorted.firstOrNull { it.format.height in 1..360 } ?: sorted.first()
            MediaQuality.BALANCED -> sorted.filter { it.format.height in 1..720 }.lastOrNull() ?: sorted[sorted.size / 2]
        }
    }

    @OptIn(UnstableApi::class)
    private fun resolveDashIndex(
        representation: Representation,
        trackType: Int,
        requestContext: RequestContext
    ): DashSegmentIndex? {
        representation.index?.let { return it }
        if (representation.indexUri == null) return null
        val baseUrl = representation.baseUrls.firstOrNull()?.url ?: return null
        val headers = linkedMapOf(
            "User-Agent" to requestContext.userAgent,
            "Accept-Encoding" to "identity"
        )
        requestContext.referer?.takeIf { it.isNotBlank() }?.let { headers["Referer"] = it }
        if (requestContext.useWebViewCookies) {
            runCatching { CookieManager.getInstance().getCookie(baseUrl) }
                .getOrNull()?.takeIf { it.isNotBlank() }?.let { headers["Cookie"] = it }
        }
        val dataSource = DefaultHttpDataSource.Factory()
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(20_000)
            .setDefaultRequestProperties(headers)
            .createDataSource()
        val chunkIndex = runCatching {
            DashUtil.loadChunkIndex(dataSource, trackType, representation)
        }.getOrNull() ?: return null
        return DashWrappingSegmentIndex(chunkIndex, representation.presentationTimeOffsetUs)
    }

    @OptIn(UnstableApi::class)
    private fun countDashSegments(index: DashSegmentIndex, periodDurationUs: Long): Int {
        val count = index.getSegmentCount(periodDurationUs)
        if (count <= 0L || count > 10_000L) throw AppError.UnsupportedMedia
        return count.toInt()
    }

    @OptIn(UnstableApi::class)
    private suspend fun downloadDashRepresentation(
        manifestUrl: String,
        representation: Representation,
        segmentIndex: DashSegmentIndex,
        periodDurationUs: Long,
        cacheDir: File,
        requestContext: RequestContext,
        trackLabel: String,
        onSegmentDownloaded: suspend (File) -> Unit
    ): SourceTrack {
        val index = segmentIndex
        val firstSegment = index.firstSegmentNum
        val count = index.getSegmentCount(periodDurationUs)
        if (count <= 0L || count > 10_000L) throw AppError.UnsupportedMedia
        val baseUrl = representation.baseUrls.firstOrNull()?.url ?: manifestUrl
        val representationId = representation.format.id?.take(100)?.ifBlank { null } ?: trackLabel
        val cacheScope = "dash|$manifestUrl|$representationId|$trackLabel"

        val initRange = representation.initializationUri
        val initMap = initRange?.let { ranged ->
            HlsPlaylistParser.InitMap(
                uri = ranged.resolveUriString(baseUrl),
                byteRange = ranged.takeIf { it.length >= 0L }?.let { HlsPlaylistParser.ByteRange(it.length, it.start) }
            )
        }
        if (initMap != null) {
            downloadAsset(
                url = initMap.uri,
                range = initMap.byteRange,
                cacheDir = cacheDir,
                cacheIdentity = mapCacheIdentity(initMap, cacheScope),
                segmentIndex = 0,
                requestContext = requestContext
            )
        }

        val stored = ArrayList<StoredSegment>(count.toInt())
        for (offset in 0 until count) {
            currentCoroutineContext().ensureActive()
            val segmentNumber = firstSegment + offset
            val ranged = index.getSegmentUrl(segmentNumber)
            val segmentUrl = ranged.resolveUriString(baseUrl)
            val durationUs = index.getDurationUs(segmentNumber, periodDurationUs)
                .takeIf { it > 0L && it != C.TIME_UNSET }
                ?: if (offset + 1L < count) {
                    (index.getTimeUs(segmentNumber + 1L) - index.getTimeUs(segmentNumber)).takeIf { it > 0L }
                        ?: throw AppError.PlaylistParseError("DASH segment duration is invalid")
                } else {
                    throw AppError.PlaylistParseError("DASH final segment duration is invalid")
                }
            val segment = HlsPlaylistParser.Segment(
                url = segmentUrl,
                durationSeconds = durationUs / 1_000_000.0,
                sequence = segmentNumber,
                byteRange = ranged.takeIf { it.length >= 0L }?.let { HlsPlaylistParser.ByteRange(it.length, it.start) },
                initMap = initMap
            )
            val file = downloadAsset(
                url = segmentUrl,
                range = segment.byteRange,
                cacheDir = cacheDir,
                cacheIdentity = segmentCacheIdentity(segment, cacheScope),
                segmentIndex = (offset + 1L).coerceAtMost(Int.MAX_VALUE.toLong()).toInt(),
                requestContext = requestContext
            )
            stored += StoredSegment(segment, file, cacheScope)
            onSegmentDownloaded(file)
        }
        val isAudio = trackLabel == "audio"
        return SourceTrack(
            segments = stored,
            includeAudio = isAudio,
            includeVideo = !isAudio
        )
    }

    private suspend fun fetchDashText(url: String, requestContext: RequestContext): String {
        val builder = Request.Builder()
            .url(url)
            .get()
            .header("User-Agent", requestContext.userAgent)
            .header("Accept", "application/dash+xml, application/xml, text/xml, */*;q=0.8")
        requestContext.referer?.let { builder.header("Referer", it) }
        addScopedWebViewCookies(url, builder, requestContext)
        return okHttpClient.newCall(builder.build()).execute().use { response ->
            if (!response.isSuccessful) {
                throw when (response.code) {
                    401 -> AppError.Unauthorized
                    403 -> AppError.Forbidden
                    404 -> AppError.NotFound
                    in 500..599 -> AppError.ServerError
                    else -> AppError.PlaylistParseError("DASH manifest HTTP ${response.code}")
                }
            }
            val body = response.body ?: throw AppError.PlaylistParseError("Empty DASH manifest response")
            if (body.contentLength() > 5_000_000L) throw AppError.PlaylistParseError("DASH manifest is too large")
            val manifestText = body.string()
            if (manifestText.length > 5_000_000) {
                throw AppError.PlaylistParseError("DASH manifest is too large")
            }
            manifestText
        }
    }

    private fun chooseVariant(
        variants: List<HlsPlaylistParser.Variant>,
        quality: MediaQuality
    ): HlsPlaylistParser.Variant? {
        if (variants.isEmpty()) return null
        val byHeight = variants.sortedWith(
            compareBy<HlsPlaylistParser.Variant> { it.resolution?.substringAfter('x')?.toIntOrNull() ?: 0 }
                .thenBy { it.bandwidth }
        )
        return when (quality) {
            MediaQuality.HIGHEST -> byHeight.last()
            MediaQuality.DATA_SAVER -> byHeight.first()
            MediaQuality.BALANCED -> byHeight.filter {
                (it.resolution?.substringAfter('x')?.toIntOrNull() ?: Int.MAX_VALUE) <= 720
            }.lastOrNull() ?: byHeight[byHeight.size / 2]
        }
    }

    private fun parseMediaPlaylist(text: String, url: String): HlsPlaylistParser.MediaPlaylist = try {
        HlsPlaylistParser.parseMediaPlaylist(text, url).also { playlist ->
            // The MP4 timeline is rebuilt from EXTINF. Invalid or zero durations would place
            // later segments at the wrong timestamp and can create a frozen/near-zero output.
            val invalidDuration = playlist.segments.any { segment ->
                !segment.durationSeconds.isFinite() || segment.durationSeconds <= 0.0
            }
            if (invalidDuration) {
                throw AppError.PlaylistParseError("The HLS playlist contains an invalid segment duration")
            }
        }
    } catch (e: AppError) {
        throw e
    } catch (e: Exception) {
        throw AppError.PlaylistParseError(e.message ?: "Malformed HLS media playlist")
    }

    private suspend fun capturePlaylist(
        playlistUrl: String,
        initialText: String,
        cacheDir: File,
        requestContext: RequestContext,
        captureDeadlineMillis: Long,
        onSegmentReady: suspend (segmentsFound: Int, newlyDownloadedBytes: Long) -> Unit
    ): CapturedPlaylist {
        val stored = linkedMapOf<String, StoredSegment>()
        var playlist = parseMediaPlaylist(initialText, playlistUrl)
        var currentText = initialText
        val initialIsLive = !playlist.isEndList && !playlist.playlistType.equals("VOD", true)
        val stateFile = File(cacheDir, ".resume-${sha256(playlistUrl)}.dat")
        val state = loadResumeState(stateFile, playlistUrl)
        val firstPlaylistMaxSequence = playlist.segments.maxOfOrNull { it.sequence }
        val savedMaxSequence = state?.segments?.maxOfOrNull { it.sequence }
        val liveSequenceLooksCompatible = state?.mode != "LIVE" ||
            firstPlaylistMaxSequence == null || savedMaxSequence == null || firstPlaylistMaxSequence >= savedMaxSequence
        val restore = state != null && liveSequenceLooksCompatible && (
            state.mode == "LIVE" ||
                (state.mode == "VOD" && state.fingerprint == sha256(initialText))
            )
        // A session that started live remains a LIVE session if the stream later adds ENDLIST.
        val sessionMode = if ((restore && state?.mode == "LIVE") || initialIsLive) "LIVE" else "VOD"
        val fingerprint = if (sessionMode == "LIVE") "LIVE" else sha256(initialText)
        val cacheScope = fingerprint
        if (restore && state != null) {
            val savedScope = if (state.mode == "LIVE") "LIVE" else state.fingerprint
            for (segment in state.segments) {
                val cacheFile = File(cacheDir, "${sha256(segmentCacheIdentity(segment, savedScope))}.bin")
                if (cacheFile.isFile && cacheFile.length() > 0L) {
                    stored[segment.identity()] = StoredSegment(segment, cacheFile, savedScope)
                }
            }
            stored.values.forEach { onSegmentReady(stored.size, it.file.length().coerceAtLeast(0L)) }
        } else {
            stateFile.delete()
        }

        val live = sessionMode == "LIVE"
        var capturedDurationSeconds = stored.values.sumOf { it.segment.durationSeconds.coerceAtLeast(0.0) }
        val remainingLiveMillis = ((MAX_LIVE_CAPTURE_SECONDS - capturedDurationSeconds).coerceAtLeast(0.0) * 1000.0).toLong()
        val sessionDeadlineMillis = if (live) {
            minOf(captureDeadlineMillis, System.currentTimeMillis() + remainingLiveMillis)
        } else captureDeadlineMillis

        while (true) {
            currentCoroutineContext().ensureActive()
            playlist = parseMediaPlaylist(currentText, playlistUrl)

            for (segment in playlist.segments) {
                if (live && capturedDurationSeconds >= MAX_LIVE_CAPTURE_SECONDS) break
                val id = segment.identity()
                if (stored.containsKey(id)) continue
                validateEncryption(segment.key, segment.sequence)
                segment.initMap?.let { validateMapEncryption(it) }
                if (segment.initMap != null) {
                    downloadAsset(
                        url = segment.initMap.uri,
                        range = segment.initMap.byteRange,
                        cacheDir = cacheDir,
                        cacheIdentity = mapCacheIdentity(segment.initMap, cacheScope),
                        segmentIndex = stored.size + 1,
                        requestContext = requestContext
                    )
                }
                val file = downloadAsset(
                    url = segment.url,
                    range = segment.byteRange,
                    cacheDir = cacheDir,
                    cacheIdentity = segmentCacheIdentity(segment, cacheScope),
                    segmentIndex = stored.size + 1,
                    requestContext = requestContext
                )
                stored[id] = StoredSegment(segment, file, cacheScope)
                capturedDurationSeconds += segment.durationSeconds.coerceAtLeast(0.0)
                saveResumeState(
                    stateFile = stateFile,
                    playlistUrl = playlistUrl,
                    mode = sessionMode,
                    fingerprint = fingerprint,
                    segments = stored.values.map { it.segment }
                )
                onSegmentReady(stored.size, file.length())
            }

            if (!live || playlist.isEndList) break
            if (System.currentTimeMillis() >= sessionDeadlineMillis || capturedDurationSeconds >= MAX_LIVE_CAPTURE_SECONDS) break

            val pollMs = (playlist.targetDurationSeconds * 500.0).toLong()
                .coerceIn(MIN_LIVE_POLL_MS, MAX_LIVE_POLL_MS)
            delay(minOf(pollMs, (sessionDeadlineMillis - System.currentTimeMillis()).coerceAtLeast(1L)))
            currentText = fetchText(playlistUrl, requestContext)
            if (!currentText.trimStart().startsWith("#EXTM3U")) {
                throw AppError.PlaylistParseError("The live playlist refresh returned invalid data")
            }
        }

        if (stored.isEmpty()) throw AppError.PlaylistParseError("The HLS playlist contained no downloadable segments")
        // Last checkpoint ensures an empty/unchanged live poll still leaves a valid state file.
        saveResumeState(
            stateFile = stateFile,
            playlistUrl = playlistUrl,
            mode = sessionMode,
            fingerprint = fingerprint,
            segments = stored.values.map { it.segment }
        )
        return CapturedPlaylist(playlistUrl, playlist, stored.values.toList())
    }

    private fun loadResumeState(stateFile: File, playlistUrl: String): ResumeState? {
        if (!stateFile.isFile || stateFile.length() <= 0L) return null
        return try {
            DataInputStream(BufferedInputStream(FileInputStream(stateFile))).use { input ->
                if (input.readInt() != 0x484C5352 || input.readInt() != 2) return null
                if (input.readUTF() != playlistUrl) return null
                val mode = input.readUTF()
                val fingerprint = input.readUTF()
                val updatedAt = input.readLong()
                if (updatedAt <= 0L || System.currentTimeMillis() - updatedAt > MAX_RESUME_STATE_AGE_MS) return null
                val count = input.readInt()
                if (count !in 0..100_000) return null
                val segments = ArrayList<HlsPlaylistParser.Segment>(count)
                repeat(count) { segments += readSegment(input) }
                ResumeState(mode, fingerprint, updatedAt, segments)
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun saveResumeState(
        stateFile: File,
        playlistUrl: String,
        mode: String,
        fingerprint: String,
        segments: List<HlsPlaylistParser.Segment>
    ) {
        val part = File(stateFile.parentFile, stateFile.name + ".part")
        try {
            DataOutputStream(BufferedOutputStream(FileOutputStream(part, false))).use { output ->
                output.writeInt(0x484C5352)
                output.writeInt(2)
                output.writeUTF(playlistUrl)
                output.writeUTF(mode)
                output.writeUTF(fingerprint)
                output.writeLong(System.currentTimeMillis())
                output.writeInt(segments.size)
                segments.forEach { writeSegment(output, it) }
                output.flush()
            }
            if (stateFile.exists()) stateFile.delete()
            if (!part.renameTo(stateFile)) {
                part.copyTo(stateFile, overwrite = true)
                part.delete()
            }
        } catch (_: Exception) {
            part.delete()
            // Cache files still allow re-downloading from the current manifest if metadata cannot be saved.
        }
    }

    private fun writeSegment(out: DataOutputStream, s: HlsPlaylistParser.Segment) {
        out.writeUTF(s.url)
        out.writeDouble(s.durationSeconds)
        out.writeLong(s.sequence)
        writeRange(out, s.byteRange)
        out.writeBoolean(s.initMap != null)
        s.initMap?.let { map ->
            out.writeUTF(map.uri)
            writeRange(out, map.byteRange)
            writeKey(out, map.key)
        }
        writeKey(out, s.key)
        out.writeBoolean(s.discontinuityBefore)
        writeNullableUtf(out, s.title)
    }

    private fun readSegment(input: DataInputStream): HlsPlaylistParser.Segment {
        val url = input.readUTF()
        val duration = input.readDouble()
        val sequence = input.readLong()
        val range = readRange(input)
        val map = if (input.readBoolean()) {
            HlsPlaylistParser.InitMap(input.readUTF(), readRange(input), readKey(input))
        } else null
        val key = readKey(input)
        val discontinuity = input.readBoolean()
        val title = readNullableUtf(input)
        return HlsPlaylistParser.Segment(url, duration, sequence, range, map, key, discontinuity, title)
    }

    private fun writeRange(out: DataOutputStream, range: HlsPlaylistParser.ByteRange?) {
        out.writeBoolean(range != null)
        if (range != null) {
            out.writeLong(range.length)
            out.writeBoolean(range.offset != null)
            range.offset?.let(out::writeLong)
        }
    }

    private fun readRange(input: DataInputStream): HlsPlaylistParser.ByteRange? {
        if (!input.readBoolean()) return null
        val length = input.readLong()
        val offset = if (input.readBoolean()) input.readLong() else null
        return HlsPlaylistParser.ByteRange(length, offset)
    }

    private fun writeKey(out: DataOutputStream, key: HlsPlaylistParser.KeySpec?) {
        out.writeBoolean(key != null)
        if (key != null) {
            out.writeUTF(key.method)
            writeNullableUtf(out, key.uri)
            out.writeInt(key.iv?.size ?: -1)
            key.iv?.let(out::write)
            out.writeUTF(key.keyFormat)
        }
    }

    private fun readKey(input: DataInputStream): HlsPlaylistParser.KeySpec? {
        if (!input.readBoolean()) return null
        val method = input.readUTF()
        val uri = readNullableUtf(input)
        val ivSize = input.readInt()
        if (ivSize !in -1..16) throw IllegalArgumentException("Invalid IV length in HLS resume state")
        val iv = if (ivSize >= 0) ByteArray(ivSize).also(input::readFully) else null
        val keyFormat = input.readUTF()
        return HlsPlaylistParser.KeySpec(method, uri, iv, keyFormat)
    }

    private fun writeNullableUtf(out: DataOutputStream, value: String?) {
        out.writeBoolean(value != null)
        if (value != null) out.writeUTF(value)
    }

    private fun readNullableUtf(input: DataInputStream): String? = if (input.readBoolean()) input.readUTF() else null

    private fun validateSessionKeys(masterText: String) {
        for (line in masterText.lineSequence().map { it.trim() }) {
            if (!line.startsWith("#EXT-X-SESSION-KEY:", true)) continue
            val attrs = HlsPlaylistParser.parseAttributes(line.substringAfter(':'))
            val method = attrs["METHOD"].orEmpty()
            val keyFormat = attrs["KEYFORMAT"] ?: "identity"
            if (!method.equals("AES-128", true) || !keyFormat.equals("identity", true)) {
                throw AppError.UnsupportedHlsFeature("session key method=$method, keyformat=$keyFormat")
            }
        }
    }

    private fun validateEncryption(key: HlsPlaylistParser.KeySpec?, sequence: Long) {
        if (key == null) return
        if (!key.keyFormat.equals("identity", true)) {
            throw AppError.UnsupportedHlsFeature("DRM/non-identity key format")
        }
        if (!key.method.equals("AES-128", true)) {
            throw AppError.UnsupportedHlsFeature(key.method)
        }
        if (key.uri.isNullOrBlank()) {
            throw AppError.PlaylistParseError("AES-128 key URI is missing")
        }
        val keyScheme = runCatching { java.net.URI(key.uri).scheme }.getOrNull()
        if (!keyScheme.equals("http", true) && !keyScheme.equals("https", true)) {
            throw AppError.UnsupportedHlsFeature("non-HTTP AES-128 key URI")
        }
        if (sequence < 0L) throw AppError.PlaylistParseError("Invalid media sequence number")
    }

    private fun validateMapEncryption(map: HlsPlaylistParser.InitMap) {
        val key = map.key ?: return
        validateEncryption(key, 0L)
        if (key.iv == null) {
            throw AppError.UnsupportedHlsFeature("encrypted EXT-X-MAP without an explicit IV")
        }
    }

    private suspend fun downloadAsset(
        url: String,
        range: HlsPlaylistParser.ByteRange?,
        cacheDir: File,
        cacheIdentity: String,
        segmentIndex: Int,
        requestContext: RequestContext
    ): File {
        val key = sha256(cacheIdentity)
        val target = File(cacheDir, "$key.bin")
        if (target.isFile && target.length() > 0L && (range == null || target.length() == range.length)) return target
        val partial = File(cacheDir, "$key.part")
        partial.delete()

        val requestBuilder = Request.Builder()
            .url(url)
            .header("User-Agent", requestContext.userAgent)
        requestContext.referer?.let { requestBuilder.header("Referer", it) }
        addScopedWebViewCookies(url, requestBuilder, requestContext)
        if (range != null) {
            val offset = range.offset ?: 0L
            val end = offset + range.length - 1L
            if (end < offset) throw AppError.PlaylistParseError("HLS byte-range overflow")
            requestBuilder.header("Range", "bytes=$offset-$end")
        }
        val response = try {
            okHttpClient.newCall(requestBuilder.build()).execute()
        } catch (ce: CancellationException) {
            throw ce
        } catch (e: Exception) {
            currentCoroutineContext().ensureActive()
            throw AppError.SegmentDownloadError(segmentIndex, e.message ?: "Network error")
        }

        response.use { res ->
            if (!res.isSuccessful) {
                throw when (res.code) {
                    401 -> AppError.Unauthorized
                    403 -> AppError.Forbidden
                    404 -> AppError.NotFound
                    in 500..599 -> AppError.ServerError
                    else -> AppError.SegmentDownloadError(segmentIndex, "HTTP ${res.code}")
                }
            }
            val body = res.body ?: throw AppError.SegmentDownloadError(segmentIndex, "Empty response body")
            try {
                body.byteStream().use { input ->
                    FileOutputStream(partial).use { output ->
                        if (range != null && res.code == 200) {
                            // Some servers ignore Range; safely skip to the requested offset and copy only the requested bytes.
                            skipFully(input, range.offset ?: 0L)
                            copyExactly(input, output, range.length)
                        } else {
                            if (range != null && res.code != 206) {
                                throw AppError.SegmentDownloadError(segmentIndex, "Server did not honor byte-range request")
                            }
                            if (range != null) {
                                val offset = range.offset ?: 0L
                                val requestedEnd = offset + range.length - 1L
                                val contentRange = res.header("Content-Range")
                                    ?: throw AppError.SegmentDownloadError(segmentIndex, "Missing Content-Range on partial response")
                                val rangeMatch = Regex("""(?i)^bytes\s+(\d+)-(\d+)/(?:\d+|\*)$""").matchEntire(contentRange.trim())
                                val returnedStart = rangeMatch?.groupValues?.getOrNull(1)?.toLongOrNull()
                                val returnedEnd = rangeMatch?.groupValues?.getOrNull(2)?.toLongOrNull()
                                if (returnedStart != offset || returnedEnd != requestedEnd) {
                                    throw AppError.SegmentDownloadError(segmentIndex, "Unexpected Content-Range")
                                }
                                copyExactly(input, output, range.length)
                            } else {
                                val buffer = ByteArray(32 * 1024)
                                while (true) {
                                    currentCoroutineContext().ensureActive()
                                    val read = input.read(buffer)
                                    if (read < 0) break
                                    output.write(buffer, 0, read)
                                }
                            }
                        }
                        output.fd.sync()
                    }
                }
                if (partial.length() <= 0L) throw AppError.SegmentDownloadError(segmentIndex, "Empty media resource")
                if (range != null && partial.length() != range.length) {
                    throw AppError.SegmentDownloadError(segmentIndex, "Byte-range length mismatch")
                }
                if (target.exists()) target.delete()
                if (!partial.renameTo(target)) {
                    partial.copyTo(target, overwrite = true)
                    partial.delete()
                }
                return target
            } catch (ce: CancellationException) {
                partial.delete()
                throw ce
            } catch (ae: AppError) {
                partial.delete()
                throw ae
            } catch (e: Exception) {
                partial.delete()
                throw AppError.SegmentDownloadError(segmentIndex, e.message ?: "Could not save media resource")
            }
        }
    }

    private suspend fun skipFully(input: InputStream, count: Long) {
        var remaining = count
        val scratch = ByteArray(8 * 1024)
        while (remaining > 0L) {
            currentCoroutineContext().ensureActive()
            val skipped = input.skip(remaining)
            if (skipped > 0L) {
                remaining -= skipped
            } else {
                val read = input.read(scratch, 0, minOf(scratch.size.toLong(), remaining).toInt())
                if (read < 0) throw AppError.PlaylistParseError("Byte-range offset exceeds resource length")
                remaining -= read
            }
        }
    }

    private suspend fun copyExactly(input: InputStream, output: FileOutputStream, count: Long) {
        var remaining = count
        val buffer = ByteArray(32 * 1024)
        while (remaining > 0L) {
            currentCoroutineContext().ensureActive()
            val read = input.read(buffer, 0, minOf(buffer.size.toLong(), remaining).toInt())
            if (read < 0) throw AppError.PlaylistParseError("Truncated byte-range resource")
            output.write(buffer, 0, read)
            remaining -= read
        }
    }

    private suspend fun assembleMediaSource(
        segments: List<StoredSegment>,
        destination: File,
        requestContext: RequestContext
    ) {
        if (segments.isEmpty()) throw AppError.MuxingFailed("No HLS segments to assemble")
        destination.parentFile?.mkdirs()
        val mapCache = hashMapOf<String, File>()
        val keyBytes = hashMapOf<String, ByteArray>()
        FileOutputStream(destination, false).use { output ->
            var activeMapIdentity: String? = null
            var previousMapIdentity: String? = null
            for ((index, item) in segments.withIndex()) {
                currentCoroutineContext().ensureActive()
                val map = item.segment.initMap
                val mapIdentity = map?.identity()
                if (map != null && mapIdentity != activeMapIdentity) {
                    if (previousMapIdentity != null && previousMapIdentity != mapIdentity) {
                        throw AppError.UnsupportedHlsFeature("multiple initialization maps in one media playlist")
                    }
                    val mapFile = mapCache.getOrPut(mapIdentity!!) {
                        val identity = mapCacheIdentity(map, segments[index].cacheScope)
                        File(File(destination.parentFile, "map_materialized"), "${sha256(identity)}.clear").also { file ->
                            file.parentFile?.mkdirs()
                        }
                    }
                    if (!mapFile.isFile || mapFile.length() == 0L) {
                        materializeAsset(
                            cachedAsset = File(segments[index].file.parentFile, "${sha256(mapCacheIdentity(map, segments[index].cacheScope))}.bin"),
                            outputFile = mapFile,
                            key = map.key,
                            sequence = item.segment.sequence,
                            keyBytes = keyBytes,
                            requestContext = requestContext
                        )
                    }
                    FileInputStream(mapFile).use { copyCancellable(it, output) }
                    activeMapIdentity = mapIdentity
                    previousMapIdentity = mapIdentity
                }
                materializeAssetToStream(
                    cachedAsset = item.file,
                    output = output,
                    key = item.segment.key,
                    sequence = item.segment.sequence,
                    keyBytes = keyBytes,
                    requestContext = requestContext
                )
            }
            output.fd.sync()
        }
        if (!destination.isFile || destination.length() == 0L) throw AppError.MuxingFailed("Assembled HLS media source is empty")
    }

    private suspend fun materializeAsset(
        cachedAsset: File,
        outputFile: File,
        key: HlsPlaylistParser.KeySpec?,
        sequence: Long,
        keyBytes: MutableMap<String, ByteArray>,
        requestContext: RequestContext
    ) {
        outputFile.parentFile?.mkdirs()
        val partial = File(outputFile.parentFile, outputFile.name + ".part")
        partial.delete()
        try {
            FileOutputStream(partial, false).use { output ->
                FileInputStream(cachedAsset).use { input ->
                    copyPossiblyDecrypted(input, output, key, sequence, keyBytes, requestContext)
                }
                output.fd.sync()
            }
            if (outputFile.exists()) outputFile.delete()
            if (!partial.renameTo(outputFile)) {
                partial.copyTo(outputFile, overwrite = true)
                partial.delete()
            }
        } catch (e: Exception) {
            partial.delete()
            throw e
        }
    }

    private suspend fun materializeAssetToStream(
        cachedAsset: File,
        output: FileOutputStream,
        key: HlsPlaylistParser.KeySpec?,
        sequence: Long,
        keyBytes: MutableMap<String, ByteArray>,
        requestContext: RequestContext
    ) {
        FileInputStream(cachedAsset).use { input ->
            copyPossiblyDecrypted(input, output, key, sequence, keyBytes, requestContext)
        }
    }

    private suspend fun copyPossiblyDecrypted(
        input: InputStream,
        output: FileOutputStream,
        key: HlsPlaylistParser.KeySpec?,
        sequence: Long,
        keyBytes: MutableMap<String, ByteArray>,
        requestContext: RequestContext
    ) {
        if (key == null) {
            copyCancellable(input, output)
            return
        }
        validateEncryption(key, sequence)
        val keyUri = key.uri!!
        val secret = keyBytes[keyUri] ?: fetchKey(keyUri, requestContext).also { keyBytes[keyUri] = it }
        if (secret.size != 16) throw AppError.ProtectedMedia
        val iv = key.iv ?: HlsPlaylistParser.sequenceIv(sequence)
        val cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
        cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(secret, "AES"), IvParameterSpec(iv))
        CipherInputStream(input, cipher).use { decrypted ->
            copyCancellable(decrypted, output)
        }
    }

    private suspend fun fetchKey(url: String, requestContext: RequestContext): ByteArray {
        val requestBuilder = Request.Builder().url(url).header("User-Agent", requestContext.userAgent)
        requestContext.referer?.let { requestBuilder.header("Referer", it) }
        addScopedWebViewCookies(url, requestBuilder, requestContext)
        val request = requestBuilder.build()
        val response = try {
            okHttpClient.newCall(request).execute()
        } catch (ce: CancellationException) {
            throw ce
        } catch (e: Exception) {
            currentCoroutineContext().ensureActive()
            throw AppError.NetworkUnavailable
        }
        return response.use { res ->
            if (!res.isSuccessful) throw AppError.SegmentDownloadError(0, "Could not fetch HLS AES-128 key (HTTP ${res.code})")
            val bytes = res.body?.bytes() ?: throw AppError.ProtectedMedia
            if (bytes.size != 16) throw AppError.ProtectedMedia
            bytes
        }
    }

    /**
     * Remux HLS one segment at a time. Each segment is placed on the cumulative EXTINF
     * timeline instead of trusting transport-stream timestamps to remain continuous across
     * segment boundaries. This avoids duration inflation and gradual A/V drift on playlists
     * whose MPEG-TS PTS clocks reset or jump between segments.
     */
    private suspend fun remuxSourcesToMp4(
        sources: List<SourceTrack>,
        outputFile: File,
        tempDir: File,
        requestContext: RequestContext
    ) {
        if (sources.isEmpty() || sources.all { it.segments.isEmpty() }) {
            throw AppError.MuxingFailed("No HLS segments are available to convert")
        }
        outputFile.parentFile?.mkdirs()
        val workDir = File(tempDir, "mux-inputs")
        if (!workDir.exists() && !workDir.mkdirs() && !workDir.isDirectory) {
            throw AppError.FileWriteError("Could not create temporary media conversion directory")
        }
        val keyBytes = hashMapOf<String, ByteArray>()
        val muxer = try {
            MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        } catch (e: Exception) {
            workDir.deleteRecursively()
            throw AppError.MuxingFailed(e.message ?: "Could not create MP4 muxer")
        }
        val readers = mutableListOf<SegmentReader?>()
        val outputTrackBySourceAndKind = hashMapOf<Pair<Int, String>, Int>()
        // Keep the maximum timeline timestamp per track for detecting only segment-boundary overlap.
        // Intra-segment sample order must be preserved (including codecs with B-frames).
        val maximumWrittenTimeByTrack = hashMapOf<Int, Long>()
        var muxerStarted = false
        var anySampleWritten = false

        try {
            // Add every muxer track from the first readable segment of its source before start().
            for (sourceIndex in sources.indices) {
                val source = sources[sourceIndex]
                val reader = openSegmentReader(
                    sourceIndex = sourceIndex,
                    source = source,
                    segmentIndex = 0,
                    timelineStartUs = 0L,
                    workDir = workDir,
                    requestContext = requestContext,
                    keyBytes = keyBytes,
                    outputTrackBySourceAndKind = outputTrackBySourceAndKind,
                    muxer = muxer,
                    mayAddTracks = true
                )
                if (reader != null) readers += reader
            }
            if (readers.isEmpty() || outputTrackBySourceAndKind.isEmpty()) {
                throw AppError.MuxingFailed("No compatible audio/video tracks were found in the HLS segments")
            }

            muxer.start()
            muxerStarted = true
            var buffer = ByteBuffer.allocateDirect(2 * 1024 * 1024)
            val info = MediaCodec.BufferInfo()

            while (true) {
                currentCoroutineContext().ensureActive()
                var replacedReader = false

                // Move exhausted segment readers to the next segment on that playlist's timeline.
                for (index in readers.indices) {
                    val reader = readers[index] ?: continue
                    if (reader.extractor.sampleTrackIndex < 0) {
                        readers[index] = advanceSegmentReader(
                            reader = reader,
                            workDir = workDir,
                            requestContext = requestContext,
                            keyBytes = keyBytes,
                            outputTrackBySourceAndKind = outputTrackBySourceAndKind,
                            muxer = muxer
                        )
                        replacedReader = true
                    }
                }
                if (replacedReader) continue
                if (readers.all { it == null }) break

                var selectedReaderIndex = -1
                var selectedOutputTrack = -1
                var selectedOutputTime = Long.MAX_VALUE

                // Interleave active video/audio playlist readers by the normalized presentation time.
                for (index in readers.indices) {
                    val reader = readers[index] ?: continue
                    val inputTrack = reader.extractor.sampleTrackIndex
                    if (inputTrack < 0) continue
                    val outputTrack = reader.trackMap[inputTrack] ?: continue
                    val rawTimeUs = reader.extractor.sampleTime.coerceAtLeast(0L)
                    val normalizedTimeUs = HlsSegmentTimeline.normalize(
                        segmentTimelineStartUs = reader.timelineStartUs,
                        rawSampleTimeUs = rawTimeUs,
                        firstSampleTimeUs = reader.baseTimeUs
                    )
                    val lastTimeUs = maximumWrittenTimeByTrack[outputTrack]
                    if (reader.firstSamplePending && HlsSegmentTimeline.overlapsPreviousSample(normalizedTimeUs, lastTimeUs)) {
                        // Only trim overlapping leading samples at a segment boundary. Never drop
                        // intra-segment samples: B-frame tracks can legitimately have non-monotonic PTS
                        // in decode order. Shifting each later segment would accumulate duration drift.
                        reader.extractor.advance()
                        replacedReader = true
                        break
                    }
                    val outputTimeUs = normalizedTimeUs
                    if (outputTimeUs < selectedOutputTime) {
                        selectedOutputTime = outputTimeUs
                        selectedReaderIndex = index
                        selectedOutputTrack = outputTrack
                    }
                }
                if (replacedReader) continue

                if (selectedReaderIndex < 0) {
                    // A segment reader without a usable sample is advanced on the next iteration.
                    continue
                }
                val reader = readers[selectedReaderIndex] ?: continue
                buffer.clear()
                var sampleSize = reader.extractor.readSampleData(buffer, 0)
                if (sampleSize <= 0) {
                    // Ignore malformed/empty samples rather than passing a zero-size buffer to MediaMuxer.
                    reader.extractor.advance()
                    continue
                }
                if (sampleSize > buffer.capacity()) {
                    val newCapacity = sampleSize.coerceAtMost(32 * 1024 * 1024)
                    if (newCapacity < sampleSize) {
                        throw AppError.MuxingFailed("Media sample exceeded the 32 MB processing limit")
                    }
                    buffer = ByteBuffer.allocateDirect(newCapacity)
                    buffer.clear()
                    sampleSize = reader.extractor.readSampleData(buffer, 0)
                    if (sampleSize < 0 || sampleSize > buffer.capacity()) {
                        throw AppError.MuxingFailed("Could not read a complete media sample")
                    }
                }

                info.set(0, sampleSize, selectedOutputTime, reader.extractor.sampleFlags)
                buffer.position(0)
                buffer.limit(sampleSize)
                muxer.writeSampleData(selectedOutputTrack, buffer, info)
                reader.firstSamplePending = false
                val previousMaximum = maximumWrittenTimeByTrack[selectedOutputTrack]
                maximumWrittenTimeByTrack[selectedOutputTrack] =
                    if (previousMaximum == null) selectedOutputTime else maxOf(previousMaximum, selectedOutputTime)
                anySampleWritten = true

                reader.extractor.advance()
            }

            if (!anySampleWritten) throw AppError.MuxingFailed("No audio/video samples could be read from the HLS segments")
        } catch (ae: AppError) {
            throw ae
        } catch (e: Exception) {
            throw AppError.MuxingFailed(e.message ?: "Could not remux HLS media")
        } finally {
            readers.filterNotNull().forEach { reader ->
                runCatching { reader.extractor.release() }
                runCatching { reader.segmentFile.delete() }
            }
            if (muxerStarted) runCatching { muxer.stop() }
            runCatching { muxer.release() }
            // Clear decrypted/materialized segment copies even when conversion fails.
            workDir.deleteRecursively()
        }
    }

    private suspend fun openSegmentReader(
        sourceIndex: Int,
        source: SourceTrack,
        segmentIndex: Int,
        timelineStartUs: Long,
        workDir: File,
        requestContext: RequestContext,
        keyBytes: MutableMap<String, ByteArray>,
        outputTrackBySourceAndKind: MutableMap<Pair<Int, String>, Int>,
        muxer: MediaMuxer,
        mayAddTracks: Boolean
    ): SegmentReader? {
        var index = segmentIndex
        var segmentStartUs = timelineStartUs
        while (index < source.segments.size) {
            currentCoroutineContext().ensureActive()
            val stored = source.segments[index]
            val materialized = File(workDir, "source${sourceIndex}_segment${index}_${System.nanoTime()}.media")
            val extractor = MediaExtractor()
            try {
                prepareSegmentFile(stored, materialized, workDir, requestContext, keyBytes)
                extractor.setDataSource(materialized.absolutePath)
                val kindsByInputTrack = selectInputTracks(extractor, source)
                val mappedTracks = linkedMapOf<Int, Int>()
                for ((inputTrack, kind) in kindsByInputTrack) {
                    val key = sourceIndex to kind
                    var outputTrack = outputTrackBySourceAndKind[key]
                    if (outputTrack == null && mayAddTracks) {
                        outputTrack = muxer.addTrack(extractor.getTrackFormat(inputTrack))
                        outputTrackBySourceAndKind[key] = outputTrack
                    }
                    if (outputTrack != null) {
                        mappedTracks[inputTrack] = outputTrack
                    } else {
                        // Do not leave an input track selected if its format appeared only in a later
                        // segment and cannot be represented by the already-started MP4 muxer. Otherwise
                        // MediaExtractor may stop on a sample that the remux loop cannot map.
                        runCatching { extractor.unselectTrack(inputTrack) }
                    }
                }
                if (mappedTracks.isNotEmpty() && extractor.sampleTrackIndex >= 0) {
                    val baseTimeUs = extractor.sampleTime.coerceAtLeast(0L)
                    return SegmentReader(
                        sourceIndex = sourceIndex,
                        source = source,
                        segmentIndex = index,
                        timelineStartUs = segmentStartUs,
                        segmentFile = materialized,
                        extractor = extractor,
                        trackMap = mappedTracks,
                        baseTimeUs = baseTimeUs
                    )
                }
            } catch (e: Exception) {
                runCatching { extractor.release() }
                materialized.delete()
                if (e is AppError) throw e
                throw AppError.MuxingFailed("Could not read HLS segment ${index + 1}: ${e.message ?: "invalid media segment"}")
            }
            runCatching { extractor.release() }
            materialized.delete()
            segmentStartUs += (stored.segment.durationSeconds.coerceAtLeast(0.0) * 1_000_000.0).toLong()
            index++
        }
        return null
    }

    private suspend fun advanceSegmentReader(
        reader: SegmentReader,
        workDir: File,
        requestContext: RequestContext,
        keyBytes: MutableMap<String, ByteArray>,
        outputTrackBySourceAndKind: MutableMap<Pair<Int, String>, Int>,
        muxer: MediaMuxer
    ): SegmentReader? {
        val previousSegment = reader.source.segments[reader.segmentIndex]
        val nextStartUs = reader.timelineStartUs +
            (previousSegment.segment.durationSeconds.coerceAtLeast(0.0) * 1_000_000.0).toLong()
        runCatching { reader.extractor.release() }
        runCatching { reader.segmentFile.delete() }
        return openSegmentReader(
            sourceIndex = reader.sourceIndex,
            source = reader.source,
            segmentIndex = reader.segmentIndex + 1,
            timelineStartUs = nextStartUs,
            workDir = workDir,
            requestContext = requestContext,
            keyBytes = keyBytes,
            outputTrackBySourceAndKind = outputTrackBySourceAndKind,
            muxer = muxer,
            mayAddTracks = false
        )
    }

    private fun selectInputTracks(extractor: MediaExtractor, source: SourceTrack): Map<Int, String> {
        val selected = linkedMapOf<Int, String>()
        var hasVideo = false
        var hasAudio = false
        for (track in 0 until extractor.trackCount) {
            val mime = runCatching { extractor.getTrackFormat(track).getString(MediaFormat.KEY_MIME).orEmpty() }
                .getOrDefault("")
            val kind = when {
                mime.startsWith("video/") && source.includeVideo && !hasVideo -> "video".also { hasVideo = true }
                mime.startsWith("audio/") && source.includeAudio && !hasAudio -> "audio".also { hasAudio = true }
                else -> null
            } ?: continue
            extractor.selectTrack(track)
            selected[track] = kind
        }
        return selected
    }

    private suspend fun prepareSegmentFile(
        stored: StoredSegment,
        destination: File,
        workDir: File,
        requestContext: RequestContext,
        keyBytes: MutableMap<String, ByteArray>
    ) {
        destination.parentFile?.mkdirs()
        destination.delete()
        FileOutputStream(destination, false).use { output ->
            val map = stored.segment.initMap
            if (map != null) {
                val cachedMap = File(
                    stored.file.parentFile,
                    "${sha256(mapCacheIdentity(map, stored.cacheScope))}.bin"
                )
                if (!cachedMap.isFile || cachedMap.length() <= 0L) {
                    throw AppError.MuxingFailed("HLS initialization map is missing")
                }
                val clearMap = File(workDir, "map-${sha256(mapCacheIdentity(map, stored.cacheScope))}.clear")
                if (!clearMap.isFile || clearMap.length() <= 0L) {
                    materializeAsset(
                        cachedAsset = cachedMap,
                        outputFile = clearMap,
                        key = map.key,
                        sequence = stored.segment.sequence,
                        keyBytes = keyBytes,
                        requestContext = requestContext
                    )
                }
                FileInputStream(clearMap).use { copyCancellable(it, output) }
            }
            materializeAssetToStream(
                cachedAsset = stored.file,
                output = output,
                key = stored.segment.key,
                sequence = stored.segment.sequence,
                keyBytes = keyBytes,
                requestContext = requestContext
            )
            output.fd.sync()
        }
        if (!destination.isFile || destination.length() <= 0L) {
            throw AppError.MuxingFailed("A materialized HLS segment is empty")
        }
    }

    private fun hasMp4Ftyp(file: File): Boolean = try {
        FileInputStream(file).use { input ->
            val header = ByteArray(12)
            if (input.read(header) < 8) return false
            val type = String(header, 4, 4, Charsets.US_ASCII)
            type == "ftyp" || type == "styp"
        }
    } catch (_: Exception) {
        false
    }

    /**
     * Meta HLS segments may be session-gated. Forward only cookies that Android WebView scopes
     * to each exact playlist/segment/key URL; leave every other website's HLS requests unchanged.
     */
    private fun addScopedWebViewCookies(
        url: String,
        requestBuilder: Request.Builder,
        requestContext: RequestContext
    ) {
        if (!requestContext.useWebViewCookies) return
        val cookies = runCatching { CookieManager.getInstance().getCookie(url) }.getOrNull()
        if (!cookies.isNullOrBlank()) requestBuilder.header("Cookie", cookies)
    }

    private suspend fun fetchText(url: String, requestContext: RequestContext): String {
        val requestBuilder = Request.Builder().url(url)
            .header("User-Agent", requestContext.userAgent)
        requestContext.referer?.let { requestBuilder.header("Referer", it) }
        addScopedWebViewCookies(url, requestBuilder, requestContext)
        val response = try {
            okHttpClient.newCall(requestBuilder.build()).execute()
        } catch (ce: CancellationException) {
            throw ce
        } catch (e: Exception) {
            currentCoroutineContext().ensureActive()
            throw AppError.NetworkUnavailable
        }
        return response.use { res ->
            if (!res.isSuccessful) {
                throw when (res.code) {
                    401 -> AppError.Unauthorized
                    403 -> AppError.Forbidden
                    404 -> AppError.NotFound
                    in 500..599 -> AppError.ServerError
                    else -> AppError.PlaylistParseError("Failed to fetch playlist (HTTP ${res.code})")
                }
            }
            res.body?.string() ?: throw AppError.PlaylistParseError("Empty playlist response")
        }
    }

    private fun segmentCacheIdentity(segment: HlsPlaylistParser.Segment, scope: String): String =
        "segment|$scope|${segment.identity()}"

    private fun mapCacheIdentity(map: HlsPlaylistParser.InitMap, scope: String): String =
        "map|$scope|${map.identity()}"

    private suspend fun copyCancellable(input: InputStream, output: FileOutputStream) {
        val buffer = ByteArray(32 * 1024)
        while (true) {
            currentCoroutineContext().ensureActive()
            val read = input.read(buffer)
            if (read < 0) break
            output.write(buffer, 0, read)
        }
    }

    private fun sha256(input: String): String = MessageDigest.getInstance("SHA-256")
        .digest(input.toByteArray(Charsets.UTF_8))
        .joinToString("") { "%02x".format(it) }
}
