package com.mahabub.downloder.browser

import android.graphics.Bitmap
import android.net.http.SslError
import android.webkit.MimeTypeMap
import android.webkit.SslErrorHandler
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import java.util.Locale

class SecureWebViewClient(
    private val mediaDetector: MediaDetector,
    private val onPageStartedCallback: (url: String) -> Unit,
    private val onPageFinishedCallback: (url: String, title: String?) -> Unit,
    /** Snapshot from WebView settings so resource candidates use the browser's real UA. */
    private val browserUserAgent: String? = null,
    /** Reads the live Settings toggle without blocking WebView resource threads. */
    private val adBlockingEnabled: () -> Boolean = { true }
) : WebViewClient() {

    @Volatile
    private var currentPageUrl: String? = null

    companion object {
        // Do not surface HLS/DASH media segments as if each were a complete video.
        private val mediaExtensions = setOf(
            "mp4", "webm", "mov", "m4v", "avi", "mkv", "m3u8", "mpd",
            "mp3", "m4a", "aac", "ogg", "wav", "flac"
        )
        private val segmentExtensions = setOf("ts", "m4s", "cmfv", "cmfa")
    }

    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
        val url = request?.url ?: return false
        val scheme = url.scheme?.lowercase(Locale.ROOT) ?: return false

        // TikTok is browser-only for this build. Do not apply the app's ad/redirect blocker
        // to any navigation while a TikTok page is being opened or viewed.
        if (!isTikTokBrowserContext(url.toString()) && adBlockingEnabled() &&
            request.isForMainFrame && AdBlocker.isAdDomain(url)
        ) return true

        // Normal web redirects stay inside WebView. Non-web schemes remain blocked for safety.
        return scheme != "http" && scheme != "https"
    }

    override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: SslError?) {
        // Never weaken TLS validation.
        handler?.cancel()
    }

    override fun shouldInterceptRequest(
        view: WebView?,
        request: WebResourceRequest?
    ): WebResourceResponse? {
        val url = request?.url ?: return super.shouldInterceptRequest(view, request)

        // Android invokes this callback off the UI thread. Do not read view.url, view.settings,
        // or any other WebView property here. This method must never be able to break navigation.
        return try {
            val rawUrl = url.toString()
            if (isTikTokBrowserContext(rawUrl)) {
                super.shouldInterceptRequest(view, request)
            } else if (adBlockingEnabled() && AdBlocker.isAdDomain(url)) {
                AdBlocker.createEmptyResponse()
            } else {
                // Only sniff GET requests; POST API calls are not reusable direct-download URLs.
                if (request.method.equals("GET", ignoreCase = true) && !request.isForMainFrame) {
                    val path = url.path.orEmpty().lowercase(Locale.ROOT)
                    val ext = path.substringAfterLast('.', "").takeIf { it != path }.orEmpty()
                    val tiktokVideoResource = TikTokMediaUrlHeuristics.isLikelyVideoResource(rawUrl)
                    if ((ext in mediaExtensions && ext !in segmentExtensions) || tiktokVideoResource) {
                        val mimeType = mimeForExtension(ext) ?: if (tiktokVideoResource) "video/mp4" else null
                        val referer = request.requestHeaders.entries
                            .firstOrNull { it.key.equals("Referer", ignoreCase = true) }?.value
                            ?: currentPageUrl
                        val userAgent = request.requestHeaders.entries
                            .firstOrNull { it.key.equals("User-Agent", ignoreCase = true) }?.value
                            ?.takeIf { it.isNotBlank() } ?: browserUserAgent
                        runCatching {
                            mediaDetector.onNetworkMediaFound(
                                url = rawUrl,
                                mimeType = mimeType,
                                currentPageUrl = referer,
                                userAgent = userAgent
                            )
                        }
                    }
                }
                super.shouldInterceptRequest(view, request)
            }
        } catch (_: Exception) {
            // A detector/ad-filter failure must not interrupt the actual browser request.
            super.shouldInterceptRequest(view, request)
        }
    }

    override fun onLoadResource(view: WebView?, url: String?) {
        super.onLoadResource(view, url)
        // Supplement shouldInterceptRequest for redirect/resource paths that WebView exposes later.
        // The narrow URL matcher excludes images and common media segments to avoid surfacing them.
        val rawUrl = url ?: return
        if (isTikTokBrowserContext(rawUrl)) return
        val currentPage = currentPageUrl
        val metaPlatform = PlatformMediaOverlayScript.platformForUrl(currentPage)
        val metaManifestOrFile = metaPlatform != null &&
            PlatformMediaOverlayScript.isAllowedMediaUrl(metaPlatform, rawUrl) &&
            runCatching {
                val path = android.net.Uri.parse(rawUrl).encodedPath.orEmpty().lowercase(Locale.ROOT)
                path.endsWith(".m3u8") || path.endsWith(".mpd") ||
                    path.endsWith(".mp4") || path.endsWith(".m4v") || path.endsWith(".webm")
            }.getOrDefault(false)
        if (TikTokMediaUrlHeuristics.isLikelyVideoResource(rawUrl) || metaManifestOrFile) {
            val ext = runCatching { android.net.Uri.parse(rawUrl).lastPathSegment.orEmpty().substringAfterLast('.', "").lowercase(Locale.ROOT) }
                .getOrDefault("")
            val mime = mimeForExtension(ext) ?: if (metaManifestOrFile) "video/mp4" else "video/mp4"
            runCatching {
                mediaDetector.onNetworkMediaFound(
                    url = rawUrl,
                    mimeType = mime,
                    currentPageUrl = currentPage,
                    userAgent = browserUserAgent
                )
            }
        }
    }

    override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
        super.onPageStarted(view, url, favicon)
        if (!url.isNullOrBlank()) {
            currentPageUrl = url
            mediaDetector.clearForNewPage()
            // Install the read-only Meta JSON/resource observer at navigation start. The normal
            // page-finished injection remains as a safety re-install after redirects/reloads.
            if (view != null && PlatformMediaOverlayScript.supportsUrl(url) && !TikTokBrowserMode.isTikTokUrl(url)) {
                runCatching { view.evaluateJavascript(SnifferScript.JAVASCRIPT_SNIFFER, null) }
            }
            onPageStartedCallback(url)
        }
    }

    override fun onPageFinished(view: WebView?, url: String?) {
        super.onPageFinished(view, url)
        if (view != null && !url.isNullOrBlank()) {
            runCatching {
                if (TikTokBrowserMode.isTikTokUrl(url) || TikTokBrowserMode.isTikTokUrl(currentPageUrl)) {
                    // Until playback is confirmed, install only a tiny listener for video playing/timeupdate.
                    // It does not inspect media URLs or hook page network APIs.
                    view.evaluateJavascript(TikTokPlaybackObserverScript.JAVASCRIPT, null)
                } else {
                    view.evaluateJavascript(SnifferScript.JAVASCRIPT_SNIFFER, null)
                    view.evaluateJavascript(BrowserPerformanceScript.JAVASCRIPT, null)
                    // The per-media red buttons are deliberately scoped to Meta social pages.
                    // Ordinary websites keep the existing single-FAB detection experience.
                    if (PlatformMediaOverlayScript.supportsUrl(url)) {
                        view.evaluateJavascript(PlatformMediaOverlayScript.JAVASCRIPT, null)
                    }
                }
            }
            runCatching { onPageFinishedCallback(url, view.title) }
        }
    }

    private fun isTikTokBrowserContext(requestUrl: String?): Boolean {
        // Only immutable URL strings are read here. currentPageUrl is volatile because this
        // helper is also called from WebView's resource worker thread.
        return runCatching {
            TikTokBrowserMode.isTikTokUrl(requestUrl) || TikTokBrowserMode.isTikTokUrl(currentPageUrl)
        }.getOrDefault(false)
    }

    private fun mimeForExtension(extension: String): String? {
        return when (extension) {
            "m3u8" -> "application/vnd.apple.mpegurl"
            "mpd" -> "application/dash+xml"
            "m4v" -> "video/mp4"
            "mkv" -> "video/x-matroska"
            "mov" -> "video/quicktime"
            "avi" -> "video/x-msvideo"
            "m4a" -> "audio/mp4"
            else -> MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension)
        }
    }
}
