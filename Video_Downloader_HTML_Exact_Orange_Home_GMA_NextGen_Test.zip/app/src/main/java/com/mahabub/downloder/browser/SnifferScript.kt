package com.mahabub.downloder.browser

/**
 * A best-effort video sniffer. It observes video/source elements, resource timing, fetch and XHR
 * responses. The Facebook-only DASH correlator may count bytes from a cloned, already-requested
 * segment response, but it never changes the page response or sends media payloads to native code.
 */
object SnifferScript {
    val JAVASCRIPT_SNIFFER = """
        (function () {
            'use strict';

            // TikTok stays browser-only until the native playback observer confirms real playback.
            // The full scanner is injected only after window.__vdTikTokPostPlaybackEnabled is set.
            try {
                var pageHost = String(location.hostname || '').toLowerCase();
                var onTikTokPage = pageHost === 'tiktok.com' || pageHost.endsWith('.tiktok.com');
                if (onTikTokPage && window.__vdTikTokPostPlaybackEnabled !== true) return;
            } catch (e) { return; }

            if (window.__videoSnifferInstalled) {
                try { if (typeof window.__runVideoSniffer === 'function') window.__runVideoSniffer(); } catch (e) {}
                return;
            }
            window.__videoSnifferInstalled = true;

            var reported = new Map();
            var MAX_REPORTED = 250;
            var nextPlayerId = 1;
            var MEDIA_EXT = /\.(?:m3u8|mpd|mp4|m4v|webm|mov|mkv|avi|mp3|m4a|aac|ogg|wav|flac)(?:$|[?#])/i;
            var SEGMENT_EXT = /\.(?:ts|m4s|cmfv|cmfa)(?:$|[?#])/i;
            var MEDIA_MIME = /^(?:video\/|audio\/)|mpegurl|dash\+xml/i;

            function safeUrl(raw) {
                if (!raw || typeof raw !== 'string' || /^(?:blob:|data:|javascript:)/i.test(raw)) return null;
                try {
                    var u = new URL(raw, document.baseURI);
                    if (u.protocol !== 'http:' && u.protocol !== 'https:') return null;
                    u.hash = '';
                    return u.href;
                } catch (e) { return null; }
            }

            function isSegmentUrl(url) {
                try {
                    var u = new URL(url);
                    var p = u.pathname.toLowerCase();
                    return SEGMENT_EXT.test(p) || /\/(?:segments?|chunks?|fragments?)\//i.test(p) || /(?:^|[-_.])(?:seg(?:ment)?|chunk|part|frag(?:ment)?)[-_.]?\d+/i.test(p.split('/').pop() || '');
                } catch (e) { return false; }
            }

            function hasMediaSignal(url, mimeType) {
                if (!url) return false;
                if (isSegmentUrl(url)) return false;
                if (MEDIA_EXT.test(url)) return true;
                if (isLikelyTikTokVideoResourceUrl(url)) return true;
                return !!(mimeType && MEDIA_MIME.test(String(mimeType).split(';')[0].trim()));
            }

            function anyVideoPlaying() {
                try {
                    var list = document.querySelectorAll('video');
                    for (var i = 0; i < list.length; i++) {
                        if (!list[i].paused && !list[i].ended) return true;
                    }
                } catch (e) {}
                return false;
            }

            function bridgeCall(method, args) {
                try {
                    var bridge = window.AndroidMediaBridge;
                    if (bridge && typeof bridge[method] === 'function') bridge[method].apply(bridge, args);
                } catch (e) {}
            }

            function firstMeta(selectors) {
                try {
                    for (var i = 0; i < selectors.length; i++) {
                        var node = document.querySelector(selectors[i]);
                        var value = node && (node.getAttribute('content') || node.getAttribute('href'));
                        if (value && value.trim()) return value.trim();
                    }
                } catch (e) {}
                return '';
            }

            function jsonLdVideoMetadata() {
                var result = { title: '', poster: '', duration: 0, mediaUrl: '' };
                try {
                    var scripts = document.querySelectorAll('script[type="application/ld+json"]');
                    var inspect = function (value) {
                        if (!value || (result.title && result.poster && result.mediaUrl) || typeof value !== 'object') return;
                        if (Array.isArray(value)) { value.forEach(inspect); return; }
                        var type = value['@type'];
                        var isVideo = type === 'VideoObject' || (Array.isArray(type) && type.indexOf('VideoObject') >= 0);
                        if (isVideo) {
                            if (typeof value.name === 'string') result.title = value.name;
                            var image = value.thumbnailUrl || value.image;
                            if (Array.isArray(image)) image = image[0];
                            if (image && typeof image === 'object') image = image.url || image.contentUrl;
                            if (typeof image === 'string') result.poster = image;
                            result.duration = parseDurationSeconds(value.duration || value.timeRequired || '');
                            var contentUrl = value.contentUrl || (value.associatedMedia && value.associatedMedia.contentUrl) || '';
                            if (contentUrl && typeof contentUrl === 'object') contentUrl = contentUrl.url || contentUrl.contentUrl || '';
                            if (typeof contentUrl === 'string') result.mediaUrl = safeUrl(contentUrl) || '';
                        }
                        if (value['@graph']) inspect(value['@graph']);
                        if (value.mainEntity) inspect(value.mainEntity);
                    };
                    for (var i = 0; i < scripts.length && !(result.title && result.poster && result.mediaUrl); i++) {
                        try { inspect(JSON.parse(scripts[i].textContent || '')); } catch (e) {}
                    }
                } catch (e) {}
                return result;
            }

            function parseDurationSeconds(raw) {
                if (typeof raw === 'number') return isFinite(raw) && raw > 0 && raw < 86400 ? raw : 0;
                var value = String(raw || '').trim();
                if (!value) return 0;
                if (/^\d+(?:\.\d+)?$/.test(value)) {
                    var numeric = Number(value);
                    return isFinite(numeric) && numeric > 0 && numeric < 86400 ? numeric : 0;
                }
                // Schema.org commonly expresses duration as ISO 8601, e.g. PT28M7S.
                var iso = /^P(?:([0-9]+(?:\.[0-9]+)?)D)?(?:T(?:([0-9]+(?:\.[0-9]+)?)H)?(?:([0-9]+(?:\.[0-9]+)?)M)?(?:([0-9]+(?:\.[0-9]+)?)S)?)?$/i.exec(value);
                if (iso) {
                    var seconds = Number(iso[1] || 0) * 86400 + Number(iso[2] || 0) * 3600 + Number(iso[3] || 0) * 60 + Number(iso[4] || 0);
                    return isFinite(seconds) && seconds > 0 && seconds < 86400 ? seconds : 0;
                }
                var clock = /^(?:(\d{1,2}):)?(\d{1,2}):(\d{2})(?:\.(\d+))?$/.exec(value);
                if (clock) {
                    var total = Number(clock[1] || 0) * 3600 + Number(clock[2] || 0) * 60 + Number(clock[3] || 0) + Number('0.' + (clock[4] || '0'));
                    return isFinite(total) && total > 0 && total < 86400 ? total : 0;
                }
                return 0;
            }

            function readPageMetadata() {
                var jsonLd = jsonLdVideoMetadata();
                var title = firstMeta([
                    'meta[property="og:title"]', 'meta[name="twitter:title"]',
                    'meta[name="title"]'
                ]) || jsonLd.title || (document.title || '');
                var poster = firstMeta([
                    'meta[property="og:image"]', 'meta[property="og:image:secure_url"]',
                    'meta[name="twitter:image"]', 'meta[name="twitter:image:src"]',
                    'meta[property="og:video:thumbnail"]'
                ]) || jsonLd.poster;
                var durationRaw = firstMeta([
                    'meta[property="og:video:duration"]', 'meta[property="video:duration"]',
                    'meta[itemprop="duration"]'
                ]);
                var duration = parseDurationSeconds(durationRaw) || jsonLd.duration;
                return {
                    title: String(title || '').trim().slice(0, 300),
                    poster: safeUrl(poster) || '',
                    duration: duration || 0,
                    mediaUrl: jsonLd.mediaUrl || ''
                };
            }

            var lastPageMetadataKey = '';
            function reportPageMetadata() {
                var metadata = readPageMetadata();
                var key = metadata.title + '|' + metadata.poster + '|' + metadata.duration + '|' + metadata.mediaUrl;
                if (!metadata.title && !metadata.poster && !metadata.duration && !metadata.mediaUrl) return;
                if (key === lastPageMetadataKey) return;
                lastPageMetadataKey = key;
                bridgeCall('onPageMetadata', [metadata.title, metadata.poster, metadata.duration]);
                // JSON-LD VideoObject.contentUrl is an additional standard, page-visible pre-play
                // source. Use it only on Meta pages and let native host/MIME validation decide.
                try {
                    var pageHost = String(location.hostname || '').toLowerCase();
                    var metaPage = pageHost === 'facebook.com' || pageHost.endsWith('.facebook.com') ||
                        pageHost === 'fb.watch' || pageHost.endsWith('.fb.watch') ||
                        pageHost === 'instagram.com' || pageHost.endsWith('.instagram.com') ||
                        pageHost === 'threads.com' || pageHost.endsWith('.threads.com') ||
                        pageHost === 'threads.net' || pageHost.endsWith('.threads.net');
                    if (metaPage && metadata.mediaUrl) {
                        bridgeCall('onVideoFound', [metadata.mediaUrl, metadata.title || 'Social video', metadata.duration || 0, '', metadata.poster, false, 'video/mp4', 'meta-jsonld']);
                    }
                } catch (e) {}
            }

            // TikTok's player source is frequently embedded in hydration JSON rather than exposed
            // through a plain <video src>. Inspect only known TikTok state objects and video
            // address fields; do not scrape arbitrary page URLs or interfere with playback.
            var tikTokReportedUrls = new Set();
            function isTikTokPage() {
                try {
                    var host = String(location.hostname || '').toLowerCase();
                    return host === 'tiktok.com' || host.endsWith('.tiktok.com');
                } catch (e) { return false; }
            }
            function isLikelyTikTokVideoResourceUrl(rawUrl) {
                if (!isTikTokPage() || !rawUrl) return false;
                try {
                    var u = new URL(rawUrl, document.baseURI);
                    var host = String(u.hostname || '').toLowerCase();
                    var path = String(u.pathname || '').toLowerCase();
                    var query = String(u.search || '').toLowerCase();
                    var knownMediaHost = /(?:^|\.)tiktokcdn(?:-[a-z0-9]+)?\.com$/.test(host) ||
                        /(?:^|\.)tiktokv\.com$/.test(host) || /(?:^|\.)byteoversea\.com$/.test(host) ||
                        /(?:^|\.)ibytedtos\.com$/.test(host) || /(?:^|\.)byteicdn\.com$/.test(host) ||
                        /(?:^|\.)muscdn\.com$/.test(host);
                    var akamaiHost = /\.akamaized\.net$/.test(host);
                    var knownHost = host === 'tiktok.com' || host.endsWith('.tiktok.com') || knownMediaHost || akamaiHost;
                    if (!knownHost) return false;
                    var explicitMime = /(?:[?&])mime_type=(?:video_mp4|video%2fmp4|video\/mp4|video_webm|video%2fwebm)(?:&|$)/i.test(query);
                    var videoPath = /\/video\/tos\//i.test(path) || /\/obj\/tos(?:[-/])/i.test(path) ||
                        /\/aweme\/v1\/play(?:wm)?\//i.test(path) || /\/media-video-hvc1\//i.test(path) ||
                        (/\/video\//i.test(path) && /(?:[?&](?:video_id|aweme_id)=)/i.test(query));
                    if (akamaiHost && !explicitMime) return false;
                    return explicitMime || videoPath;
                } catch (e) { return false; }
            }

            function tikTokTargetVideoId() {
                try {
                    var m = /\/video\/(\d+)/.exec(String(location.pathname || ''));
                    return m ? m[1] : '';
                } catch (e) { return ''; }
            }

            // Parse JSON returned by the page's own fetch/XHR calls. This is not an external
            // downloader API: it observes first-party page data that the browser already requested.
            // It only emits URLs explicitly nested under known video address fields.
            function scanTikTokJsonData(root) {
                if (!isTikTokPage() || !root || typeof root !== 'object') return 0;
                var visited = 0;
                var emitted = 0;
                var targetId = tikTokTargetVideoId();
                function inspect(value, depth) {
                    if (!value || depth > 22 || visited++ > 12000) return;
                    if (Array.isArray(value)) {
                        for (var ai = 0; ai < Math.min(value.length, 1000); ai++) inspect(value[ai], depth + 1);
                        return;
                    }
                    if (typeof value !== 'object') return;
                    var video = value.video && typeof value.video === 'object' ? value.video : null;
                    if (video) {
                        var urls = [];
                        ['playAddr', 'play_addr', 'downloadAddr', 'download_addr', 'play_addr_h264', 'play_addr_bytevc1'].forEach(function (key) {
                            if (Object.prototype.hasOwnProperty.call(video, key)) addTikTokAddress(video[key], urls, 0);
                        });
                        var bitrates = video.bitrateInfo || video.bitrate_info || video.bit_rate || video.bitRate;
                        if (Array.isArray(bitrates)) {
                            for (var bi = 0; bi < Math.min(bitrates.length, 12); bi++) {
                                var entry = bitrates[bi];
                                if (!entry || typeof entry !== 'object') continue;
                                addTikTokAddress(entry.PlayAddr || entry.playAddr || entry.play_addr || entry.play_addr_h264, urls, 0);
                            }
                        }
                        var videoId = String(value.id || value.awemeId || value.aweme_id || video.id || '');
                        if (urls.length && (!targetId || !videoId || targetId === videoId)) {
                            var meta = readPageMetadata();
                            var title = String(value.desc || value.title || meta.title || document.title || 'TikTok Video')
                                .replace(/[\r\n\t]+/g, ' ').trim().slice(0, 300);
                            var poster = tikTokCover(video.cover) || tikTokCover(video.originCover) ||
                                tikTokCover(video.dynamicCover) || meta.poster || '';
                            var duration = parseDurationSeconds(video.duration || 0);
                            urls.forEach(function (raw) {
                                var url = safeUrl(raw);
                                if (!url || tikTokReportedUrls.has(url)) return;
                                tikTokReportedUrls.add(url);
                                bridgeCall('onVideoFound', [url, title, duration, '', poster, anyVideoPlaying(), 'video/mp4',
                                    'tiktok-json-' + String(videoId || 'page').slice(0, 80)]);
                                emitted++;
                            });
                        }
                    }
                    Object.keys(value).forEach(function (key) {
                        var child = value[key];
                        if (child && typeof child === 'object' && visited < 12000) inspect(child, depth + 1);
                    });
                }
                try { inspect(root, 0); } catch (e) {}
                return emitted;
            }

            function addTikTokAddress(value, output, depth) {
                if (value == null || depth > 5 || output.length >= 12) return;
                if (typeof value === 'string') {
                    var url = safeUrl(value);
                    if (url && !isSegmentUrl(url) && output.indexOf(url) < 0) output.push(url);
                    return;
                }
                if (Array.isArray(value)) {
                    for (var i = 0; i < Math.min(value.length, 20); i++) addTikTokAddress(value[i], output, depth + 1);
                    return;
                }
                if (typeof value === 'object') {
                    ['UrlList', 'urlList', 'url_list', 'url_list_v2', 'url', 'uri', 'Uri'].forEach(function (key) {
                        if (output.length < 12 && Object.prototype.hasOwnProperty.call(value, key)) {
                            addTikTokAddress(value[key], output, depth + 1);
                        }
                    });
                }
            }
            function tikTokCover(value) {
                var urls = [];
                addTikTokAddress(value, urls, 0);
                return urls.length ? urls[0] : '';
            }
            function scanTikTokEmbeddedMedia() {
                if (!isTikTokPage()) return 0;
                var roots = [];
                try {
                    ['SIGI_STATE', '__UNIVERSAL_DATA_FOR_REHYDRATION__', '__NEXT_DATA__'].forEach(function (name) {
                        var value = window[name];
                        if (value && typeof value === 'object') roots.push(value);
                        else if (typeof value === 'string' && value.length < 8000000) {
                            try { roots.push(JSON.parse(value)); } catch (e) {}
                        }
                    });
                    ['SIGI_STATE', '__UNIVERSAL_DATA_FOR_REHYDRATION__', '__NEXT_DATA__'].forEach(function (id) {
                        var node = document.getElementById(id);
                        if (!node || !node.textContent) return;
                        try { roots.push(JSON.parse(node.textContent)); } catch (e) {}
                    });
                    // Some TikTok responses embed a raw JSON state script without a stable id.
                    // Parse only bounded scripts whose contents contain known video-state markers.
                    var stateScripts = document.querySelectorAll('script');
                    for (var si = 0; si < Math.min(stateScripts.length, 160); si++) {
                        var scriptText = String(stateScripts[si].textContent || '').trim();
                        if (!scriptText || scriptText.length > 3000000) continue;
                        if (scriptText.indexOf('playAddr') < 0 && scriptText.indexOf('downloadAddr') < 0 && scriptText.indexOf('bitrateInfo') < 0) continue;
                        if (scriptText.charAt(0) === '{' || scriptText.charAt(0) === '[') {
                            try { roots.push(JSON.parse(scriptText)); } catch (e) {}
                        }
                    }
                } catch (e) {}
                if (!roots.length) return 0;

                var visited = 0;
                var results = [];
                var pageVideoId = '';
                try {
                    var idMatch = /\/video\/(\d+)/.exec(String(location.pathname || ''));
                    if (idMatch) pageVideoId = idMatch[1];
                } catch (e) {}
                function inspect(value, depth, parent) {
                    if (!value || depth > 22 || visited++ > 16000) return;
                    if (Array.isArray(value)) {
                        for (var i = 0; i < Math.min(value.length, 1000); i++) inspect(value[i], depth + 1, parent);
                        return;
                    }
                    if (typeof value !== 'object') return;
                    var video = value.video && typeof value.video === 'object' ? value.video : null;
                    if (video) {
                        var urls = [];
                        ['playAddr', 'play_addr', 'downloadAddr', 'download_addr'].forEach(function (key) {
                            if (Object.prototype.hasOwnProperty.call(video, key)) addTikTokAddress(video[key], urls, 0);
                        });
                        var bitrates = video.bitrateInfo || video.bitrate_info;
                        if (Array.isArray(bitrates)) {
                            for (var bi = 0; bi < Math.min(bitrates.length, 8); bi++) {
                                var entry = bitrates[bi];
                                if (!entry || typeof entry !== 'object') continue;
                                addTikTokAddress(entry.PlayAddr || entry.playAddr || entry.play_addr, urls, 0);
                            }
                        }
                        var unique = [];
                        urls.forEach(function (u) { if (unique.indexOf(u) < 0 && unique.length < 8) unique.push(u); });
                        if (unique.length) {
                            var videoId = String(value.id || video.id || value.awemeId || value.aweme_id || '');
                            // A TikTok video page can contain related-video state as well as the
                            // selected post. Do not surface unrelated recommendations when the URL
                            // gives us an exact target ID; still walk children to find that target.
                            if (!pageVideoId || !videoId || videoId === pageVideoId) {
                                var title = (value.desc || value.title || readPageMetadata().title || document.title || 'TikTok Video');
                                title = String(title).replace(/[\r\n\t]+/g, ' ').trim().slice(0, 300);
                                var poster = tikTokCover(video.cover) || tikTokCover(video.originCover) ||
                                    tikTokCover(video.dynamicCover) || readPageMetadata().poster || '';
                                var duration = parseDurationSeconds(video.duration || 0);
                                unique.forEach(function (url, index) {
                                    if (tikTokReportedUrls.has(url)) return;
                                    tikTokReportedUrls.add(url);
                                    // Embedded video-address fields are strong media hints even when the
                                    // CDN uses an extensionless URL. Native code probes the actual response.
                                    bridgeCall('onVideoFound', [url, title, duration, '', poster, anyVideoPlaying(), 'video/mp4',
                                        'tiktok-' + String(videoId || 'player').slice(0, 80)]);
                                    results.push(url);
                                });
                            }
                        }
                    }
                    Object.keys(value).forEach(function (key) {
                        var child = value[key];
                        if (child && typeof child === 'object' && visited < 16000) inspect(child, depth + 1, value);
                    });
                }
                roots.forEach(function (root) { inspect(root, 0, null); });
                return results.length;
            }

            function reportResource(rawUrl, mimeType, playing) {
                var url = safeUrl(rawUrl);
                if (!url) return;
                var effectiveMime = mimeType || (isLikelyTikTokVideoResourceUrl(url) ? 'video/mp4' : '');
                if (!hasMediaSignal(url, effectiveMime)) return;
                try {
                    var cache = window.__vdPlatformMediaResources || (window.__vdPlatformMediaResources = []);
                    cache.push({url:url, mime:effectiveMime || '', playing:!!playing, at:Date.now()});
                    if (cache.length > 80) cache.splice(0, cache.length - 80);
                    var activeVideos = Array.prototype.filter.call(document.querySelectorAll('video'), function(v){ return !v.paused && !v.ended; });
                    if (playing && activeVideos.length === 1) activeVideos[0].__vdLastMediaResourceUrl = url;
                } catch (e) {}
                var key = url;
                var existing = reported.get(key);
                if (existing && (!playing || existing.playing) && existing.mime === effectiveMime) return;
                var hasDomState = !!(existing && existing.domReported);
                var preservedPlaying = hasDomState ? !!existing.playing : (!!playing || !!(existing && existing.playing));
                reported.set(key, { playing: preservedPlaying, mime: effectiveMime || (existing && existing.mime) || '', domReported: hasDomState, metadataSignature: existing && existing.metadataSignature });
                if (reported.size > MAX_REPORTED) {
                    var first = reported.keys().next().value;
                    reported.delete(first);
                }
                bridgeCall('onMediaResourceFound', [url, effectiveMime || '', !!playing]);
            }

            function reportVideo(video, isPlaying) {
                if (!video) return;
                if (!video.__vdPlayerGroupId) {
                    try {
                        video.__vdPlayerGroupId = 'player-' + (nextPlayerId++).toString(36);
                    } catch (e) {}
                }
                var playerGroupId = video.__vdPlayerGroupId || '';
                var urls = [];
                function add(raw, mime, fromVideoElement) {
                    if (raw) urls.push({ raw: raw, mime: mime || '', fromVideoElement: !!fromVideoElement });
                }
                try {
                    var videoMime = video.getAttribute('type') || '';
                    if (video.currentSrc) add(video.currentSrc, videoMime, true);
                    if (video.getAttribute && video.getAttribute('src')) {
                        add(video.getAttribute('src'), videoMime, true);
                    }
                    ['data-src', 'data-video-src', 'data-mp4', 'data-m3u8', 'data-hls'].forEach(function (attr) {
                        var raw = video.getAttribute && video.getAttribute(attr);
                        if (raw) {
                            var hintMime = /m3u8|hls/i.test(attr) ? 'application/vnd.apple.mpegurl' :
                                (/mp4/i.test(attr) ? 'video/mp4' : (videoMime || 'video/mp4'));
                            add(raw, hintMime);
                        }
                    });
                    var sources = video.querySelectorAll ? video.querySelectorAll('source') : [];
                    for (var i = 0; i < sources.length; i++) {
                        var source = sources[i];
                        var sourceMime = source.getAttribute('type') || 'video/mp4';
                        add(source.src || source.getAttribute('src'), sourceMime, true);
                        ['data-src', 'data-mp4', 'data-m3u8', 'data-hls'].forEach(function (attr) {
                            var raw = source.getAttribute && source.getAttribute(attr);
                            if (raw) {
                                var hintMime = /m3u8|hls/i.test(attr) ? 'application/vnd.apple.mpegurl' :
                                    (/mp4/i.test(attr) ? 'video/mp4' : sourceMime);
                                add(raw, hintMime);
                            }
                        });
                    }
                } catch (e) {}

                var title = '';
                var poster = '';
                var duration = 0;
                var resolution = '';
                var activeSourceUrl = '';
                var hasVideoMetadata = false;
                try {
                    var pageMetadata = readPageMetadata();
                    title = pageMetadata.title || (document.title || '').slice(0, 300);
                    poster = video.poster || pageMetadata.poster || '';
                    duration = isFinite(video.duration) && video.duration > 0 ? video.duration : (pageMetadata.duration || 0);
                    activeSourceUrl = safeUrl(video.currentSrc || '');
                    hasVideoMetadata = video.readyState >= 1 && video.videoWidth > 0 && video.videoHeight > 0;
                    if (video.videoWidth > 0 && video.videoHeight > 0) {
                        resolution = video.videoWidth + 'x' + video.videoHeight;
                    }
                } catch (e) {}

                for (var j = 0; j < urls.length; j++) {
                    var item = urls[j];
                    var url = safeUrl(item.raw);
                    if (!url) continue;
                    var mime = item.mime || '';
                    // A URL attached to a real <video>/<source> is strong evidence even if the
                    // CDN hides its extension. Use a provisional MIME; native probing may refine
                    // it to HLS/DASH before download.
                    if (!hasMediaSignal(url, mime) && (hasVideoMetadata || item.fromVideoElement)) {
                        mime = mime || 'video/mp4';
                    }
                    if (!hasMediaSignal(url, mime)) continue;

                    // videoWidth/videoHeight describe only the currently selected source. Never
                    // copy that resolution onto every alternate <source>, or a 240p URL can be
                    // incorrectly labelled 1080p merely because 1080p is currently playing.
                    var itemResolution = (activeSourceUrl && url === activeSourceUrl) ? resolution : '';
                    var metadataSignature = [title, duration || 0, itemResolution, poster, mime, !!isPlaying].join('|');
                    var state = reported.get(url);
                    if (state && state.domReported && state.metadataSignature === metadataSignature) continue;
                    reported.set(url, {
                        playing: !!isPlaying,
                        mime: mime,
                        domReported: true,
                        metadataSignature: metadataSignature
                    });
                    bridgeCall('onVideoFound', [url, title, duration, itemResolution, poster, !!isPlaying, mime, playerGroupId]);
                }

                // A blob: currentSrc cannot itself be downloaded. Still scan the real HTTP resources
                // which commonly back MediaSource/HLS playback instead of silently giving up.
                try { scanPerformance(isPlaying); } catch (e) {}
            }

            function scanLazyMedia() {
                try {
                    var selector = [
                        'video[data-src]', 'video[data-video-src]', 'video[data-mp4]', 'video[data-m3u8]', 'video[data-hls]',
                        'source[data-src]', 'source[data-mp4]', 'source[data-m3u8]', 'source[data-hls]',
                        '[data-video-src]', '[data-mp4]', '[data-m3u8]', '[data-hls]',
                        'meta[property="og:video"]', 'meta[property="og:video:url"]',
                        'meta[name="twitter:player:stream"]', 'link[rel="video_src"]', 'link[rel="preload"][as="video"]'
                    ].join(',');
                    var nodes = document.querySelectorAll(selector);
                    var attrNames = ['src', 'data-src', 'data-video-src', 'data-mp4', 'data-m3u8', 'data-hls', 'content', 'href'];
                    var limit = Math.min(nodes.length, 400);
                    for (var i = 0; i < limit; i++) {
                        var node = nodes[i];
                        var nodeMime = node.getAttribute && node.getAttribute('type') || '';
                        if (!nodeMime && node.tagName) {
                            var tagName = node.tagName.toLowerCase();
                            var metaProperty = (node.getAttribute('property') || '').toLowerCase();
                            var metaName = (node.getAttribute('name') || '').toLowerCase();
                            var linkRel = (node.getAttribute('rel') || '').toLowerCase();
                            if (tagName === 'video' || tagName === 'source' || metaProperty.indexOf('og:video') === 0 ||
                                metaName === 'twitter:player:stream' || linkRel === 'video_src' ||
                                (tagName === 'link' && (node.getAttribute('as') || '').toLowerCase() === 'video')) nodeMime = 'video/mp4';
                        }
                        for (var j = 0; j < attrNames.length; j++) {
                            var raw = node.getAttribute && node.getAttribute(attrNames[j]);
                            var url = safeUrl(raw);
                            if (url && hasMediaSignal(url, nodeMime)) {
                                reportResource(url, nodeMime, anyVideoPlaying());
                            }
                        }
                    }
                } catch (e) {}
            }

            function scanAllVideos() {
                try {
                    var videos = document.querySelectorAll('video');
                    for (var i = 0; i < videos.length; i++) {
                        (function (video) {
                            reportVideo(video, !video.paused && !video.ended);
                            if (video.__vdEventsAttached) return;
                            video.__vdEventsAttached = true;
                            var lastTimeReport = 0;
                            ['play', 'playing', 'pause', 'ended', 'loadedmetadata', 'loadeddata', 'canplay', 'durationchange', 'emptied'].forEach(function (eventName) {
                                video.addEventListener(eventName, function () {
                                    reportVideo(video, !video.paused && !video.ended);
                                }, { passive: true });
                            });
                            video.addEventListener('timeupdate', function () {
                                var now = Date.now();
                                if (now - lastTimeReport > 2500) {
                                    lastTimeReport = now;
                                    reportVideo(video, !video.paused && !video.ended);
                                }
                            }, { passive: true });
                        })(videos[i]);
                    }
                } catch (e) {}
            }

            var lastPerformanceScanAt = 0;
            function scanPerformance(playing) {
                try {
                    // A single long page can create thousands of performance entries. This is
                    // called by several video events, so rate-limit expensive full timing scans.
                    var now = Date.now();
                    if (now - lastPerformanceScanAt < 1400) return;
                    lastPerformanceScanAt = now;
                    var entries = performance.getEntriesByType('resource') || [];
                    for (var i = 0; i < entries.length; i++) {
                        var entry = entries[i];
                        var name = entry && entry.name;
                        if (!name || isSegmentUrl(name)) continue;
                        var initiator = String(entry.initiatorType || '').toLowerCase();
                        var mime = initiator === 'audio' ? 'audio/mp4' : (initiator === 'video' ? 'video/mp4' : '');
                        if (MEDIA_EXT.test(name)) reportResource(name, '', !!playing || anyVideoPlaying());
                        else if (isLikelyTikTokVideoResourceUrl(name)) reportResource(name, 'video/mp4', !!playing || anyVideoPlaying());
                        else if ((initiator === 'video' || initiator === 'audio') && safeUrl(name)) {
                            reportResource(name, mime, !!playing || anyVideoPlaying());
                        }
                    }
                } catch (e) {}
            }


            // Meta platforms (Facebook, Instagram, Threads): inspect only the first-party JSON
            // payloads that the signed-in page itself receives. We do not call private APIs or
            // read/decrypt media bodies; only explicit video-address fields are emitted.
            var metaReportedUrls = new Set();
            function isMetaSocialPage() {
                try {
                    var host = String(location.hostname || '').toLowerCase();
                    return host === 'facebook.com' || host.endsWith('.facebook.com') ||
                        host === 'fb.watch' || host.endsWith('.fb.watch') ||
                        host === 'instagram.com' || host.endsWith('.instagram.com') ||
                        host === 'instagr.am' || host.endsWith('.instagr.am') ||
                        host === 'threads.com' || host.endsWith('.threads.com') ||
                        host === 'threads.net' || host.endsWith('.threads.net');
                } catch (e) { return false; }
            }
            function metaAddressValues(value, output, depth) {
                if (value == null || depth > 4 || output.length >= 12) return;
                if (typeof value === 'string') {
                    var clean = safeUrl(value.replace(/\\u0026/gi, '&').replace(/\\\//g, '/'));
                    if (clean && !isSegmentUrl(clean) && output.indexOf(clean) < 0) output.push(clean);
                    return;
                }
                if (Array.isArray(value)) {
                    for (var i = 0; i < Math.min(value.length, 24); i++) metaAddressValues(value[i], output, depth + 1);
                    return;
                }
                if (typeof value === 'object') {
                    ['url', 'src', 'uri', 'href', 'playable_url', 'video_url'].forEach(function (key) {
                        if (output.length < 12 && Object.prototype.hasOwnProperty.call(value, key)) {
                            metaAddressValues(value[key], output, depth + 1);
                        }
                    });
                }
            }
            function metaPosterFromObject(value, fallback) {
                if (!value || typeof value !== 'object') return fallback || '';
                var keys = ['thumbnail_url', 'thumbnail_src', 'display_url', 'image_url', 'cover_url', 'poster_url'];
                for (var i = 0; i < keys.length; i++) {
                    var values = [];
                    if (Object.prototype.hasOwnProperty.call(value, keys[i])) metaAddressValues(value[keys[i]], values, 0);
                    if (values.length) return values[0];
                }
                var versions = value.image_versions2 && (value.image_versions2.candidates || value.image_versions2);
                var candidates = [];
                metaAddressValues(versions, candidates, 0);
                return candidates[0] || fallback || '';
            }
            var inlineDashReported = new Set();

            // Facebook Reels can publish the DASH MPD inside a first-party GraphQL response,
            // then play the selected representation through MediaSource/SourceBuffer and a blob:
            // URL. Keep a narrowly-scoped map so a visible Reel can be associated with the MPD
            // that produced its buffered segments. This observes requests made by ordinary page
            // playback only; it does not call hidden endpoints, read cookies, inspect/decrypt media
            // payloads, or bypass protected streams. Only matched segment byte lengths are kept.
            var fbDashEntries = [];
            var fbDashRoutes = [];
            var fbSegmentOwnersBySize = new Map();
            var fbBlobToMediaSource = new Map();
            var fbSourceBufferToMediaSource = new WeakMap();
            var fbMediaSourceToEntry = new WeakMap();
            var fbMseHooksInstalled = false;

            function isFacebookPage() {
                var host = String(location.hostname || '').toLowerCase();
                return host === 'facebook.com' || host.endsWith('.facebook.com') ||
                    host === 'fb.com' || host.endsWith('.fb.com') ||
                    host === 'fb.watch' || host.endsWith('.fb.watch');
            }

            function fbDirectChild(node, tagName) {
                if (!node || !node.children) return null;
                var wanted = String(tagName || '').toLowerCase();
                for (var i = 0; i < node.children.length; i++) {
                    if (String(node.children[i].localName || node.children[i].tagName || '').toLowerCase() === wanted) return node.children[i];
                }
                return null;
            }

            function fbResolveChildBase(parentBase, node) {
                var child = fbDirectChild(node, 'BaseURL');
                if (!child) return parentBase;
                var value = String(child.textContent || '').trim();
                if (!value) return parentBase;
                try { return new URL(value, parentBase).href; } catch (e) { return parentBase; }
            }

            function fbAddDashRoute(rawUrl, entry) {
                if (!rawUrl || !entry) return;
                try {
                    var parsed = new URL(rawUrl, entry.responseUrl || location.href);
                    if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') return;
                    var path = parsed.pathname || '/';
                    // For a BaseURL that is a file, use its directory as a route prefix; for a
                    // directory BaseURL, retain the trailing slash. This avoids matching every
                    // media resource on the CDN host.
                    if (!path.endsWith('/')) path = path.substring(0, path.lastIndexOf('/') + 1);
                    if (path.length < 2) return;
                    fbDashRoutes.push({ origin: parsed.origin, prefix: path, entry: entry });
                    if (fbDashRoutes.length > 500) fbDashRoutes.splice(0, fbDashRoutes.length - 500);
                } catch (e) {}
            }

            function registerFacebookDashManifest(xml, responseUrl, itemUrl, itemId, posterUrl, title, duration) {
                if (!isFacebookPage() || typeof xml !== 'string' || xml.length > 1500000) return null;
                if (/<!DOCTYPE|<!ENTITY|<ContentProtection\b/i.test(xml)) return null;
                try {
                    var documentXml = new DOMParser().parseFromString(xml, 'application/xml');
                    if (documentXml.querySelector('parsererror')) return null;
                    var mpd = documentXml.documentElement;
                    if (!mpd || String(mpd.localName || '').toLowerCase() !== 'mpd') return null;
                    var response = safeUrl(responseUrl) || safeUrl(location.href);
                    if (!response) return null;
                    var entry = {
                        xml: xml,
                        responseUrl: response,
                        itemUrl: itemUrl || '',
                        itemId: String(itemId || ''),
                        poster: posterUrl || '',
                        title: String(title || document.title || 'Facebook video').slice(0, 180),
                        duration: Number(duration || 0),
                        createdAt: Date.now()
                    };
                    var rootBase = fbResolveChildBase(response, mpd);
                    var periods = mpd.getElementsByTagName('Period');
                    var period = periods && periods.length ? periods[0] : null;
                    var periodBase = period ? fbResolveChildBase(rootBase, period) : rootBase;
                    var adaptations = period ? period.children : [];
                    for (var ai = 0; ai < adaptations.length; ai++) {
                        var adaptation = adaptations[ai];
                        if (String(adaptation.localName || '').toLowerCase() !== 'AdaptationSet') continue;
                        var adaptationBase = fbResolveChildBase(periodBase, adaptation);
                        var representations = adaptation.children || [];
                        for (var ri = 0; ri < representations.length; ri++) {
                            var representation = representations[ri];
                            if (String(representation.localName || '').toLowerCase() !== 'Representation') continue;
                            var representationBase = fbResolveChildBase(adaptationBase, representation);
                            if (representationBase !== response) fbAddDashRoute(representationBase, entry);
                            // Some MPDs place media templates on AdaptationSet/Representation.
                            // Add only the stable directory prefix; token expansion is left to
                            // the DASH parser in the native layer.
                            var template = fbDirectChild(representation, 'SegmentTemplate') ||
                                fbDirectChild(adaptation, 'SegmentTemplate') ||
                                (period && fbDirectChild(period, 'SegmentTemplate')) || fbDirectChild(mpd, 'SegmentTemplate');
                            var mediaTemplate = template && template.getAttribute('media');
                            if (mediaTemplate) {
                                try {
                                    var resolvedTemplate = new URL(mediaTemplate.replace(/\$[^$]+\$/g, 'vd-token'), representationBase).href;
                                    fbAddDashRoute(resolvedTemplate, entry);
                                } catch (e) {}
                            }
                            var segmentList = fbDirectChild(representation, 'SegmentList') ||
                                fbDirectChild(adaptation, 'SegmentList') ||
                                (period && fbDirectChild(period, 'SegmentList')) || fbDirectChild(mpd, 'SegmentList');
                            if (segmentList) {
                                var segmentUrls = segmentList.getElementsByTagName('SegmentURL');
                                for (var si = 0; si < Math.min(segmentUrls.length, 200); si++) {
                                    var mediaPath = segmentUrls[si].getAttribute('media');
                                    if (!mediaPath) continue;
                                    try { fbAddDashRoute(new URL(mediaPath, representationBase).href, entry); } catch (e) {}
                                }
                            }
                        }
                    }
                    fbDashEntries.push(entry);
                    if (fbDashEntries.length > 120) fbDashEntries.splice(0, fbDashEntries.length - 120);
                    return entry;
                } catch (e) { return null; }
            }

            function fbEntriesForSegmentUrl(rawUrl) {
                var result = [];
                try {
                    var parsed = new URL(rawUrl, location.href);
                    for (var i = 0; i < fbDashRoutes.length; i++) {
                        var route = fbDashRoutes[i];
                        if (route.origin === parsed.origin && parsed.pathname.indexOf(route.prefix) === 0 &&
                            Date.now() - route.entry.createdAt < 180000 && result.indexOf(route.entry) < 0) {
                            result.push(route.entry);
                        }
                    }
                } catch (e) {}
                return result;
            }

            function fbRecordSegmentSize(rawUrl, byteLength) {
                if (!isFacebookPage() || !Number.isFinite(byteLength) || byteLength < 1024 || byteLength > 16777216) return;
                var owners = fbEntriesForSegmentUrl(rawUrl);
                if (owners.length !== 1) return;
                var list = fbSegmentOwnersBySize.get(byteLength) || [];
                list.push({ entry: owners[0], at: Date.now() });
                if (list.length > 12) list.splice(0, list.length - 12);
                fbSegmentOwnersBySize.set(byteLength, list);
                if (fbSegmentOwnersBySize.size > 500) fbSegmentOwnersBySize.delete(fbSegmentOwnersBySize.keys().next().value);
            }

            function fbUniqueEntryForSize(byteLength) {
                var list = (fbSegmentOwnersBySize.get(byteLength) || []).filter(function (item) {
                    return Date.now() - item.at < 15000;
                });
                var unique = [];
                list.forEach(function (item) {
                    var key = item.entry.itemUrl || item.entry.itemId || item.entry.poster;
                    if (key && !unique.some(function (entry) {
                        return (entry.itemUrl || entry.itemId || entry.poster) === key;
                    })) unique.push(item.entry);
                });
                return unique.length === 1 ? unique[0] : null;
            }

            function installFacebookMseObserver() {
                if (!isFacebookPage() || fbMseHooksInstalled) return;
                fbMseHooksInstalled = true;
                try {
                    if (window.URL && typeof URL.createObjectURL === 'function') {
                        var originalCreateObjectUrl = URL.createObjectURL;
                        URL.createObjectURL = function (object) {
                            var result = originalCreateObjectUrl.apply(this, arguments);
                            try {
                                if (window.MediaSource && object instanceof MediaSource) {
                                    fbBlobToMediaSource.set(String(result), object);
                                    if (fbBlobToMediaSource.size > 120) fbBlobToMediaSource.delete(fbBlobToMediaSource.keys().next().value);
                                }
                            } catch (e) {}
                            return result;
                        };
                        var originalRevokeObjectUrl = URL.revokeObjectURL;
                        URL.revokeObjectURL = function (url) {
                            try { fbBlobToMediaSource.delete(String(url || '')); } catch (e) {}
                            return originalRevokeObjectUrl.apply(this, arguments);
                        };
                    }
                } catch (e) {}
                try {
                    if (window.MediaSource && MediaSource.prototype.addSourceBuffer && !MediaSource.prototype.addSourceBuffer.__vdWrapped) {
                        var originalAddSourceBuffer = MediaSource.prototype.addSourceBuffer;
                        var wrappedAddSourceBuffer = function () {
                            var buffer = originalAddSourceBuffer.apply(this, arguments);
                            try { fbSourceBufferToMediaSource.set(buffer, this); } catch (e) {}
                            return buffer;
                        };
                        wrappedAddSourceBuffer.__vdWrapped = true;
                        MediaSource.prototype.addSourceBuffer = wrappedAddSourceBuffer;
                    }
                } catch (e) {}
                try {
                    if (window.SourceBuffer && SourceBuffer.prototype.appendBuffer && !SourceBuffer.prototype.appendBuffer.__vdWrapped) {
                        var originalAppendBuffer = SourceBuffer.prototype.appendBuffer;
                        var wrappedAppendBuffer = function (data) {
                            try {
                                var size = data && typeof data.byteLength === 'number' ? Number(data.byteLength) : 0;
                                var entry = size ? fbUniqueEntryForSize(size) : null;
                                var mediaSource = fbSourceBufferToMediaSource.get(this);
                                if (entry && mediaSource) fbMediaSourceToEntry.set(mediaSource, entry);
                            } catch (e) {}
                            return originalAppendBuffer.apply(this, arguments);
                        };
                        wrappedAppendBuffer.__vdWrapped = true;
                        SourceBuffer.prototype.appendBuffer = wrappedAppendBuffer;
                    }
                } catch (e) {}
                window.__vdFacebookMse = {
                    entryForVideo: function (video) {
                        try {
                            if (!video) return null;
                            var src = String(video.currentSrc || video.src || '');
                            var mediaSource = fbBlobToMediaSource.get(src);
                            if (mediaSource) return fbMediaSourceToEntry.get(mediaSource) || null;
                            var poster = String(video.poster || video.getAttribute('poster') || '');
                            if (poster) {
                                var matches = fbDashEntries.filter(function (entry) {
                                    return entry.poster && entry.poster === poster && Date.now() - entry.createdAt < 180000;
                                });
                                if (matches.length === 1) return matches[0];
                            }
                        } catch (e) {}
                        return null;
                    }
                };
            }

            installFacebookMseObserver();

            function metaPlatformHostMatches(url) {
                try {
                    var targetHost = String(new URL(url, document.baseURI).hostname || '').toLowerCase();
                    var pageHost = String(location.hostname || '').toLowerCase();
                    function group(host) {
                        if (host === 'facebook.com' || host.endsWith('.facebook.com') || host === 'fb.watch' || host.endsWith('.fb.watch')) return 'facebook';
                        if (host === 'instagram.com' || host.endsWith('.instagram.com') || host === 'instagr.am' || host.endsWith('.instagr.am')) return 'instagram';
                        if (host === 'threads.com' || host.endsWith('.threads.com') || host === 'threads.net' || host.endsWith('.threads.net')) return 'threads';
                        return '';
                    }
                    return !!group(pageHost) && group(pageHost) === group(targetHost);
                } catch (e) { return false; }
            }
            function metaItemPermalink(value) {
                if (!value || typeof value !== 'object') return '';
                var keys = ['permalink_url', 'permalinkUrl', 'permalink', 'share_url', 'shareUrl', 'post_url', 'postUrl', 'canonical_url', 'canonicalUrl', 'story_url', 'storyUrl', 'web_url', 'url'];
                for (var i = 0; i < keys.length; i++) {
                    var raw = value[keys[i]];
                    if (typeof raw !== 'string') continue;
                    var candidate = safeUrl(raw);
                    if (!candidate || !metaPlatformHostMatches(candidate)) continue;
                    try {
                        var path = new URL(candidate).pathname.toLowerCase();
                        if (/\/(?:reel|reels|stories|story\.php|share|p|posts|post|watch|videos|video\.php|tv)(?:\/|$)/i.test(path) ||
                            /\/story\.php$/i.test(path)) return candidate;
                    } catch (e) {}
                }
                return '';
            }
            function findInlineMpdText(raw, depth) {
                if (depth > 5 || raw == null) return '';
                if (typeof raw === 'string') {
                    var candidate = raw.trim();
                    if (candidate.length > 1500000) return '';
                    candidate = candidate.replace(/\\u003c/gi, '<').replace(/\\u003e/gi, '>')
                        .replace(/&lt;/gi, '<').replace(/&gt;/gi, '>');
                    return /<MPD(?:\s|>)/i.test(candidate) && /<\/MPD\s*>/i.test(candidate) ? candidate : '';
                }
                if (Array.isArray(raw)) {
                    for (var i = 0; i < Math.min(raw.length, 8); i++) {
                        var nestedArrayValue = findInlineMpdText(raw[i], depth + 1);
                        if (nestedArrayValue) return nestedArrayValue;
                    }
                    return '';
                }
                if (typeof raw === 'object') {
                    var keys = ['manifest', 'mpd', 'xml', 'text', 'data', 'dash_manifest', 'value'];
                    for (var j = 0; j < keys.length; j++) {
                        if (!Object.prototype.hasOwnProperty.call(raw, keys[j])) continue;
                        var nestedValue = findInlineMpdText(raw[keys[j]], depth + 1);
                        if (nestedValue) return nestedValue;
                    }
                }
                return '';
            }
            function emitInlineDashManifest(value, key, raw, responseUrl, inheritedItemUrl, inheritedItemId, inheritedPoster) {
                if (!/dash_manifest/i.test(String(key || ''))) return;
                var xml = findInlineMpdText(raw, 0);
                if (!xml) return;
                if (xml.length > 1500000) return;
                // JSON strings normally arrive decoded; handle common HTML/JSON escaped forms too.
                xml = xml.replace(/\\u003c/gi, '<').replace(/\\u003e/gi, '>')
                    .replace(/\\u0026/gi, '&').replace(/&lt;/gi, '<').replace(/&gt;/gi, '>')
                    .replace(/&quot;/gi, '"').replace(/&#39;/gi, "'");
                if (!/<MPD(?:\s|>)/i.test(xml) || !/<\/MPD\s*>/i.test(xml)) return;
                // DRM / XML external entity documents are never passed to the native downloader.
                if (/<!DOCTYPE|<!ENTITY|<ContentProtection\b/i.test(xml)) return;
                var baseUrl = safeUrl(responseUrl) || safeUrl(location.href);
                if (!baseUrl || !metaPlatformHostMatches(baseUrl)) baseUrl = safeUrl(location.href);
                if (!baseUrl) return;
                var itemUrl = metaItemPermalink(value) || inheritedItemUrl || '';
                try {
                    var pagePath = String(location.pathname || '').toLowerCase();
                    if (!itemUrl && /\/(?:reel|reels|stories|story\.php|share|p|posts|post|watch|videos|video\.php|tv)(?:\/|$)/i.test(pagePath)) {
                        itemUrl = safeUrl(location.href) || '';
                    }
                } catch (e) {}
                // A permalink is preferred. If the GraphQL media node omits it, only a unique
                // media-specific poster may be used for an exact overlay match; never use the
                // page-wide og:image for a feed item.
                var caption = value && (value.caption || value.title || value.name || value.text);
                if (caption && typeof caption === 'object') caption = caption.text || caption.title || '';
                var meta = readPageMetadata();
                var title = String(caption || meta.title || document.title || 'Facebook video').replace(/[\r\n\t]+/g, ' ').trim().slice(0, 180);
                // Avoid exposing opaque CDN/GraphQL IDs as the user-facing media title.
                if (!title || /^[A-Za-z0-9_-]{36,}$/.test(title) || /^https?:\/\//i.test(title)) title = 'Facebook video';
                // Keep a media-specific poster separate from a page-wide og:image. The native
                // resolver may use the exact poster URL to associate an inline MPD when a GraphQL
                // object does not expose a permalink field.
                var specificPoster = metaPosterFromObject(value, '') || inheritedPoster || '';
                var poster = specificPoster || meta.poster || '';
                var duration = parseDurationSeconds(value && (value.video_duration || value.videoDuration || value.duration || 0)) || meta.duration || 0;
                var itemId = String(value && (value.video_id || value.videoId || value.reel_id || value.reelId || value.media_id || value.id || value.pk || value.code) || inheritedItemId || '');
                if (!itemUrl && /^\d{6,}$/.test(itemId) && isFacebookPage()) {
                    itemUrl = 'https://www.facebook.com/reel/' + itemId;
                }
                if (!itemUrl && !specificPoster) return;
                var fingerprint = (itemUrl || specificPoster) + '|' + itemId + '|' + xml.length + '|' + xml.slice(0, 96);
                if (inlineDashReported.has(fingerprint)) return;
                inlineDashReported.add(fingerprint);
                if (inlineDashReported.size > 40) inlineDashReported.delete(inlineDashReported.values().next().value);
                registerFacebookDashManifest(xml, baseUrl, itemUrl, itemId, specificPoster, title, duration);
                bridgeCall('onInlineDashManifestFound', [xml, baseUrl, title, duration, specificPoster, itemUrl]);
            }

            function parseMetaJsonText(text) {
                if (typeof text !== 'string' || !text || text.length > 2500000) return null;
                var value = text.trim();
                // Meta endpoints sometimes prefix JSON with an anti-XSSI sentinel.
                value = value.replace(/^(?:for\s*\(\s*;;\s*\)|while\s*\(\s*1\s*\)|\)\]\}')\s*;?\s*/i, '');
                try { return JSON.parse(value); } catch (e) {}
                // Some batched GraphQL responses are newline-delimited JSON objects.
                var rows = value.split(/\r?\n/).map(function (line) {
                    line = line.trim();
                    if (!line || line === 'for (;;);') return null;
                    try { return JSON.parse(line.replace(/^for\s*\(\s*;;\s*\)\s*;?\s*/i, '')); } catch (e) { return null; }
                }).filter(Boolean);
                return rows.length ? rows : null;
            }

            function scanMetaJsonData(root, responseUrl) {
                if (!isMetaSocialPage() || !root || typeof root !== 'object') return 0;
                var visited = 0, emitted = 0;
                var directVideoKeys = {
                    playable_url_quality_hd: 100, browser_native_hd_url: 98, browser_native_sd_url: 76,
                    playable_url: 92, video_url: 94, videourl: 90, playback_url: 92,
                    video_url_original: 92, post_video_url: 90, video_playable_url: 94,
                    player_video_url: 92, sd_src: 74, hd_src: 88, progressive_url: 82,
                    play_addr: 90, download_addr: 88, download_url: 86,
                    video_dash_manifest_url: 97, dash_manifest_url: 96, video_dash_manifest: 95,
                    dash_manifest: 95, manifest_url: 78,
                    hls_manifest_url: 95, hls_url: 94, video_hls_manifest: 94, hls_manifest: 94
                };
                function emitFromObject(value, key, raw, inheritedItemUrl) {
                    var urls = [];
                    metaAddressValues(raw, urls, 0);
                    if (!urls.length) return;
                    var meta = readPageMetadata();
                    var caption = value && (value.caption || value.title || value.name || value.text);
                    if (caption && typeof caption === 'object') caption = caption.text || caption.title || '';
                    var title = String(caption || meta.title || document.title || 'Social video')
                        .replace(/[\r\n\t]+/g, ' ').trim().slice(0, 280);
                    // Only a media-specific poster may be used to associate this stream with a
                    // feed card. Never key a Reel candidate by the page-wide og:image.
                    var poster = metaPosterFromObject(value, '');
                    var duration = parseDurationSeconds(value && (value.video_duration || value.videoDuration || value.duration || 0)) || meta.duration || 0;
                    var id = String((value && (value.id || value.pk || value.media_id || value.code || value.video_id)) || '')
                        .replace(/[^a-zA-Z0-9_.:-]/g, '').slice(0, 80);
                    urls.forEach(function (url) {
                        if (!url || metaReportedUrls.has(url)) return;
                        metaReportedUrls.add(url);
                        var lower = url.toLowerCase();
                        var mime = key.indexOf('hls') >= 0 || lower.indexOf('.m3u8') >= 0 ? 'application/vnd.apple.mpegurl' :
                            (key.indexOf('dash') >= 0 || lower.indexOf('.mpd') >= 0 ? 'application/dash+xml' : 'video/mp4');
                        var itemUrl = metaItemPermalink(value) || inheritedItemUrl || '';
                        bridgeCall('onMetaVideoFound', [url, title, duration, poster, false, mime,
                            'meta-' + (id || 'page'), itemUrl]);
                        emitted++;
                    });
                }
                function inspect(value, depth, inVideoVersions, inheritedItemUrl, inheritedItemId, inheritedPoster) {
                    if (!value || depth > 22 || visited++ > 18000) return;
                    if (Array.isArray(value)) {
                        for (var ai = 0; ai < Math.min(value.length, 500); ai++) inspect(value[ai], depth + 1, inVideoVersions, inheritedItemUrl, inheritedItemId, inheritedPoster);
                        return;
                    }
                    if (typeof value !== 'object') return;
                    var itemUrlContext = metaItemPermalink(value) || inheritedItemUrl || '';
                    var itemIdContext = String(value.video_id || value.videoId || value.reel_id || value.reelId || value.media_id || inheritedItemId || '');
                    var posterContext = metaPosterFromObject(value, '') || inheritedPoster || '';
                    var explicitVideo = value.is_video === true || value.isVideo === true ||
                        value.media_type === 2 || value.product_type === 'clips' || inVideoVersions;
                    Object.keys(value).slice(0, 250).forEach(function (key) {
                        if (visited > 18000) return;
                        var normalized = key.toLowerCase();
                        var child = value[key];
                        if (Object.prototype.hasOwnProperty.call(directVideoKeys, normalized)) {
                            if (/dash_manifest/i.test(normalized) && (normalized !== 'dash_manifest' || isFacebookPage())) {
                                emitInlineDashManifest(value, normalized, child, responseUrl, itemUrlContext, itemIdContext, posterContext);
                            }
                            emitFromObject(value, normalized, child, itemUrlContext);
                        } else if (explicitVideo && /^(?:url|src|uri|play_addr|playaddr|download_url)$/.test(normalized) && typeof child === 'string') {
                            emitFromObject(value, normalized, child, itemUrlContext);
                        } else if (normalized === 'video_versions' || normalized === 'video_resources' || normalized === 'bitrate_info') {
                            if (Array.isArray(child)) {
                                for (var vi = 0; vi < Math.min(child.length, 32); vi++) {
                                    var entry = child[vi];
                                    if (!entry || typeof entry !== 'object') continue;
                                    var candidate = entry.url || entry.src || entry.uri || entry.playable_url ||
                                        entry.video_url || entry.download_url || entry.play_addr || entry.playAddr;
                                    if (candidate) emitFromObject(value, normalized, candidate, itemUrlContext);
                                }
                            } else if (child && typeof child === 'object') {
                                inspect(child, depth + 1, true, itemUrlContext, itemIdContext, posterContext);
                            }
                        } else if (child && typeof child === 'object') {
                            var nextVideoContext = explicitVideo || normalized === 'video' || normalized === 'video_data' || normalized === 'media_video';
                            inspect(child, depth + 1, nextVideoContext, itemUrlContext, itemIdContext, posterContext);
                        }
                    });
                }
                try { inspect(root, 0, false, '', '', ''); } catch (e) {}
                return emitted;
            }
            function scanMetaEmbeddedData() {
                if (!isMetaSocialPage()) return 0;
                var roots = [];
                try {
                    ['__additionalDataLoaded', '__initialData', '__RELAY_STORE__', '__NEXT_DATA__', '__APOLLO_STATE__'].forEach(function (name) {
                        var value = window[name];
                        if (value && typeof value === 'object') roots.push(value);
                        else if (typeof value === 'string' && value.length < 2500000) {
                            try { roots.push(JSON.parse(value)); } catch (e) {}
                        }
                    });
                    var scripts = document.querySelectorAll('script');
                    for (var i = 0; i < Math.min(scripts.length, 180); i++) {
                        var text = String(scripts[i].textContent || '').trim();
                        if (!text || text.length > 2500000) continue;
                        if (text.indexOf('playable_url') < 0 && text.indexOf('video_versions') < 0 &&
                            text.indexOf('video_dash_manifest') < 0 &&
                            !(isFacebookPage() && text.indexOf('dash_manifest') >= 0) &&
                            text.indexOf('browser_native_hd_url') < 0 && text.indexOf('video_url') < 0) continue;
                        try { roots.push(JSON.parse(text)); } catch (e) {}
                    }
                } catch (e) {}
                var emitted = 0;
                roots.forEach(function (root) { emitted += scanMetaJsonData(root, safeUrl(location.href)); });
                return emitted;
            }

            // Observe resource loads whose MIME reveals media even when the URL has no file extension.
            try {
                if (window.fetch && !window.fetch.__vdWrapped) {
                    var originalFetch = window.fetch;
                    var wrappedFetch = function () {
                        var args = arguments;
                        var requestUrl = '';
                        try {
                            requestUrl = typeof args[0] === 'string' ? args[0] : (args[0] && args[0].url) || '';
                        } catch (e) {}
                        var result = originalFetch.apply(this, args);
                        return result.then(function (response) {
                            try {
                                var mime = response && response.headers ? response.headers.get('content-type') : '';
                                if (hasMediaSignal(safeUrl(requestUrl), mime)) reportResource(requestUrl, mime, anyVideoPlaying());
                                if (isFacebookPage() && response && fbEntriesForSegmentUrl(response.url || requestUrl).length === 1) {
                                    var lengthHeader = response.headers ? Number(response.headers.get('content-length') || 0) : 0;
                                    if (lengthHeader > 0) fbRecordSegmentSize(response.url || requestUrl, lengthHeader);
                                    else {
                                        try {
                                            response.clone().arrayBuffer().then(function (buffer) {
                                                if (buffer) fbRecordSegmentSize(response.url || requestUrl, buffer.byteLength);
                                            }).catch(function () {});
                                        } catch (e) {}
                                    }
                                }
                                if (isTikTokPage() && response && /(?:application|text)\/(?:[^;]+\+)?json/i.test(mime || '')) {
                                    try { response.clone().json().then(function (payload) { scanTikTokJsonData(payload); }).catch(function () {}); } catch (e) {}
                                }
                                if (isMetaSocialPage() && response && /(?:application|text)\/(?:[^;]+\+)?json|text\/plain/i.test(mime || '')) {
                                    try {
                                        response.clone().text().then(function (body) {
                                            var payload = parseMetaJsonText(body);
                                            if (payload) scanMetaJsonData(payload, safeUrl(response.url || requestUrl));
                                        }).catch(function () {});
                                    } catch (e) {}
                                }
                            } catch (e) {}
                            return response;
                        });
                    };
                    wrappedFetch.__vdWrapped = true;
                    window.fetch = wrappedFetch;
                }
            } catch (e) {}

            try {
                if (window.XMLHttpRequest && !XMLHttpRequest.prototype.__vdWrapped) {
                    var originalOpen = XMLHttpRequest.prototype.open;
                    var originalSend = XMLHttpRequest.prototype.send;
                    XMLHttpRequest.prototype.open = function (method, url) {
                        try { this.__vdMediaUrl = String(url || ''); } catch (e) { this.__vdMediaUrl = ''; }
                        return originalOpen.apply(this, arguments);
                    };
                    XMLHttpRequest.prototype.send = function () {
                        var xhr = this;
                        if (!xhr.__vdMediaListenerAdded) {
                            xhr.__vdMediaListenerAdded = true;
                            xhr.addEventListener('load', function () {
                                try {
                                    var mime = xhr.getResponseHeader('content-type') || '';
                                    if (isFacebookPage()) {
                                        var xhrUrl = xhr.responseURL || xhr.__vdMediaUrl || '';
                                        if (xhr.responseType === 'arraybuffer' && xhr.response) fbRecordSegmentSize(xhrUrl, xhr.response.byteLength);
                                        else if (xhr.responseType === 'blob' && xhr.response) fbRecordSegmentSize(xhrUrl, xhr.response.size);
                                        else {
                                            var xhrLength = Number(xhr.getResponseHeader('content-length') || 0);
                                            if (xhrLength > 0) fbRecordSegmentSize(xhrUrl, xhrLength);
                                        }
                                    }
                                    if (hasMediaSignal(safeUrl(xhr.__vdMediaUrl), mime)) {
                                        reportResource(xhr.__vdMediaUrl, mime, anyVideoPlaying());
                                    }
                                    if (isTikTokPage() && /(?:application|text)\/(?:[^;]+\+)?json/i.test(mime || '')) {
                                        try {
                                            var payload = xhr.responseType === 'json' ? xhr.response : JSON.parse(xhr.responseText || 'null');
                                            scanTikTokJsonData(payload);
                                        } catch (e) {}
                                    }
                                    if (isMetaSocialPage() && /(?:application|text)\/(?:[^;]+\+)?json|text\/plain/i.test(mime || '')) {
                                        try {
                                            var metaPayload = xhr.responseType === 'json' ? xhr.response : parseMetaJsonText(xhr.responseText || '');
                                            if (metaPayload) scanMetaJsonData(metaPayload, safeUrl(xhr.responseURL || xhr.__vdMediaUrl));
                                        } catch (e) {}
                                    }
                                } catch (e) {}
                            });
                        }
                        return originalSend.apply(this, arguments);
                    };
                    XMLHttpRequest.prototype.__vdWrapped = true;
                }
            } catch (e) {}

            window.__runVideoSniffer = function () {
                reportPageMetadata();
                scanAllVideos();
                scanLazyMedia();
                scanPerformance(anyVideoPlaying());
                // TikTok exposes player media in page hydration JSON on some versions. Run this
                // alongside generic DOM/network sniffing so the existing detection flow receives it.
                try { scanTikTokEmbeddedMedia(); } catch (e) {}
                try { scanMetaEmbeddedData(); } catch (e) {}
                // This means the current DOM/performance scan finished, not that the page
                // can never issue another media request. Later mutations/resources are scanned too.
                bridgeCall('onSnifferScanCompleted', [reported.size]);
                return reported.size;
            };

            var scanScheduled = false;
            var lastMutationScanAt = 0;
            function scheduleScan() {
                if (scanScheduled) return;
                scanScheduled = true;
                // Feed pages mutate their DOM continuously while preview videos play. Avoid a full
                // document scan every animation frame; batch meaningful mutations instead.
                var wait = Math.max(220, 850 - (Date.now() - lastMutationScanAt));
                setTimeout(function () {
                    scanScheduled = false;
                    lastMutationScanAt = Date.now();
                    try { window.__runVideoSniffer(); } catch (e) {}
                }, wait);
            }

            function nodeMayContainMedia(node) {
                try {
                    if (!node || node.nodeType !== 1) return false;
                    var selector = 'video,source,[data-video-src],[data-mp4],[data-m3u8],[data-hls],meta[property^="og:video"],meta[name="twitter:player:stream"],link[rel="video_src"],script#SIGI_STATE,script#__UNIVERSAL_DATA_FOR_REHYDRATION__,script#__NEXT_DATA__';
                    if (node.matches && node.matches(selector)) return true;
                    return !!(node.querySelector && node.querySelector(selector));
                } catch (e) { return false; }
            }

            try {
                var observer = new MutationObserver(function (mutations) {
                    var shouldScan = false;
                    for (var i = 0; i < mutations.length; i++) {
                        var m = mutations[i];
                        if (m.type === 'attributes') {
                            var tag = (m.target && m.target.tagName || '').toUpperCase();
                            if (tag === 'VIDEO' || tag === 'SOURCE' || tag === 'META' || tag === 'LINK' ||
                                (m.target && m.target.matches && m.target.matches('[data-video-src],[data-mp4],[data-m3u8],[data-hls]'))) {
                                shouldScan = true;
                                break;
                            }
                        } else if (m.addedNodes && m.addedNodes.length) {
                            for (var j = 0; j < m.addedNodes.length; j++) {
                                if (nodeMayContainMedia(m.addedNodes[j])) {
                                    shouldScan = true;
                                    break;
                                }
                            }
                            if (shouldScan) break;
                        }
                    }
                    if (shouldScan) scheduleScan();
                });
                observer.observe(document.documentElement || document, {
                    childList: true,
                    subtree: true,
                    attributes: true,
                    attributeFilter: ['src', 'poster', 'href', 'content', 'data-src', 'data-video-src', 'data-mp4', 'data-m3u8', 'data-hls']
                });
            } catch (e) {}

            try {
                if (window.PerformanceObserver) {
                    var performanceObserver = new PerformanceObserver(function (list) {
                        var entries = list.getEntries() || [];
                        for (var i = 0; i < entries.length; i++) {
                            var entry = entries[i];
                            var name = entry && entry.name;
                            if (!name || isSegmentUrl(name)) continue;
                            var initiator = String(entry.initiatorType || '').toLowerCase();
                            if (MEDIA_EXT.test(name)) {
                                reportResource(name, '', anyVideoPlaying());
                            } else if (isLikelyTikTokVideoResourceUrl(name)) {
                                reportResource(name, 'video/mp4', anyVideoPlaying());
                            } else if ((initiator === 'video' || initiator === 'audio') && safeUrl(name)) {
                                reportResource(name, initiator === 'audio' ? 'audio/mp4' : 'video/mp4', anyVideoPlaying());
                            }
                        }
                    });
                    performanceObserver.observe({ entryTypes: ['resource'] });
                }
            } catch (e) {}

            window.__runVideoSniffer();
        })();
    """.trimIndent()
}
