package com.mahabub.downloder.extractor

import com.mahabub.downloder.extractor.ExtractorUtils.unescapeHtml
import com.mahabub.downloder.model.MediaCandidate
import com.mahabub.downloder.model.PlatformSource
import com.mahabub.downloder.model.StreamType
import okhttp3.OkHttpClient
import java.util.regex.Pattern

class PinterestExtractor(private val okHttpClient: OkHttpClient) : PlatformExtractor {

    override val platform: PlatformSource = PlatformSource.PINTEREST

    override fun matches(url: String): Boolean {
        val lower = url.lowercase()
        return lower.contains("pinterest.com") || lower.contains("pin.it")
    }

    override suspend fun extract(url: String): MediaCandidate? {
        return try {
            val request = ExtractorUtils.buildRequest(url)
            val response = okHttpClient.newCall(request).execute()
            if (!response.isSuccessful) return null

            val html = response.body?.string() ?: return null

            var videoUrl = ExtractorUtils.extractMetaTag(html, "og:video")

            if (videoUrl.isNullOrBlank()) {
                val pinPattern = Pattern.compile("(https?://v1\\.pinimg\\.com/videos/[^\"'\\s]+\\.(?:mp4|m3u8))")
                val matcher = pinPattern.matcher(html)
                if (matcher.find()) {
                    videoUrl = matcher.group(1)?.unescapeHtml()
                }
            }

            if (videoUrl.isNullOrBlank()) return null

            val title = ExtractorUtils.extractTitle(html) ?: "Pinterest Video"
            val poster = ExtractorUtils.extractMetaTag(html, "og:image")
            val isHls = videoUrl.contains(".m3u8")

            MediaCandidate(
                id = ExtractorUtils.generateMediaId(),
                url = videoUrl,
                title = title,
                mimeType = if (isHls) "application/vnd.apple.mpegurl" else "video/mp4",
                sourcePageUrl = url,
                sourcePlatform = PlatformSource.PINTEREST,
                streamType = if (isHls) StreamType.HLS else StreamType.PROGRESSIVE,
                thumbnailUrl = poster,
                isDirectDownload = !isHls
            )
        } catch (_: Exception) {
            null
        }
    }
}
