package com.mahabub.downloder.model

import java.net.URI
import java.util.Locale

/** A single logical video with one or more downloadable source/quality choices. */
data class MediaVideoGroup(
    val id: String,
    val title: String,
    val candidates: List<MediaCandidate>,
    val primary: MediaCandidate
)

/**
 * Consolidates duplicate requests and alternate qualities without merging unrelated videos.
 * Strong grouping signals (player identity, a shared poster, or a quality-tagged file stem) are
 * preferred. Otherwise candidates stay separate rather than being merged just because they share
 * the same page title or host.
 */
object MediaCandidateGrouping {

    fun group(
        candidates: List<MediaCandidate>,
        includeLikelyAds: Boolean = false
    ): List<MediaVideoGroup> {
        val unique = candidates.distinctBy { canonicalUrl(it.url) }
        if (unique.isEmpty()) return emptyList()

        val nonAds = unique.filterNot { it.isLikelyAd }
        val visible = if (includeLikelyAds || nonAds.isEmpty()) unique else nonAds
        val groups = LinkedHashMap<String, MutableList<MediaCandidate>>()

        visible.forEach { candidate ->
            val key = groupKey(candidate)
            groups.getOrPut(key) { mutableListOf() }.add(candidate)
        }

        val unsorted = groups.entries.map { (key, values) ->
            val sortedCandidates = values.distinctBy { canonicalUrl(it.url) }
                .sortedWith(
                    compareByDescending<MediaCandidate> { qualityRank(it) }
                        .thenByDescending { it.isDirectDownload }
                        .thenByDescending { it.isPlaying }
                        .thenByDescending { it.detectionConfidence }
                        .thenByDescending { it.contentLength ?: it.estimatedSizeBytes ?: 0L }
                )

            // Different CDN URLs can expose the same resolution. Present one option per known
            // quality instead of duplicate 480p/240p buttons, while preserving separate unknown
            // streams when we do not have enough evidence to compare them.
            val seenQualities = HashSet<String>()
            val sortedOptions = sortedCandidates.filter { item ->
                val label = qualityLabel(item)
                val normalized = label.lowercase(Locale.ROOT)
                if (Regex("\\d{3,4}p").matches(normalized)) seenQualities.add("quality:$normalized")
                else seenQualities.add("url:${canonicalUrl(item.url)}")
            }
            val primary = sortedOptions.first()
            MediaVideoGroup(
                id = key,
                title = displayTitle(primary, sortedOptions),
                candidates = sortedOptions,
                primary = primary
            )
        }

        val titled = unsorted.groupBy { it.title.lowercase(Locale.ROOT) }
        val result = unsorted.map { group ->
            if ((titled[group.title.lowercase(Locale.ROOT)]?.size ?: 0) > 1) {
                val index = unsorted.indexOf(group) + 1
                val uniqueTitle = if (isGenericStreamName(group.title)) {
                    "Video $index"
                } else {
                    "${group.title} · Video $index"
                }
                group.copy(title = uniqueTitle)
            } else group
        }

        return result.sortedWith(
            compareByDescending<MediaVideoGroup> { it.primary.isPlaying }
                .thenByDescending { it.primary.detectionConfidence }
                .thenByDescending { it.candidates.size }
                .thenByDescending { it.primary.detectedAt }
        )
    }

    fun qualityLabel(candidate: MediaCandidate): String {
        // A candidate may point at an alternate source while videoWidth/videoHeight still describe
        // the currently playing variant. Prefer a quality explicitly encoded in THIS source URL
        // so a 100p/240p URL is not mislabeled as the active player's 1080p dimensions.
        val fileName = runCatching {
            URI(candidate.url).path.orEmpty().substringAfterLast('/')
        }.getOrDefault("")
        val filenameDimensions = Regex("(?i)(?:^|[-_.])\\d{2,5}x(\\d{2,5})(?=$|[-_.])")
            .find(fileName)?.groupValues?.getOrNull(1)?.toIntOrNull()
        if (filenameDimensions != null && filenameDimensions > 0) return "${filenameDimensions}p"

        val commonHeights = setOf(144, 160, 180, 240, 360, 480, 540, 720, 1080, 1440, 2160)
        val filenameHeight = Regex("(?i)(?:^|[-_.])(\\d{2,4})p(?=$|[-_.])")
            .find(fileName)?.groupValues?.getOrNull(1)?.toIntOrNull()
        if (filenameHeight != null && (filenameHeight in commonHeights || (filenameHeight < 240 && filenameHeight != 144 && filenameHeight != 180))) {
            return "${filenameHeight}p"
        }

        candidate.qualityLabel?.trim()?.takeIf { it.isNotBlank() }?.let { explicit ->
            val explicitHeight = Regex("(?i)^(\\d{2,4})p$").matchEntire(explicit)
                ?.groupValues?.getOrNull(1)?.toIntOrNull()
            if (explicitHeight != null && (explicitHeight in commonHeights || (explicitHeight < 240 && explicitHeight != 144 && explicitHeight != 180))) {
                return "${explicitHeight}p"
            }
            if (explicitHeight == null) return explicit
            // Odd inferred labels such as 250p are not trusted without source dimensions.
        }

        // Fall back to manifest or media-element dimensions only when the source URL does not
        // carry a more specific variant marker.
        val dimensions = candidate.resolution?.let {
            Regex("^(\\d{2,5})x(\\d{2,5})$", RegexOption.IGNORE_CASE).matchEntire(it)
        }
        val height = dimensions?.groupValues?.getOrNull(2)?.toIntOrNull()
        if (height != null && height > 0) return "${height}p"

        if (candidate.mimeType.orEmpty().startsWith("audio/", ignoreCase = true)) return "Audio"
        return if (candidate.streamType == StreamType.HLS) "Auto" else "Original"
    }

    fun qualityRank(candidate: MediaCandidate): Int {
        val label = qualityLabel(candidate)
        return when {
            label.equals("audio", true) -> -1
            label.equals("original", true) -> 1
            label.equals("auto", true) -> 0
            else -> Regex("(?i)(\\d{3,4})p$").find(label)?.groupValues?.getOrNull(1)?.toIntOrNull() ?: 0
        }
    }

    private fun groupKey(candidate: MediaCandidate): String {
        val sourcePage = pageKey(candidate.sourcePageUrl ?: candidate.url)
        val playerId = candidate.videoGroupId?.takeIf { it.isNotBlank() }
        if (playerId != null) {
            // The video element ID is stable across alternate source URLs. Adding poster/duration
            // to the key made early detections (metadata not loaded yet) split away from the same
            // sources after their thumbnail or duration became available.
            return "player:$sourcePage:$playerId"
        }

        qualityVariantKey(candidate)?.let { return it }

        // If the exact same poster and runtime have been independently reported, those are strong
        // enough to group alternative source URLs. Do not use document title alone: ads often share it.
        val poster = candidate.thumbnailUrl?.takeIf { it.isNotBlank() }
        val duration = candidate.durationSeconds?.takeIf { it > 0.0 }
        if (poster != null && duration != null) {
            return "metadata:$sourcePage:${canonicalUrl(poster).substringBefore('?')}:${(duration / 2.0).toInt()}"
        }

        return "url:${canonicalUrl(candidate.url)}"
    }

    private fun qualityVariantKey(candidate: MediaCandidate): String? {
        val uri = runCatching { URI(candidate.url) }.getOrNull() ?: return null
        val path = uri.path.orEmpty()
        val name = path.substringAfterLast('/').substringBeforeLast('.', path.substringAfterLast('/'))
        val qualityPattern = Regex(
            "(?i)(?:^|[-_.])(?:\\d{3,4}p|\\d{3,4}x\\d{3,4}|240|360|480|540|720|1080|1440|2160)(?=$|[-_.])"
        )
        if (!qualityPattern.containsMatchIn(name)) return null

        var stem = name.replace(qualityPattern, "-")
            .replace(Regex("[-_.]{2,}"), "-")
            .trim('-', '.', '_')
        // Common CDN URLs append a short variant hash after the quality token.
        stem = stem.replace(Regex("(?i)-[a-z0-9]{4,12}$"), "").trim('-', '.', '_')
        if (stem.isBlank()) return null

        val parent = path.substringBeforeLast('/', "")
        val sourcePage = runCatching {
            val page = URI(candidate.sourcePageUrl ?: "")
            "${page.host.orEmpty().lowercase(Locale.ROOT)}${page.path.orEmpty()}"
        }.getOrDefault("")

        // Some streaming hosts use names such as hls-480p-4b3d2.m3u8 and
        // hls-360p-8a712.m3u8. Their only shared stem is generic, but a matching quality tag,
        // HLS extension, media directory and source page form a conservative grouping signal.
        // Never merge generic MP4 names or generic playlists without an explicit quality marker.
        if (isGenericStreamName(stem)) {
            val extension = path.substringAfterLast('.', "").lowercase(Locale.ROOT)
            if (extension != "m3u8" || !qualityPattern.containsMatchIn(name) || parent.isBlank()) return null
            return "variant:${uri.host.orEmpty().lowercase(Locale.ROOT)}:$parent:generic-hls:$sourcePage"
        }

        return "variant:${uri.host.orEmpty().lowercase(Locale.ROOT)}:$parent:$stem:$sourcePage"
    }

    private fun displayTitle(primary: MediaCandidate, candidates: List<MediaCandidate>): String {
        val preferred = candidates.firstNotNullOfOrNull { candidate ->
            candidate.title?.trim()?.takeIf { it.isNotBlank() && !isGenericStreamName(it) }
        }
        if (preferred != null) return preferred.take(180)

        val host = host(primary.sourcePageUrl ?: primary.url).ifBlank { host(primary.url) }
        val fromPath = runCatching {
            URI(primary.url).path.orEmpty().substringAfterLast('/').substringBeforeLast('.')
                .replace(Regex("(?i)(?:[-_.])(?:\\d{3,4}p|\\d{3,4}x\\d{3,4})(?:[-_.].*)?$"), "")
                .replace(Regex("[-_.]+"), " ")
                .trim()
        }.getOrDefault("")
        return fromPath.takeIf { it.isNotBlank() && !isGenericStreamName(it) }
            ?: host.ifBlank { "Detected video" }
    }

    private fun isGenericStreamName(value: String): Boolean {
        val trimmed = value.trim()
        val name = trimmed.substringBeforeLast('.').trim().lowercase(Locale.ROOT)
        val looksLikeMediaFile = Regex("(?i)\\.(?:m3u8|mpd|mp4|m4v|webm|mov|mkv|avi|mp3|m4a|aac|ogg|wav|flac)$")
            .containsMatchIn(trimmed) && trimmed.none { it.isWhitespace() }
        return looksLikeMediaFile || name.isBlank() || name in setOf(
            "video", "detected video", "detected media stream", "media", "stream", "master",
            "playlist", "index", "index-v1-a1", "hls", "manifest", "original"
        ) || name.matches(Regex("(?:hls|stream|index|video|playlist|master)(?:[-_.][a-z0-9]+)*"))
    }

    private fun pageKey(url: String): String = runCatching {
        val uri = URI(url)
        "${uri.scheme.orEmpty().lowercase(Locale.ROOT)}://${uri.host.orEmpty().lowercase(Locale.ROOT)}${uri.path.orEmpty()}"
    }.getOrDefault(url.substringBefore('?').substringBefore('#'))

    private fun host(url: String): String = runCatching { URI(url).host.orEmpty() }
        .getOrDefault("").lowercase(Locale.ROOT)

    private fun canonicalUrl(url: String): String = url.trim().substringBefore('#')
}
