package com.mahabub.downloder.model

enum class DownloadStatus {
    QUEUED,
    DOWNLOADING,
    CONVERTING,
    PAUSED,
    COMPLETED,
    FAILED,
    CANCELED,
    WAITING_FOR_NETWORK
}
