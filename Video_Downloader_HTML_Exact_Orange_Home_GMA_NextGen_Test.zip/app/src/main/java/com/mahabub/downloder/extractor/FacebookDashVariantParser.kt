package com.mahabub.downloder.extractor

import org.w3c.dom.Document
import org.w3c.dom.Element
import org.w3c.dom.Node
import org.w3c.dom.NodeList
import org.xml.sax.InputSource
import java.io.StringReader
import java.io.StringWriter
import javax.xml.XMLConstants
import javax.xml.parsers.DocumentBuilderFactory
import javax.xml.transform.OutputKeys
import javax.xml.transform.TransformerFactory
import javax.xml.transform.dom.DOMSource
import javax.xml.transform.stream.StreamResult
import kotlin.math.roundToLong

/**
 * Creates selectable, single-video-representation MPDs from a Facebook MPD already exposed by the
 * signed-in page. Audio AdaptationSets are retained so the existing DASH downloader can mux the
 * selected video quality with its matching audio. This class does not fetch URLs or bypass DRM.
 */
internal object FacebookDashVariantParser {
    data class Variant(
        val manifestText: String,
        val qualityLabel: String,
        val resolution: String?,
        val bitrate: Long?,
        val durationSeconds: Double?,
        val estimatedSizeBytes: Long?
    )

    private data class VideoRep(
        val adaptationIndex: Int,
        val representationIndex: Int,
        val width: Int,
        val height: Int,
        val bitrate: Long,
        val id: String?
    )

    fun createVariants(rawManifest: String, fallbackDurationSeconds: Double?): List<Variant> {
        val source = rawManifest.trim()
        if (source.length !in 1..1_500_000 ||
            !source.contains("<MPD", ignoreCase = true) ||
            Regex("(?i)<!DOCTYPE|<!ENTITY|<ContentProtection\\b").containsMatchIn(source)
        ) return emptyList()

        val original = parseDocument(source) ?: return emptyList()
        val mpd = original.documentElement ?: return emptyList()
        if (!localName(mpd).equals("MPD", true)) return emptyList()
        val periods = directChildren(mpd).filter { localName(it).equals("Period", true) }
        // The current Native DASH downloader supports one static period only.
        if (periods.size != 1 || mpd.getAttribute("type").equals("dynamic", true)) return emptyList()
        val period = periods.single()
        val adaptations = directChildren(period).filter { localName(it).equals("AdaptationSet", true) }
        if (adaptations.isEmpty()) return emptyList()

        val videoReps = mutableListOf<VideoRep>()
        var bestAudioBitrate = 0L
        adaptations.forEachIndexed { adaptationIndex, adaptation ->
            val reps = directChildren(adaptation).filter { localName(it).equals("Representation", true) }
            val type = adaptationType(adaptation, reps)
            if (type == TrackType.AUDIO) {
                val audioRate = reps.maxOfOrNull { longAttribute(it, "bandwidth") } ?: longAttribute(adaptation, "bandwidth")
                bestAudioBitrate = maxOf(bestAudioBitrate, audioRate)
            } else if (type == TrackType.VIDEO) {
                reps.forEachIndexed { representationIndex, representation ->
                    val width = intAttribute(representation, "width").takeIf { it > 0 }
                        ?: intAttribute(adaptation, "width")
                    val height = intAttribute(representation, "height").takeIf { it > 0 }
                        ?: intAttribute(adaptation, "height")
                    val bitrate = longAttribute(representation, "bandwidth").takeIf { it > 0L }
                        ?: longAttribute(adaptation, "bandwidth")
                    videoReps += VideoRep(
                        adaptationIndex = adaptationIndex,
                        representationIndex = representationIndex,
                        width = width,
                        height = height,
                        bitrate = bitrate,
                        id = representation.getAttribute("id").takeIf { it.isNotBlank() }
                    )
                }
            }
        }
        if (videoReps.isEmpty()) return emptyList()

        val duration = parseDurationSeconds(mpd.getAttribute("mediaPresentationDuration"))
            ?: parseDurationSeconds(period.getAttribute("duration"))
            ?: fallbackDurationSeconds?.takeIf { it.isFinite() && it > 0.0 && it < 86_400.0 }

        // Prefer one option per actual height. When the MPD exposes two encodings at the same
        // height, keep the higher declared bitrate rather than showing duplicate quality tiles.
        val selected = videoReps
            .groupBy { it.height.takeIf { h -> h > 0 }?.toLong() ?: -it.bitrate.coerceAtLeast(1L) }
            .values
            .mapNotNull { group -> group.maxByOrNull { it.bitrate } }
            .sortedWith(compareBy<VideoRep> { it.height }.thenBy { it.bitrate })
            .takeLast(MAX_VARIANTS)

        return selected.mapNotNull { rep ->
            val filtered = filterToRepresentation(source, rep) ?: return@mapNotNull null
            val label = if (rep.height > 0) "${rep.height}p" else if (rep.bitrate > 0L) "${rep.bitrate / 1000L} kbps" else "Original"
            val totalBitrate = (rep.bitrate + bestAudioBitrate).takeIf { it > 0L }
            val estimatedSize = if (duration != null && totalBitrate != null) {
                ((totalBitrate.toDouble() * duration) / 8.0)
                    .takeIf { it.isFinite() && it > 0.0 && it < Long.MAX_VALUE.toDouble() }
                    ?.roundToLong()
            } else null
            Variant(
                manifestText = filtered,
                qualityLabel = label,
                resolution = if (rep.width > 0 && rep.height > 0) "${rep.width}x${rep.height}" else null,
                bitrate = totalBitrate,
                durationSeconds = duration,
                estimatedSizeBytes = estimatedSize
            )
        }
    }

    private fun filterToRepresentation(source: String, selected: VideoRep): String? {
        val document = parseDocument(source) ?: return null
        val mpd = document.documentElement ?: return null
        val period = directChildren(mpd).firstOrNull { localName(it).equals("Period", true) } ?: return null
        val adaptations = directChildren(period).filter { localName(it).equals("AdaptationSet", true) }
        val selectedAdaptation = adaptations.getOrNull(selected.adaptationIndex) ?: return null
        val selectedRepresentation = directChildren(selectedAdaptation)
            .filter { localName(it).equals("Representation", true) }
            .getOrNull(selected.representationIndex) ?: return null

        // Remove alternative video AdaptationSets and Representations while retaining every audio
        // AdaptationSet, its SegmentTemplate/SegmentList inheritance, and MPD/Period BaseURLs.
        adaptations.toList().forEach { adaptation ->
            val reps = directChildren(adaptation).filter { localName(it).equals("Representation", true) }
            if (adaptationType(adaptation, reps) == TrackType.VIDEO) {
                if (adaptation === selectedAdaptation) {
                    reps.filter { it !== selectedRepresentation }.forEach(adaptation::removeChild)
                } else {
                    period.removeChild(adaptation)
                }
            }
        }
        return serialize(document)
    }

    private enum class TrackType { VIDEO, AUDIO, OTHER }

    private fun adaptationType(adaptation: Element, representations: List<Element>): TrackType {
        val explicit = sequenceOf(adaptation.getAttribute("contentType"), adaptation.getAttribute("mimeType"))
            .firstOrNull { it.isNotBlank() }?.lowercase().orEmpty()
        if (explicit.startsWith("video") || explicit == "video") return TrackType.VIDEO
        if (explicit.startsWith("audio") || explicit == "audio") return TrackType.AUDIO
        val representationMimes = representations.map { it.getAttribute("mimeType").lowercase() }
        if (representationMimes.any { it.startsWith("video/") }) return TrackType.VIDEO
        if (representationMimes.any { it.startsWith("audio/") }) return TrackType.AUDIO
        val codecs = (adaptation.getAttribute("codecs") + " " + representations.joinToString(" ") { it.getAttribute("codecs") }).lowercase()
        if (codecs.contains("avc") || codecs.contains("hev") || codecs.contains("hvc") || codecs.contains("vp") || codecs.contains("av01")) return TrackType.VIDEO
        if (codecs.contains("mp4a") || codecs.contains("aac") || codecs.contains("opus") || codecs.contains("ac-3") || codecs.contains("ec-3")) return TrackType.AUDIO
        return TrackType.OTHER
    }

    private fun parseDocument(xml: String): Document? = runCatching {
        val factory = DocumentBuilderFactory.newInstance().apply {
            isNamespaceAware = true
            isXIncludeAware = false
            setExpandEntityReferences(false)
            runCatching { setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true) }
            runCatching { setFeature("http://apache.org/xml/features/disallow-doctype-decl", true) }
            runCatching { setFeature("http://xml.org/sax/features/external-general-entities", false) }
            runCatching { setFeature("http://xml.org/sax/features/external-parameter-entities", false) }
            runCatching { setAttribute("http://javax.xml.XMLConstants/property/accessExternalDTD", "") }
            runCatching { setAttribute("http://javax.xml.XMLConstants/property/accessExternalSchema", "") }
        }
        factory.newDocumentBuilder().parse(InputSource(StringReader(xml)))
    }.getOrNull()

    private fun serialize(document: Document): String? = runCatching {
        val factory = TransformerFactory.newInstance().apply {
            runCatching { setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true) }
            runCatching { setAttribute("http://javax.xml.XMLConstants/property/accessExternalDTD", "") }
            runCatching { setAttribute("http://javax.xml.XMLConstants/property/accessExternalStylesheet", "") }
        }
        val transformer = factory.newTransformer().apply {
            setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes")
            setOutputProperty(OutputKeys.ENCODING, "UTF-8")
        }
        StringWriter().also { writer -> transformer.transform(DOMSource(document), StreamResult(writer)) }
            .toString().takeIf { it.length <= 1_500_000 && it.contains("</MPD", true) }
    }.getOrNull()

    private fun directChildren(node: Node): List<Element> {
        val result = ArrayList<Element>()
        val children: NodeList = node.childNodes
        for (i in 0 until children.length) {
            val child = children.item(i)
            if (child is Element) result += child
        }
        return result
    }

    private fun localName(element: Element): String = element.localName ?: element.nodeName.substringAfter(':')
    private fun intAttribute(element: Element, name: String): Int = element.getAttribute(name).toIntOrNull()?.coerceIn(0, 20_000) ?: 0
    private fun longAttribute(element: Element, name: String): Long = element.getAttribute(name).toLongOrNull()?.coerceAtLeast(0L) ?: 0L

    private fun parseDurationSeconds(raw: String?): Double? {
        val value = raw?.trim()?.takeIf { it.isNotBlank() } ?: return null
        val match = Regex("^P(?:(\\d+(?:\\.\\d+)?)D)?(?:T(?:(\\d+(?:\\.\\d+)?)H)?(?:(\\d+(?:\\.\\d+)?)M)?(?:(\\d+(?:\\.\\d+)?)S)?)?$", RegexOption.IGNORE_CASE)
            .matchEntire(value) ?: return null
        val seconds = (match.groupValues[1].toDoubleOrNull() ?: 0.0) * 86_400.0 +
            (match.groupValues[2].toDoubleOrNull() ?: 0.0) * 3_600.0 +
            (match.groupValues[3].toDoubleOrNull() ?: 0.0) * 60.0 +
            (match.groupValues[4].toDoubleOrNull() ?: 0.0)
        return seconds.takeIf { it.isFinite() && it > 0.0 && it < 86_400.0 }
    }

    private const val MAX_VARIANTS = 8
}
