package com.mahabub.downloder.repository

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.util.Log
import androidx.core.content.ContextCompat
import com.mahabub.downloder.db.AppDatabase
import com.mahabub.downloder.db.DownloadEntity
import com.mahabub.downloder.model.AppError
import com.mahabub.downloder.model.DownloadStatus
import com.mahabub.downloder.model.MediaCandidate
import com.mahabub.downloder.preferences.PreferenceManager
import com.mahabub.downloder.service.DownloadService
import com.mahabub.downloder.storage.SafeFileName
import com.mahabub.downloder.storage.SocialMediaFileName
import com.mahabub.downloder.storage.StorageManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class DownloadRepository(
    context: Context,
    private val database: AppDatabase,
    private val preferenceManager: PreferenceManager,
    private val storageManager: StorageManager
) {

    companion object {
        private const val TAG = "DownloadRepository"
    }

    // Use application context to avoid retaining an Activity.
    private val appContext = context.applicationContext

    private val downloadDao = database.downloadDao()

    // This repository lives for the application lifetime.
    private val appScope =
        CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val connectivityManager =
        appContext.getSystemService(
            Context.CONNECTIVITY_SERVICE
        ) as ConnectivityManager

    val activeDownloads: Flow<List<DownloadEntity>> =
        downloadDao.getActiveDownloads()

    val completedDownloads: Flow<List<DownloadEntity>> =
        downloadDao.getCompletedDownloads()

    // Do not hide failed tasks: TikTok/CDN responses can fail immediately (e.g. expired URL or HTTP 403).
    val failedDownloads: Flow<List<DownloadEntity>> =
        downloadDao.getFailedDownloads()

    val allDownloads: Flow<List<DownloadEntity>> =
        downloadDao.getAllDownloads()

    fun observeDownload(
        id: String
    ): Flow<DownloadEntity?> {
        return downloadDao.observeDownloadById(id)
    }

    /**
     * Check the queue when the network becomes available,
     * is lost, or its capabilities change.
     */
    private val networkCallback =
        object : ConnectivityManager.NetworkCallback() {

            override fun onAvailable(network: Network) {
                scheduleQueueCheck()
            }

            override fun onLost(network: Network) {
                scheduleQueueCheck()
            }

            override fun onCapabilitiesChanged(
                network: Network,
                networkCapabilities: NetworkCapabilities
            ) {
                scheduleQueueCheck()
            }
        }

    init {
        try {
            connectivityManager.registerDefaultNetworkCallback(
                networkCallback
            )
        } catch (e: Exception) {
            Log.w(
                TAG,
                "Could not register network callback",
                e
            )
        }
    }

    private fun scheduleQueueCheck() {
        appScope.launch {
            try {
                checkAndTriggerQueue()
            } catch (e: Exception) {
                Log.e(
                    TAG,
                    "Failed to process download queue",
                    e
                )
            }
        }
    }

    /**
     * Adds a new download to the database and starts the queue.
     */
    suspend fun enqueueDownload(
        candidate: MediaCandidate,
        customFileName: String? = null
    ): String = withContext(Dispatchers.IO) {

        val requiredBytes =
            candidate.contentLength ?: (10 * 1024 * 1024L)

        if (!storageManager.hasEnoughSpace(requiredBytes)) {
            throw AppError.InsufficientStorage
        }

        val extension =
            SafeFileName.getExtensionFromMime(
                candidate.mimeType
            )

        val suppliedName = customFileName?.trim()?.takeIf { it.isNotBlank() }
        val detectedTitle = candidate.title?.trim()?.takeIf { it.isNotBlank() }
        val generatedSocialName = SocialMediaFileName.forVideo(candidate)

        // The selection sheet passes its initial title as `customFileName` even when the user
        // has not edited it. Detect that unchanged default so social media receives the short
        // platform_random13 style. An actually edited custom name is still respected.
        val isDefaultGeneratedSheetTitle = detectedTitle == null &&
            suppliedName?.matches(Regex("video_[0-9]+")) == true
        val userChangedName = suppliedName != null &&
            suppliedName != detectedTitle && !isDefaultGeneratedSheetTitle
        val defaultName = when {
            userChangedName -> suppliedName
            generatedSocialName != null -> generatedSocialName
            else -> suppliedName ?: detectedTitle ?: "video_${System.currentTimeMillis()}"
        }

        val sanitizedFileName = SafeFileName.sanitize(defaultName, extension)

        val entity = DownloadEntity(
            id = candidate.id,
            sourceUrl = candidate.url,
            sourcePageUrl = candidate.sourcePageUrl,
            sourcePlatform = candidate.sourcePlatform,
            streamType = candidate.streamType,
            fileName = sanitizedFileName,
            mimeType = candidate.mimeType,
            totalBytes = candidate.contentLength ?: 0L,
            downloadedBytes = 0L,
            status = DownloadStatus.QUEUED,
            userAgent = candidate.userAgent,
            referer = candidate.referer,
            thumbnailUrl = candidate.thumbnailUrl,
            hlsAudioPlaylistUrl = candidate.hlsAudioPlaylistUrl,
            durationMs = candidate.durationSeconds?.takeIf { it.isFinite() && it > 0.0 && it < 86_400.0 }
                ?.let { (it * 1000.0).toLong() }
        )

        downloadDao.insertDownload(entity)

        checkAndTriggerQueue()

        entity.id
    }

    /**
     * Pauses a download.
     */
    suspend fun pauseDownload(
        id: String
    ) = withContext(Dispatchers.IO) {

        val intent = Intent(
            appContext,
            DownloadService::class.java
        ).apply {
            action = DownloadService.ACTION_PAUSE
            putExtra(
                DownloadService.EXTRA_TASK_ID,
                id
            )
        }

        ContextCompat.startForegroundService(
            appContext,
            intent
        )

        downloadDao.updateStatus(
            id,
            DownloadStatus.PAUSED
        )
    }

    /**
     * Resumes a paused download.
     */
    suspend fun resumeDownload(
        id: String
    ) = withContext(Dispatchers.IO) {

        downloadDao.updateStatus(
            id,
            DownloadStatus.QUEUED
        )

        checkAndTriggerQueue()
    }

    /**
     * Cancels a download.
     */
    suspend fun cancelDownload(
        id: String
    ) = withContext(Dispatchers.IO) {

        val intent = Intent(
            appContext,
            DownloadService::class.java
        ).apply {
            action = DownloadService.ACTION_CANCEL
            putExtra(
                DownloadService.EXTRA_TASK_ID,
                id
            )
        }

        ContextCompat.startForegroundService(
            appContext,
            intent
        )

        downloadDao.updateStatus(
            id,
            DownloadStatus.CANCELED
        )
    }

    /**
     * Retries a failed download.
     */
    suspend fun retryDownload(
        id: String
    ) = withContext(Dispatchers.IO) {

        downloadDao.updateStatus(
            id,
            DownloadStatus.QUEUED
        )

        checkAndTriggerQueue()
    }

    /**
     * Deletes a download record and optionally its saved file.
     */
    suspend fun deleteDownload(
        id: String,
        deleteFile: Boolean = true
    ) = withContext(Dispatchers.IO) {

        val item = downloadDao.getDownloadById(id)

        if (item != null) {
            cancelDownload(id)

            if (
                deleteFile &&
                !item.localUri.isNullOrBlank()
            ) {
                storageManager.deleteMedia(
                    item.localUri
                )
            }

            downloadDao.deleteDownloadById(id)
        }
    }

    /**
     * Renames the saved file and then updates its completed-download record.
     * The media file is renamed first so a failed storage operation never leaves
     * Room pointing at a path that was not successfully changed.
     */
    suspend fun renameCompletedDownload(id: String, requestedName: String) = withContext(Dispatchers.IO) {
        val item = downloadDao.getDownloadById(id)
            ?: throw IllegalArgumentException("This download no longer exists")
        if (item.status != DownloadStatus.COMPLETED) {
            throw IllegalStateException("Only completed downloads can be renamed")
        }
        val currentUri = item.localUri?.takeIf { it.isNotBlank() }
            ?: throw IllegalStateException("The saved file location is missing")
        val fallbackExtension = SafeFileName.getExtensionFromMime(item.mimeType)
        val originalExtension = item.fileName.substringAfterLast('.', "")
            .takeIf { it.matches(Regex("[A-Za-z0-9]{1,10}")) }
            ?: fallbackExtension
        val trimmedRequestedName = requestedName.trim()
        val requestedBase = trimmedRequestedName.substringBeforeLast('.', trimmedRequestedName)
            .ifBlank { "video_${System.currentTimeMillis()}" }
        val safeName = SafeFileName.sanitize("$requestedBase.$originalExtension", originalExtension)
        val (renamedUri, actualName) = storageManager.renameMedia(currentUri, safeName, item.mimeType)
        val updatedRows = downloadDao.updateCompletedFileName(
            id = id,
            fileName = actualName,
            localUri = renamedUri
        )
        if (updatedRows == 0) {
            throw IllegalStateException("The file was renamed, but its library entry could not be updated")
        }
    }

    /**
     * Clears completed download records.
     *
     * Saved media files are intentionally retained.
     */
    suspend fun clearCompleted() = withContext(Dispatchers.IO) {
        downloadDao.clearCompleted()
    }

    /**
     * Pauses all downloads currently marked as downloading.
     */
    suspend fun pauseAll() = withContext(Dispatchers.IO) {

        val downloading =
            downloadDao.getCurrentlyDownloading()

        for (item in downloading) {
            pauseDownload(item.id)
        }
    }

    /**
     * Resumes paused downloads.
     *
     * WAITING_FOR_NETWORK tasks are handled by
     * checkAndTriggerQueue() according to the Wi-Fi setting.
     */
    suspend fun resumeAll() = withContext(Dispatchers.IO) {

        val activeItems =
            downloadDao.getActiveDownloads().first()

        for (item in activeItems) {
            if (item.status == DownloadStatus.PAUSED) {
                downloadDao.updateStatus(
                    item.id,
                    DownloadStatus.QUEUED
                )
            }
        }

        checkAndTriggerQueue()
    }

    /**
     * Returns true when the active network uses Wi-Fi.
     */
    fun isWifiConnected(): Boolean {
        val network =
            connectivityManager.activeNetwork
                ?: return false

        val capabilities =
            connectivityManager.getNetworkCapabilities(
                network
            ) ?: return false

        return capabilities.hasTransport(
            NetworkCapabilities.TRANSPORT_WIFI
        )
    }

    /**
     * Returns true when the active network reports
     * internet capability.
     */
    fun isNetworkAvailable(): Boolean {
        val network =
            connectivityManager.activeNetwork
                ?: return false

        val capabilities =
            connectivityManager.getNetworkCapabilities(
                network
            ) ?: return false

        return capabilities.hasCapability(
            NetworkCapabilities.NET_CAPABILITY_INTERNET
        )
    }

    /**
     * Processes waiting and queued downloads.
     *
     * - With Wi-Fi-only enabled and no Wi-Fi, queued tasks
     *   are moved to WAITING_FOR_NETWORK.
     * - When network policy allows downloads again,
     *   waiting tasks are returned to QUEUED.
     * - Only the available concurrency slots are dispatched.
     */
    suspend fun checkAndTriggerQueue() =
        withContext(Dispatchers.IO) {

            val wifiOnly =
                preferenceManager.isWifiOnly.first()

            val hasWifi = isWifiConnected()

            val activeItems =
                downloadDao.getActiveDownloads().first()

            if (wifiOnly && !hasWifi) {

                for (item in activeItems) {
                    if (item.status == DownloadStatus.QUEUED) {
                        downloadDao.updateStatus(
                            item.id,
                            DownloadStatus.WAITING_FOR_NETWORK
                        )
                    }
                }

                return@withContext
            }

            // The network policy now permits downloads.
            // Return waiting tasks to the normal queue.
            for (item in activeItems) {
                if (
                    item.status ==
                    DownloadStatus.WAITING_FOR_NETWORK
                ) {
                    downloadDao.updateStatus(
                        item.id,
                        DownloadStatus.QUEUED
                    )
                }
            }

            val maxConcurrent =
                preferenceManager.maxConcurrentDownloads
                    .first()
                    .coerceAtLeast(1)

            val currentlyRunning =
                downloadDao.getCurrentlyDownloading()

            val availableSlots =
                maxConcurrent - currentlyRunning.size

            if (availableSlots <= 0) {
                return@withContext
            }

            val queued =
                downloadDao.getQueuedDownloads()

            val tasksToStart =
                queued.take(availableSlots)

            for (task in tasksToStart) {

                val intent = Intent(
                    appContext,
                    DownloadService::class.java
                ).apply {
                    action = DownloadService.ACTION_START

                    putExtra(
                        DownloadService.EXTRA_TASK_ID,
                        task.id
                    )
                }

                ContextCompat.startForegroundService(
                    appContext,
                    intent
                )
            }
        }
}