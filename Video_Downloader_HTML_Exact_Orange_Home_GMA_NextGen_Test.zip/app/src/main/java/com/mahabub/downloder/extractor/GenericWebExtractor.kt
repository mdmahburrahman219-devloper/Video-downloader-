package com.mahabub.downloder.extractor

import com.mahabub.downloder.extractor.ExtractorUtils.unescapeHtml
import com.mahabub.downloder.model.MediaCandidate
import com.mahabub.downloder.model.PlatformSource
import com.mahabub.downloder.model.StreamType
import okhttp3.OkHttpClient
import java.util.regex.Pattern

class GenericWebExtractor(private val okHttpClient: OkHttpClient) : PlatformExtractor {

    override val platform: PlatformSource = PlatformSource.GENERIC_WEB

    override fun matches(url: String): Boolean = true // Catch-all fallback

    override suspend fun extract(url: String): MediaCandidate? {
        return try {
            val request = ExtractorUtils.buildRequest(url)
            val response = okHttpClient.newCall(request).execute()
            if (!response.isSuccessful) return null

            val html = response.body?.string() ?: return null

            // 1. Try og:video or og:video:secure_url
            var videoUrl = ExtractorUtils.extractMetaTag(html, "og:video")
                ?: ExtractorUtils.extractMetaTag(html, "og:video:secure_url")

            // 2. Try <video src="...">
            if (videoUrl.isNullOrBlank()) {
                val videoTagPattern = Pattern.compile("<video[^>]+src=[\"']([^\"']+)[\"']", Pattern.CASE_INSENSITIVE)
                val matcher = videoTagPattern.matcher(html)
                if (matcher.find()) {
                    videoUrl = matcher.group(1)?.unescapeHtml()
                }
            }

            // 3. Try <source src="..." type="video/...">
            if (videoUrl.isNullOrBlank()) {
                val sourcePattern = Pattern.compile("<source[^>]+src=[\"']([^\"']+)[\"']", Pattern.CASE_INSENSITIVE)
                val matcher = sourcePattern.matcher(html)
                if (matcher.find()) {
                    videoUrl = matcher.group(1)?.unescapeHtml()
                }
            }

            if (videoUrl.isNullOrBlank()) return null

            // Resolve relative URLs against page URL
            if (videoUrl.startsWith("/")) {
                val baseUri = java.net.URI(url)
                videoUrl = "${baseUri.scheme}://${baseUri.host}$videoUrl"
            }

            val title = ExtractorUtils.extractTitle(html) ?: "Web Video"
            val poster = ExtractorUtils.extractMetaTag(html, "og:image")
            val isHls = videoUrl.contains(".m3u8")
            val isDash = videoUrl.contains(".mpd")

            val streamType = when {
                isHls -> StreamType.HLS
                isDash -> StreamType.DASH
                else -> StreamType.PROGRESSIVE
            }

            MediaCandidate(
                id = ExtractorUtils.generateMediaId(),
                url = videoUrl,
                title = title,
                mimeType = if (isHls) "application/vnd.apple.mpegurl" else if (isDash) "application/dash+xml" else "video/mp4",
                sourcePageUrl = url,
                sourcePlatform = PlatformSource.GENERIC_WEB,
                streamType = streamType,
                thumbnailUrl = poster,
                isDirectDownload = streamType == StreamType.PROGRESSIVE
            )
        } catch (_: Exception) {
            null
        }
    }
}
