package com.mahabub.downloder.extractor

import com.mahabub.downloder.model.MediaCandidate
import com.mahabub.downloder.model.PlatformSource
import okhttp3.OkHttpClient

/** Threads-specific extractor. It supports both current threads.com and legacy threads.net URLs. */
class ThreadsExtractor(private val okHttpClient: OkHttpClient) : PlatformExtractor {
    override val platform: PlatformSource = PlatformSource.THREADS

    override fun matches(url: String): Boolean {
        val host = runCatching { java.net.URI(url).host.orEmpty().lowercase() }.getOrDefault("")
        return host == "threads.net" || host.endsWith(".threads.net") ||
            host == "threads.com" || host.endsWith(".threads.com")
    }

    override suspend fun extract(url: String): MediaCandidate? = extract(url, null)

    override suspend fun extract(url: String, userAgentOverride: String?): MediaCandidate? = try {
        val ua = userAgentOverride?.takeIf { it.isNotBlank() } ?: ExtractorUtils.USER_AGENT
        val request = ExtractorUtils.buildRequest(url = url, referer = url, userAgent = ua)
        okHttpClient.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return null
            val html = response.body?.string()?.take(5_000_000) ?: return null
            MetaMediaPageParser.extract(html, url, platform, ua)
        }
    } catch (_: Exception) {
        null
    }
}
