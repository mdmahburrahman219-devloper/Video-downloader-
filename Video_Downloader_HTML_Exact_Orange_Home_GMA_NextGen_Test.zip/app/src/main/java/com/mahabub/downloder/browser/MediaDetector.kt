package com.mahabub.downloder.browser

import com.mahabub.downloder.extractor.ExtractorUtils
import com.mahabub.downloder.model.MediaCandidate
import com.mahabub.downloder.model.MediaDetectionSource
import com.mahabub.downloder.model.PlatformSource
import com.mahabub.downloder.model.StreamType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.net.URI
import java.util.Locale

/** Thread-safe collector for media URLs observed by WebView, its DOM script and download callbacks. */
class MediaDetector {

    companion object {
        private const val MAX_CANDIDATES = 100
        private val URL_FILE_NAME_REGEX = Regex("[\\r\\n\\t]")
        private val MEDIA_EXTENSIONS = setOf(
            "mp4", "webm", "mov", "m4v", "mkv", "avi", "m3u8", "mpd",
            "mp3", "m4a", "aac", "ogg", "wav", "flac"
        )
        private val SEGMENT_EXTENSIONS = setOf("ts", "m4s", "cmfv", "cmfa")
        private val AD_HOST_HINTS = listOf(
            "doubleclick.net", "googlesyndication.com", "googleadservices.com",
            "adservice.google.com", "adnxs.com", "adroll.com", "popads.net",
            "popcash.net", "propellerads.com", "taboola.com", "outbrain.com",
            "criteo.com", "rubiconproject.com", "adsafeprotected.com",
            "adsterra.com", "trafficjunky.net", "exoclick.com", "juicyads.com",
            "hilltopads.com", "adcash.com", "monetag.com", "onclkds.com",
            "ad-maven.com", "adnium.com", "trafficstars.com", "ad-delivery.net",
            "ad-score.com", "yllix.com", "popunder.net", "ero-advertising.com"
        )
        private val AD_PATH_HINTS = listOf(
            "/ads/", "/ad/", "/advert", "/preroll", "/vast", "ad_video",
            "adbreak", "ad-break", "sponsor-video", "pre_roll", "preroll",
            "adcreative", "advertisement", "/vast/", "vast.xml", "/promo/",
            "impression", "adunit", "ad-unit", "popunder", "clickunder"
        )
    }

    private val lock = Any()
    private val _detectedMedia = MutableStateFlow<List<MediaCandidate>>(emptyList())
    val detectedMedia: StateFlow<List<MediaCandidate>> = _detectedMedia.asStateFlow()
    private var metadataPageKey: String? = null
    private var pageTitle: String? = null
    private var pagePosterUrl: String? = null
    private var pageDurationSeconds: Double? = null

    /** A new main-frame page starts a fresh list and metadata context. */
    fun clearForNewPage() {
        synchronized(lock) {
            _detectedMedia.value = emptyList()
            metadataPageKey = null
            pageTitle = null
            pagePosterUrl = null
            pageDurationSeconds = null
        }
    }

    /** Receives Open Graph/Twitter/JSON-LD metadata discovered by the document-start sniffer. */
    fun onPageMetadata(title: String?, posterUrl: String?, durationSeconds: Double?, currentPageUrl: String?) {
        synchronized(lock) {
            val safeTitle = title?.trim()?.take(300)?.takeIf { it.isNotBlank() }
            val safePoster = posterUrl?.let(::normalizeHttpUrl)
            val pageKey = currentPageUrl?.let(::pageIdentity)
            if (safeTitle == null && safePoster == null && durationSeconds == null) return
            val previousPageTitle = pageTitle
            val previousPagePoster = pagePosterUrl
            if (pageKey != null) metadataPageKey = pageKey
            if (safeTitle != null && !isGenericTitle(safeTitle)) pageTitle = safeTitle
            if (safePoster != null) pagePosterUrl = safePoster
            durationSeconds?.takeIf { it.isFinite() && it > 0.0 && it < 86_400.0 }?.let { pageDurationSeconds = it }

            _detectedMedia.value = _detectedMedia.value.map { candidate ->
                if (metadataPageKey != null && pageIdentity(candidate.sourcePageUrl ?: candidate.referer ?: "") != metadataPageKey) {
                    candidate
                } else {
                    candidate.copy(
                        title = when {
                            pageTitle != null && candidate.title == previousPageTitle -> pageTitle
                            candidate.title == null || isFallbackTitle(candidate.title, candidate.url) -> pageTitle ?: candidate.title
                            else -> candidate.title
                        },
                        thumbnailUrl = when {
                            pagePosterUrl != null && candidate.thumbnailUrl == previousPagePoster -> pagePosterUrl
                            candidate.thumbnailUrl == null -> pagePosterUrl
                            else -> candidate.thumbnailUrl
                        },
                        // Page-level duration belongs to the actual DOM video candidate. Do not
                        // copy it blindly onto ad/API requests that happen to load on the page.
                        durationSeconds = candidate.durationSeconds ?: pageDurationSeconds.takeIf {
                            candidate.detectionSource == MediaDetectionSource.DOM_VIDEO
                        }
                    )
                }
            }
        }
    }

    fun onNetworkMediaFound(
        url: String,
        mimeType: String?,
        currentPageUrl: String?,
        userAgent: String?
    ) {
        val cleanUrl = normalizeHttpUrl(url) ?: return
        if (!isCandidateMedia(cleanUrl, mimeType)) return
        if (isSegmentUrl(cleanUrl)) return

        val streamType = determineStreamType(cleanUrl, mimeType)
        val platform = detectPlatformFromUrl(currentPageUrl ?: cleanUrl)
        val fileName = URL_FILE_NAME_REGEX.replace(cleanUrl.substringAfterLast('/').substringBefore('?'), "")
        val title = fileName.takeIf { it.isNotBlank() } ?: "Detected video"
        val likelyAd = isLikelyAd(cleanUrl)

        addOrMergeCandidate(
            MediaCandidate(
                id = ExtractorUtils.generateMediaId(),
                url = cleanUrl,
                title = title,
                mimeType = mimeType ?: guessedMime(cleanUrl),
                sourcePageUrl = currentPageUrl,
                referer = currentPageUrl,
                sourcePlatform = platform,
                streamType = streamType,
                userAgent = userAgent,
                isDirectDownload = streamType == StreamType.PROGRESSIVE,
                detectionSource = MediaDetectionSource.NETWORK_REQUEST,
                detectionConfidence = confidenceFor(MediaDetectionSource.NETWORK_REQUEST, cleanUrl, streamType, false, likelyAd),
                isLikelyAd = likelyAd,
                qualityLabel = qualityFromUrl(cleanUrl)
            )
        )
    }

    /** Called by the injected script for an actual HTML video element or its source variants. */
    fun onDomVideoFound(
        url: String,
        title: String?,
        durationSeconds: Double?,
        resolution: String?,
        posterUrl: String?,
        currentPageUrl: String?,
        isPlaying: Boolean = false,
        mimeType: String? = null,
        videoGroupId: String? = null,
        userAgent: String? = null
    ) {
        val cleanUrl = normalizeHttpUrl(url) ?: return
        if (!isCandidateMedia(cleanUrl, mimeType) || isSegmentUrl(cleanUrl)) return

        val streamType = determineStreamType(cleanUrl, mimeType)
        val likelyAd = isLikelyAd(cleanUrl, title)
        val safeDuration = durationSeconds?.takeIf { it.isFinite() && it > 0.0 && it < 86_400.0 }
        val safeResolution = resolution?.takeIf { it.matches(Regex("\\d{2,5}x\\d{2,5}")) }

        addOrMergeCandidate(
            MediaCandidate(
                id = ExtractorUtils.generateMediaId(),
                url = cleanUrl,
                title = title?.trim()?.takeIf { it.isNotBlank() } ?: "Detected video",
                mimeType = mimeType?.takeIf { it.isNotBlank() } ?: guessedMime(cleanUrl)
                    ?: if (streamType == StreamType.HLS) "application/vnd.apple.mpegurl" else null,
                sourcePageUrl = currentPageUrl,
                referer = currentPageUrl,
                userAgent = userAgent,
                sourcePlatform = detectPlatformFromUrl(currentPageUrl ?: cleanUrl),
                streamType = streamType,
                thumbnailUrl = posterUrl?.takeIf { it.startsWith("http://") || it.startsWith("https://") },
                durationSeconds = safeDuration,
                resolution = safeResolution,
                isDirectDownload = streamType == StreamType.PROGRESSIVE,
                isPlaying = isPlaying,
                detectionSource = MediaDetectionSource.DOM_VIDEO,
                detectionConfidence = confidenceFor(MediaDetectionSource.DOM_VIDEO, cleanUrl, streamType, isPlaying, likelyAd),
                isLikelyAd = likelyAd,
                videoGroupId = videoGroupId?.takeIf { it.isNotBlank() },
                // The active video's dimensions are more authoritative than quality-looking text in a URL.
                qualityLabel = qualityFromResolution(safeResolution) ?: qualityFromUrl(cleanUrl)
            )
        )
    }

    /** Called by the page's fetch/XHR/performance hooks. MIME can identify streams with extensionless URLs. */
    fun onScriptResourceFound(
        url: String,
        mimeType: String?,
        currentPageUrl: String?,
        userAgent: String?,
        isPlaying: Boolean
    ) {
        val cleanUrl = normalizeHttpUrl(url) ?: return
        if (!isCandidateMedia(cleanUrl, mimeType) || isSegmentUrl(cleanUrl)) return

        val streamType = determineStreamType(cleanUrl, mimeType)
        val likelyAd = isLikelyAd(cleanUrl)
        addOrMergeCandidate(
            MediaCandidate(
                id = ExtractorUtils.generateMediaId(),
                url = cleanUrl,
                title = cleanUrl.substringAfterLast('/').substringBefore('?').takeIf { it.isNotBlank() }
                    ?: "Detected media stream",
                mimeType = mimeType ?: guessedMime(cleanUrl),
                userAgent = userAgent,
                sourcePageUrl = currentPageUrl,
                referer = currentPageUrl,
                sourcePlatform = detectPlatformFromUrl(currentPageUrl ?: cleanUrl),
                streamType = streamType,
                isDirectDownload = streamType == StreamType.PROGRESSIVE,
                isPlaying = isPlaying,
                detectionSource = MediaDetectionSource.SCRIPT_RESOURCE,
                detectionConfidence = confidenceFor(MediaDetectionSource.SCRIPT_RESOURCE, cleanUrl, streamType, isPlaying, likelyAd),
                isLikelyAd = likelyAd,
                qualityLabel = qualityFromUrl(cleanUrl)
            )
        )
    }

    /** Add a media candidate discovered by a platform-specific resolver (e.g. TikTok page JSON). */
    fun onExtractorCandidate(candidate: MediaCandidate) {
        val cleanUrl = normalizeHttpUrl(candidate.url) ?: return
        if (!isCandidateMedia(cleanUrl, candidate.mimeType) || isSegmentUrl(cleanUrl)) return
        val streamType = when {
            candidate.streamType == StreamType.UNSUPPORTED_PROTECTED -> StreamType.UNSUPPORTED_PROTECTED
            else -> determineStreamType(cleanUrl, candidate.mimeType)
        }
        val safeCandidate = candidate.copy(
            url = cleanUrl,
            sourcePageUrl = candidate.sourcePageUrl ?: candidate.referer,
            referer = candidate.referer ?: candidate.sourcePageUrl,
            mimeType = candidate.mimeType ?: guessedMime(cleanUrl),
            streamType = streamType,
            isDirectDownload = streamType == StreamType.PROGRESSIVE,
            detectionSource = MediaDetectionSource.EXTRACTOR,
            detectionConfidence = maxOf(candidate.detectionConfidence, 92),
            isLikelyAd = false
        )
        addOrMergeCandidate(safeCandidate)
    }

    fun onServerDownloadStart(
        url: String,
        userAgent: String?,
        contentDisposition: String?,
        mimeType: String?,
        contentLength: Long,
        currentPageUrl: String?
    ) {
        val cleanUrl = normalizeHttpUrl(url) ?: return
        if (!isCandidateMedia(cleanUrl, mimeType) || isSegmentUrl(cleanUrl)) return

        val streamType = determineStreamType(cleanUrl, mimeType)
        val likelyAd = isLikelyAd(cleanUrl, contentDisposition)
        val titleFromHeader = contentDisposition
            ?.substringAfter("filename=", "")
            ?.trim()
            ?.trim('"', '\'')
            ?.takeIf { it.isNotBlank() }
        val title = titleFromHeader ?: cleanUrl.substringAfterLast('/').substringBefore('?').ifBlank { "Detected video" }

        addOrMergeCandidate(
            MediaCandidate(
                id = ExtractorUtils.generateMediaId(),
                url = cleanUrl,
                title = title,
                mimeType = mimeType ?: guessedMime(cleanUrl),
                contentDisposition = contentDisposition,
                contentLength = contentLength.takeIf { it > 0 },
                userAgent = userAgent,
                sourcePageUrl = currentPageUrl,
                referer = currentPageUrl,
                sourcePlatform = detectPlatformFromUrl(currentPageUrl ?: cleanUrl),
                streamType = streamType,
                isDirectDownload = streamType == StreamType.PROGRESSIVE,
                detectionSource = MediaDetectionSource.DOWNLOAD_EVENT,
                detectionConfidence = confidenceFor(MediaDetectionSource.DOWNLOAD_EVENT, cleanUrl, streamType, false, likelyAd),
                isLikelyAd = likelyAd,
                qualityLabel = qualityFromUrl(cleanUrl)
            )
        )
    }

    private fun addOrMergeCandidate(rawIncoming: MediaCandidate) {
        synchronized(lock) {
            val incoming = applyCurrentPageMetadata(rawIncoming)
            val current = _detectedMedia.value
            val key = canonicalKey(incoming.url)
            val activeCleared = if (incoming.isPlaying && !incoming.videoGroupId.isNullOrBlank()) {
                current.map { old ->
                    if (old.videoGroupId == incoming.videoGroupId && canonicalKey(old.url) != key && old.isPlaying) {
                        old.copy(isPlaying = false)
                    } else old
                }
            } else current
            val existingIndex = activeCleared.indexOfFirst { canonicalKey(it.url) == key }
            val updated = if (existingIndex >= 0) {
                val old = activeCleared[existingIndex]
                val mergedStreamType = when {
                    incoming.streamType == StreamType.HLS || incoming.streamType == StreamType.DASH -> incoming.streamType
                    old.streamType == StreamType.HLS || old.streamType == StreamType.DASH -> old.streamType
                    else -> StreamType.PROGRESSIVE
                }
                val mergedTitle = when {
                    incoming.title.isNullOrBlank() -> old.title
                    incoming.detectionSource == MediaDetectionSource.DOM_VIDEO -> incoming.title
                    old.detectionSource == MediaDetectionSource.DOM_VIDEO -> old.title
                    else -> preferUseful(incoming.title, old.title)
                }
                val merged = old.copy(
                    title = mergedTitle,
                    mimeType = incoming.mimeType?.takeIf { it.isNotBlank() } ?: old.mimeType,
                    contentDisposition = incoming.contentDisposition ?: old.contentDisposition,
                    contentLength = incoming.contentLength?.takeIf { it > 0 } ?: old.contentLength,
                    userAgent = incoming.userAgent ?: old.userAgent,
                    referer = incoming.referer ?: old.referer,
                    sourcePageUrl = incoming.sourcePageUrl ?: old.sourcePageUrl,
                    sourcePlatform = if (incoming.sourcePlatform != PlatformSource.GENERIC_WEB) incoming.sourcePlatform else old.sourcePlatform,
                    streamType = mergedStreamType,
                    isDirectDownload = mergedStreamType == StreamType.PROGRESSIVE && (old.isDirectDownload || incoming.isDirectDownload),
                    thumbnailUrl = incoming.thumbnailUrl ?: old.thumbnailUrl,
                    durationSeconds = incoming.durationSeconds ?: old.durationSeconds,
                    resolution = incoming.resolution ?: old.resolution,
                    isPlaying = if (incoming.detectionSource == MediaDetectionSource.DOM_VIDEO) incoming.isPlaying
                        else old.isPlaying || incoming.isPlaying,
                    detectionSource = if (sourceRank(incoming.detectionSource) > sourceRank(old.detectionSource)) incoming.detectionSource else old.detectionSource,
                    detectionConfidence = maxOf(old.detectionConfidence, incoming.detectionConfidence),
                    isLikelyAd = old.isLikelyAd || incoming.isLikelyAd,
                    videoGroupId = incoming.videoGroupId ?: old.videoGroupId,
                    qualityLabel = incoming.qualityLabel ?: old.qualityLabel,
                    bitrate = incoming.bitrate ?: old.bitrate,
                    estimatedSizeBytes = incoming.estimatedSizeBytes ?: old.estimatedSizeBytes,
                    sizeIsEstimated = incoming.sizeIsEstimated || old.sizeIsEstimated,
                    detectedAt = System.currentTimeMillis()
                )
                activeCleared.toMutableList().apply { set(existingIndex, merged) }
            } else {
                (activeCleared + incoming).toMutableList()
            }

            // When one player element transitions from a short pre-roll to a much longer title,
            // mark the earlier short stream as a probable advert. Keep it in raw detections so the
            // user can still reveal all results if a site is misclassified.
            val contextual = updated.map { candidate ->
                val playerId = candidate.videoGroupId
                val duration = candidate.durationSeconds
                if (playerId.isNullOrBlank() || duration == null || duration !in 1.0..35.0 || candidate.isLikelyAd) {
                    candidate
                } else {
                    val hasLongSibling = updated.any { sibling ->
                        sibling.url != candidate.url &&
                            sibling.videoGroupId == playerId &&
                            sibling.durationSeconds != null && sibling.durationSeconds >= 60.0 &&
                            sibling.sourcePageUrl == candidate.sourcePageUrl
                    }
                    if (hasLongSibling) candidate.copy(
                        isLikelyAd = true,
                        detectionConfidence = (candidate.detectionConfidence - 35).coerceAtLeast(1)
                    ) else candidate
                }
            }
            val sorted = contextual
                .sortedWith(compareByDescending<MediaCandidate> { it.detectionConfidence }
                    .thenByDescending { it.isPlaying }
                    .thenByDescending { it.detectedAt })
                .take(MAX_CANDIDATES)
            _detectedMedia.value = sorted
        }
    }

    private fun applyCurrentPageMetadata(candidate: MediaCandidate): MediaCandidate {
        val candidatePageKey = pageIdentity(candidate.sourcePageUrl ?: candidate.referer ?: "")
        if (metadataPageKey != null && candidatePageKey != metadataPageKey) return candidate
        return candidate.copy(
            title = candidate.title?.takeIf { !isFallbackTitle(it, candidate.url) } ?: pageTitle ?: candidate.title,
            thumbnailUrl = candidate.thumbnailUrl ?: pagePosterUrl,
            durationSeconds = candidate.durationSeconds ?: pageDurationSeconds.takeIf {
                candidate.detectionSource == MediaDetectionSource.DOM_VIDEO
            }
        )
    }

    private fun isGenericTitle(value: String): Boolean {
        val normalized = value.trim().substringBeforeLast('.').lowercase(Locale.ROOT)
        return normalized.isBlank() || normalized in setOf(
            "video", "detected video", "detected media stream", "media", "stream", "master", "playlist", "index"
        ) || normalized.matches(Regex("(?:hls|stream|index|video|playlist|master)(?:[-_.][a-z0-9]+)*"))
    }

    /** Strip compound media suffixes such as .av1.mp4.m3u8 when detecting generated filenames. */
    private fun stripMediaSuffixes(value: String): String = value.trim().replace(
        Regex("(?i)(?:\\.(?:m3u8|mpd|mp4|m4v|webm|mov|mkv|avi|mp3|m4a|aac|ogg|wav|flac))+$"),
        ""
    ).trim()

    /** Treat URL basenames and generated CDN IDs as fallbacks so page metadata can replace them. */
    private fun isFallbackTitle(value: String, mediaUrl: String): Boolean {
        if (isGenericTitle(value)) return true
        val rawBase = runCatching { URI(mediaUrl).path.orEmpty().substringAfterLast('/') }.getOrDefault("")
        val candidateName = stripMediaSuffixes(rawBase)
        val normalizedTitle = stripMediaSuffixes(value)
        if (candidateName.isNotBlank() && normalizedTitle.isNotBlank() &&
            normalizedTitle.equals(candidateName, ignoreCase = true)) return true
        // Filenames such as _TPL_.av1.mp4.m3u8 are implementation labels, not video titles.
        if (Regex("(?i)\\.(?:m3u8|mpd|mp4|m4v|webm|mov|mkv|avi|mp3|m4a|aac|ogg|wav|flac)$")
                .containsMatchIn(value.trim()) && value.trim().none { it.isWhitespace() }) return true
        val normalized = normalizedTitle.substringBeforeLast('.').trim()
        return normalized.matches(Regex("(?i)(?:[a-f0-9]{16,}|[a-f0-9]{8}-[a-f0-9-]{20,}|[a-z0-9_-]{32,})"))
    }

    private fun pageIdentity(raw: String): String = runCatching {
        val uri = URI(raw)
        "${uri.scheme.orEmpty().lowercase(Locale.ROOT)}://${uri.host.orEmpty().lowercase(Locale.ROOT)}${uri.path.orEmpty().trimEnd('/')}"
    }.getOrDefault(raw.substringBefore('?').substringBefore('#').trimEnd('/'))

    private fun preferUseful(incoming: String?, old: String?): String? {
        if (incoming.isNullOrBlank()) return old
        if (old.isNullOrBlank()) return incoming
        val genericTitles = setOf("detected video", "detected media stream", "video")
        return if (incoming.lowercase(Locale.ROOT) !in genericTitles) incoming else old
    }

    private fun normalizeHttpUrl(raw: String): String? {
        val trimmed = raw.trim().substringBefore('#')
        if (trimmed.isBlank() || trimmed.length > 8_192) return null
        return try {
            val uri = URI(trimmed)
            val scheme = uri.scheme?.lowercase(Locale.ROOT)
            if ((scheme == "http" || scheme == "https") && !uri.host.isNullOrBlank()) uri.toASCIIString() else null
        } catch (_: Exception) {
            null
        }
    }

    private fun canonicalKey(url: String): String = url.substringBefore('#')

    private fun isCandidateMedia(url: String, mimeType: String?): Boolean {
        val mime = mimeType?.substringBefore(';')?.trim()?.lowercase(Locale.ROOT).orEmpty()
        if (mime.startsWith("video/") || mime.startsWith("audio/")) return true
        if (mime.contains("mpegurl") || mime.contains("dash+xml")) return true
        val path = runCatching { URI(url).path.orEmpty().lowercase(Locale.ROOT) }.getOrDefault("")
        val ext = path.substringAfterLast('.', "").takeIf { it != path } ?: return false
        return ext in MEDIA_EXTENSIONS
    }

    private fun isSegmentUrl(url: String): Boolean {
        val uri = runCatching { URI(url) }.getOrNull() ?: return false
        val path = uri.path.orEmpty().lowercase(Locale.ROOT)
        val ext = path.substringAfterLast('.', "").takeIf { it != path }.orEmpty()
        if (ext in SEGMENT_EXTENSIONS) return true
        if (path.contains("/segment/") || path.contains("/segments/") ||
            path.contains("/chunks/") || path.contains("/chunk/") ||
            path.contains("/fragment/") || path.contains("/fragments/")) return true
        val fileName = path.substringAfterLast('/')
        return Regex("(?:^|[-_.])(?:seg(?:ment)?|chunk|part|frag(?:ment)?)[-_.]?\\d+", RegexOption.IGNORE_CASE)
            .containsMatchIn(fileName)
    }

    private fun determineStreamType(url: String, mime: String?): StreamType {
        val lowerUrl = url.lowercase(Locale.ROOT)
        val lowerMime = mime?.lowercase(Locale.ROOT) ?: ""
        if (lowerUrl.substringBefore('?').contains(".m3u8") || lowerMime.contains("mpegurl")) return StreamType.HLS
        if (lowerUrl.substringBefore('?').contains(".mpd") || lowerMime.contains("dash+xml")) return StreamType.DASH
        return StreamType.PROGRESSIVE
    }

    private fun guessedMime(url: String): String? {
        val ext = runCatching { URI(url).path.orEmpty().substringAfterLast('.', "").lowercase(Locale.ROOT) }.getOrDefault("")
        return when (ext) {
            "mp4", "m4v" -> "video/mp4"
            "webm" -> "video/webm"
            "mov" -> "video/quicktime"
            "mkv" -> "video/x-matroska"
            "avi" -> "video/x-msvideo"
            "m3u8" -> "application/vnd.apple.mpegurl"
            "mpd" -> "application/dash+xml"
            "mp3" -> "audio/mpeg"
            "m4a" -> "audio/mp4"
            "aac" -> "audio/aac"
            "ogg" -> "audio/ogg"
            "wav" -> "audio/wav"
            "flac" -> "audio/flac"
            else -> null
        }
    }

    private fun confidenceFor(
        source: MediaDetectionSource,
        url: String,
        streamType: StreamType,
        isPlaying: Boolean,
        likelyAd: Boolean
    ): Int {
        var score = when (source) {
            MediaDetectionSource.DOM_VIDEO -> 88
            MediaDetectionSource.SCRIPT_RESOURCE -> 76
            MediaDetectionSource.NETWORK_REQUEST -> 70
            MediaDetectionSource.DOWNLOAD_EVENT -> 62
            MediaDetectionSource.EXTRACTOR -> 80
        }
        if (streamType == StreamType.HLS || streamType == StreamType.DASH) score += 4
        if (isPlaying) score += 8
        val path = runCatching { URI(url).path.orEmpty().lowercase(Locale.ROOT) }.getOrDefault("")
        if (path.endsWith(".mp4") || path.endsWith(".webm") || path.endsWith(".m3u8")) score += 3
        if (likelyAd) score -= 45
        return score.coerceIn(1, 100)
    }

    private fun isLikelyAd(url: String, titleHint: String? = null): Boolean {
        val uri = runCatching { URI(url) }.getOrNull() ?: return false
        val host = uri.host?.lowercase(Locale.ROOT).orEmpty()
        val full = (uri.path.orEmpty() + "?" + uri.query.orEmpty()).lowercase(Locale.ROOT)
        val fileName = uri.path.orEmpty().substringAfterLast('/').lowercase(Locale.ROOT)
        val title = titleHint.orEmpty().lowercase(Locale.ROOT)
        val fileAdHint = Regex("(?:^|[-_.])(?:ad|ads|advert|advertisement|preroll|pre-roll|adcreative|advideo|vast|sponsor)(?:[-_.]|\\d|$)")
            .containsMatchIn(fileName)
        val titleAdHint = Regex("\\b(advertisement|sponsored video|commercial break|ad break|preroll)\\b")
            .containsMatchIn(title)
        val queryAdHint = Regex("(?:^|[&?])(?:ad|adid|adtag|vast|advertisement)=", RegexOption.IGNORE_CASE)
            .containsMatchIn("?${uri.query.orEmpty()}")
        return AD_HOST_HINTS.any { host == it || host.endsWith(".$it") } ||
            AD_PATH_HINTS.any { full.contains(it) } || fileAdHint || titleAdHint || queryAdHint
    }

    /** Infer quality only from the filename, never from the page title or an arbitrary parent path. */
    private fun qualityFromUrl(url: String): String? {
        val fileName = runCatching { URI(url).path.orEmpty().substringAfterLast('/') }.getOrDefault("")
        val commonHeights = setOf(144, 160, 180, 240, 360, 480, 540, 720, 1080, 1440, 2160)
        val height = Regex("(?i)(?:^|[-_.])(\\d{3,4})p?(?=$|[-_.])")
            .find(fileName)?.groupValues?.getOrNull(1)?.toIntOrNull()
        if (height != null && height in commonHeights) return "${height}p"
        val dimensions = Regex("(?i)(?:^|[-_.])(\\d{3,4})x(\\d{3,4})(?=$|[-_.])")
            .find(fileName)
        val dimensionHeight = dimensions?.groupValues?.getOrNull(2)?.toIntOrNull()
        if (dimensionHeight != null && dimensionHeight in commonHeights) return "${dimensionHeight}p"
        return null
    }

    private fun qualityFromResolution(resolution: String?): String? {
        val dimensions = resolution?.let { Regex("^(\\d{2,5})x(\\d{2,5})$").matchEntire(it) } ?: return null
        val height = dimensions.groupValues.getOrNull(2)?.toIntOrNull() ?: return null
        return height.takeIf { it > 0 }?.let { "${it}p" }
    }

    private fun sourceRank(source: MediaDetectionSource): Int = when (source) {
        MediaDetectionSource.DOM_VIDEO -> 5
        MediaDetectionSource.EXTRACTOR -> 4
        MediaDetectionSource.SCRIPT_RESOURCE -> 3
        MediaDetectionSource.NETWORK_REQUEST -> 2
        MediaDetectionSource.DOWNLOAD_EVENT -> 1
    }

    private fun detectPlatformFromUrl(url: String): PlatformSource {
        val lower = url.lowercase(Locale.ROOT)
        return when {
            lower.contains("instagram.com") -> PlatformSource.INSTAGRAM
            lower.contains("tiktok.com") -> PlatformSource.TIKTOK
            lower.contains("facebook.com") || lower.contains("fb.watch") -> PlatformSource.FACEBOOK
            lower.contains("twitter.com") || lower.contains("x.com") -> PlatformSource.TWITTER_X
            lower.contains("pinterest.com") || lower.contains("pin.it") -> PlatformSource.PINTEREST
            lower.contains("reddit.com") || lower.contains("redd.it") -> PlatformSource.REDDIT
            lower.contains("threads.net") || lower.contains("threads.com") -> PlatformSource.THREADS
            else -> PlatformSource.GENERIC_WEB
        }
    }

}
