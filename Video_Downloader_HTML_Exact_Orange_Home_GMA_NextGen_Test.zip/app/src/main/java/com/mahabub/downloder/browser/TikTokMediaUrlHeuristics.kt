package com.mahabub.downloder.browser

import java.net.URI
import java.net.URLDecoder
import java.nio.charset.StandardCharsets
import java.util.Locale

/**
 * Narrow heuristic for TikTok's extensionless video CDN URLs.
 * It deliberately requires a known TikTok/ByteDance media host plus a video-specific path or MIME
 * query marker; it does not classify arbitrary TikTok JSON, avatars, covers, or page requests.
 */
object TikTokMediaUrlHeuristics {
    private val knownMediaDomainSuffixes = listOf(
        "tiktokcdn.com", "tiktokcdn-us.com", "tiktokcdn-eu.com", "tiktokv.com",
        "byteoversea.com", "ibytedtos.com", "byteicdn.com", "muscdn.com"
    )

    fun isLikelyVideoResource(rawUrl: String): Boolean {
        val uri = runCatching { URI(rawUrl) }.getOrNull() ?: return false
        val scheme = uri.scheme?.lowercase(Locale.ROOT)
        if (scheme != "http" && scheme != "https") return false
        val host = uri.host?.lowercase(Locale.ROOT).orEmpty()
        if (host.isBlank()) return false
        val isTikTokMediaHost = knownMediaDomainSuffixes.any { host == it || host.endsWith(".$it") }
        val isAkamaiHost = host.endsWith(".akamaized.net")
        val isTikTokHost = host == "tiktok.com" || host.endsWith(".tiktok.com") ||
            isTikTokMediaHost || isAkamaiHost
        if (!isTikTokHost) return false

        val path = runCatching {
            URLDecoder.decode(uri.rawPath.orEmpty().replace("+", "%2B"), StandardCharsets.UTF_8.name())
                .lowercase(Locale.ROOT)
        }.getOrDefault(uri.rawPath.orEmpty().lowercase(Locale.ROOT))
        val extension = path.substringAfterLast('/', "").substringAfterLast('.', "")
        if (extension in setOf("jpg", "jpeg", "png", "webp", "gif", "avif", "ts", "m4s", "cmfv", "cmfa")) return false
        val query = runCatching {
            URLDecoder.decode(uri.rawQuery.orEmpty().replace("+", "%2B"), StandardCharsets.UTF_8.name())
                .lowercase(Locale.ROOT)
        }.getOrDefault(uri.rawQuery.orEmpty().lowercase(Locale.ROOT))

        val explicitVideoMime = Regex("(?:^|[&?])mime_type=(?:video_mp4|video%2fmp4|video/mp4|video_webm|video%2fwebm)(?:&|$)")
            .containsMatchIn(uri.rawQuery.orEmpty().lowercase(Locale.ROOT)) ||
            Regex("(?:^|[&?])mime_type=(?:video_mp4|video/mp4|video_webm)").containsMatchIn(query)
        val videoPath = path.contains("/video/tos/") ||
            Regex("/obj/tos(?:[-/])").containsMatchIn(path) ||
            path.contains("/aweme/v1/play/") ||
            path.contains("/aweme/v1/playwm/") ||
            path.contains("/media-video-hvc1/") ||
            (path.contains("/video/") && (query.contains("video_id=") || query.contains("aweme_id=")))
        if (isAkamaiHost && !explicitVideoMime) return false
        return explicitVideoMime || videoPath
    }
}
