package com.mahabub.downloder.model

/** Chooses whether the browser should show the detected-video list or open a video's quality sheet. */
object MediaSelectionRouting {

    /**
     * The list is only needed when multiple logical videos were detected and none of them has
     * more than one known numeric resolution. If one video has multiple resolutions, open the
     * best candidate directly. A single detected video also opens directly, even if it has only
     * one option.
     */
    fun shouldShowDetectedList(groups: List<MediaVideoGroup>): Boolean {
        if (groups.size <= 1) return false
        return groups.none(::hasMultipleResolutions)
    }

    /** True only when the group has two or more distinct, explicit numeric resolution labels. */
    fun hasMultipleResolutions(group: MediaVideoGroup): Boolean {
        val resolutions = group.candidates
            .map(MediaCandidateGrouping::qualityLabel)
            .mapNotNull { label ->
                Regex("(?i)^(\\d{2,4})p$").matchEntire(label.trim())
                    ?.groupValues?.getOrNull(1)?.toIntOrNull()
            }
            .distinct()
        return resolutions.size > 1
    }

    /** Selects the group with the most real quality options, then uses player/confidence signals to break ties. */
    fun preferredGroup(groups: List<MediaVideoGroup>): MediaVideoGroup? = groups.maxWithOrNull(
        compareBy<MediaVideoGroup> { qualityOptionCount(it) }
            .thenBy { it.primary.isPlaying }
            .thenBy { it.primary.detectionConfidence }
            .thenBy { it.primary.detectedAt }
    )

    private fun qualityOptionCount(group: MediaVideoGroup): Int = group.candidates
        .map(MediaCandidateGrouping::qualityLabel)
        .mapNotNull { label ->
            Regex("(?i)^(\\d{2,4})p$").matchEntire(label.trim())
                ?.groupValues?.getOrNull(1)?.toIntOrNull()
        }
        .distinct()
        .size
}
