package com.mahabub.downloder.ui.screens

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color as AndroidColor
import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import android.view.MotionEvent
import android.webkit.CookieManager
import android.webkit.WebSettings
import android.webkit.WebView
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import android.widget.Toast
import com.mahabub.downloder.ui.components.LocalBottomBarContentPadding
import com.mahabub.downloder.browser.TikTokBrowserMode
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.keyframes
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.RepeatMode
import androidx.compose.foundation.Image
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.HelpOutline
import androidx.compose.material.icons.automirrored.filled.KeyboardReturn
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DesktopMac
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Feedback
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import com.mahabub.downloder.AppContainer
import com.mahabub.downloder.ads.HomeNativeAdCard
import com.mahabub.downloder.browser.AndroidMediaBridge
import com.mahabub.downloder.browser.PlatformMediaOverlayScript
import com.mahabub.downloder.browser.SecureWebChromeClient
import com.mahabub.downloder.browser.SecureWebViewClient
import com.mahabub.downloder.browser.SnifferScript
import com.mahabub.downloder.db.BrowserHistoryEntity
import com.mahabub.downloder.preferences.HomeShortcut
import com.mahabub.downloder.preferences.HomeShortcutDefaults
import com.mahabub.downloder.model.MediaCandidate
import com.mahabub.downloder.model.MediaDetectionSource
import com.mahabub.downloder.model.MediaCandidateGrouping
import com.mahabub.downloder.model.MediaSelectionRouting
import com.mahabub.downloder.model.MediaVideoGroup
import com.mahabub.downloder.model.SmartFilterSettings
import com.mahabub.downloder.model.SmartMediaFilter
import com.mahabub.downloder.model.PlatformSource
import com.mahabub.downloder.model.StreamType
import com.mahabub.downloder.ui.dialogs.MediaSelectionBottomSheet
import com.mahabub.downloder.ui.viewmodel.BrowserTab
import com.mahabub.downloder.ui.viewmodel.BrowserViewModel
import java.net.URI
import java.net.URLEncoder
import org.json.JSONObject
import org.json.JSONTokener
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean

private val ReferenceHomeWhite = Color(0xFFFFFFFF)
private val ReferenceHomePanel = Color(0xFFE9E9E9)
private val ReferenceSearchFill = Color(0xFFDDDDDD)
private val ReferenceOrange = Color(0xFFFF5A2E)
private val ReferenceOrangeBorder = Color(0xFFFF6A3D)
private val ReferenceOrangeButton = Color(0xFFFF5F33)
private val ReferenceHomeInk = Color(0xFF111111)
private val ReferenceHomeMuted = Color(0xFF5F5F5F)
private val ReferenceHomeLabel = Color(0xFF6E6E6E)

private data class BrowserContextTarget(
    /** URL opened/shared/copied by the link actions. */
    val url: String,
    val hitType: Int,
    val pageUrl: String,
    /** Media source can differ from the enclosing link URL for linked images/videos. */
    val mediaUrl: String? = null,
    val imageUrl: String? = null
)

private data class BrowserElementDetails(
    val href: String? = null,
    val imageUrl: String? = null,
    val videoUrl: String? = null,
    val isVideoElement: Boolean = false
)

private fun parseBrowserElementDetails(rawResult: String?): BrowserElementDetails? {
    if (rawResult.isNullOrBlank() || rawResult == "null") return null
    return runCatching {
        val decoded = runCatching { JSONTokener(rawResult).nextValue() as? String }.getOrNull() ?: rawResult
        val json = JSONObject(decoded)
        fun value(key: String) = json.optString(key).trim().takeIf { it.isNotBlank() && it != "null" }
        BrowserElementDetails(
            href = value("href"),
            imageUrl = value("imageUrl"),
            videoUrl = value("videoUrl"),
            isVideoElement = json.optBoolean("isVideo", false)
        )
    }.getOrNull()
}

/** Capture a small, bounded-memory snapshot for the Opera-style tab cards. */
private fun captureWebViewPreview(webView: WebView): Bitmap? = runCatching {
    val sourceWidth = webView.width
    val sourceHeight = webView.height
    if (sourceWidth <= 0 || sourceHeight <= 0) return null
    val targetWidth = 144
    val targetHeight = 240
    val scale = minOf(targetWidth.toFloat() / sourceWidth, targetHeight.toFloat() / sourceHeight)
    val outputWidth = (sourceWidth * scale).toInt().coerceAtLeast(1)
    val outputHeight = (sourceHeight * scale).toInt().coerceAtLeast(1)
    val bitmap = Bitmap.createBitmap(outputWidth, outputHeight, Bitmap.Config.RGB_565)
    val canvas = Canvas(bitmap)
    canvas.drawColor(AndroidColor.WHITE)
    canvas.scale(outputWidth.toFloat() / sourceWidth, outputHeight.toFloat() / sourceHeight)
    webView.draw(canvas)
    bitmap
}.getOrNull()

private fun contextMimeType(url: String, imageHint: Boolean): String {
    val extension = runCatching { URI(url).path.orEmpty().substringAfterLast('.', "").lowercase() }.getOrDefault("")
    return when (extension) {
        "m3u8" -> "application/vnd.apple.mpegurl"
        "mpd" -> "application/dash+xml"
        "webm" -> "video/webm"
        "mov" -> "video/quicktime"
        "m4v", "mp4" -> "video/mp4"
        "mkv" -> "video/x-matroska"
        "avi" -> "video/x-msvideo"
        "jpg", "jpeg" -> "image/jpeg"
        "png" -> "image/png"
        "gif" -> "image/gif"
        "webp" -> "image/webp"
        "bmp" -> "image/bmp"
        "avif" -> "image/avif"
        else -> if (imageHint) "image/jpeg" else "video/mp4"
    }
}

private fun contextFileTitle(url: String, fallback: String): String =
    runCatching { URI(url).path.orEmpty().substringAfterLast('/').substringBeforeLast('.').take(100) }
        .getOrNull()?.takeIf { it.isNotBlank() } ?: fallback

private fun isHttpUrl(url: String): Boolean =
    url.startsWith("https://", ignoreCase = true) || url.startsWith("http://", ignoreCase = true)

private fun isMediaUrl(url: String): Boolean =
    Regex("(?i)\\.(?:mp4|m4v|webm|mov|mkv|avi|m3u8|mpd|mp3|m4a|aac|ogg|wav|flac)(?:$|[?#])").containsMatchIn(url)

private fun isImageUrl(url: String): Boolean =
    Regex("(?i)\\.(?:jpe?g|png|gif|webp|bmp|avif)(?:$|[?#])").containsMatchIn(url)

private data class SiteShortcut(val name: String, val url: String)

/** Uses a domain-specific favicon provider; the URL is derived from the actual visited website. */
private fun faviconUrlFor(url: String): String? {
    val host = runCatching {
        URI(url).host?.lowercase()?.trimEnd('.')
            ?.removePrefix("www.")?.removePrefix("m.")?.removePrefix("mobile.")
            ?.takeIf { it.isNotBlank() }
    }.getOrNull() ?: return null
    val encodedHost = runCatching { URLEncoder.encode(host, "UTF-8") }.getOrDefault(host)
    return "https://www.google.com/s2/favicons?domain=$encodedHost&sz=128"
}

@Composable
private fun homeBackgroundColor(choice: String): Color {
    val themeBackground = MaterialTheme.colorScheme.background
    if (themeBackground.luminance() < 0.35f) return themeBackground
    return when (choice) {
        "light", "white" -> Color(0xFFFFFFFF)
        "ice" -> Color(0xFFF6F7FB)
        "lavender" -> Color(0xFFF8F4FF)
        "warm" -> Color(0xFFFFFAF5)
        else -> themeBackground
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun HomeBrowserScreen(
    container: AppContainer,
    viewModel: BrowserViewModel,
    onNavigateToHistory: () -> Unit,
    onNavigateToBookmarks: () -> Unit,
    onNavigateToSettings: () -> Unit
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsState()
    val detectedMedia by viewModel.detectedMediaList.collectAsState()
    val showQuickAccess by container.preferenceManager.showQuickAccess.collectAsState(initial = true)
    val storedHomeShortcuts by container.preferenceManager.homeShortcuts.collectAsState(initial = HomeShortcutDefaults.items)
    val blockAdsEnabled by container.preferenceManager.blockAds.collectAsState(initial = true)
    val adBlockingFlag = remember { AtomicBoolean(blockAdsEnabled) }
    SideEffect { adBlockingFlag.set(blockAdsEnabled) }
    val focusManager = LocalFocusManager.current
    val snackbarHostState = remember { SnackbarHostState() }

    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var showMenuDropdown by remember { mutableStateOf(false) }
    var showHelpDialog by remember { mutableStateOf(false) }
    var showFeedbackDialog by remember { mutableStateOf(false) }
    var showAddressDialog by remember { mutableStateOf(false) }
    var showQuickLinksEditor by remember { mutableStateOf(false) }
    val homeCoroutineScope = rememberCoroutineScope()
    var addressDraft by remember { mutableStateOf("") }
    var showMediaPicker by remember { mutableStateOf(false) }
    var pendingAutomaticDownloadRoute by remember { mutableStateOf(false) }
    var contextMenuTarget by remember { mutableStateOf<BrowserContextTarget?>(null) }
    var showTabSearch by remember { mutableStateOf(false) }
    var tabSearchQuery by remember { mutableStateOf("") }
    var showingPrivateTabs by remember { mutableStateOf(false) }

    val activeTabId = uiState.activeTabId
    val lifecycleOwner = LocalLifecycleOwner.current

    // Persist the latest active tab and all normal tab URLs as soon as the app moves to background.
    // This complements per-navigation DataStore writes and protects the session if Android later
    // kills the process while the browser screen is not visible.
    DisposableEffect(lifecycleOwner, activeTabId) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP) {
                viewModel.persistCurrentBrowserSession(webViewRef)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    LaunchedEffect(uiState.snackbarMessage) {
        uiState.snackbarMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearSnackbar()
        }
    }

    // Remember which explicit address request has already been sent to this tab's WebView.
    val lastHandledNavigationRequest = remember(activeTabId) { mutableStateOf(uiState.navigationRequestId) }
    LaunchedEffect(uiState.showTabsOverview) {
        if (!uiState.showTabsOverview) {
            showTabSearch = false
            tabSearchQuery = ""
        }
    }

    LaunchedEffect(uiState.currentUrl) {
        if (PlatformMediaOverlayScript.supportsUrl(uiState.currentUrl)) {
            pendingAutomaticDownloadRoute = false
            showMediaPicker = false
        }
    }

    // If the user taps Download before the scan has populated candidates, wait for the existing
    // detector to settle, then route straight to the best quality sheet when possible. The list is
    // only shown for multiple separate videos when none has multiple known resolutions.
    LaunchedEffect(detectedMedia, uiState.isMediaDetectionLoading, uiState.currentUrl, pendingAutomaticDownloadRoute) {
        if (!pendingAutomaticDownloadRoute) return@LaunchedEffect
        if (PlatformMediaOverlayScript.supportsUrl(uiState.currentUrl)) {
            pendingAutomaticDownloadRoute = false
            showMediaPicker = false
            return@LaunchedEffect
        }
        if (detectedMedia.isEmpty()) {
            if (!uiState.isMediaDetectionLoading) {
                pendingAutomaticDownloadRoute = false
                if (!TikTokBrowserMode.isTikTokUrl(uiState.currentUrl)) {
                    showMediaPicker = true
                }
            }
            return@LaunchedEffect
        }
        if (uiState.isMediaDetectionLoading) return@LaunchedEffect

        // Detection callbacks can arrive in batches; let the final batch update before choosing.
        delay(400)
        if (!pendingAutomaticDownloadRoute) return@LaunchedEffect
        val groups = SmartMediaFilter.apply(
            detectedMedia,
            uiState.currentUrl,
            SmartFilterSettings()
        ).visibleGroups
        val preferredGroup = MediaSelectionRouting.preferredGroup(groups)
        pendingAutomaticDownloadRoute = false
        if (preferredGroup == null || MediaSelectionRouting.shouldShowDetectedList(groups)) {
            showMediaPicker = true
        } else {
            showMediaPicker = false
            viewModel.selectCandidateGroupForDownload(
                preferredGroup.candidates.map { it.copy(title = preferredGroup.title) }
            )
        }
    }

    BackHandler(enabled = uiState.showTabsOverview || !uiState.isHomeView) {
        when {
            uiState.showTabsOverview -> viewModel.closeTabsOverview()
            webViewRef?.canGoBack() == true -> {
                webViewRef?.goBack()
                webViewRef?.post {
                    webViewRef?.let { viewModel.updateNavigationState(activeTabId, it.canGoBack(), it.canGoForward()) }
                }
            }
            else -> viewModel.setHomeView()
        }
    }

    fun shareText(text: String, chooserTitle: String) {
        try {
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, text)
            }
            context.startActivity(Intent.createChooser(shareIntent, chooserTitle))
        } catch (_: Exception) {
            Toast.makeText(context, "Unable to share from this device", Toast.LENGTH_SHORT).show()
        }
    }

    fun shareCurrentPage() {
        val url = uiState.currentUrl.ifBlank { uiState.inputUrl }
        if (url.isNotBlank()) shareText(url, "Share link")
        else shareText("Try Video Downloader", "Share with friends")
    }

    fun copyCurrentLink() {
        val url = uiState.currentUrl.ifBlank { uiState.inputUrl }
        if (url.isBlank()) {
            Toast.makeText(context, "Open a website first", Toast.LENGTH_SHORT).show()
            return
        }
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("URL", url))
        Toast.makeText(context, "Link copied to clipboard", Toast.LENGTH_SHORT).show()
    }

    fun changeDesktopMode(enabled: Boolean) {
        viewModel.setDesktopMode(enabled)
        webViewRef?.let { browser ->
            browser.settings.userAgentString = if (enabled) {
                // Desktop mode intentionally uses a desktop UA. Keep it isolated from mobile mode.
                "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36"
            } else {
                // Rebuild the Chrome-style mobile UA from this device's installed WebView version.
                TikTokBrowserMode.mobileBrowserUserAgent(context)
            }
            if (!uiState.isHomeView) browser.reload()
        }
    }

    fun openSite(url: String) {
        focusManager.clearFocus()
        val normalizedUrl = if (url.startsWith("http://", true) || url.startsWith("https://", true)) url else "https://$url"
        if (PlatformMediaOverlayScript.isSingleMediaPostUrl(normalizedUrl)) {
            viewModel.analyzeExternalUrl(normalizedUrl)
        } else {
            viewModel.loadUrl(url)
        }
    }

    fun pasteClipboardToHome() {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val pasted = runCatching { clipboard.primaryClip?.getItemAt(0)?.coerceToText(context)?.toString().orEmpty() }.getOrDefault("").trim()
        if (pasted.isBlank()) {
            Toast.makeText(context, "Clipboard is empty", Toast.LENGTH_SHORT).show()
        } else {
            viewModel.onInputUrlChanged(pasted)
        }
    }

    fun navigateFromHomeAction(rawInput: String) {
        val trimmed = rawInput.trim()
        if (trimmed.isBlank()) {
            Toast.makeText(context, "Enter a search term or website address", Toast.LENGTH_SHORT).show()
            return
        }
        // A pasted/shared Meta single-post link gets a targeted extraction pass first. Ordinary
        // searches and all non-Meta URLs keep the previous navigation path unchanged.
        pendingAutomaticDownloadRoute = false
        focusManager.clearFocus()
        val normalizedUrl = if (trimmed.startsWith("http://", true) || trimmed.startsWith("https://", true)) {
            trimmed
        } else {
            "https://$trimmed"
        }
        if (PlatformMediaOverlayScript.isSingleMediaPostUrl(normalizedUrl)) {
            viewModel.analyzeExternalUrl(normalizedUrl)
        } else {
            viewModel.loadUrl(trimmed)
        }
    }

    /** Invokes the page sniffer. TikTok gets its full scanner only after playback is confirmed. */
    fun scanCurrentPage() {
        val browser = webViewRef
        if (browser == null) {
            viewModel.onSnifferScanUnavailable(activeTabId)
            return
        }
        val isTikTokPage = TikTokBrowserMode.isTikTokUrl(uiState.currentUrl)
        if (isTikTokPage && !uiState.hasTikTokPlaybackStarted) {
            viewModel.startManualMediaScan()
            return
        }
        if (isTikTokPage) {
            // First TikTok inspection point: the playback gate has already fired.
            browser.evaluateJavascript(
                "window.__vdTikTokPostPlaybackEnabled=true;\n" + SnifferScript.JAVASCRIPT_SNIFFER,
                null
            )
            return
        }
        browser.evaluateJavascript(
            "(function(){try{if(typeof window.__runVideoSniffer==='function'){window.__runVideoSniffer();return 'SCANNED';}return 'NO_SNIFFER';}catch(e){return 'NO_SNIFFER';}})()"
        ) { result ->
            if (result == "\"NO_SNIFFER\"" || result == "null") {
                viewModel.onSnifferScanUnavailable(activeTabId)
            }
        }
    }

    // TikTok-only phase transition. It starts scanning after playback and routes results to popup.
    LaunchedEffect(uiState.tiktokPlaybackScanRequestId) {
        if (uiState.tiktokPlaybackScanRequestId > 0L &&
            uiState.hasTikTokPlaybackStarted && TikTokBrowserMode.isTikTokUrl(uiState.currentUrl)) {
            pendingAutomaticDownloadRoute = true
            scanCurrentPage()
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        contentWindowInsets = WindowInsets(0.dp),
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            if (!uiState.showTabsOverview && !uiState.isHomeView) {
                BrowserPageTopBar(
                    tabCount = uiState.tabs.size,
                    currentUrl = uiState.currentUrl,
                    loadProgress = uiState.loadProgress,
                    isLoading = uiState.isLoading,
                    onOpenTabs = { viewModel.openTabsOverview() },
                    onHome = { viewModel.setHomeView() },
                    onOpenAddressEditor = {
                        addressDraft = uiState.currentUrl
                        showAddressDialog = true
                    },
                    onReload = { webViewRef?.reload() },
                    onFeedback = { showFeedbackDialog = true },
                    showMenu = showMenuDropdown,
                    onMenuToggle = { showMenuDropdown = it },
                    menu = {
                        BrowserOverflowMenu(
                            expanded = showMenuDropdown,
                            isDesktopMode = uiState.isDesktopMode,
                            onDismiss = { showMenuDropdown = false },
                            onNewTab = { viewModel.createNewTab(isPrivate = uiState.tabs.firstOrNull { it.id == activeTabId }?.isPrivate == true) },
                            onShare = { shareCurrentPage() },
                            onHistory = onNavigateToHistory,
                            onCopyLink = { copyCurrentLink() },
                            onBookmarks = onNavigateToBookmarks,
                            onAddBookmark = { viewModel.toggleBookmark() },
                            onDesktopModeChange = ::changeDesktopMode,
                            onShareWithFriends = { shareText("Try Video Downloader", "Share with friends") },
                            onHelp = { showHelpDialog = true },
                            onSettings = onNavigateToSettings
                        )
                    }
                )
            }
        },
        floatingActionButton = {
            if (!uiState.isHomeView && !uiState.showTabsOverview && !PlatformMediaOverlayScript.supportsUrl(uiState.currentUrl)) {
                FloatingActionButton(
                    onClick = {
                        val result = SmartMediaFilter.apply(
                            detectedMedia,
                            uiState.currentUrl,
                            SmartFilterSettings()
                        )
                        val groups = result.visibleGroups
                        val preferredGroup = MediaSelectionRouting.preferredGroup(groups)
                        when {
                            uiState.isMediaDetectionLoading -> {
                                // Wait for in-flight candidates to finish resolving before deciding
                                // whether this page needs a list or can open one video's qualities.
                                pendingAutomaticDownloadRoute = true
                                showMediaPicker = false
                            }
                            groups.isEmpty() && detectedMedia.isEmpty() -> {
                                // There is not enough data to choose a route yet. Keep the list
                                // closed while scanning; the effect above will route once ready.
                                pendingAutomaticDownloadRoute = true
                                showMediaPicker = false
                                viewModel.startManualMediaScan()
                            }
                            groups.isEmpty() -> {
                                // Everything may have been filtered. Keep the review/list available
                                // so the user can open Other Detected instead of losing the streams.
                                pendingAutomaticDownloadRoute = false
                                showMediaPicker = true
                            }
                            MediaSelectionRouting.shouldShowDetectedList(groups) -> {
                                pendingAutomaticDownloadRoute = false
                                showMediaPicker = true
                            }
                            preferredGroup != null -> {
                                pendingAutomaticDownloadRoute = false
                                showMediaPicker = false
                                viewModel.selectCandidateGroupForDownload(
                                    preferredGroup.candidates.map { it.copy(title = preferredGroup.title) }
                                )
                            }
                            else -> {
                                pendingAutomaticDownloadRoute = false
                                showMediaPicker = true
                            }
                        }
                        scanCurrentPage()
                    },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    shape = CircleShape,
                    modifier = Modifier.size(56.dp).testTag("floating_download_btn")
                ) {
                    if (uiState.isMediaDetectionLoading) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(25.dp),
                            color = MaterialTheme.colorScheme.onPrimary,
                            strokeWidth = 2.5.dp
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.Download,
                            contentDescription = if (detectedMedia.isEmpty()) "Scan for downloadable media" else "Choose video to download",
                            tint = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.size(25.dp)
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            when {
                uiState.showTabsOverview -> BrowserTabsOverview(
                    tabs = uiState.tabs,
                    onBack = { viewModel.closeTabsOverview() },
                    activeTabId = uiState.activeTabId,
                    showingPrivateTabs = showingPrivateTabs,
                    onShowPrivateTabs = { showingPrivateTabs = it; showTabSearch = false; tabSearchQuery = "" },
                    searchExpanded = showTabSearch,
                    searchQuery = tabSearchQuery,
                    onToggleSearch = { showTabSearch = !showTabSearch; if (showTabSearch) tabSearchQuery = "" },
                    onSearchQueryChanged = { tabSearchQuery = it },
                    onSelect = { viewModel.selectTab(it) },
                    onCloseTab = { viewModel.closeTab(it) },
                    onNewTab = { isPrivate -> viewModel.createNewTab(isPrivate = isPrivate) },
                    onClearAll = { privateOnly -> viewModel.clearAllTabs(privateOnly) }
                )
                uiState.isHomeView -> BrowserHomeContent(
                    inputUrl = uiState.inputUrl,
                    tabCount = uiState.tabs.size,
                    showSocialApps = showQuickAccess,
                    onOpenTabs = { viewModel.openTabsOverview() },
                    onPremium = {
                        Toast.makeText(context, "Premium is coming soon", Toast.LENGTH_SHORT).show()
                    },
                    onPrivateFolder = {
                        Toast.makeText(context, "Private folder is locked", Toast.LENGTH_SHORT).show()
                    },
                    onSettings = onNavigateToSettings,
                    onInputChanged = viewModel::onInputUrlChanged,
                    onNavigate = ::openSite,
                    onOpenUrl = ::openSite,
                    onPasteClipboard = ::pasteClipboardToHome,
                    onDownload = { navigateFromHomeAction(uiState.inputUrl) },
                    onHelp = { showHelpDialog = true },
                    onSeeAll = { showQuickLinksEditor = true }
                )
                else -> {
                    val currentTabId = uiState.activeTabId
                    key(currentTabId) {
                        AndroidView(
                            modifier = Modifier.fillMaxSize().testTag("browser_webview"),
                            factory = { ctx ->
                                WebView(ctx).apply {
                                    layoutParams = ViewGroup.LayoutParams(
                                        ViewGroup.LayoutParams.MATCH_PARENT,
                                        ViewGroup.LayoutParams.MATCH_PARENT
                                    )
                                    settings.apply {
                                        javaScriptEnabled = true
                                        domStorageEnabled = true
                                        databaseEnabled = true
                                        mediaPlaybackRequiresUserGesture = false
                                        mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                                        loadsImagesAutomatically = true
                                        blockNetworkImage = false
                                        blockNetworkLoads = false
                                        cacheMode = WebSettings.LOAD_DEFAULT
                                        javaScriptCanOpenWindowsAutomatically = true
                                        allowFileAccess = false
                                        allowContentAccess = false
                                        safeBrowsingEnabled = true
                                        userAgentString = if (uiState.isDesktopMode) {
                                            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36"
                                        } else {
                                            // Keep the installed Chromium version/device token while using
                                            // the common Chrome-style mobile UA format.
                                            TikTokBrowserMode.mobileBrowserUserAgent(ctx)
                                        }
                                        setSupportMultipleWindows(false)
                                    }

                                    CookieManager.getInstance().setAcceptCookie(true)
                                    CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)

                                    val browserView = this
                                    val mainHandler = Handler(Looper.getMainLooper())
                                    val mediaBridge = AndroidMediaBridge(
                                        onVideoDetected = { url, title, duration, resolution, poster, isPlaying, mimeType, videoGroupId ->
                                            // JavaScript interfaces run on a bridge thread; use the main thread
                                            // for WebView properties and publish only validated metadata.
                                            mainHandler.post {
                                                container.mediaDetector.onDomVideoFound(
                                                    url = url,
                                                    title = title,
                                                    durationSeconds = duration,
                                                    resolution = resolution,
                                                    posterUrl = poster,
                                                    currentPageUrl = browserView.url,
                                                    isPlaying = isPlaying,
                                                    mimeType = mimeType,
                                                    videoGroupId = videoGroupId,
                                                    userAgent = browserView.settings.userAgentString
                                                )
                                            }
                                        },
                                        onResourceDetected = { url, mimeType, isPlaying ->
                                            mainHandler.post {
                                                container.mediaDetector.onScriptResourceFound(
                                                    url = url,
                                                    mimeType = mimeType,
                                                    currentPageUrl = browserView.url,
                                                    userAgent = browserView.settings.userAgentString,
                                                    isPlaying = isPlaying
                                                )
                                            }
                                        },
                                        onPageMetadataDetected = { title, poster, duration ->
                                            mainHandler.post {
                                                viewModel.onPageMetadata(currentTabId, title, poster, duration, browserView.url)
                                            }
                                        },
                                        onScanFinishedCallback = { count ->
                                            mainHandler.post {
                                                viewModel.onSnifferScanCompleted(currentTabId, count)
                                            }
                                        },
                                        onTikTokPlaybackConfirmedCallback = { _ ->
                                            mainHandler.post {
                                                val actualPageUrl = browserView.url.orEmpty()
                                                if (TikTokBrowserMode.isTikTokUrl(actualPageUrl)) {
                                                    viewModel.onTikTokPlaybackConfirmed(currentTabId, actualPageUrl)
                                                }
                                            }
                                        },
                                        onPlatformMediaActionDetected = { kind, mediaUrl, mimeType, title, duration, _, _, isVideoPosterTarget, thumbnailUrl, contentItemUrl ->
                                            mainHandler.post {
                                                val pageUrl = browserView.url.orEmpty()
                                                val platform = PlatformMediaOverlayScript.platformForUrl(pageUrl)
                                                if (platform == null) return@post
                                                if (mediaUrl.isNullOrBlank()) {
                                                    // For a Story/Reel poster, first resolve only that item's own permalink
                                                    // through the signed-in session. The same card thumbnail is the final fallback.
                                                    if (kind == "video" && isVideoPosterTarget) {
                                                        viewModel.resolveMetaVideoOrThumbnail(
                                                            itemPageUrl = contentItemUrl,
                                                            thumbnailUrl = thumbnailUrl,
                                                            title = title,
                                                            pageUrl = pageUrl,
                                                            userAgent = browserView.settings.userAgentString,
                                                            durationSeconds = duration
                                                        )
                                                        return@post
                                                    }
                                                    val pageCandidates = if (isVideoPosterTarget) emptyList() else viewModel.detectedMediaList.value.filter {
                                                        it.sourcePlatform == platform && !it.isLikelyAd &&
                                                            PlatformMediaOverlayScript.isAllowedMediaUrl(platform, it.url) &&
                                                            (it.mimeType.orEmpty().startsWith("video/") || it.streamType == StreamType.HLS || it.streamType == StreamType.DASH)
                                                    }
                                                    val active = pageCandidates.filter { it.isPlaying }
                                                    val fallback = active.singleOrNull() ?: pageCandidates.singleOrNull()
                                                    if (kind == "video" && fallback != null) {
                                                        viewModel.selectCandidateForDownload(fallback)
                                                    } else {
                                                        val message = if (kind == "image") "This image has not exposed an original downloadable URL." else "This player has not exposed a direct media URL yet."
                                                        Toast.makeText(ctx, message, Toast.LENGTH_SHORT).show()
                                                    }
                                                    return@post
                                                }
                                                if (!PlatformMediaOverlayScript.isAllowedMediaUrl(platform, mediaUrl)) {
                                                    Toast.makeText(ctx, "This media URL is not from a supported platform CDN.", Toast.LENGTH_SHORT).show()
                                                    return@post
                                                }
                                                viewModel.selectPlatformMediaAction(
                                                    kind = kind,
                                                    mediaUrl = mediaUrl,
                                                    mimeType = mimeType,
                                                    title = title,
                                                    pageUrl = pageUrl,
                                                    userAgent = browserView.settings.userAgentString,
                                                    durationSeconds = duration
                                                )
                                            }
                                        },
                                        onMetaVideoDetected = { url, title, duration, poster, isPlaying, mimeType, videoGroupId, contentItemUrl ->
                                            mainHandler.post {
                                                val pageUrl = browserView.url.orEmpty()
                                                if (PlatformMediaOverlayScript.platformForUrl(pageUrl) != null) {
                                                    viewModel.onMetaVideoCandidate(
                                                        mediaUrl = url,
                                                        title = title,
                                                        durationSeconds = duration,
                                                        posterUrl = poster,
                                                        isPlaying = isPlaying,
                                                        mimeType = mimeType,
                                                        videoGroupId = videoGroupId,
                                                        contentItemUrl = contentItemUrl,
                                                        pageUrl = pageUrl,
                                                        userAgent = browserView.settings.userAgentString
                                                    )
                                                }
                                            }
                                        },
                                        onInlineDashManifestDetected = { manifestText, responseUrl, title, duration, poster, contentItemUrl ->
                                            mainHandler.post {
                                                val pageUrl = browserView.url.orEmpty()
                                                if (PlatformMediaOverlayScript.platformForUrl(pageUrl) != null) {
                                                    viewModel.onMetaInlineDashManifest(
                                                        manifestText = manifestText,
                                                        responseUrl = responseUrl,
                                                        title = title,
                                                        durationSeconds = duration,
                                                        posterUrl = poster,
                                                        contentItemUrl = contentItemUrl,
                                                        pageUrl = pageUrl,
                                                        userAgent = browserView.settings.userAgentString
                                                    )
                                                }
                                            }
                                        }
                                    )
                                    addJavascriptInterface(mediaBridge, "AndroidMediaBridge")
                                    // Catch first-party Meta fetch/XHR and media requests before the
                                    // site's own scripts run. Older WebView builds safely fall back
                                    // to SecureWebViewClient's onPageStarted/onPageFinished injection.
                                    runCatching {
                                        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
                                            WebViewCompat.addDocumentStartJavaScript(
                                                browserView,
                                                SnifferScript.JAVASCRIPT_SNIFFER,
                                                setOf(
                                                    "https://facebook.com", "https://*.facebook.com",
                                                    "https://fb.com", "https://*.fb.com",
                                                    "https://fb.watch", "https://*.fb.watch",
                                                    "https://instagram.com", "https://*.instagram.com",
                                                    "https://instagr.am", "https://*.instagr.am",
                                                    "https://threads.com", "https://*.threads.com",
                                                    "https://threads.net", "https://*.threads.net"
                                                )
                                            )
                                        }
                                    }
                                    // Keep third-party pages untouched until their document has loaded.
                                    // The non-TikTok sniffer is injected once from onPageFinished;
                                    // TikTok receives only its playback observer until playback starts.

                                    webViewClient = SecureWebViewClient(
                                        mediaDetector = container.mediaDetector,
                                        onPageStartedCallback = { url ->
                                            viewModel.onPageStarted(currentTabId, url)
                                            viewModel.updateNavigationState(currentTabId, canGoBack(), canGoForward())
                                        },
                                        onPageFinishedCallback = { url, title ->
                                            viewModel.onPageFinished(currentTabId, url, title)
                                            viewModel.updateNavigationState(currentTabId, canGoBack(), canGoForward())
                                        },
                                        browserUserAgent = browserView.settings.userAgentString,
                                        adBlockingEnabled = { adBlockingFlag.get() }
                                    )

                                    webChromeClient = SecureWebChromeClient(
                                        onProgressUpdate = { progress ->
                                            viewModel.onProgressChanged(currentTabId, progress)
                                            viewModel.updateNavigationState(currentTabId, canGoBack(), canGoForward())
                                        },
                                        onTitleReceived = { title ->
                                            viewModel.onPageTitleChanged(currentTabId, this.url ?: "", title)
                                        }
                                    )

                                    var lastTouchX = 0f
                                    var lastTouchY = 0f
                                    setOnTouchListener { _, event ->
                                        if (event.actionMasked == MotionEvent.ACTION_DOWN || event.actionMasked == MotionEvent.ACTION_MOVE) {
                                            lastTouchX = event.x
                                            lastTouchY = event.y
                                        }
                                        // Let WebView receive the event normally; only remember coordinates.
                                        false
                                    }
                                    setOnLongClickListener { _ ->
                                        val hit = browserView.hitTestResult
                                        if (hit == null) {
                                            false
                                        } else {
                                            val fallbackUrl = hit.extra?.trim().orEmpty()
                                            val density = resources.displayMetrics.density.coerceAtLeast(1f)
                                            val xCss = lastTouchX / density
                                            val yCss = lastTouchY / density
                                            val script = """
                                                (function(x,y){
                                                  try {
                                                    var el=document.elementFromPoint(x,y);
                                                    if(!el) return JSON.stringify({});
                                                    var anchor=el.closest ? el.closest('a[href]') : null;
                                                    var picture=el.closest?el.closest('picture'):null;
                                                    var image=(el.tagName==='IMG')?el:(picture && picture.querySelector ? picture.querySelector('img') : null);
                                                    var video=(el.tagName==='VIDEO')?el:(el.closest?el.closest('video'):null);
                                                    return JSON.stringify({
                                                      href: anchor ? anchor.href : '',
                                                      imageUrl: image ? (image.currentSrc || image.src || '') : '',
                                                      videoUrl: video ? (video.currentSrc || video.src || '') : '',
                                                      isVideo: !!video
                                                    });
                                                  } catch(e) { return JSON.stringify({}); }
                                                })($xCss,$yCss)
                                            """.trimIndent()
                                            browserView.evaluateJavascript(script) { result ->
                                                val details = parseBrowserElementDetails(result)
                                                val rawLink = details?.href?.takeIf { isHttpUrl(it) }
                                                val rawImage = details?.imageUrl?.takeIf { isHttpUrl(it) }
                                                val rawVideo = details?.videoUrl?.takeIf { isHttpUrl(it) }
                                                val isVideoElement = details?.isVideoElement == true
                                                val candidateFallback = viewModel.detectedMediaList.value.firstOrNull {
                                                    it.isPlaying && (it.sourcePageUrl.isNullOrBlank() || it.sourcePageUrl == browserView.url)
                                                }?.url
                                                // Android WebView HitTestResult has no VIDEO_TYPE constant. Identify
                                                // video targets using the actual DOM element and media URL instead.
                                                val targetUrl = when {
                                                    hit.type == WebView.HitTestResult.IMAGE_TYPE -> rawImage ?: fallbackUrl
                                                    hit.type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE -> rawLink ?: fallbackUrl
                                                    hit.type == WebView.HitTestResult.SRC_ANCHOR_TYPE -> rawLink ?: fallbackUrl
                                                    isVideoElement -> rawVideo
                                                        ?: fallbackUrl.takeIf { isHttpUrl(it) }
                                                        ?: candidateFallback.orEmpty()
                                                    rawVideo != null -> rawVideo
                                                    else -> rawLink ?: fallbackUrl
                                                }
                                                val mediaUrl = when {
                                                    isVideoElement -> rawVideo
                                                        ?: fallbackUrl.takeIf { isMediaUrl(it) }
                                                        ?: candidateFallback
                                                    isMediaUrl(targetUrl) -> targetUrl
                                                    else -> null
                                                }
                                                val imageUrl = if (
                                                    hit.type == WebView.HitTestResult.IMAGE_TYPE ||
                                                    hit.type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE ||
                                                    rawImage != null
                                                ) rawImage ?: fallbackUrl.takeIf { hit.type == WebView.HitTestResult.IMAGE_TYPE } else null
                                                if (isHttpUrl(targetUrl)) {
                                                    contextMenuTarget = BrowserContextTarget(
                                                        url = targetUrl,
                                                        hitType = hit.type,
                                                        pageUrl = browserView.url.orEmpty(),
                                                        mediaUrl = mediaUrl,
                                                        imageUrl = imageUrl
                                                    )
                                                }
                                            }
                                            true
                                        }
                                    }

                                    setDownloadListener { url, userAgent, contentDisposition, mimeType, contentLength ->
                                        container.mediaDetector.onServerDownloadStart(
                                            url = url,
                                            userAgent = userAgent,
                                            contentDisposition = contentDisposition,
                                            mimeType = mimeType,
                                            contentLength = contentLength,
                                            currentPageUrl = this.url
                                        )
                                    }

                                    val restored = viewModel.restoreWebViewState(currentTabId, this)
                                    if (!restored && uiState.currentUrl.isNotBlank()) {
                                        loadUrl(uiState.currentUrl)
                                    }
                                    lastHandledNavigationRequest.value = uiState.navigationRequestId
                                    webViewRef = this
                                }
                            },
                            update = { browser ->
                                webViewRef = browser
                                // Only an explicit new address request triggers loadUrl. Page redirects
                                // and title/progress updates do not repeatedly reload the page.
                                if (lastHandledNavigationRequest.value != uiState.navigationRequestId) {
                                    lastHandledNavigationRequest.value = uiState.navigationRequestId
                                    if (!uiState.isHomeView && uiState.currentUrl.isNotBlank() && browser.url != uiState.currentUrl) {
                                        browser.loadUrl(uiState.currentUrl)
                                    }
                                }
                            },
                            onRelease = { browser ->
                                val tabBeforeRelease = viewModel.uiState.value.tabs.firstOrNull { it.id == currentTabId }
                                if (tabBeforeRelease != null && !tabBeforeRelease.isHomeView) {
                                    captureWebViewPreview(browser)?.let { preview ->
                                        viewModel.updateTabPreview(currentTabId, preview)
                                    }
                                }
                                viewModel.saveWebViewState(currentTabId, browser)
                                try {
                                    browser.stopLoading()
                                    browser.onPause()
                                    browser.removeJavascriptInterface("AndroidMediaBridge")
                                    browser.destroy()
                                } catch (_: Exception) {
                                    // Releasing a WebView must not crash navigation.
                                }
                                if (webViewRef === browser) webViewRef = null
                            }
                        )
                    }
                }
            }
        }
    }

    contextMenuTarget?.let { target ->
        // Only show Download image when we have an image source. For a linked image, the
        // link URL and image URL differ; never download the HTML link as if it were an image.
        val imageTarget = target.imageUrl != null || isImageUrl(target.url)
        // HitTestResult has no VIDEO_TYPE on Android; use the detected media URL.
        val videoTarget = !target.mediaUrl.isNullOrBlank() || isMediaUrl(target.url)
        Dialog(
            onDismissRequest = { contextMenuTarget = null },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Surface(
                modifier = Modifier.fillMaxWidth(0.88f).widthIn(max = 430.dp),
                shape = RoundedCornerShape(22.dp),
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 18.dp
            ) {
                Column(modifier = Modifier.padding(horizontal = 18.dp, vertical = 15.dp)) {
                    Text(
                        target.url,
                        modifier = Modifier.padding(bottom = 7.dp),
                        color = MaterialTheme.colorScheme.onSurface,
                        fontSize = 15.sp,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    BrowserContextAction("Open in new tab", Icons.Default.Add) {
                        contextMenuTarget = null
                        viewModel.openUrlInNewTab(target.url, activate = true)
                    }
                    BrowserContextAction("Open in background tab", Icons.Default.Add) {
                        contextMenuTarget = null
                        viewModel.openUrlInNewTab(target.url, activate = false)
                    }
                    BrowserContextAction("Share", Icons.Default.Share) {
                        contextMenuTarget = null
                        shareText(target.url, "Share link")
                    }
                    BrowserContextAction("Copy link", Icons.Default.ContentCopy) {
                        contextMenuTarget = null
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clipboard.setPrimaryClip(ClipData.newPlainText("URL", target.url))
                        Toast.makeText(context, "Link copied to clipboard", Toast.LENGTH_SHORT).show()
                    }
                    if (imageTarget) {
                        BrowserContextAction("Download image", Icons.Default.Download) {
                            contextMenuTarget = null
                            val downloadUrl = target.imageUrl ?: target.url
                            val existing = detectedMedia.firstOrNull { it.url.substringBefore('#') == downloadUrl.substringBefore('#') }
                            val mime = contextMimeType(downloadUrl, imageHint = true)
                            val title = contextFileTitle(downloadUrl, "image_${System.currentTimeMillis()}")
                            val candidate = existing ?: MediaCandidate(
                                id = "context-image-${downloadUrl.hashCode()}-${System.currentTimeMillis()}",
                                url = downloadUrl,
                                title = title,
                                mimeType = mime,
                                userAgent = webViewRef?.settings?.userAgentString,
                                referer = target.pageUrl,
                                sourcePageUrl = target.pageUrl,
                                sourcePlatform = PlatformSource.GENERIC_WEB,
                                streamType = StreamType.PROGRESSIVE,
                                isDirectDownload = true,
                                detectionSource = MediaDetectionSource.NETWORK_REQUEST,
                                detectionConfidence = 85
                            )
                            viewModel.confirmDownload(candidate.copy(mimeType = mime, title = title), title, false)
                        }
                    } else if (videoTarget) {
                        BrowserContextAction("Download video", Icons.Default.Download) {
                            contextMenuTarget = null
                            val downloadUrl = target.mediaUrl ?: target.url
                            val existing = detectedMedia.firstOrNull { it.url.substringBefore('#') == downloadUrl.substringBefore('#') }
                            if (existing != null) {
                                viewModel.selectCandidateForDownload(existing)
                            } else {
                                val mime = contextMimeType(downloadUrl, imageHint = false)
                                val type = when {
                                    mime.contains("mpegurl") -> StreamType.HLS
                                    mime.contains("dash+xml") -> StreamType.DASH
                                    else -> StreamType.PROGRESSIVE
                                }
                                val title = contextFileTitle(downloadUrl, "video_${System.currentTimeMillis()}")
                                val candidate = MediaCandidate(
                                    id = "context-video-${downloadUrl.hashCode()}-${System.currentTimeMillis()}",
                                    url = downloadUrl,
                                    title = title,
                                    mimeType = mime,
                                    userAgent = webViewRef?.settings?.userAgentString,
                                    referer = target.pageUrl,
                                    sourcePageUrl = target.pageUrl,
                                    sourcePlatform = PlatformSource.GENERIC_WEB,
                                    streamType = type,
                                    isDirectDownload = type == StreamType.PROGRESSIVE,
                                    detectionSource = MediaDetectionSource.NETWORK_REQUEST,
                                    detectionConfidence = 85
                                )
                                viewModel.selectCandidateForDownload(candidate)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showMediaPicker && !PlatformMediaOverlayScript.supportsUrl(uiState.currentUrl)) {
        MediaCandidatesPicker(
            candidates = detectedMedia,
            pageUrl = uiState.currentUrl,
            isDetecting = uiState.isMediaDetectionLoading,
            detectionStage = uiState.mediaDetectionStage,
            onDismiss = { showMediaPicker = false; pendingAutomaticDownloadRoute = false },
            onScanAgain = {
                viewModel.startManualMediaScan()
                scanCurrentPage()
            },
            onSelect = { group ->
                showMediaPicker = false
                viewModel.selectCandidateGroupForDownload(group.candidates.map { it.copy(title = group.title) })
            }
        )
    }

    if (uiState.showMediaSheet && uiState.selectedCandidate != null) {
        val platformLabel = when (uiState.selectedCandidate!!.sourcePlatform) {
            PlatformSource.INSTAGRAM -> "Instagram"
            PlatformSource.TIKTOK -> "TikTok"
            PlatformSource.FACEBOOK -> "Facebook"
            PlatformSource.TWITTER_X -> "Twitter / X"
            PlatformSource.REDDIT -> "Reddit"
            PlatformSource.PINTEREST -> "Pinterest"
            PlatformSource.THREADS -> "Threads"
            else -> "Video"
        }
        val isPlatformMediaSelection = uiState.selectedCandidate!!.sourcePlatform in setOf(
            PlatformSource.FACEBOOK, PlatformSource.INSTAGRAM, PlatformSource.THREADS
        )
        MediaSelectionBottomSheet(
            candidate = uiState.selectedCandidate!!,
            platformName = platformLabel,
            candidates = uiState.selectedCandidates,
            allDetectedCandidates = if (isPlatformMediaSelection) uiState.selectedCandidates else detectedMedia,
            currentPageUrl = if (isPlatformMediaSelection) {
                uiState.selectedCandidate!!.sourcePageUrl ?: uiState.currentUrl
            } else uiState.currentUrl,
            isParsing = uiState.isResolvingVariants,
            enableOtherDetected = !isPlatformMediaSelection,
            onDismiss = { viewModel.dismissMediaSheet() },
            onSelectOtherCandidates = { otherCandidates ->
                viewModel.selectCandidateGroupForDownload(otherCandidates)
            },
            onConfirmDownload = { chosenCandidate, customTitle, rememberSession ->
                viewModel.confirmDownload(chosenCandidate, customTitle, rememberSession)
            }
        )
    }

    if (showAddressDialog) {
        AlertDialog(
            onDismissRequest = { showAddressDialog = false },
            title = { Text("Search or type URL") },
            text = {
                OutlinedTextField(
                    value = addressDraft,
                    onValueChange = { addressDraft = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    placeholder = { Text("https://example.com") },
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(onGo = {
                        showAddressDialog = false
                        openSite(addressDraft)
                    })
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showAddressDialog = false
                    openSite(addressDraft)
                }) { Text("Go") }
            },
            dismissButton = {
                TextButton(onClick = { showAddressDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showHelpDialog) {
        AlertDialog(
            onDismissRequest = { showHelpDialog = false },
            title = { Text("Browser help") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Enter a web address or search phrase in the home search bar.")
                    Text("Tap the tab counter to switch between open tabs. Your current page and navigation history are kept when you open Progress or Finished.")
                    Text("On a page, tap the download button after playing a video so the browser can detect available media.")
                }
            },
            confirmButton = { TextButton(onClick = { showHelpDialog = false }) { Text("Got it") } }
        )
    }

    if (showFeedbackDialog) {
        var feedbackText by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showFeedbackDialog = false },
            title = { Text("Got feedback or questions?") },
            text = {
                Column {
                    Text("Write a note or bug report. It will open your email/share app so you can send it.")
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = feedbackText,
                        onValueChange = { feedbackText = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("Write your message here…") },
                        maxLines = 4
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val message = feedbackText.ifBlank { "Feedback about Video Downloader" }
                    shareText(message, "Send feedback")
                    showFeedbackDialog = false
                }) { Text("Send") }
            },
            dismissButton = {
                TextButton(onClick = { showFeedbackDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showQuickLinksEditor) {
        QuickLinksEditorDialog(
            shortcuts = storedHomeShortcuts,
            onDismiss = { showQuickLinksEditor = false },
            onAdd = { shortcut ->
                val host = shortcutHostForHome(shortcut.url)
                if (storedHomeShortcuts.any { shortcutHostForHome(it.url) == host }) {
                    Toast.makeText(context, "This website is already in Quick Access", Toast.LENGTH_SHORT).show()
                } else if (storedHomeShortcuts.size >= 20) {
                    Toast.makeText(context, "You can add up to 20 shortcuts", Toast.LENGTH_SHORT).show()
                } else {
                    homeCoroutineScope.launch {
                        container.preferenceManager.addHomeShortcut(shortcut)
                    }
                }
            },
            onRemove = { url ->
                homeCoroutineScope.launch {
                    container.preferenceManager.removeHomeShortcut(url)
                }
            }
        )
    }
}

@Composable
private fun HomeTopBar(
    tabCount: Int,
    onOpenTabs: () -> Unit,
    onPremium: () -> Unit,
    onPrivateFolder: () -> Unit,
    onSettings: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(60.dp)
            .background(ReferenceHomeWhite)
            .padding(start = 14.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(0.dp)
    ) {
        ReferenceHomeTabCounter(tabCount = tabCount, onClick = onOpenTabs)
        Text(
            text = "Video Downloader",
            modifier = Modifier.weight(1f).padding(start = 14.dp),
            color = ReferenceHomeInk,
            fontSize = 18.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 1,
            softWrap = false,
            overflow = TextOverflow.Ellipsis
        )
        IconButton(onClick = onPremium, modifier = Modifier.size(44.dp)) {
            ReferenceCrownIcon(Modifier.size(28.dp))
        }
        IconButton(onClick = onPrivateFolder, modifier = Modifier.size(44.dp)) {
            ReferencePrivateFolderIcon(Modifier.size(28.dp))
        }
        IconButton(onClick = onSettings, modifier = Modifier.size(44.dp)) {
            ReferenceStrokeIcon(
                pathData = "M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0z",
                modifier = Modifier.size(27.dp),
                strokeWidth = 1.9.dp
            )
        }
    }
}

@Composable
private fun ReferenceHomeTabCounter(tabCount: Int, onClick: () -> Unit) {
    Box(
        modifier = Modifier.size(44.dp).clickable(role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .align(Alignment.Center)
                .offset(x = (-5).dp, y = (-4).dp)
                .size(24.dp)
                .border(2.dp, ReferenceHomeInk, RoundedCornerShape(7.dp))
        )
        Box(
            modifier = Modifier
                .align(Alignment.Center)
                .offset(x = 1.dp, y = 1.dp)
                .size(27.dp)
                .background(ReferenceHomeWhite, RoundedCornerShape(8.dp))
                .border(2.dp, ReferenceHomeInk, RoundedCornerShape(8.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = tabCount.toString(),
                color = ReferenceHomeInk,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun ReferenceStrokeIcon(
    pathData: String,
    modifier: Modifier = Modifier,
    strokeWidth: androidx.compose.ui.unit.Dp = 2.dp,
    tint: Color = ReferenceHomeInk
) {
    val path = remember(pathData) { PathParser().parsePathString(pathData).toPath() }
    Canvas(modifier = modifier) {
        withTransform({ scale(size.width / 24f, size.height / 24f, pivot = Offset.Zero) }) {
            drawPath(
                path = path,
                color = tint,
                style = Stroke(
                    width = strokeWidth.toPx(),
                    cap = StrokeCap.Round,
                    join = StrokeJoin.Round
                )
            )
        }
    }
}

@Composable
private fun ReferenceCrownIcon(modifier: Modifier = Modifier) {
    val crown = remember {
        PathParser().parsePathString("M2.5 7.5l5 4.2L12 3.5l4.5 8.2 5-4.2-1.8 11.2H4.3z").toPath()
    }
    val star = remember {
        PathParser().parsePathString("M12 11l1 2.2 2.4.2-1.8 1.6.6 2.4-2.2-1.3-2.2 1.3.6-2.4-1.8-1.6 2.4-.2z").toPath()
    }
    val crownTransition = rememberInfiniteTransition(label = "homeCrownShine")
    val crownRotation by crownTransition.animateFloat(
        initialValue = 0f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = keyframes {
                durationMillis = 4_000
                0f at 0
                0f at 2_800
                -10f at 3_120
                9f at 3_440
                -4f at 3_760
                0f at 4_000
            },
            repeatMode = RepeatMode.Restart
        ),
        label = "homeCrownRotation"
    )
    Canvas(modifier = modifier.graphicsLayer(rotationZ = crownRotation)) {
        withTransform({ scale(size.width / 24f, size.height / 24f, pivot = Offset.Zero) }) {
            drawPath(
                path = crown,
                brush = Brush.linearGradient(
                    colors = listOf(Color(0xFFFFB300), Color(0xFFFF6A00)),
                    start = Offset(0f, 0f),
                    end = Offset(0f, 24f)
                )
            )
            drawPath(
                path = crown,
                color = Color(0xFFFF8A00),
                style = Stroke(width = 1.2.dp.toPx(), join = StrokeJoin.Round)
            )
            drawPath(path = star, color = Color.White)
        }
    }
}

@Composable
private fun ReferencePrivateFolderIcon(modifier: Modifier = Modifier) {
    val folder = remember {
        PathParser().parsePathString("M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z").toPath()
    }
    val lockBody = remember {
        PathParser().parsePathString("M10 12h4a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1h-4a1 1 0 0 1-1-1v-3a1 1 0 0 1 1-1z").toPath()
    }
    val lockShackle = remember {
        PathParser().parsePathString("M10.2 12v-1a1.8 1.8 0 0 1 3.6 0v1").toPath()
    }
    Canvas(modifier = modifier) {
        withTransform({ scale(size.width / 24f, size.height / 24f, pivot = Offset.Zero) }) {
            drawPath(folder, color = ReferenceHomeInk, style = Stroke(width = 1.9.dp.toPx(), join = StrokeJoin.Round))
            drawPath(lockBody, color = ReferenceHomeInk)
            drawPath(lockShackle, color = ReferenceHomeInk, style = Stroke(width = 1.9.dp.toPx(), cap = StrokeCap.Round))
        }
    }
}

@Composable
private fun BrowserPageTopBar(
    tabCount: Int,
    currentUrl: String,
    loadProgress: Int,
    isLoading: Boolean,
    onOpenTabs: () -> Unit,
    onHome: () -> Unit,
    onOpenAddressEditor: () -> Unit,
    onReload: () -> Unit,
    onFeedback: () -> Unit,
    showMenu: Boolean,
    onMenuToggle: (Boolean) -> Unit,
    menu: @Composable () -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface)) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            TabCounter(tabCount = tabCount, onClick = onOpenTabs, size = 30.dp)
            IconButton(onClick = onHome, modifier = Modifier.size(36.dp)) {
                Icon(Icons.Default.Home, contentDescription = "Home", tint = MaterialTheme.colorScheme.onSurface, modifier = Modifier.size(22.dp))
            }
            Surface(
                modifier = Modifier.weight(1f).height(42.dp)
                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(21.dp)),
                shape = RoundedCornerShape(21.dp),
                color = MaterialTheme.colorScheme.surfaceVariant
            ) {
                Row(
                    modifier = Modifier.fillMaxSize().padding(start = 12.dp, end = 5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Public, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(7.dp))
                    Text(
                        text = currentUrl.ifBlank { "Search or type URL" },
                        modifier = Modifier.weight(1f).clickable(onClick = onOpenAddressEditor),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        color = MaterialTheme.colorScheme.onSurface,
                        fontSize = 13.sp
                    )
                    IconButton(onClick = onReload, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Refresh, contentDescription = "Reload", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                    }
                }
            }
            IconButton(onClick = onFeedback, modifier = Modifier.size(36.dp)) {
                Icon(Icons.Default.Feedback, contentDescription = "Feedback", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(21.dp))
            }
            Box {
                IconButton(onClick = { onMenuToggle(true) }, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.Default.MoreVert, contentDescription = "More options", tint = MaterialTheme.colorScheme.onSurface, modifier = Modifier.size(23.dp))
                }
                menu()
            }
        }
        if (isLoading) {
            LinearProgressIndicator(
                progress = { loadProgress / 100f },
                modifier = Modifier.fillMaxWidth().height(2.dp),
                color = MaterialTheme.colorScheme.primary,
                trackColor = MaterialTheme.colorScheme.outlineVariant
            )
        }
    }
}

@Composable
private fun TabCounter(
    tabCount: Int,
    onClick: () -> Unit,
    size: androidx.compose.ui.unit.Dp,
    filled: Boolean = false,
    tint: Color? = null
) {
    val counterTint = tint ?: MaterialTheme.colorScheme.primary
    val pressInteraction = remember { MutableInteractionSource() }
    val pressed by pressInteraction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.94f else 1f, animationSpec = tween(130), label = "tabCounterScale")
    Box(
        modifier = Modifier.size(size)
            .graphicsLayer(scaleX = scale, scaleY = scale)
            .then(if (filled) Modifier.background(counterTint, RoundedCornerShape(10.dp)) else Modifier.border(2.dp, counterTint, RoundedCornerShape(8.dp)))
            .clip(RoundedCornerShape(8.dp))
            .clickable(interactionSource = pressInteraction, indication = null, role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = tabCount.toString(),
            fontWeight = FontWeight.Bold,
            fontSize = if (tabCount > 9) 12.sp else 16.sp,
            color = if (filled) MaterialTheme.colorScheme.onPrimary else counterTint,
            maxLines = 1
        )
    }
}

@Composable
private fun BrowserOverflowMenu(
    expanded: Boolean,
    isDesktopMode: Boolean,
    onDismiss: () -> Unit,
    onNewTab: () -> Unit,
    onShare: () -> Unit,
    onHistory: () -> Unit,
    onCopyLink: () -> Unit,
    onBookmarks: () -> Unit,
    onAddBookmark: () -> Unit,
    onDesktopModeChange: (Boolean) -> Unit,
    onShareWithFriends: () -> Unit,
    onHelp: () -> Unit = {},
    onSettings: () -> Unit
) {
    DropdownMenu(
        expanded = expanded,
        onDismissRequest = onDismiss,
        modifier = Modifier.widthIn(min = 248.dp, max = 320.dp).background(MaterialTheme.colorScheme.surface)
    ) {
        OverflowItem("New tab", Icons.Default.Add, onClick = { onDismiss(); onNewTab() })
        OverflowItem("Share", Icons.Default.Share, onClick = { onDismiss(); onShare() })
        OverflowItem("History", Icons.Default.History, onClick = { onDismiss(); onHistory() })
        OverflowItem("Copy link", Icons.Default.ContentCopy, onClick = { onDismiss(); onCopyLink() })
        OverflowItem("Bookmarks", Icons.Default.Bookmark, onClick = { onDismiss(); onBookmarks() })
        OverflowItem("Add bookmark", Icons.Default.BookmarkBorder, onClick = { onDismiss(); onAddBookmark() })
        DropdownMenuItem(
            modifier = Modifier.height(56.dp),
            text = { Text("Desktop site", fontSize = 16.sp, color = MaterialTheme.colorScheme.onSurface) },
            leadingIcon = { Icon(Icons.Default.DesktopMac, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(24.dp)) },
            trailingIcon = {
                Checkbox(checked = isDesktopMode, onCheckedChange = { checked -> onDismiss(); onDesktopModeChange(checked) })
            },
            onClick = { onDismiss(); onDesktopModeChange(!isDesktopMode) }
        )
        OverflowItem("Share with friends", Icons.Default.People, onClick = { onDismiss(); onShareWithFriends() })
        OverflowItem("Help", Icons.AutoMirrored.Filled.HelpOutline, onClick = { onDismiss(); onHelp() })
        OverflowItem("Settings", Icons.Default.Settings, onClick = { onDismiss(); onSettings() })
    }
}

@Composable
private fun OverflowItem(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    DropdownMenuItem(
        modifier = Modifier.height(56.dp),
        text = { Text(title, fontSize = 16.sp, color = MaterialTheme.colorScheme.onSurface) },
        leadingIcon = { Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(24.dp)) },
        onClick = onClick
    )
}

@Composable
private fun BrowserHomeContent(
    inputUrl: String,
    tabCount: Int,
    showSocialApps: Boolean,
    onOpenTabs: () -> Unit,
    onPremium: () -> Unit,
    onPrivateFolder: () -> Unit,
    onSettings: () -> Unit,
    onInputChanged: (String) -> Unit,
    onNavigate: (String) -> Unit,
    onOpenUrl: (String) -> Unit,
    onPasteClipboard: () -> Unit,
    onDownload: () -> Unit,
    onHelp: () -> Unit,
    onSeeAll: () -> Unit
) {
    val focusManager = LocalFocusManager.current
    var searchFocused by remember { mutableStateOf(false) }
    var entranceStarted by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { entranceStarted = true }

    val contentAlpha by animateFloatAsState(
        targetValue = if (entranceStarted) 1f else 0f,
        animationSpec = tween(300),
        label = "homeContentAlpha"
    )
    val contentOffset by animateDpAsState(
        targetValue = if (entranceStarted) 0.dp else 12.dp,
        animationSpec = tween(300),
        label = "homeContentOffset"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ReferenceHomeWhite)
            .verticalScroll(rememberScrollState())
            .padding(bottom = LocalBottomBarContentPadding.current + 16.dp),
        horizontalAlignment = Alignment.Start
    ) {
        // The HTML reference scrolls its complete header and body as one surface.
        Spacer(Modifier.height(14.dp))
        HomeTopBar(
            tabCount = tabCount,
            onOpenTabs = onOpenTabs,
            onPremium = onPremium,
            onPrivateFolder = onPrivateFolder,
            onSettings = onSettings
        )

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp),
            horizontalAlignment = Alignment.Start
        ) {
        Spacer(Modifier.height(2.dp))

        // Reference layout: the URL field and primary Download action share one gray panel.
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .graphicsLayer(alpha = contentAlpha)
                .offset(y = contentOffset),
            shape = RoundedCornerShape(18.dp),
            color = ReferenceHomePanel
        ) {
            Column(
                modifier = Modifier.padding(start = 14.dp, top = 19.dp, end = 14.dp, bottom = 13.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(51.dp)
                        .border(2.dp, ReferenceOrangeBorder, RoundedCornerShape(26.dp))
                        .shadow(
                            if (searchFocused) 4.dp else 0.dp,
                            RoundedCornerShape(26.dp),
                            ambientColor = ReferenceOrange.copy(alpha = 0.22f),
                            spotColor = ReferenceOrange.copy(alpha = 0.22f)
                        ),
                    shape = RoundedCornerShape(26.dp),
                    color = ReferenceSearchFill
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(start = 15.dp, end = 3.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        ReferenceStrokeIcon(
                            pathData = "M21 21l-4.34-4.34 M19 11a8 8 0 1 1-16 0 8 8 0 0 1 16 0z",
                            modifier = Modifier.size(21.dp),
                            strokeWidth = 2.2.dp,
                            tint = ReferenceHomeMuted
                        )
                        Spacer(Modifier.width(12.dp))
                        BasicTextField(
                            value = inputUrl,
                            onValueChange = onInputChanged,
                            modifier = Modifier
                                .weight(1f)
                                .onFocusChanged { searchFocused = it.isFocused }
                                .testTag("search_type_url_input"),
                            singleLine = true,
                            textStyle = TextStyle(fontSize = 15.5.sp, color = ReferenceHomeInk),
                            cursorBrush = SolidColor(ReferenceOrange),
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                            keyboardActions = KeyboardActions(onGo = {
                                if (inputUrl.isNotBlank()) {
                                    focusManager.clearFocus()
                                    onNavigate(inputUrl)
                                }
                            }),
                            decorationBox = { innerTextField ->
                                if (inputUrl.isEmpty()) {
                                    Text(
                                        text = "Search or paste URL",
                                        fontSize = 15.5.sp,
                                        color = ReferenceHomeMuted,
                                        fontWeight = FontWeight.Normal,
                                        maxLines = 1
                                    )
                                }
                                innerTextField()
                            }
                        )
                        IconButton(onClick = onPasteClipboard, modifier = Modifier.size(42.dp)) {
                            ReferenceStrokeIcon(
                                pathData = "M8 2h8v4H8z M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2 M9 12h6 M9 16h4",
                                modifier = Modifier.size(23.dp),
                                strokeWidth = 1.9.dp
                            )
                        }
                    }
                }

                val downloadInteraction = remember { MutableInteractionSource() }
                val downloadPressed by downloadInteraction.collectIsPressedAsState()
                val downloadScale by animateFloatAsState(
                    targetValue = if (downloadPressed) 0.97f else 1f,
                    animationSpec = tween(130),
                    label = "homeDownloadScale"
                )
                val ctaTransition = rememberInfiniteTransition(label = "homeDownloadCta")
                val ctaGlowElevationDp by ctaTransition.animateFloat(
                    initialValue = 8f,
                    targetValue = 12f,
                    animationSpec = infiniteRepeatable(tween(1_400), repeatMode = RepeatMode.Reverse),
                    label = "homeDownloadGlowElevation"
                )
                val ctaGlowElevation = ctaGlowElevationDp.dp
                val ctaGlowAlpha by ctaTransition.animateFloat(
                    initialValue = 0.28f,
                    targetValue = 0.48f,
                    animationSpec = infiniteRepeatable(tween(1_400), repeatMode = RepeatMode.Reverse),
                    label = "homeDownloadGlowAlpha"
                )
                val shimmerStartFraction by ctaTransition.animateFloat(
                    initialValue = -0.42f,
                    targetValue = 1.14f,
                    animationSpec = infiniteRepeatable(
                        animation = keyframes {
                            durationMillis = 3_400
                            -0.42f at 0
                            1.14f at 1_870
                            1.14f at 3_400
                        },
                        repeatMode = RepeatMode.Restart
                    ),
                    label = "homeDownloadShimmer"
                )
                Box(
                    modifier = Modifier
                        .widthIn(max = 206.dp)
                        .fillMaxWidth()
                        .height(51.dp)
                        .graphicsLayer(scaleX = downloadScale, scaleY = downloadScale)
                        .shadow(
                            ctaGlowElevation,
                            RoundedCornerShape(26.dp),
                            ambientColor = ReferenceOrange.copy(alpha = ctaGlowAlpha),
                            spotColor = ReferenceOrange.copy(alpha = ctaGlowAlpha)
                        )
                        .clip(RoundedCornerShape(26.dp))
                        .background(ReferenceOrangeButton)
                        .clickable(
                            interactionSource = downloadInteraction,
                            indication = null,
                            role = Role.Button,
                            onClick = onDownload
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(Modifier.fillMaxSize()) {
                        val bandWidth = size.width * 0.30f
                        val bandX = size.width * shimmerStartFraction
                        drawRect(
                            brush = Brush.horizontalGradient(
                                colors = listOf(Color.Transparent, Color.White.copy(alpha = 0.42f), Color.Transparent),
                                startX = bandX,
                                endX = bandX + bandWidth
                            ),
                            topLeft = Offset(bandX, 0f),
                            size = androidx.compose.ui.geometry.Size(bandWidth, size.height)
                        )
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        ReferenceStrokeIcon(
                            pathData = "M12 3v12 M6.5 10.5L12 16l5.5-5.5 M5 21h14",
                            modifier = Modifier.size(22.dp),
                            strokeWidth = 2.6.dp,
                            tint = Color.White
                        )
                        Text(
                            text = "Download",
                            color = Color.White,
                            fontSize = 19.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }

        if (showSocialApps) {
            Spacer(Modifier.height(14.dp))
            SocialAppsSection(onOpenUrl = onOpenUrl, onSeeAll = onSeeAll)
        }

        Spacer(Modifier.height(28.dp))
        Box(Modifier.padding(start = 1.dp)) { HomeHelpPill(onClick = onHelp) }

        // The reference has no Recent Websites row: its ad follows the help pill directly.
        Spacer(Modifier.height(50.dp))
        HomeNativeAdCard(modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(18.dp))
        }
    }
}

@Composable
private fun RecentWebsitesSection(
    sites: List<SiteShortcut>,
    onOpenUrl: (String) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = "Recently visited",
            fontSize = 17.sp,
            color = MaterialTheme.colorScheme.onBackground,
            fontWeight = FontWeight.SemiBold
        )
        Spacer(Modifier.height(12.dp))
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalAlignment = Alignment.Top
        ) {
            sites.forEachIndexed { index, site ->
                SiteShortcutItem(
                    site = site,
                    isRecent = true,
                    entryIndex = index,
                    onClick = { onOpenUrl(site.url) }
                )
            }
        }
    }
}

private data class SocialAppShortcut(
    val label: String,
    val url: String,
    val background: Color,
    val pathData: String
)

@Composable
private fun SocialAppsSection(
    onOpenUrl: (String) -> Unit,
    onSeeAll: () -> Unit
) {
    val apps = listOf(
        SocialAppShortcut("Instagram", "https://www.instagram.com/", Color(0xFFE8397F), "M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z M15 13a3 3 0 1 1-6 0 3 3 0 0 1 6 0z"),
        SocialAppShortcut("X", "https://x.com/", Color(0xFF1BBDE8), "M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"),
        SocialAppShortcut("Facebook", "https://www.facebook.com/", Color(0xFF1B6EF3), "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2 M13 7a4 4 0 1 1-8 0 4 4 0 0 1 8 0z M22 21v-2a4 4 0 0 0-3-3.87 M16 3.13a4 4 0 0 1 0 7.75"),
        SocialAppShortcut("Tiktok", "https://www.tiktok.com/", Color(0xFF3A3A3A), "M9 18V5l12-2v13 M9 18a3 3 0 1 1-6 0 3 3 0 0 1 6 0z M21 16a3 3 0 1 1-6 0 3 3 0 0 1 6 0z"),
        SocialAppShortcut("Daily Motion", "https://www.dailymotion.com/", Color(0xFF0B57D0), "M4.18 2h15.64A2.18 2.18 0 0 1 22 4.18v15.64A2.18 2.18 0 0 1 19.82 22H4.18A2.18 2.18 0 0 1 2 19.82V4.18A2.18 2.18 0 0 1 4.18 2z M7 2v20 M17 2v20 M2 12h20 M2 7h5 M2 17h5 M17 17h5 M17 7h5"),
        SocialAppShortcut("Threads", "https://www.threads.net/", Color(0xFF202020), "M7.9 20A9 9 0 1 0 4 16.1L2 22z"),
        SocialAppShortcut("WA Status", "https://web.whatsapp.com/", Color(0xFF4CC15A), "M22 12A10 10 0 1 1 2 12a10 10 0 0 1 20 0z M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0z"),
        SocialAppShortcut("Pinterest", "https://www.pinterest.com/", Color(0xFFC4161C), "M12 17v5 M9 10.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24V16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V7a1 1 0 0 1 1-1 2 2 0 0 0 0-4H8a2 2 0 0 0 0 4 1 1 0 0 1 1 1z")
    )

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "Social Apps",
                fontSize = 19.sp,
                color = ReferenceHomeInk,
                fontWeight = FontWeight.Medium,
                lineHeight = 28.sp
            )
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(18.dp))
                    .clickable(role = Role.Button, onClick = onSeeAll)
                    .padding(horizontal = 2.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "See All →",
                    fontSize = 14.sp,
                    color = ReferenceOrange,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        Spacer(Modifier.height(9.dp))
        Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
            apps.chunked(4).forEachIndexed { rowIndex, rowApps ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(0.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    rowApps.forEach { app ->
                        SocialAppTile(
                            app = app,
                            modifier = Modifier.weight(1f),
                            onClick = { onOpenUrl(app.url) }
                        )
                    }
                }
                if (rowIndex == 0) Spacer(Modifier.height(8.dp))
            }
        }
    }
}

@Composable
private fun SocialAppTile(
    app: SocialAppShortcut,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val interaction = remember(app.url) { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.94f else 1f,
        animationSpec = tween(120),
        label = "socialTileScale_${app.label}"
    )
    val appPath = remember(app.pathData) { PathParser().parsePathString(app.pathData).toPath() }
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .clickable(interactionSource = interaction, indication = null, role = Role.Button, onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .graphicsLayer(scaleX = scale, scaleY = scale)
                .clip(CircleShape)
                .background(
                    if (app.label == "Instagram") {
                        Brush.linearGradient(
                            colors = listOf(Color(0xFFE8397F), Color(0xFFF7863A)),
                            start = Offset(0f, 48f),
                            end = Offset(48f, 0f)
                        )
                    } else {
                        Brush.linearGradient(listOf(app.background, app.background))
                    }
                ),
            contentAlignment = Alignment.Center
        ) {
            Canvas(Modifier.size(24.dp)) {
                drawPath(
                    path = appPath,
                    color = Color.White,
                    style = Stroke(
                        width = 2.2.dp.toPx(),
                        cap = StrokeCap.Round,
                        join = StrokeJoin.Round
                    )
                )
            }
        }
        Spacer(Modifier.height(7.dp))
        Text(
            text = app.label,
            color = ReferenceHomeLabel,
            fontSize = 12.5.sp,
            letterSpacing = 0.25.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 1,
            softWrap = false,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun HomeHelpPill(onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(22.dp))
            .border(2.dp, ReferenceOrangeBorder, RoundedCornerShape(22.dp))
            .background(ReferenceHomeWhite)
            .clickable(role = Role.Button, onClick = onClick)
            .height(44.dp)
            .padding(start = 12.dp, end = 20.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Box(
            modifier = Modifier
                .size(22.dp)
                .clip(CircleShape)
                .background(ReferenceOrange),
            contentAlignment = Alignment.Center
        ) {
            Text("?", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold, lineHeight = 14.sp)
        }
        Text(
            text = "How to download?",
            color = ReferenceHomeInk,
            fontSize = 16.sp,
            fontWeight = FontWeight.Medium
        )
    }
}


@Composable
private fun AddShortcutTile(onClick: () -> Unit) {
    Column(
        modifier = Modifier.width(82.dp).clip(RoundedCornerShape(18.dp)).clickable(onClick = onClick).padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.size(56.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.10f)), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Add, contentDescription = "Add quick link", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(25.dp))
        }
        Spacer(Modifier.height(7.dp))
        Text("Add link", fontSize = 12.sp, color = MaterialTheme.colorScheme.onBackground, textAlign = TextAlign.Center)
    }
}

@Composable
private fun QuickLinksEditorDialog(
    shortcuts: List<HomeShortcut>,
    onDismiss: () -> Unit,
    onAdd: (HomeShortcut) -> Unit,
    onRemove: (String) -> Unit
) {
    var urlInput by remember { mutableStateOf("") }
    var validationMessage by remember { mutableStateOf<String?>(null) }
    var localShortcuts by remember { mutableStateOf(shortcuts) }
    LaunchedEffect(shortcuts) { localShortcuts = shortcuts }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Quick links", fontWeight = FontWeight.Bold) },
        text = {
            Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Add a website link or remove an existing one. Its icon is added automatically.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = urlInput,
                        onValueChange = { urlInput = it.take(2048); validationMessage = null },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        placeholder = { Text("example.com") },
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                        keyboardActions = KeyboardActions(onDone = {
                            val candidate = makeQuickShortcut(urlInput)
                            if (candidate == null) validationMessage = "Enter a valid website URL"
                            else if (localShortcuts.size >= 20) validationMessage = "Maximum 20 quick links"
                            else if (localShortcuts.any { shortcutHostForHome(it.url) == shortcutHostForHome(candidate.url) }) validationMessage = "This site is already added"
                            else { localShortcuts = localShortcuts + candidate; onAdd(candidate); urlInput = ""; validationMessage = null }
                        })
                    )
                    IconButton(onClick = {
                        val candidate = makeQuickShortcut(urlInput)
                        when {
                            candidate == null -> validationMessage = "Enter a valid website URL"
                            localShortcuts.size >= 20 -> validationMessage = "Maximum 20 quick links"
                            localShortcuts.any { shortcutHostForHome(it.url) == shortcutHostForHome(candidate.url) } -> validationMessage = "This site is already added"
                            else -> { localShortcuts = localShortcuts + candidate; onAdd(candidate); urlInput = ""; validationMessage = null }
                        }
                    }) {
                        Icon(Icons.Default.Add, contentDescription = "Add quick link", tint = MaterialTheme.colorScheme.primary)
                    }
                }
                validationMessage?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 12.sp) }
                Divider(color = MaterialTheme.colorScheme.outlineVariant)
                if (localShortcuts.isEmpty()) {
                    Text("No quick links added yet.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    Column(modifier = Modifier.fillMaxWidth().heightIn(max = 280.dp).verticalScroll(rememberScrollState())) {
                        localShortcuts.forEach { shortcut ->
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                SiteLogo(SiteShortcut(shortcut.name, shortcut.url), size = 36.dp)
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(shortcut.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                    Text(shortcutHostForHome(shortcut.url), maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                IconButton(onClick = { localShortcuts = localShortcuts.filterNot { it.url == shortcut.url }; onRemove(shortcut.url) }) {
                                    Icon(Icons.Default.Close, contentDescription = "Remove ${shortcut.name}", tint = MaterialTheme.colorScheme.error)
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done", color = MaterialTheme.colorScheme.primary) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}

private fun makeQuickShortcut(raw: String): HomeShortcut? {
    val trimmed = raw.trim()
    if (trimmed.isBlank()) return null
    val normalized = when {
        trimmed.startsWith("https://", true) || trimmed.startsWith("http://", true) -> trimmed
        trimmed.contains('.') && !trimmed.contains(' ') -> "https://$trimmed"
        else -> return null
    }
    val uri = runCatching { URI(normalized) }.getOrNull() ?: return null
    val host = uri.host?.lowercase()?.trimEnd('.')
        ?.removePrefix("www.")?.removePrefix("m.")?.removePrefix("mobile.")
        ?.takeIf { it.contains('.') } ?: return null
    val label = host.substringBefore('.').replace('-', ' ').split(' ').filter { it.isNotBlank() }
        .joinToString(" ") { it.replaceFirstChar { first -> first.uppercase() } }.ifBlank { host }
    return HomeShortcut(label.take(48), normalized)
}

private fun shortcutHostForHome(url: String): String =
    runCatching {
        URI(url).host?.lowercase()?.trimEnd('.')
            ?.removePrefix("www.")?.removePrefix("m.")?.removePrefix("mobile.") ?: url.lowercase()
    }.getOrDefault(url.lowercase())

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MediaCandidatesPicker(
    candidates: List<MediaCandidate>,
    pageUrl: String?,
    isDetecting: Boolean,
    detectionStage: String?,
    onDismiss: () -> Unit,
    onScanAgain: () -> Unit,
    onSelect: (MediaVideoGroup) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var showFilteredReview by remember { mutableStateOf(false) }
    val filterResult = remember(candidates, pageUrl) {
        SmartMediaFilter.apply(candidates, pageUrl, SmartFilterSettings())
    }
    val groups = filterResult.visibleGroups
    val suspectedAdCount = filterResult.filteredItems.size

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface,
        dragHandle = null,
        shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 24.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Detected videos", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                    Text(
                        text = when {
                            isDetecting -> detectionStage ?: "Finding video and reading details…"
                            groups.isEmpty() -> "No video found yet"
                            filterResult.isSocialMediaBypass -> "${groups.size} video(s) · social media filtering off"
                            else -> "${groups.size} video(s) · smart filtered"
                        },
                        fontSize = 13.sp,
                        color = if (isDetecting) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                TextButton(onClick = onScanAgain) { Text("Scan again") }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close detector")
                }
            }

            if (!filterResult.isSocialMediaBypass && suspectedAdCount > 0) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 3.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.FilterList, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(17.dp))
                    Spacer(Modifier.width(7.dp))
                    Text(
                        "$suspectedAdCount item(s) hidden by smart filters",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.weight(1f)
                    )
                    TextButton(onClick = { showFilteredReview = true }) {
                        Text("Other Detected", fontSize = 11.sp)
                    }
                }
            }

            Spacer(Modifier.height(8.dp))
            if (groups.isEmpty()) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    if (isDetecting) {
                        CircularProgressIndicator(color = MaterialTheme.colorScheme.primary, strokeWidth = 3.dp)
                    } else {
                        Icon(Icons.Default.Movie, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(42.dp))
                    }
                    Spacer(Modifier.height(12.dp))
                    Text(
                        if (isDetecting) "Detecting video and collecting details…" else "No downloadable video found yet",
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        if (isDetecting) "Keep this page open. The download button will become ready after a stream is resolved. You can also tap Scan again." else "Some players reveal their stream only after interaction. Tap Scan again or play the video, then try once more. DRM-protected streams may not be downloadable.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center,
                        fontSize = 13.sp
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxWidth().heightIn(max = 560.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                ) {
                    items(groups, key = { it.id }) { group ->
                        val candidate = group.primary
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .clickable { onSelect(group) }
                                .padding(horizontal = 10.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                modifier = Modifier.size(width = 68.dp, height = 54.dp),
                                shape = RoundedCornerShape(9.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    if (!candidate.thumbnailUrl.isNullOrBlank()) {
                                        AsyncImage(
                                            model = candidate.thumbnailUrl,
                                            contentDescription = null,
                                            modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(9.dp)),
                                            contentScale = androidx.compose.ui.layout.ContentScale.Crop
                                        )
                                    } else {
                                        Icon(Icons.Default.Movie, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(28.dp))
                                    }
                                }
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = group.title,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 14.sp
                                )
                                Spacer(Modifier.height(4.dp))
                                val host = runCatching { URI(candidate.sourcePageUrl ?: candidate.url).host }.getOrNull().orEmpty()
                                val duration = candidate.durationSeconds?.takeIf { it > 0.0 }?.let { seconds ->
                                    if (seconds >= 3600.0) "%d:%02d:%02d".format((seconds / 3600).toInt(), (seconds.toInt() / 60) % 60, seconds.toInt() % 60)
                                    else "%d:%02d".format((seconds / 60).toInt(), seconds.toInt() % 60)
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(host, maxLines = 1, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp, modifier = Modifier.weight(1f, fill = false))
                                    if (duration != null) {
                                        Spacer(Modifier.width(6.dp))
                                        Text(duration, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                                    }
                                }
                                Spacer(Modifier.height(5.dp))
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    val qualities = group.candidates.map { MediaCandidateGrouping.qualityLabel(it) }.distinct().take(5)
                                    qualities.forEach { quality ->
                                        Surface(shape = RoundedCornerShape(5.dp), color = MaterialTheme.colorScheme.primaryContainer) {
                                            Text(
                                                quality,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                                color = MaterialTheme.colorScheme.primary,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        }
                                    }
                                    if (group.candidates.size > 1) {
                                        Text("${group.candidates.size} options", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 10.sp)
                                    }
                                    if (candidate.isPlaying) {
                                        Text("Playing", color = MaterialTheme.colorScheme.primary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                            Spacer(Modifier.width(8.dp))
                            Icon(Icons.Default.Download, contentDescription = "Choose video", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(22.dp))
                        }
                        Divider(color = MaterialTheme.colorScheme.outlineVariant)
                    }
                }
            }
        }
    }

    if (showFilteredReview) {
        AlertDialog(
            onDismissRequest = { showFilteredReview = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.FilterList, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Text("Other Detected")
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth().heightIn(max = 520.dp).verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("These streams were hidden by the active smart filters.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                    filterResult.filteredItems.forEach { item ->
                        Surface(
                            modifier = Modifier.fillMaxWidth().clickable {
                                showFilteredReview = false
                                val originalTitle = item.candidates.firstOrNull()?.title?.takeIf { it.isNotBlank() } ?: item.title
                                val selectable = item.candidates.map { it.copy(title = originalTitle) }
                                val primary = selectable.maxWithOrNull(
                                    compareBy<MediaCandidate> { MediaCandidateGrouping.qualityRank(it) }
                                        .thenBy { it.detectionConfidence }
                                ) ?: return@clickable
                                onSelect(
                                    MediaVideoGroup(
                                        id = "other-detected:${selectable.first().id}",
                                        title = originalTitle,
                                        candidates = selectable,
                                        primary = primary
                                    )
                                )
                            },
                            shape = RoundedCornerShape(10.dp),
                            color = Color.White,
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                        ) {
                            Column(Modifier.padding(10.dp)) {
                                Text(item.title, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                Spacer(Modifier.height(3.dp))
                                Text(item.reasons.joinToString(" · "), color = MaterialTheme.colorScheme.error, fontSize = 11.sp)
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showFilteredReview = false }) { Text("Done") } }
        )
    }
}

@Composable
private fun SiteShortcutItem(
    site: SiteShortcut,
    isRecent: Boolean,
    entryIndex: Int = 0,
    onClick: () -> Unit
) {
    val interaction = remember(site.url) { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    var entranceVisible by remember(site.url, isRecent) { mutableStateOf(false) }
    LaunchedEffect(site.url, isRecent, entryIndex) {
        val baseDelay = if (isRecent) 250L else 110L
        delay(baseDelay + entryIndex.coerceIn(0, 8) * 48L)
        entranceVisible = true
    }
    val entranceAlpha by animateFloatAsState(if (entranceVisible) 1f else 0f, tween(280), label = "siteEntranceAlpha")
    val entranceOffset by animateDpAsState(if (entranceVisible) 0.dp else 12.dp, tween(280), label = "siteEntranceOffset")
    val scale by animateFloatAsState(if (pressed) 1.025f else 1f, tween(150), label = "siteShortcutScale")
    val lift by animateDpAsState(if (pressed) (-4).dp else 0.dp, tween(150), label = "siteShortcutLift")
    val elevation by animateDpAsState(if (pressed) 8.dp else 5.dp, tween(150), label = "siteShortcutElevation")
    Column(
        modifier = Modifier.width(80.dp)
            .offset(y = entranceOffset + lift)
            .graphicsLayer(alpha = entranceAlpha, scaleX = scale, scaleY = scale)
            .clickable(interactionSource = interaction, indication = null, role = Role.Button, onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier.size(58.dp)
                .shadow(elevation, CircleShape)
                .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.08f), CircleShape)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            SiteLogo(site = site, size = 42.dp)
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = site.name,
            fontSize = if (isRecent) 12.sp else 12.sp,
            color = MaterialTheme.colorScheme.onBackground,
            maxLines = 2,
            minLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
            lineHeight = 14.sp
        )
    }
}

@Composable
private fun SiteLogo(site: SiteShortcut, size: androidx.compose.ui.unit.Dp) {
    var failed by remember(site.url) { mutableStateOf(false) }
    val faviconUrl = remember(site.url) { faviconUrlFor(site.url) }
    Box(
        modifier = Modifier.size(size).clip(CircleShape)
            .background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center
    ) {
        if (!failed && faviconUrl != null) {
            AsyncImage(
                model = faviconUrl,
                contentDescription = "${site.name} website icon",
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize().padding(8.dp),
                onError = { failed = true }
            )
        } else {
            // Keep both Quick Access and Recently Visited consistent; never show fake/demo logos.
            Icon(Icons.Default.Public, contentDescription = "Website icon unavailable", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(size * 0.45f))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun BrowserTabsOverview(
    tabs: List<BrowserTab>,
    onBack: () -> Unit,
    activeTabId: Long,
    showingPrivateTabs: Boolean,
    onShowPrivateTabs: (Boolean) -> Unit,
    searchExpanded: Boolean,
    searchQuery: String,
    onToggleSearch: () -> Unit,
    onSearchQueryChanged: (String) -> Unit,
    onSelect: (Long) -> Unit,
    onCloseTab: (Long) -> Unit,
    onNewTab: (Boolean) -> Unit,
    onClearAll: (Boolean) -> Unit
) {
    var showClearConfirmation by remember { mutableStateOf(false) }
    val colors = MaterialTheme.colorScheme
    val displayedTabs = remember(tabs, showingPrivateTabs, searchQuery) {
        tabs.filter { it.isPrivate == showingPrivateTabs }.filter { tab ->
            val query = searchQuery.trim()
            query.isBlank() || tab.title.contains(query, ignoreCase = true) || tab.url.contains(query, ignoreCase = true)
        }
    }
    val groupCount = tabs.count { it.isPrivate == showingPrivateTabs }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(colors.background)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier.size(40.dp)
                        .clip(CircleShape)
                        .background(colors.surfaceVariant)
                ) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back to browser",
                        tint = colors.onSurface,
                        modifier = Modifier.size(21.dp)
                    )
                }
                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(1.dp)) {
                    Text("Your tabs", color = colors.onSurface, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "$groupCount ${if (showingPrivateTabs) "private" else "open"} ${if (groupCount == 1) "tab" else "tabs"}",
                        color = colors.onSurfaceVariant,
                        fontSize = 12.sp
                    )
                }
                IconButton(
                    onClick = onToggleSearch,
                    modifier = Modifier.size(40.dp)
                        .clip(CircleShape)
                        .background(colors.surfaceVariant)
                ) {
                    Icon(
                        Icons.Default.Search,
                        contentDescription = "Search tabs",
                        tint = colors.onSurface,
                        modifier = Modifier.size(21.dp)
                    )
                }
            }

            Spacer(Modifier.height(14.dp))

            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                color = colors.surfaceVariant
            ) {
                Row(
                    modifier = Modifier.padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    listOf(false to "Tabs", true to "Private").forEach { (privateTab, label) ->
                        val selected = showingPrivateTabs == privateTab
                        Surface(
                            modifier = Modifier.weight(1f).clip(RoundedCornerShape(14.dp))
                                .clickable { onShowPrivateTabs(privateTab) },
                            color = if (selected) colors.surface else Color.Transparent,
                            shape = RoundedCornerShape(14.dp),
                            shadowElevation = if (selected) 1.dp else 0.dp
                        ) {
                            Text(
                                text = label,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                                color = if (selected) colors.primary else colors.onSurfaceVariant,
                                fontSize = 14.sp,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }

            if (showingPrivateTabs) {
                Surface(
                    modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
                    shape = RoundedCornerShape(14.dp),
                    color = colors.primaryContainer.copy(alpha = 0.62f)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.Top,
                        horizontalArrangement = Arrangement.spacedBy(9.dp)
                    ) {
                        Icon(Icons.Default.Lock, contentDescription = null, tint = colors.primary, modifier = Modifier.size(17.dp))
                        Text(
                            "Private tabs are omitted from app history and bookmarks. Website cookies may still be shared with regular tabs.",
                            color = colors.onSurface,
                            fontSize = 11.sp,
                            lineHeight = 15.sp
                        )
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (searchQuery.isBlank()) "${displayedTabs.size} shown" else "${displayedTabs.size} results",
                    color = colors.onSurfaceVariant,
                    fontSize = 12.sp,
                    modifier = Modifier.weight(1f)
                )
                TextButton(onClick = { showClearConfirmation = true }, enabled = groupCount > 0) {
                    Text("Clear all", color = if (groupCount > 0) colors.primary else colors.onSurfaceVariant)
                }
            }

            if (searchExpanded) {
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = colors.surfaceVariant,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
                ) {
                    Row(
                        Modifier.padding(horizontal = 14.dp, vertical = 11.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Search, contentDescription = null, tint = colors.onSurfaceVariant, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(8.dp))
                        BasicTextField(
                            value = searchQuery,
                            onValueChange = onSearchQueryChanged,
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            textStyle = TextStyle(color = colors.onSurface, fontSize = 14.sp),
                            cursorBrush = SolidColor(colors.primary),
                            decorationBox = { inner ->
                                if (searchQuery.isEmpty()) Text("Search open tabs", color = colors.onSurfaceVariant, fontSize = 14.sp)
                                inner()
                            }
                        )
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { onSearchQueryChanged("") }, modifier = Modifier.size(26.dp)) {
                                Icon(Icons.Default.Close, contentDescription = "Clear search", tint = colors.onSurfaceVariant, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }

            if (displayedTabs.isEmpty()) {
                Box(modifier = Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        Icon(
                            if (showingPrivateTabs) Icons.Default.Lock else Icons.Default.Public,
                            contentDescription = null,
                            tint = colors.onSurfaceVariant,
                            modifier = Modifier.size(46.dp)
                        )
                        Text(
                            when {
                                searchQuery.isNotBlank() -> "No matching tabs"
                                showingPrivateTabs -> "No private tabs open"
                                else -> "No tabs open"
                            },
                            color = colors.onSurface,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            if (showingPrivateTabs) "Create a private tab with +" else "Open a new tab with +",
                            color = colors.onSurfaceVariant,
                            fontSize = 13.sp
                        )
                    }
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    modifier = Modifier.fillMaxSize().weight(1f),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(start = 0.dp, end = 0.dp, top = 4.dp, bottom = 104.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    gridItems(displayedTabs, key = { it.id }) { tab ->
                        BrowserTabCard(
                            tab = tab,
                            selected = tab.id == activeTabId,
                            onSelect = { onSelect(tab.id) },
                            onClose = { onCloseTab(tab.id) }
                        )
                    }
                }
            }
        }

        FloatingActionButton(
            onClick = { onNewTab(showingPrivateTabs) },
            modifier = Modifier.align(Alignment.BottomEnd).padding(end = 18.dp, bottom = 18.dp).size(56.dp),
            shape = CircleShape,
            containerColor = colors.primaryContainer,
            contentColor = colors.onPrimaryContainer
        ) {
            Icon(Icons.Default.Add, contentDescription = if (showingPrivateTabs) "New private tab" else "New tab", modifier = Modifier.size(27.dp))
        }
    }

    if (showClearConfirmation) {
        AlertDialog(
            onDismissRequest = { showClearConfirmation = false },
            title = { Text(if (showingPrivateTabs) "Clear private tabs?" else "Clear all tabs?") },
            text = {
                Text(
                    if (showingPrivateTabs) "Close all $groupCount private tabs? This cannot be undone."
                    else "Close all $groupCount regular tabs? This cannot be undone."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showClearConfirmation = false
                    onClearAll(showingPrivateTabs)
                }) { Text("Clear all") }
            },
            dismissButton = { TextButton(onClick = { showClearConfirmation = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun BrowserTabCard(
    tab: BrowserTab,
    selected: Boolean,
    onSelect: () -> Unit,
    onClose: () -> Unit
) {
    val colors = MaterialTheme.colorScheme
    val cardColor = if (selected) colors.primaryContainer else colors.surface
    val cardText = if (selected) colors.onPrimaryContainer else colors.onSurface

    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onSelect),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = cardColor),
        border = androidx.compose.foundation.BorderStroke(
            if (selected) 1.5.dp else 1.dp,
            if (selected) colors.primary.copy(alpha = 0.75f) else colors.outlineVariant
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (selected) 3.dp else 1.dp)
    ) {
        Column(modifier = Modifier.padding(9.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    if (tab.isPrivate) Icons.Default.Lock else Icons.Default.Public,
                    contentDescription = null,
                    tint = if (selected) colors.primary else colors.onSurfaceVariant,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(Modifier.width(5.dp))
                Text(
                    text = if (tab.isHomeView || tab.title.isBlank()) (if (tab.isPrivate) "Private tab" else "New tab") else tab.title,
                    modifier = Modifier.weight(1f),
                    color = cardText,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                IconButton(onClick = onClose, modifier = Modifier.size(26.dp)) {
                    Icon(Icons.Default.Close, contentDescription = "Close tab", tint = colors.onSurfaceVariant, modifier = Modifier.size(17.dp))
                }
            }
            Spacer(Modifier.height(6.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1.22f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(colors.surfaceVariant)
            ) {
                val preview = tab.preview
                if (preview != null) {
                    Image(
                        bitmap = preview.asImageBitmap(),
                        contentDescription = "Preview of ${tab.title}",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Column(
                        modifier = Modifier.fillMaxSize().padding(8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            if (tab.isPrivate) Icons.Default.Lock else Icons.Default.Public,
                            contentDescription = null,
                            tint = colors.onSurfaceVariant,
                            modifier = Modifier.size(34.dp)
                        )
                        Spacer(Modifier.height(7.dp))
                        Text(
                            if (tab.isHomeView) "Search or type URL" else siteHost(tab.url),
                            color = colors.onSurfaceVariant,
                            fontSize = 10.sp,
                            textAlign = TextAlign.Center,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
            Spacer(Modifier.height(7.dp))
            Text(
                text = if (tab.isHomeView) "New tab" else tab.url,
                color = if (selected) colors.onPrimaryContainer.copy(alpha = 0.75f) else colors.onSurfaceVariant,
                fontSize = 10.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun BrowserContextAction(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable(onClick = onClick).padding(horizontal = 8.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onSurface, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(13.dp))
        Text(title, color = MaterialTheme.colorScheme.onSurface, fontSize = 16.sp)
    }
}

private fun siteHost(url: String): String = try {
    URI(url).host?.lowercase()?.trimEnd('.')
        ?.removePrefix("www.")?.removePrefix("m.")?.removePrefix("mobile.") ?: url
} catch (_: Exception) {
    url
}

private fun historyToShortcut(history: BrowserHistoryEntity): SiteShortcut {
    val host = runCatching {
        URI(history.url).host?.lowercase()?.trimEnd('.')
            ?.removePrefix("www.")?.removePrefix("m.")?.removePrefix("mobile.")
    }.getOrNull()
    val label = host.orEmpty().substringBefore('.').replace('-', ' ')
        .split(' ').filter { it.isNotBlank() }.joinToString(" ") { part -> part.replaceFirstChar { it.uppercase() } }
        .ifBlank { "Website" }
    return SiteShortcut(label, history.url)
}
