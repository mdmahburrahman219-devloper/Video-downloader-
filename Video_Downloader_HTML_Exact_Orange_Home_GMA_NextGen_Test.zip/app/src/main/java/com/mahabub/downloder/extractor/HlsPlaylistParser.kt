package com.mahabub.downloder.extractor

import java.net.URI
import java.nio.ByteBuffer
import java.util.Locale

/** RFC 8216 playlist parsing helpers used by the native HLS downloader. */
object HlsPlaylistParser {
    data class ByteRange(val length: Long, val offset: Long?)

    data class KeySpec(
        val method: String,
        val uri: String? = null,
        val iv: ByteArray? = null,
        val keyFormat: String = "identity"
    ) {
        fun identity(): String = listOf(method, uri.orEmpty(), iv?.joinToString("") { "%02x".format(it) }.orEmpty(), keyFormat).joinToString("|")
    }

    data class InitMap(
        val uri: String,
        val byteRange: ByteRange? = null,
        val key: KeySpec? = null
    ) {
        fun identity(): String = "$uri|${byteRange?.length}|${byteRange?.offset}|${key?.identity()}"
    }

    data class Segment(
        val url: String,
        val durationSeconds: Double,
        val sequence: Long,
        val byteRange: ByteRange? = null,
        val initMap: InitMap? = null,
        val key: KeySpec? = null,
        val discontinuityBefore: Boolean = false,
        val title: String? = null
    ) {
        fun identity(): String = "$sequence|$url|${byteRange?.length}|${byteRange?.offset}|${key?.identity()}|${initMap?.identity()}"
    }

    data class MediaPlaylist(
        val segments: List<Segment>,
        val mediaSequence: Long,
        val targetDurationSeconds: Double,
        val isEndList: Boolean,
        val playlistType: String?,
        val hasDiscontinuity: Boolean
    )

    data class Variant(
        val url: String,
        val resolution: String?,
        val bandwidth: Long,
        val audioGroupId: String? = null,
        val codecs: String? = null
    )

    data class AudioRendition(
        val groupId: String,
        val name: String,
        val url: String?,
        val language: String? = null,
        val isDefault: Boolean = false,
        val isAutoselect: Boolean = false
    )

    data class MasterPlaylist(
        val variants: List<Variant>,
        val audioRenditions: List<AudioRendition>
    )

    fun parseMasterPlaylist(text: String, masterUrl: String): List<Variant> =
        parseMaster(text, masterUrl).variants

    fun parseMaster(text: String, masterUrl: String): MasterPlaylist {
        if (!text.trimStart().startsWith("#EXTM3U")) return MasterPlaylist(emptyList(), emptyList())
        val base = runCatching { URI(masterUrl) }.getOrNull() ?: return MasterPlaylist(emptyList(), emptyList())
        val lines = text.lines()
        val variants = mutableListOf<Variant>()
        val audio = mutableListOf<AudioRendition>()
        var pendingAttributes: Map<String, String>? = null

        for (rawLine in lines) {
            val line = rawLine.trim()
            when {
                line.startsWith("#EXT-X-STREAM-INF:", ignoreCase = true) -> {
                    pendingAttributes = parseAttributes(line.substringAfter(':', ""))
                }
                line.startsWith("#EXT-X-MEDIA:", ignoreCase = true) -> {
                    val attrs = parseAttributes(line.substringAfter(':', ""))
                    if (attrs["TYPE"].equals("AUDIO", true)) {
                        val group = attrs["GROUP-ID"].orEmpty()
                        val uri = attrs["URI"]?.let { resolveUrl(base, it) }
                        if (group.isNotBlank()) {
                            audio += AudioRendition(
                                groupId = group,
                                name = attrs["NAME"].orEmpty(),
                                url = uri,
                                language = attrs["LANGUAGE"],
                                isDefault = attrs["DEFAULT"].equals("YES", true),
                                isAutoselect = attrs["AUTOSELECT"].equals("YES", true)
                            )
                        }
                    }
                }
                line.isNotBlank() && !line.startsWith("#") && pendingAttributes != null -> {
                    val attrs = pendingAttributes
                    val resolved = resolveUrl(base, line)
                    val parsed = runCatching { URI(resolved) }.getOrNull()
                    if (parsed != null && parsed.scheme in setOf("http", "https") && !parsed.host.isNullOrBlank()) {
                        variants += Variant(
                            url = resolved,
                            resolution = attrs["RESOLUTION"],
                            bandwidth = (attrs["AVERAGE-BANDWIDTH"] ?: attrs["BANDWIDTH"])?.toLongOrNull() ?: 0L,
                            audioGroupId = attrs["AUDIO"],
                            codecs = attrs["CODECS"]
                        )
                    }
                    pendingAttributes = null
                }
                else -> Unit
            }
        }
        return MasterPlaylist(
            variants = variants.distinctBy { it.url }.sortedWith(
                compareByDescending<Variant> { it.resolution?.substringAfter('x')?.toIntOrNull() ?: 0 }
                    .thenByDescending { it.bandwidth }
            ),
            audioRenditions = audio.distinctBy { "${it.groupId}|${it.name}|${it.url}" }
        )
    }

    fun parseMediaPlaylist(text: String, playlistUrl: String): MediaPlaylist {
        require(text.trimStart().startsWith("#EXTM3U")) { "Invalid HLS header" }
        val base = URI(playlistUrl)
        val segments = mutableListOf<Segment>()
        var mediaSequence = 0L
        var nextSequence: Long? = null
        var targetDuration = 6.0
        var endList = false
        var playlistType: String? = null
        var duration = 0.0
        var title: String? = null
        var pendingRange: ByteRange? = null
        var previousRangeEndByUri = mutableMapOf<String, Long>()
        var previousMapRangeEndByUri = mutableMapOf<String, Long>()
        var activeMap: InitMap? = null
        var activeKey: KeySpec? = null
        var discontinuityPending = false
        var hasDiscontinuity = false

        for (rawLine in text.lineSequence()) {
            val line = rawLine.trim()
            when {
                line.startsWith("#EXT-X-MEDIA-SEQUENCE:", true) -> {
                    mediaSequence = line.substringAfter(':').trim().toLongOrNull() ?: 0L
                    nextSequence = mediaSequence
                }
                line.startsWith("#EXT-X-TARGETDURATION:", true) -> {
                    targetDuration = line.substringAfter(':').trim().toDoubleOrNull()?.coerceAtLeast(1.0) ?: 6.0
                }
                line.startsWith("#EXT-X-PLAYLIST-TYPE:", true) -> playlistType = line.substringAfter(':').trim().uppercase(Locale.ROOT)
                line.startsWith("#EXT-X-ENDLIST", true) -> endList = true
                line.startsWith("#EXT-X-DISCONTINUITY", true) -> {
                    discontinuityPending = true
                    hasDiscontinuity = true
                }
                line.startsWith("#EXTINF:", true) -> {
                    val value = line.substringAfter(':')
                    duration = value.substringBefore(',').trim().toDoubleOrNull() ?: 0.0
                    title = value.substringAfter(',', "").takeIf { it.isNotBlank() }
                }
                line.startsWith("#EXT-X-BYTERANGE:", true) -> {
                    pendingRange = parseByteRange(line.substringAfter(':'))
                }
                line.startsWith("#EXT-X-MAP:", true) -> {
                    val attrs = parseAttributes(line.substringAfter(':'))
                    val rawUri = attrs["URI"] ?: throw IllegalArgumentException("EXT-X-MAP has no URI")
                    val mapUrl = resolveUrl(base, rawUri)
                    val rawMapRange = attrs["BYTERANGE"]?.let { parseByteRange(it) }
                    val mapRange = rawMapRange?.let { pending ->
                        val offset = pending.offset ?: previousMapRangeEndByUri[mapUrl]
                            ?: throw IllegalArgumentException("Implicit EXT-X-MAP byte-range offset has no preceding map range")
                        if (pending.length > Long.MAX_VALUE - offset) {
                            throw IllegalArgumentException("EXT-X-MAP byte range overflows the supported range")
                        }
                        previousMapRangeEndByUri[mapUrl] = offset + pending.length
                        ByteRange(pending.length, offset)
                    }
                    activeMap = InitMap(mapUrl, mapRange, activeKey)
                }
                line.startsWith("#EXT-X-KEY:", true) -> {
                    val attrs = parseAttributes(line.substringAfter(':'))
                    val method = attrs["METHOD"]?.uppercase(Locale.ROOT) ?: "NONE"
                    activeKey = if (method == "NONE") {
                        null
                    } else {
                        val uri = attrs["URI"]?.let { resolveUrl(base, it) }
                        KeySpec(method, uri, attrs["IV"]?.let(::parseIv), attrs["KEYFORMAT"] ?: "identity")
                    }
                    // If a map is declared after a key, it carries that key context.
                }
                line.isNotBlank() && !line.startsWith("#") -> {
                    val resolvedUrl = resolveUrl(base, line)
                    val previousRange = previousRangeEndByUri[resolvedUrl]
                    val range = pendingRange?.let { pending ->
                        val offset = pending.offset ?: previousRange
                            ?: throw IllegalArgumentException("Implicit byte-range offset has no preceding range for this resource")
                        if (pending.length > Long.MAX_VALUE - offset) {
                            throw IllegalArgumentException("HLS byte range overflows the supported range")
                        }
                        ByteRange(pending.length, offset)
                    }
                    // An implicit offset may refer only to the immediately preceding media segment.
                    previousRangeEndByUri.clear()
                    if (range != null) previousRangeEndByUri[resolvedUrl] = range.offset!! + range.length
                    val sequence = nextSequence ?: mediaSequence
                    segments += Segment(
                        url = resolvedUrl,
                        durationSeconds = duration,
                        sequence = sequence,
                        byteRange = range,
                        initMap = activeMap,
                        key = activeKey,
                        discontinuityBefore = discontinuityPending,
                        title = title
                    )
                    nextSequence = sequence + 1
                    duration = 0.0
                    title = null
                    pendingRange = null
                    discontinuityPending = false
                }
            }
        }
        return MediaPlaylist(segments, mediaSequence, targetDuration, endList, playlistType, hasDiscontinuity)
    }

    fun parseAttributes(value: String): Map<String, String> {
        val result = linkedMapOf<String, String>()
        val token = StringBuilder()
        val parts = mutableListOf<String>()
        var quoted = false
        var escaped = false
        for (ch in value) {
            if (escaped) {
                token.append(ch); escaped = false; continue
            }
            if (ch == '\\' && quoted) {
                token.append(ch); escaped = true; continue
            }
            if (ch == '"') quoted = !quoted
            if (ch == ',' && !quoted) {
                parts += token.toString(); token.setLength(0)
            } else token.append(ch)
        }
        if (token.isNotEmpty()) parts += token.toString()
        for (part in parts) {
            val eq = part.indexOf('=')
            if (eq <= 0) continue
            val key = part.substring(0, eq).trim().uppercase(Locale.ROOT)
            val raw = part.substring(eq + 1).trim()
            result[key] = if (raw.length >= 2 && raw.first() == '"' && raw.last() == '"') {
                raw.substring(1, raw.length - 1).replace("\\\"", "\"").replace("\\\\", "\\")
            } else raw
        }
        return result
    }

    private fun parseByteRange(value: String): ByteRange {
        val trimmed = value.trim()
        val lengthText = trimmed.substringBefore('@')
        val length = lengthText.toLongOrNull()?.takeIf { it > 0L }
            ?: throw IllegalArgumentException("Invalid HLS byte range")
        val offset = if ('@' in trimmed) {
            trimmed.substringAfter('@').toLongOrNull()?.takeIf { it >= 0L }
                ?: throw IllegalArgumentException("Invalid HLS byte range offset")
        } else null
        return ByteRange(length, offset)
    }

    private fun parseIv(value: String): ByteArray {
        val hex = value.removePrefix("0x").removePrefix("0X").filterNot { it.isWhitespace() }
        require(hex.isNotEmpty() && hex.length <= 32 && hex.all { it.digitToIntOrNull(16) != null }) { "Invalid HLS IV" }
        val normalized = hex.padStart(32, '0')
        return ByteArray(16) { idx -> normalized.substring(idx * 2, idx * 2 + 2).toInt(16).toByte() }
    }

    private fun resolveUrl(base: URI, reference: String): String = base.resolve(reference).normalize().toASCIIString()

    fun sequenceIv(sequence: Long): ByteArray = ByteBuffer.allocate(16).putLong(8, sequence).array()
}
