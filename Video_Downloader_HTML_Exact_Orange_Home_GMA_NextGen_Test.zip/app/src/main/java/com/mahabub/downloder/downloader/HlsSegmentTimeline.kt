package com.mahabub.downloder.downloader

/** Pure timestamp mapping helpers used by the HLS segment remuxer. */
internal object HlsSegmentTimeline {
    /** Maps a segment-local PTS clock onto the playlist's cumulative EXTINF timeline. */
    fun normalize(
        segmentTimelineStartUs: Long,
        rawSampleTimeUs: Long,
        firstSampleTimeUs: Long
    ): Long = segmentTimelineStartUs + (rawSampleTimeUs - firstSampleTimeUs).coerceAtLeast(0L)

    /**
     * A segment can overlap the previous segment by a frame because EXTINF values are rounded.
     * This predicate is applied only while trimming the leading samples at a new segment boundary,
     * never to later samples inside the segment (which may be in B-frame decode order).
     */
    fun overlapsPreviousSample(normalizedSampleTimeUs: Long, lastWrittenTimeUs: Long?): Boolean =
        lastWrittenTimeUs != null && normalizedSampleTimeUs <= lastWrittenTimeUs
}
