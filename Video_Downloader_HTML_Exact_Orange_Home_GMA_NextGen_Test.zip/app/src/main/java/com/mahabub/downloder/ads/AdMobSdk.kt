package com.mahabub.downloder.ads

import android.app.Application
import android.util.Log
import com.google.android.libraries.ads.mobile.sdk.MobileAds
import com.google.android.libraries.ads.mobile.sdk.initialization.InitializationConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean

/** Google-provided GMA Next-Gen TEST IDs. Replace with the publisher's own IDs before release. */
object AdMobConfig {
    const val TEST_APP_ID = "ca-app-pub-3940256099942544~3347511713"
    const val TEST_NATIVE_AD_UNIT_ID = "ca-app-pub-3940256099942544/2247696110"
}

/** Initializes GMA Next-Gen exactly once from a background dispatcher. */
object AdMobSdk {
    private const val TAG = "AdMobSdk"
    private val initializationStarted = AtomicBoolean(false)
    private val initializationScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val _isInitialized = MutableStateFlow(false)
    val isInitialized: StateFlow<Boolean> = _isInitialized.asStateFlow()
    private val _initializationFinished = MutableStateFlow(false)
    val initializationFinished: StateFlow<Boolean> = _initializationFinished.asStateFlow()

    fun initialize(application: Application) {
        if (!initializationStarted.compareAndSet(false, true)) return

        initializationScope.launch {
            try {
                val config = InitializationConfig.Builder(AdMobConfig.TEST_APP_ID).build()
                MobileAds.initialize(application, config) {
                    _isInitialized.value = true
                    _initializationFinished.value = true
                    Log.d(TAG, "Google Mobile Ads Next-Gen SDK initialized")
                }
            } catch (error: Exception) {
                initializationStarted.set(false)
                _isInitialized.value = false
                _initializationFinished.value = true
                Log.e(TAG, "Google Mobile Ads Next-Gen SDK initialization failed", error)
            }
        }
    }
}
