package com.mahabub.downloder.db

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.mahabub.downloder.model.DownloadStatus
import com.mahabub.downloder.model.PlatformSource
import com.mahabub.downloder.model.StreamType

@Entity(tableName = "downloads")
data class DownloadEntity(
    @PrimaryKey val id: String,
    val sourceUrl: String,
    val sourcePageUrl: String?,
    val sourcePlatform: PlatformSource,
    val streamType: StreamType,
    val fileName: String,
    val mimeType: String?,
    val totalBytes: Long = 0L,
    val downloadedBytes: Long = 0L,
    val totalSegments: Int = 0,
    val completedSegments: Int = 0,
    val status: DownloadStatus = DownloadStatus.QUEUED,
    val localUri: String? = null,
    val temporaryPath: String? = null,
    val etag: String? = null,
    val lastModified: String? = null,
    val userAgent: String? = null,
    val referer: String? = null,
    val errorMessage: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val completedAt: Long? = null,
    val speedBytesPerSec: Long = 0L,
    val thumbnailUrl: String? = null,
    val hlsAudioPlaylistUrl: String? = null,
    /** Known media duration in milliseconds; local-file metadata replaces source metadata on completion. */
    val durationMs: Long? = null
) {
    val progressFraction: Float
        get() {
            if (streamType == StreamType.HLS || streamType == StreamType.DASH) {
                return if (totalSegments > 0) completedSegments.toFloat() / totalSegments.toFloat() else 0f
            }
            return if (totalBytes > 0) downloadedBytes.toFloat() / totalBytes.toFloat() else 0f
        }

    val progressPercent: Int
        get() = (progressFraction * 100f).toInt().coerceIn(0, 100)
}
