package com.mahabub.downloder.model

enum class PlatformSource {
    DIRECT,
    INSTAGRAM,
    TIKTOK,
    FACEBOOK,
    TWITTER_X,
    PINTEREST,
    REDDIT,
    THREADS,
    GENERIC_WEB
}

enum class StreamType {
    PROGRESSIVE,            // A single direct file (HttpDownloader path)
    HLS,                    // .m3u8 playlist (HlsDownloader path)
    DASH,                   // .mpd manifest (static, non-DRM DASH supported)
    UNSUPPORTED_PROTECTED   // DRM/encrypted - reported with explanation only
}

enum class MediaQuality(val label: String) {
    HIGHEST("Original / HD"),
    BALANCED("Balanced (720p/480p)"),
    DATA_SAVER("Data Saver (360p)")
}

/** Where the browser first discovered a candidate. DOM/player evidence is ranked above raw requests. */
enum class MediaDetectionSource {
    DOM_VIDEO,
    SCRIPT_RESOURCE,
    NETWORK_REQUEST,
    DOWNLOAD_EVENT,
    EXTRACTOR
}

data class MediaCandidate(
    val id: String,
    val url: String,
    val title: String?,
    val mimeType: String?,
    val contentDisposition: String? = null,
    val contentLength: Long? = null,
    val userAgent: String? = null,
    val referer: String? = null,
    val sourcePageUrl: String? = null,
    val sourcePlatform: PlatformSource = PlatformSource.GENERIC_WEB,
    val streamType: StreamType = StreamType.PROGRESSIVE,
    val detectedAt: Long = System.currentTimeMillis(),
    val isDirectDownload: Boolean = true,
    val thumbnailUrl: String? = null,
    val durationSeconds: Double? = null,
    val resolution: String? = null,
    /** True when this URL was observed on a video element that was playing. */
    val isPlaying: Boolean = false,
    /** Relative ranking signal, not a guarantee that the URL is downloadable. */
    val detectionSource: MediaDetectionSource = MediaDetectionSource.NETWORK_REQUEST,
    val detectionConfidence: Int = 50,
    /** Heuristic only; a user can still inspect/select the item if a site is misclassified. */
    val isLikelyAd: Boolean = false,
    /** Stable identity for alternative sources exposed by one HTML video player. */
    val videoGroupId: String? = null,
    /** Quality declared by an HLS master playlist or parsed from a source URL. */
    val qualityLabel: String? = null,
    /** Separate HLS audio rendition URL selected from the master playlist, if any. */
    val hlsAudioPlaylistUrl: String? = null,
    /** HLS variant bitrate in bits/second, when declared by the master playlist. */
    val bitrate: Long? = null,
    /** Estimated output size only; do not use this as the HTTP download progress total. */
    val estimatedSizeBytes: Long? = null,
    val sizeIsEstimated: Boolean = false
)
