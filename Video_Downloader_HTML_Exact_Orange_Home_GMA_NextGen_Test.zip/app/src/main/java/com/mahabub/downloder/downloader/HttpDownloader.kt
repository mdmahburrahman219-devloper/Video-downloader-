
package com.mahabub.downloder.downloader

import android.webkit.CookieManager
import com.mahabub.downloder.model.AppError
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile

class HttpDownloader(private val okHttpClient: OkHttpClient) {

    private data class ContentRange(
        val start: Long,
        val end: Long,
        val total: Long?
    )

    suspend fun download(
        url: String,
        tempFile: File,
        userAgent: String?,
        referer: String?,
        cachedEtag: String?,
        onProgress: suspend (
            downloadedBytes: Long,
            totalBytes: Long,
            speedBytesPerSec: Long
        ) -> Unit
    ): File = withContext(Dispatchers.IO) {
        var attempt = 0
        val maxAttempts = 3
        var lastException: Throwable? = null

        tempFile.parentFile?.let { parent ->
            if (!parent.exists() && !parent.mkdirs() && !parent.isDirectory) {
                throw AppError.FileWriteError(
                    "Could not create temporary download directory"
                )
            }
        }

        while (attempt < maxAttempts && isActive) {
            currentCoroutineContext().ensureActive()

            try {
                return@withContext executeDownload(
                    url = url,
                    tempFile = tempFile,
                    userAgent = userAgent,
                    referer = referer,
                    cachedEtag = cachedEtag,
                    onProgress = onProgress,
                    forceFresh = false
                )
            } catch (ce: CancellationException) {
                throw ce
            } catch (ae: AppError) {
                if (
                    ae is AppError.Unauthorized ||
                    ae is AppError.Forbidden ||
                    ae is AppError.NotFound ||
                    ae is AppError.InsufficientStorage ||
                    ae is AppError.ResumeNotSupported ||
                    ae is AppError.InvalidUrl ||
                    ae is AppError.UnsupportedMedia ||
                    ae is AppError.ProtectedMedia
                ) {
                    throw ae
                }

                lastException = ae
                attempt++

                if (attempt < maxAttempts) {
                    delay(1000L * (1 shl (attempt - 1)))
                }
            } catch (ioe: IOException) {
                currentCoroutineContext().ensureActive()

                lastException = ioe
                attempt++

                if (attempt < maxAttempts) {
                    delay(1000L * (1 shl (attempt - 1)))
                }
            } catch (e: Exception) {
                throw AppError.UnknownError(e)
            }
        }

        throw lastException?.let { last ->
            if (last is AppError) {
                last
            } else {
                AppError.UnknownError(last)
            }
        } ?: AppError.UnknownError(
            Exception("Download failed after $maxAttempts attempts")
        )
    }

    private suspend fun executeDownload(
        url: String,
        tempFile: File,
        userAgent: String?,
        referer: String?,
        cachedEtag: String?,
        onProgress: suspend (
            downloadedBytes: Long,
            totalBytes: Long,
            speedBytesPerSec: Long
        ) -> Unit,
        forceFresh: Boolean
    ): File {
        val existingBytes = if (!forceFresh && tempFile.exists()) {
            tempFile.length()
        } else {
            0L
        }

        val requestBuilder = try {
            Request.Builder().url(url)
        } catch (e: IllegalArgumentException) {
            throw AppError.InvalidUrl
        }

        if (!userAgent.isNullOrBlank()) {
            requestBuilder.header("User-Agent", userAgent)
        }

        if (!referer.isNullOrBlank()) {
            requestBuilder.header("Referer", referer)
        }

        // Use only cookies scoped by Android WebView to this exact media URL's host/domain.
        // Never forward TikTok page cookies manually to an unrelated CDN host.
        val cookieManager = CookieManager.getInstance()
        // WebView may have just completed a login or refreshed session cookies.
        // Flush its cookie store before reading the URL-scoped cookies for this request.
        runCatching { cookieManager.flush() }
        val scopedCookies = runCatching {
            cookieManager.getCookie(url)
        }.getOrNull()
        if (!scopedCookies.isNullOrBlank()) {
            requestBuilder.header("Cookie", scopedCookies)
        }
        requestBuilder.header("Accept", "*/*")

        if (existingBytes > 0L) {
            requestBuilder.header("Range", "bytes=$existingBytes-")

            if (!cachedEtag.isNullOrBlank()) {
                requestBuilder.header("If-Range", cachedEtag)
            }
        }

        val response = try {
            okHttpClient.newCall(requestBuilder.build()).execute()
        } catch (e: IOException) {
            throw AppError.NetworkUnavailable
        }

        response.use { res ->
            when (res.code) {
                401 -> throw AppError.Unauthorized
                403 -> throw AppError.Forbidden
                404 -> throw AppError.NotFound
                in 500..599 -> throw AppError.ServerError
            }

            // HTTP 416: the requested byte range is no longer available.
            // If the temporary file already equals the server's reported size,
            // consider it complete. Otherwise restart from byte zero.
            if (res.code == 416 && existingBytes > 0L) {
                val serverSize = res.header("Content-Range")
                    ?.let(::parseUnsatisfiedContentRange)

                if (serverSize != null && serverSize == existingBytes) {
                    onProgress(existingBytes, existingBytes, 0L)
                    return tempFile
                }

                res.close()
                tempFile.delete()

                return executeDownload(
                    url,
                    tempFile,
                    userAgent,
                    referer,
                    cachedEtag,
                    onProgress,
                    forceFresh = true
                )
            }

            if (!res.isSuccessful && res.code != 206) {
                throw AppError.HttpError(res.code)
            }

            val body = res.body ?: throw AppError.HttpError(res.code)

            // Signed-in social pages can redirect a stale/unauthorized media URL to an
            // HTML login/error page (or return a small JSON error payload) with HTTP 200.
            // Do not save that response as an MP4: it is the common cause of tiny corrupt files.
            val responseMime = res.header("Content-Type")
                ?.substringBefore(';')
                ?.trim()
                ?.lowercase()
                .orEmpty()
            val isNonMediaErrorPayload = responseMime == "text/html" ||
                responseMime == "application/xhtml+xml" ||
                responseMime == "application/json" ||
                responseMime.endsWith("+json") ||
                responseMime == "text/xml" || responseMime == "application/xml"
            // MIME headers are sometimes missing or incorrect on CDN error responses, so
            // inspect a small non-consuming prefix for every response as a second safeguard.
            val responsePreview: ByteArray? = runCatching { res.peekBody(8_192L).bytes() }.getOrNull()
            val previewText = responsePreview
                ?.take(512)
                ?.toByteArray()
                ?.toString(Charsets.UTF_8)
                ?.trimStart()
                ?.lowercase()
                .orEmpty()
            val looksLikeHtmlOrJson = previewText.startsWith("<") ||
                previewText.startsWith("{") || previewText.startsWith("[")
            if (isNonMediaErrorPayload || looksLikeHtmlOrJson) {
                // Do not leave a previous partial file looking like a completed download.
                runCatching { tempFile.delete() }
                throw AppError.UnsupportedMedia
            }

            val receivedRange = res.header("Content-Range")
                ?.let(::parseContentRange)

            val isValidResumeResponse =
                existingBytes > 0L && res.code == 206

            if (isValidResumeResponse) {
                if (
                    receivedRange == null ||
                    receivedRange.start != existingBytes
                ) {
                    // Never append bytes at an unverified position.
                    res.close()
                    tempFile.delete()

                    return executeDownload(
                        url,
                        tempFile,
                        userAgent,
                        referer,
                        cachedEtag,
                        onProgress,
                        forceFresh = true
                    )
                }
            } else if (
                res.code == 206 &&
                receivedRange?.start != 0L
            ) {
                throw AppError.ResumeNotSupported
            }

            // A 200 response can mean that the server ignored Range or
            // that the If-Range validator no longer matches. In that case,
            // write the new complete representation from the beginning.
            val append = isValidResumeResponse
            val initialBytes = if (append) existingBytes else 0L
            val contentLength = body.contentLength()

            val totalBytes = when {
                receivedRange?.total != null -> receivedRange.total
                contentLength > 0L -> initialBytes + contentLength
                else -> 0L
            }

            val buffer = ByteArray(32 * 1024)
            var downloadedBytes = initialBytes
            var bytesSinceLastSample = 0L
            var lastSampleTime = System.currentTimeMillis()

            try {
                RandomAccessFile(tempFile, "rw").use { raf ->
                    if (append) {
                        raf.seek(existingBytes)
                    } else {
                        raf.setLength(0L)
                    }

                    body.byteStream().use { input ->
                        while (true) {
                            currentCoroutineContext().ensureActive()

                            val bytesRead = input.read(buffer)
                            if (bytesRead == -1) break

                            raf.write(buffer, 0, bytesRead)

                            downloadedBytes += bytesRead
                            bytesSinceLastSample += bytesRead

                            val now = System.currentTimeMillis()
                            val timeDiff = now - lastSampleTime

                            if (timeDiff >= 1000L) {
                                val currentSpeed =
                                    (bytesSinceLastSample * 1000L) / timeDiff

                                bytesSinceLastSample = 0L
                                lastSampleTime = now

                                onProgress(
                                    downloadedBytes,
                                    totalBytes,
                                    currentSpeed
                                )
                            }
                        }
                    }
                }

                onProgress(downloadedBytes, totalBytes, 0L)

                if (totalBytes > 0L && downloadedBytes != totalBytes) {
                    throw AppError.FileWriteError(
                        "Incomplete file: received $downloadedBytes of $totalBytes bytes"
                    )
                }

                if (!tempFile.exists() || tempFile.length() == 0L) {
                    throw AppError.FileWriteError("Downloaded file is empty")
                }

                return tempFile
            } catch (ce: CancellationException) {
                throw ce
            } catch (ae: AppError) {
                throw ae
            } catch (e: IOException) {
                throw e
            } catch (e: Exception) {
                throw AppError.FileWriteError(e.message)
            }
        }
    }

    private fun parseContentRange(value: String): ContentRange? {
        val match = Regex(
            """bytes\s+(\d+)-(\d+)/(\d+|\*)""",
            RegexOption.IGNORE_CASE
        ).matchEntire(value.trim()) ?: return null

        val start = match.groupValues[1].toLongOrNull() ?: return null
        val end = match.groupValues[2].toLongOrNull() ?: return null

        val total = match.groupValues[3]
            .takeIf { it != "*" }
            ?.toLongOrNull()

        if (start < 0L || end < start) return null
        if (total != null && end >= total) return null

        return ContentRange(start, end, total)
    }

    private fun parseUnsatisfiedContentRange(value: String): Long? {
        return Regex(
            """bytes\s+\*/(\d+)""",
            RegexOption.IGNORE_CASE
        )
            .matchEntire(value.trim())
            ?.groupValues
            ?.getOrNull(1)
            ?.toLongOrNull()
    }
}
