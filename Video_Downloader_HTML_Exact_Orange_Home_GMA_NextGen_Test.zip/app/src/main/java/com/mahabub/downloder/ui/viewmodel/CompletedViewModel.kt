package com.mahabub.downloder.ui.viewmodel

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.mahabub.downloder.AppContainer
import com.mahabub.downloder.db.DownloadEntity
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class CompletedViewModel(private val container: AppContainer) : ViewModel() {

    val completedDownloads: StateFlow<List<DownloadEntity>> = container.downloadRepository.completedDownloads
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun deleteCompleted(id: String) {
        viewModelScope.launch {
            container.downloadRepository.deleteDownload(id, deleteFile = true)
        }
    }

    fun clearAllCompleted() {
        viewModelScope.launch {
            container.downloadRepository.clearCompleted()
        }
    }

    suspend fun renameCompleted(id: String, newFileName: String) {
        container.downloadRepository.renameCompletedDownload(id, newFileName)
    }

    fun getShareUri(uriString: String?): Uri? {
        if (uriString.isNullOrBlank()) return null
        return container.storageManager.getShareableUri(uriString)
    }

    class Factory(private val container: AppContainer) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return CompletedViewModel(container) as T
        }
    }
}
