package com.mahabub.downloder.extractor

import android.content.Context
import com.mahabub.downloder.model.PlatformSource
import org.json.JSONObject
import java.io.File
import java.net.URI
import java.util.UUID

/**
 * Persists a small, page-visible MPD manifest captured from the signed-in WebView response.
 * The database stores only an opaque `vd-inline-dash://UUID` reference; the actual manifest
 * remains in app-private storage and survives process restarts for queued/retried downloads.
 * No cookies, credentials, DRM keys, or media bytes are stored here.
 */
object InlineDashManifestStore {
    private const val SCHEME_PREFIX = "vd-inline-dash://"
    private const val MAX_MANIFEST_CHARS = 1_500_000
    private const val MAX_STORE_AGE_MS = 7L * 24L * 60L * 60L * 1000L

    data class Record(
        val id: String,
        val manifestBaseUrl: String,
        val manifestText: String,
        val createdAt: Long
    )

    data class Selection(
        val videoRepresentationIndex: Int? = null,
        val audioRepresentationIndex: Int? = null,
        val audioOnly: Boolean = false
    )

    fun save(
        context: Context,
        platform: PlatformSource,
        manifestBaseUrl: String,
        manifestText: String
    ): String? {
        val base = safeBaseUrl(manifestBaseUrl, platform) ?: return null
        val xml = normalizeManifest(manifestText) ?: return null
        val id = UUID.randomUUID().toString()
        val directory = directory(context)
        if (!directory.exists() && !directory.mkdirs()) return null
        cleanupExpired(directory)
        val json = JSONObject()
            .put("id", id)
            .put("manifestBaseUrl", base)
            .put("manifestText", xml)
            .put("createdAt", System.currentTimeMillis())
        return runCatching {
            File(directory, "$id.json").writeText(json.toString(), Charsets.UTF_8)
            "$SCHEME_PREFIX$id"
        }.getOrNull()
    }

    fun read(context: Context, sourceUrl: String): Record? {
        val id = manifestId(sourceUrl) ?: return null
        val file = File(directory(context), "$id.json")
        if (!file.isFile || file.length() !in 1..(MAX_MANIFEST_CHARS * 4L)) return null
        return runCatching {
            val json = JSONObject(file.readText(Charsets.UTF_8))
            val text = normalizeManifest(json.optString("manifestText")) ?: return null
            val base = json.optString("manifestBaseUrl")
            if (!isHttpUrl(base)) return null
            val created = json.optLong("createdAt", 0L)
            if (created <= 0L || System.currentTimeMillis() - created > MAX_STORE_AGE_MS) return null
            Record(id, base, text, created)
        }.getOrNull()
    }

    fun delete(context: Context, sourceUrl: String) {
        val id = manifestId(sourceUrl) ?: return
        runCatching { File(directory(context), "$id.json").delete() }
    }

    fun isInlineDashUrl(url: String): Boolean = manifestId(url) != null

    /** Adds a stable representation selection to an opaque manifest reference for the queue. */
    fun withSelection(
        sourceUrl: String,
        videoRepresentationIndex: Int?,
        audioRepresentationIndex: Int?,
        audioOnly: Boolean = false
    ): String {
        val id = manifestId(sourceUrl) ?: return sourceUrl
        val params = buildList {
            videoRepresentationIndex?.takeIf { it >= 0 }?.let { add("video=$it") }
            audioRepresentationIndex?.takeIf { it >= 0 }?.let { add("audio=$it") }
            if (audioOnly) add("audioOnly=1")
        }
        return if (params.isEmpty()) "$SCHEME_PREFIX$id" else "$SCHEME_PREFIX$id?${params.joinToString("&")}"
    }

    fun selection(sourceUrl: String): Selection {
        if (!isInlineDashUrl(sourceUrl)) return Selection()
        val query = runCatching { URI(sourceUrl).rawQuery.orEmpty() }.getOrDefault("")
        val values = query.split('&').mapNotNull { part ->
            val key = part.substringBefore('=')
            val value = part.substringAfter('=', "")
            key to value
        }.toMap()
        return Selection(
            videoRepresentationIndex = values["video"]?.toIntOrNull()?.takeIf { it >= 0 },
            audioRepresentationIndex = values["audio"]?.toIntOrNull()?.takeIf { it >= 0 },
            audioOnly = values["audioOnly"] == "1"
        )
    }

    private fun manifestId(sourceUrl: String): String? {
        if (!sourceUrl.startsWith(SCHEME_PREFIX)) return null
        val host = runCatching { URI(sourceUrl).host }.getOrNull() ?: return null
        return host.takeIf { runCatching { UUID.fromString(it).toString() == it }.getOrDefault(false) }
    }

    private fun directory(context: Context): File = File(context.applicationContext.filesDir, "inline_dash_manifests")

    private fun cleanupExpired(directory: File) {
        runCatching {
            val files = directory.listFiles { file -> file.isFile && file.extension.equals("json", true) }
                ?.sortedByDescending { it.lastModified() } ?: return
            val now = System.currentTimeMillis()
            files.forEachIndexed { index, file ->
                val createdAt = runCatching {
                    JSONObject(file.readText(Charsets.UTF_8)).optLong("createdAt", file.lastModified())
                }.getOrDefault(0L)
                if (now - createdAt > MAX_STORE_AGE_MS || index >= 200) file.delete()
            }
        }
    }

    private fun normalizeManifest(raw: String?): String? {
        val text = raw?.trim()?.takeIf { it.isNotEmpty() && it.length <= MAX_MANIFEST_CHARS } ?: return null
        if (!text.contains("<MPD", ignoreCase = true) || !text.contains("</MPD>", ignoreCase = true)) return null
        // Refuse XML features that can cause external entity resolution or protected media paths.
        if (Regex("(?i)<!DOCTYPE|<!ENTITY|<ContentProtection\\b").containsMatchIn(text)) return null
        return text
    }

    private fun safeBaseUrl(raw: String, platform: PlatformSource): String? {
        if (!isHttpUrl(raw)) return null
        val host = URI(raw).host.orEmpty().lowercase()
        val firstParty = when (platform) {
            PlatformSource.FACEBOOK -> isHostOrSubdomain(host, "facebook.com") ||
                isHostOrSubdomain(host, "fbcdn.net") ||
                isHostOrSubdomain(host, "fbsbx.com")
            PlatformSource.INSTAGRAM -> host == "instagram.com" || host.endsWith(".instagram.com") ||
                host == "instagr.am" || host.endsWith(".instagr.am")
            PlatformSource.THREADS -> host == "threads.com" || host.endsWith(".threads.com") ||
                host == "threads.net" || host.endsWith(".threads.net")
            else -> false
        }
        return raw.takeIf { firstParty && it.length <= 8192 }
    }

    /**
     * Facebook media manifests may be served from signed CDN URLs rather than the page host.
     * Keep the allowlist suffix-boundary-safe: "evilfacebook.com" must never match.
     */
    internal fun isHostOrSubdomain(host: String, domain: String): Boolean {
        val normalizedHost = host.trimEnd('.').lowercase()
        val normalizedDomain = domain.trimEnd('.').lowercase()
        return normalizedHost == normalizedDomain || normalizedHost.endsWith(".$normalizedDomain")
    }

    private fun isHttpUrl(value: String): Boolean = runCatching {
        val uri = URI(value)
        (uri.scheme.equals("https", true) || uri.scheme.equals("http", true)) && !uri.host.isNullOrBlank()
    }.getOrDefault(false)
}
