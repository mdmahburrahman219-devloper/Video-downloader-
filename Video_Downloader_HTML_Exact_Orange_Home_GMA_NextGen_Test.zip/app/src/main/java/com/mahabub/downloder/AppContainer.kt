package com.mahabub.downloder

import android.content.Context
import com.mahabub.downloder.browser.MediaDetector
import com.mahabub.downloder.db.AppDatabase
import com.mahabub.downloder.extractor.FacebookExtractor
import com.mahabub.downloder.extractor.InstagramExtractor
import com.mahabub.downloder.extractor.PinterestExtractor
import com.mahabub.downloder.extractor.PlatformExtractor
import com.mahabub.downloder.extractor.RedditExtractor
import com.mahabub.downloder.extractor.ThreadsExtractor
import com.mahabub.downloder.extractor.TwitterXExtractor
import com.mahabub.downloder.preferences.PreferenceManager
import com.mahabub.downloder.repository.DownloadRepository
import com.mahabub.downloder.repository.MediaExtractionRepository
import com.mahabub.downloder.storage.StorageManager
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

class AppContainer(val context: Context) {

    val okHttpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .followRedirects(true)
            .followSslRedirects(true)
            .build()
    }

    val database: AppDatabase by lazy {
        AppDatabase.getInstance(context)
    }

    val preferenceManager: PreferenceManager by lazy {
        PreferenceManager(context)
    }

    val storageManager: StorageManager by lazy {
        StorageManager(context)
    }

    val platformExtractors: Set<PlatformExtractor> by lazy {
        setOf(
            InstagramExtractor(okHttpClient),
            FacebookExtractor(okHttpClient),
            TwitterXExtractor(okHttpClient),
            PinterestExtractor(okHttpClient),
            RedditExtractor(okHttpClient),
            ThreadsExtractor(okHttpClient)
        )
    }

    val mediaExtractionRepository: MediaExtractionRepository by lazy {
        MediaExtractionRepository(okHttpClient, platformExtractors)
    }

    val downloadRepository: DownloadRepository by lazy {
        DownloadRepository(
            context = context,
            database = database,
            preferenceManager = preferenceManager,
            storageManager = storageManager
        )
    }

    val mediaDetector: MediaDetector by lazy {
        MediaDetector()
    }
}
