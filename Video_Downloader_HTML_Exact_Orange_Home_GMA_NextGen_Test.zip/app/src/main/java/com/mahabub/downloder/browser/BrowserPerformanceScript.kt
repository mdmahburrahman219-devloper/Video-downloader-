package com.mahabub.downloder.browser

/**
 * A conservative WebView optimization for muted autoplay/loop preview videos.
 * It pauses only off-screen preview-style videos and resumes only videos paused by this guard.
 * Normal user-controlled videos are intentionally left alone.
 */
object BrowserPerformanceScript {
    val JAVASCRIPT = """
        (function () {
          'use strict';
          if (window.__vdPreviewPerformanceGuard) return;
          window.__vdPreviewPerformanceGuard = true;
          if (!('IntersectionObserver' in window)) return;

          var watched = new WeakSet();
          var scanScheduled = false;
          var observer = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
              var video = entry.target;
              if (!isPreview(video)) return;
              if (!entry.isIntersecting || entry.intersectionRatio < 0.01) {
                if (!video.paused && !video.ended) {
                  video.__vdPausedByPreviewGuard = true;
                  try { video.pause(); } catch (e) {}
                }
              } else if (video.__vdPausedByPreviewGuard && document.visibilityState === 'visible') {
                video.__vdPausedByPreviewGuard = false;
                try {
                  var p = video.play();
                  if (p && typeof p.catch === 'function') p.catch(function () {});
                } catch (e) {}
              }
            });
          }, { rootMargin: '140px 0px', threshold: [0, 0.01] });

          function isPreview(video) {
            return !!(video && (video.muted || video.defaultMuted) && (video.loop || video.autoplay));
          }

          function scanBatch() {
            scanScheduled = false;
            var hasMore = false;
            try {
              var videos = document.querySelectorAll('video');
              var observedThisBatch = 0;
              // Observe in small batches so a page with hundreds of previews doesn't lock scrolling.
              for (var i = 0; i < videos.length; i++) {
                var video = videos[i];
                if (!video || watched.has(video)) continue;
                if (observedThisBatch >= 80) { hasMore = true; break; }
                watched.add(video);
                observedThisBatch++;
                try { observer.observe(video); } catch (e) {}
              }
            } catch (e) {}
            if (hasMore) scheduleScan(120);
          }

          function scheduleScan(delayMs) {
            if (scanScheduled) return;
            scanScheduled = true;
            setTimeout(scanBatch, typeof delayMs === 'number' ? delayMs : 250);
          }

          scheduleScan(150);
          try {
            new MutationObserver(function (mutations) {
              for (var i = 0; i < mutations.length; i++) {
                var m = mutations[i];
                if (m.type === 'attributes') {
                  if (m.target && m.target.tagName === 'VIDEO') { scheduleScan(250); return; }
                } else if (m.addedNodes) {
                  for (var j = 0; j < m.addedNodes.length; j++) {
                    var node = m.addedNodes[j];
                    if (node && node.nodeType === 1 &&
                      ((node.matches && node.matches('video')) || (node.querySelector && node.querySelector('video')))) {
                      scheduleScan(250); return;
                    }
                  }
                }
              }
            }).observe(document.documentElement || document, {
              childList: true, subtree: true, attributes: true, attributeFilter: ['src', 'autoplay', 'loop', 'muted']
            });
          } catch (e) {}
          document.addEventListener('visibilitychange', function () {
            if (document.visibilityState === 'visible') scheduleScan(150);
          }, { passive: true });
        })();
    """.trimIndent()
}
