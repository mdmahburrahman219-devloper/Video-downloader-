package com.mahabub.downloder.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import org.json.JSONArray
import org.json.JSONObject
import com.mahabub.downloder.model.MediaQuality
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "user_settings")

data class HomeShortcut(val name: String, val url: String)

object HomeShortcutDefaults {
    val items = listOf(
        HomeShortcut("Facebook", "https://www.facebook.com/"),
        HomeShortcut("Instagram", "https://www.instagram.com/"),
        HomeShortcut("Vimeo", "https://vimeo.com/"),
        HomeShortcut("Dailymotion", "https://www.dailymotion.com/")
    )
}

class PreferenceManager(private val context: Context) {

    companion object {
        private val KEY_WIFI_ONLY = booleanPreferencesKey("pref_wifi_only")
        private val KEY_MAX_CONCURRENT = intPreferencesKey("pref_max_concurrent")
        private val KEY_PREFERRED_QUALITY = stringPreferencesKey("pref_preferred_quality")
        private val KEY_ASK_BEFORE_DOWNLOAD = booleanPreferencesKey("pref_ask_before_download")
        private val KEY_PRIVATE_DOWNLOADS = booleanPreferencesKey("pref_private_downloads")
        private val KEY_DARK_MODE = stringPreferencesKey("pref_dark_mode") // "system", "light", "amoled", "normal_dark"
        private val KEY_SEARCH_ENGINE = stringPreferencesKey("pref_search_engine")
        private val KEY_CUSTOM_SEARCH_URL = stringPreferencesKey("pref_custom_search_url")
        private val KEY_BROWSER_TABS = stringPreferencesKey("pref_browser_tabs_v1")
        private val KEY_ACTIVE_BROWSER_TAB_ID = longPreferencesKey("pref_active_browser_tab_id_v1")
        private val KEY_BLOCK_ADS = booleanPreferencesKey("pref_block_ads")
        private val KEY_SHOW_RECENT_WEBSITES = booleanPreferencesKey("pref_show_recent_websites")
        private val KEY_SYNC_TO_GALLERY = booleanPreferencesKey("pref_sync_to_gallery")
        private val KEY_DOWNLOAD_LOCATION = stringPreferencesKey("pref_download_location")
        private val KEY_DOWNLOAD_TREE_URI = stringPreferencesKey("pref_download_tree_uri")
        private val KEY_LANGUAGE = stringPreferencesKey("pref_language")
        private val KEY_NOTICE_ACCEPTED_PERMANENT = booleanPreferencesKey("pref_notice_accepted_permanent")
        private val KEY_HOME_SHORTCUTS = stringPreferencesKey("pref_home_shortcuts_v1")
        private val KEY_HOME_SHOW_QUICK_ACCESS = booleanPreferencesKey("pref_home_show_quick_access")
        private val KEY_HOME_ACCENT_COLOR = stringPreferencesKey("pref_home_accent_color")
        private val KEY_HOME_BACKGROUND = stringPreferencesKey("pref_home_background")
    }

    // Session-only acceptance flag (in-memory)
    var sessionNoticeAccepted: Boolean = false

    val isWifiOnly: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_WIFI_ONLY] ?: false
    }

    val maxConcurrentDownloads: Flow<Int> = context.dataStore.data.map { prefs ->
        prefs[KEY_MAX_CONCURRENT] ?: 2
    }

    val preferredQuality: Flow<MediaQuality> = context.dataStore.data.map { prefs ->
        when (prefs[KEY_PREFERRED_QUALITY]) {
            MediaQuality.BALANCED.name -> MediaQuality.BALANCED
            MediaQuality.DATA_SAVER.name -> MediaQuality.DATA_SAVER
            else -> MediaQuality.HIGHEST
        }
    }

    val askBeforeDownload: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_ASK_BEFORE_DOWNLOAD] ?: true
    }

    val isPrivateDownloads: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_PRIVATE_DOWNLOADS] ?: false
    }

    val darkMode: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[KEY_DARK_MODE] ?: "system"
    }

    val searchEngine: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[KEY_SEARCH_ENGINE] ?: "Google"
    }

    val customSearchUrl: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[KEY_CUSTOM_SEARCH_URL] ?: "https://www.google.com/search?q=%s"
    }

    /** JSON snapshot of non-private browser tabs, persisted across process death. */
    val browserTabsSnapshot: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[KEY_BROWSER_TABS] ?: ""
    }

    val activeBrowserTabId: Flow<Long> = context.dataStore.data.map { prefs ->
        prefs[KEY_ACTIVE_BROWSER_TAB_ID] ?: 1L
    }

    val blockAds: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_BLOCK_ADS] ?: true
    }

    val showRecentWebsites: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_SHOW_RECENT_WEBSITES] ?: false
    }

    val syncToGallery: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_SYNC_TO_GALLERY] ?: false
    }

    val downloadLocation: Flow<String> = context.dataStore.data.map { prefs ->
        val saved = prefs[KEY_DOWNLOAD_LOCATION]?.trim().orEmpty()
        // Migrate the previous built-in Download/VideoDownloader default to the
        // requested shared-storage root folder without overriding user custom paths.
        if (saved.isBlank() || saved.equals("/storage/emulated/0/Download/VideoDownloader", true) ||
            saved.equals("/storage/emulated/0/Download/Video Downloader", true)) {
            "/storage/emulated/0/Video downloader"
        } else saved
    }

    val downloadFolderTreeUri: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[KEY_DOWNLOAD_TREE_URI].orEmpty()
    }

    val language: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[KEY_LANGUAGE] ?: "Default"
    }

    val isNoticeAcceptedPermanently: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_NOTICE_ACCEPTED_PERMANENT] ?: false
    }

    val homeShortcuts: Flow<List<HomeShortcut>> = context.dataStore.data.map { prefs ->
        decodeHomeShortcuts(prefs[KEY_HOME_SHORTCUTS])
    }

    val showQuickAccess: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_HOME_SHOW_QUICK_ACCESS] ?: true
    }

    val homeAccentColor: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[KEY_HOME_ACCENT_COLOR] ?: "purple"
    }

    val homeBackground: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[KEY_HOME_BACKGROUND] ?: "light"
    }

    suspend fun setWifiOnly(enabled: Boolean) {
        context.dataStore.edit { it[KEY_WIFI_ONLY] = enabled }
    }

    suspend fun setMaxConcurrentDownloads(count: Int) {
        context.dataStore.edit { it[KEY_MAX_CONCURRENT] = count.coerceIn(1, 5) }
    }

    suspend fun setPreferredQuality(quality: MediaQuality) {
        context.dataStore.edit { it[KEY_PREFERRED_QUALITY] = quality.name }
    }

    suspend fun setAskBeforeDownload(enabled: Boolean) {
        context.dataStore.edit { it[KEY_ASK_BEFORE_DOWNLOAD] = enabled }
    }

    suspend fun setPrivateDownloads(enabled: Boolean) {
        context.dataStore.edit { it[KEY_PRIVATE_DOWNLOADS] = enabled }
    }

    suspend fun setDarkMode(mode: String) {
        val allowed = setOf("system", "light", "amoled", "normal_dark")
        context.dataStore.edit { it[KEY_DARK_MODE] = mode.takeIf { it in allowed } ?: "system" }
    }

    suspend fun setSearchEngine(name: String) {
        val allowed = setOf(
            "Custom URL", "Google", "Ask", "Bing", "Yahoo", "StartPage",
            "StartPage (Mobile)", "DuckDuckGo (Privacy)", "DuckDuckGo Lite (Privacy)",
            "Baidu (Chinese)", "Yandex (Russian)"
        )
        context.dataStore.edit { it[KEY_SEARCH_ENGINE] = name.takeIf { it in allowed } ?: "Google" }
    }

    suspend fun setCustomSearchUrl(url: String) {
        context.dataStore.edit { it[KEY_CUSTOM_SEARCH_URL] = url.trim().take(2048) }
    }

    suspend fun setBrowserSession(tabsJson: String, activeTabId: Long) {
        context.dataStore.edit { prefs ->
            prefs[KEY_BROWSER_TABS] = tabsJson.take(64_000)
            prefs[KEY_ACTIVE_BROWSER_TAB_ID] = activeTabId.coerceAtLeast(1L)
        }
    }

    suspend fun setBlockAds(enabled: Boolean) {
        context.dataStore.edit { it[KEY_BLOCK_ADS] = enabled }
    }

    suspend fun setShowRecentWebsites(enabled: Boolean) {
        context.dataStore.edit { it[KEY_SHOW_RECENT_WEBSITES] = enabled }
    }

    suspend fun setSyncToGallery(enabled: Boolean) {
        context.dataStore.edit { it[KEY_SYNC_TO_GALLERY] = enabled }
    }

    suspend fun setDownloadLocation(path: String) {
        context.dataStore.edit { it[KEY_DOWNLOAD_LOCATION] = path }
    }

    suspend fun setDownloadFolderTreeUri(uri: String?) {
        context.dataStore.edit { prefs ->
            if (uri.isNullOrBlank()) prefs.remove(KEY_DOWNLOAD_TREE_URI)
            else prefs[KEY_DOWNLOAD_TREE_URI] = uri.take(4096)
        }
    }

    suspend fun setLanguage(lang: String) {
        context.dataStore.edit { it[KEY_LANGUAGE] = lang }
    }

    suspend fun setNoticeAcceptedPermanently(accepted: Boolean) {
        context.dataStore.edit { it[KEY_NOTICE_ACCEPTED_PERMANENT] = accepted }
    }

    suspend fun setHomeShortcuts(shortcuts: List<HomeShortcut>) {
        context.dataStore.edit { it[KEY_HOME_SHORTCUTS] = encodeHomeShortcuts(shortcuts) }
    }

    /** Add one quick link atomically so rapid edits cannot overwrite one another. */
    suspend fun addHomeShortcut(shortcut: HomeShortcut) {
        context.dataStore.edit { prefs ->
            val current = decodeHomeShortcuts(prefs[KEY_HOME_SHORTCUTS])
            val newHost = shortcutHost(shortcut.url)
            if (current.size < 20 && current.none { shortcutHost(it.url) == newHost }) {
                prefs[KEY_HOME_SHORTCUTS] = encodeHomeShortcuts(current + shortcut)
            }
        }
    }

    /** Remove a single quick link atomically. */
    suspend fun removeHomeShortcut(url: String) {
        context.dataStore.edit { prefs ->
            val current = decodeHomeShortcuts(prefs[KEY_HOME_SHORTCUTS])
            prefs[KEY_HOME_SHORTCUTS] = encodeHomeShortcuts(current.filterNot { it.url == url })
        }
    }

    private fun encodeHomeShortcuts(shortcuts: List<HomeShortcut>): String {
        val json = JSONArray()
        shortcuts.take(20).forEach { item ->
            json.put(JSONObject().put("name", item.name.take(48)).put("url", item.url.take(2048)))
        }
        return json.toString()
    }

    private fun shortcutHost(url: String): String = runCatching {
        java.net.URI(url).host?.lowercase()?.trimEnd('.')
            ?.removePrefix("www.")?.removePrefix("m.")?.removePrefix("mobile.") ?: url.lowercase()
    }.getOrDefault(url.lowercase())

    suspend fun setShowQuickAccess(enabled: Boolean) {
        context.dataStore.edit { it[KEY_HOME_SHOW_QUICK_ACCESS] = enabled }
    }

    suspend fun setHomeAccentColor(color: String) {
        val allowed = setOf("blue", "purple", "teal", "green", "orange", "rose")
        context.dataStore.edit { it[KEY_HOME_ACCENT_COLOR] = color.takeIf { it in allowed } ?: "purple" }
    }

    suspend fun setHomeBackground(background: String) {
        val allowed = setOf("light", "ice", "lavender", "warm")
        context.dataStore.edit { it[KEY_HOME_BACKGROUND] = background.takeIf { it in allowed } ?: "light" }
    }

    private fun decodeHomeShortcuts(raw: String?): List<HomeShortcut> {
        if (raw == null) return HomeShortcutDefaults.items
        return runCatching {
            val array = JSONArray(raw)
            buildList {
                for (index in 0 until array.length()) {
                    val obj = array.optJSONObject(index) ?: continue
                    val name = obj.optString("name").trim().take(48)
                    val url = obj.optString("url").trim().take(2048)
                    if (name.isNotBlank() && (url.startsWith("https://") || url.startsWith("http://"))) {
                        add(HomeShortcut(name, url))
                    }
                    if (size >= 20) break
                }
            }.distinctBy { shortcut ->
                runCatching {
                    java.net.URI(shortcut.url).host?.lowercase()?.trimEnd('.')
                        ?.removePrefix("www.")?.removePrefix("m.")?.removePrefix("mobile.") ?: shortcut.url.lowercase()
                }.getOrDefault(shortcut.url.lowercase())
            }
        }.getOrDefault(HomeShortcutDefaults.items)
    }
}
