
package com.mahabub.downloder.storage

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.provider.DocumentsContract
import androidx.core.content.FileProvider
import com.mahabub.downloder.model.AppError
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException

class StorageManager(private val context: Context) {

    private val appContext = context.applicationContext

    /**
     * Creates or returns the resumable HTTP partial-download file.
     *
     * Keep temporary names independent of the media title. Social post titles can contain
     * long UTF-8 text (including Japanese/emoji); combining those titles with a UUID can exceed
     * Android/Linux's per-component filename byte limit and fail before the HTTP request starts.
     * The user-facing name is applied only when the completed file is saved.
     */
    fun createTempFile(taskId: String): File {
        val tempDir = ensureDirectory(File(appContext.cacheDir, "downloads"))
        val safeId = sanitizeTaskId(taskId)
        return File(tempDir, "${safeId}.part")
    }

    /** Creates or returns a task-specific folder for HLS segments. */
    fun createHlsTempDir(taskId: String): File {
        val root = ensureDirectory(File(appContext.cacheDir, "hls_temp"))
        return ensureDirectory(File(root, sanitizeTaskId(taskId)))
    }

    /** Checks available cache storage with a 20 MiB safety margin. */
    fun hasEnoughSpace(requiredBytes: Long): Boolean {
        if (requiredBytes < 0L) return false

        return try {
            val available = StatFs(appContext.cacheDir.absolutePath).availableBytes
            val bufferBytes = 20L * 1024L * 1024L

            if (requiredBytes > Long.MAX_VALUE - bufferBytes) {
                false
            } else {
                available >= requiredBytes + bufferBytes
            }
        } catch (_: Exception) {
            // Storage state could not be checked; do not claim that space is sufficient.
            false
        }
    }

    /**
     * Saves completed downloads to one of three destinations:
     * - Private downloads: app-private storage.
     * - Sync to gallery: DCIM/Video downloader (MediaStore video collection).
     * - Normal downloads: Internal Storage/Video downloader when the OS grants raw
     *   shared-storage writes; otherwise use the scoped-storage-safe Downloads collection.
     */
    fun saveCompletedMedia(
        sourceFile: File,
        desiredFileName: String,
        mimeType: String?,
        isPrivate: Boolean,
        syncToGallery: Boolean = false,
        downloadLocation: String? = null,
        downloadFolderTreeUri: String? = null
    ): String {
        if (!sourceFile.isFile || sourceFile.length() <= 0L) {
            throw AppError.FileWriteError("Source file is empty or does not exist")
        }

        val finalMime = mimeType
            ?.substringBefore(';')
            ?.trim()
            ?.takeIf { it.isNotEmpty() }
            ?: "video/mp4"
        val fallbackExtension = SafeFileName.getExtensionFromMime(finalMime)
        val safeName = SafeFileName.sanitize(desiredFileName, fallbackExtension)

        if (isPrivate) return saveToPrivateStorage(sourceFile, safeName)

        if (syncToGallery) {
            val relativePath = when {
                finalMime.startsWith("audio/", true) -> "${Environment.DIRECTORY_MUSIC}/Video downloader/"
                finalMime.startsWith("image/", true) -> "${Environment.DIRECTORY_PICTURES}/Video downloader/"
                else -> "${Environment.DIRECTORY_DCIM}/Video downloader/"
            }
            return saveToMediaStore(sourceFile, safeName, finalMime, relativePath)
        }

        // Prefer the user's persisted SAF grant for the exact shared root folder. This
        // works on current Android without MANAGE_EXTERNAL_STORAGE or broad file access.
        if (!downloadFolderTreeUri.isNullOrBlank()) {
            return saveToTreeFolder(sourceFile, safeName, finalMime, downloadFolderTreeUri)
        }

        // Attempt the requested shared root path on legacy/compatible devices. Scoped
        // storage may reject this; the scoped Downloads collection is the safe fallback.
        return try {
            saveToPublicRootFolder(sourceFile, safeName, downloadLocation)
        } catch (rootWriteError: Exception) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                saveToMediaStore(
                    sourceFile = sourceFile,
                    safeName = safeName,
                    mimeType = finalMime,
                    requestedRelativePath = "${Environment.DIRECTORY_DOWNLOADS}/Video downloader/",
                    collectionOverride = MediaStore.Downloads.EXTERNAL_CONTENT_URI
                )
            } else {
                throw AppError.FileWriteError(
                    rootWriteError.message ?: "Could not write to Internal Storage/Video downloader"
                )
            }
        }
    }

    private fun saveToTreeFolder(
        sourceFile: File,
        safeName: String,
        mimeType: String,
        treeUriString: String
    ): String {
        val resolver = appContext.contentResolver
        val treeUri = Uri.parse(treeUriString)
        var createdUri: Uri? = null
        try {
            val treeDocumentId = DocumentsContract.getTreeDocumentId(treeUri)
            val treeDocumentUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, treeDocumentId)
            val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, treeDocumentId)
            val existingNames = mutableSetOf<String>()
            resolver.query(
                childrenUri,
                arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME),
                null, null, null
            )?.use { cursor ->
                val nameColumn = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
                while (cursor.moveToNext()) {
                    if (nameColumn >= 0) existingNames += cursor.getString(nameColumn)
                }
            }

            // Keep Sync OFF downloads out of gallery/media scans. Marker creation is
            // best-effort because some document providers disallow dot-files.
            if (".nomedia" !in existingNames) {
                runCatching {
                    DocumentsContract.createDocument(
                        resolver, treeDocumentUri, "application/octet-stream", ".nomedia"
                    )
                }
            }

            val uniqueName = uniqueNameFromSet(safeName, existingNames)
            createdUri = DocumentsContract.createDocument(
                resolver, treeDocumentUri, mimeType, uniqueName
            ) ?: throw IOException("Could not create the file in the selected Video downloader folder")

            val output = resolver.openOutputStream(createdUri, "w")
                ?: throw IOException("Could not open the selected download folder")
            FileInputStream(sourceFile).use { input ->
                output.use { stream ->
                    input.copyTo(stream)
                    stream.flush()
                }
            }
            sourceFile.delete()
            return createdUri.toString()
        } catch (e: Exception) {
            createdUri?.let { runCatching { DocumentsContract.deleteDocument(resolver, it) } }
            if (e is AppError) throw e
            throw AppError.FileWriteError(
                e.message ?: "The selected Video downloader folder is no longer accessible"
            )
        }
    }

    private fun uniqueNameFromSet(requestedName: String, existingNames: Set<String>): String {
        if (requestedName !in existingNames) return requestedName
        val dot = requestedName.lastIndexOf('.')
        val base = if (dot > 0) requestedName.substring(0, dot) else requestedName
        val extension = if (dot > 0) requestedName.substring(dot) else ""
        for (index in 1..9999) {
            val candidate = "$base ($index)$extension"
            if (candidate !in existingNames) return candidate
        }
        return "${System.currentTimeMillis()}_$requestedName"
    }

    private fun saveToPublicRootFolder(
        sourceFile: File,
        safeName: String,
        requestedPath: String?
    ): String {
        val storageRoot = Environment.getExternalStorageDirectory().canonicalFile
        val requested = requestedPath?.trim()?.takeIf { it.isNotBlank() }
        val rootFolder = if (requested == null ||
            requested.equals("/storage/emulated/0/Download/VideoDownloader", true) ||
            requested.equals("/storage/emulated/0/Download/Video Downloader", true)) {
            File(storageRoot, "Video downloader")
        } else {
            val candidate = File(requested).canonicalFile
            // Keep custom destinations inside shared internal storage.
            if (candidate.path.startsWith(storageRoot.path + File.separator)) candidate
            else File(storageRoot, "Video downloader")
        }
        val directory = ensureDirectory(rootFolder)
        // Suppress gallery indexing while Sync to gallery is OFF.
        runCatching { File(directory, ".nomedia").createNewFile() }
        val destination = uniqueFile(directory, safeName)
        val staging = File(directory, ".${destination.name}.pending")

        try {
            if (staging.exists() && !staging.delete()) {
                throw IOException("Could not clear an earlier staging file")
            }
            FileInputStream(sourceFile).use { input ->
                FileOutputStream(staging).use { output ->
                    input.copyTo(output)
                    output.fd.sync()
                }
            }
            if (!staging.renameTo(destination)) {
                staging.copyTo(destination, overwrite = false)
                staging.delete()
            }
            if (!destination.isFile || destination.length() != sourceFile.length()) {
                destination.delete()
                throw IOException("Saved file size does not match the source")
            }
            sourceFile.delete()
            return Uri.fromFile(destination).toString()
        } catch (e: Exception) {
            staging.delete()
            throw e
        }
    }

    private fun saveToPrivateStorage(
        sourceFile: File,
        safeName: String
    ): String {
        val privateDir = ensureDirectory(File(appContext.filesDir, "completed"))
        val destination = uniqueFile(privateDir, safeName)
        val staging = File(privateDir, ".${destination.name}.pending")

        try {
            if (staging.exists() && !staging.delete()) {
                throw IOException("Could not clear an earlier staging file")
            }

            FileInputStream(sourceFile).use { input ->
                FileOutputStream(staging).use { output ->
                    input.copyTo(output)
                    output.fd.sync()
                }
            }

            if (!staging.renameTo(destination)) {
                // Rename can fail on some filesystems; copy as a safe fallback.
                staging.copyTo(destination, overwrite = false)
                staging.delete()
            }

            if (!destination.isFile || destination.length() != sourceFile.length()) {
                destination.delete()
                throw IOException("Saved file size does not match the source")
            }

            // Delete the source only after a successful save.
            sourceFile.delete()
            return Uri.fromFile(destination).toString()
        } catch (e: Exception) {
            staging.delete()
            if (e is AppError) throw e
            throw AppError.FileWriteError(e.message ?: "Could not save private media")
        }
    }

    private fun saveToMediaStore(
        sourceFile: File,
        safeName: String,
        mimeType: String,
        requestedRelativePath: String,
        collectionOverride: Uri? = null
    ): String {
        val isAudio = mimeType.startsWith("audio/", ignoreCase = true)
        val isImage = mimeType.startsWith("image/", ignoreCase = true)

        val collectionUri = collectionOverride ?: when {
            isAudio -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            } else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            isImage -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            } else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            else -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            } else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        }

        // The user's selected folder now controls the MediaStore destination on Android 10+.
        // Older Android versions retain MediaStore's standard public collection behavior.
        val relativePath = requestedRelativePath.ifBlank {
            when {
                isAudio -> "${Environment.DIRECTORY_MUSIC}/VideoDownloader/"
                isImage -> "${Environment.DIRECTORY_PICTURES}/VideoDownloader/"
                else -> "${Environment.DIRECTORY_DCIM}/Video downloader/"
            }
        }

        val uniqueName = uniqueMediaStoreName(
            collectionUri = collectionUri,
            requestedName = safeName,
            relativePath = relativePath
        )

        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, uniqueName)
            put(MediaStore.MediaColumns.MIME_TYPE, mimeType)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.MediaColumns.RELATIVE_PATH, relativePath)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
        }

        val itemUri = appContext.contentResolver.insert(collectionUri, values)
            ?: throw AppError.FileWriteError("Failed to create MediaStore record")

        try {
            val outputStream = appContext.contentResolver.openOutputStream(itemUri, "w")
                ?: throw IOException("Could not open the MediaStore output stream")

            FileInputStream(sourceFile).use { input ->
                outputStream.use { output ->
                    input.copyTo(output)
                    output.flush()
                }
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val publishValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.IS_PENDING, 0)
                }

                val updatedRows = appContext.contentResolver.update(
                    itemUri,
                    publishValues,
                    null,
                    null
                )

                if (updatedRows <= 0) {
                    throw IOException("Could not publish the saved media")
                }
            }

            // Keep the source if deletion fails; the completed copy is valid.
            sourceFile.delete()
            return itemUri.toString()
        } catch (e: Exception) {
            // Remove partial/unpublished media so it is not shown as a finished item.
            try {
                appContext.contentResolver.delete(itemUri, null, null)
            } catch (_: Exception) {
                // Best-effort cleanup.
            }

            if (e is AppError) throw e
            throw AppError.FileWriteError(e.message ?: "Could not save media to MediaStore")
        }
    }

    private fun uniqueMediaStoreName(
        collectionUri: Uri,
        requestedName: String,
        relativePath: String
    ): String {
        if (!mediaStoreNameExists(collectionUri, requestedName, relativePath)) {
            return requestedName
        }

        val dotIndex = requestedName.lastIndexOf('.')
        val base = if (dotIndex > 0) requestedName.substring(0, dotIndex) else requestedName
        val extension = if (dotIndex > 0) requestedName.substring(dotIndex) else ""

        for (counter in 1..9999) {
            val candidate = "$base ($counter)$extension"

            if (!mediaStoreNameExists(collectionUri, candidate, relativePath)) {
                return candidate
            }
        }

        return "${System.currentTimeMillis()}_$requestedName"
    }

    private fun mediaStoreNameExists(
        collectionUri: Uri,
        displayName: String,
        relativePath: String
    ): Boolean {
        val projection = arrayOf(MediaStore.MediaColumns.DISPLAY_NAME)
        val selection: String
        val selectionArgs: Array<String>

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            selection =
                "${MediaStore.MediaColumns.DISPLAY_NAME} = ? AND ${MediaStore.MediaColumns.RELATIVE_PATH} = ?"
            selectionArgs = arrayOf(displayName, relativePath)
        } else {
            selection = "${MediaStore.MediaColumns.DISPLAY_NAME} = ?"
            selectionArgs = arrayOf(displayName)
        }

        var cursor: Cursor? = null

        return try {
            cursor = appContext.contentResolver.query(
                collectionUri,
                projection,
                selection,
                selectionArgs,
                null
            )
            cursor?.use { it.moveToFirst() } ?: false
        } catch (_: Exception) {
            // If querying is unavailable, let MediaStore handle the insert.
            false
        } finally {
            try {
                cursor?.close()
            } catch (_: Exception) {
                // Ignore close errors.
            }
        }
    }

    private fun uniqueFile(directory: File, desiredName: String): File {
        var candidate = File(directory, desiredName)
        if (!candidate.exists()) return candidate

        val dotIndex = desiredName.lastIndexOf('.')
        val base = if (dotIndex > 0) desiredName.substring(0, dotIndex) else desiredName
        val extension = if (dotIndex > 0) desiredName.substring(dotIndex) else ""

        for (counter in 1..9999) {
            candidate = File(directory, "$base ($counter)$extension")
            if (!candidate.exists()) return candidate
        }

        return File(directory, "${System.currentTimeMillis()}_$desiredName")
    }

    private fun ensureDirectory(directory: File): File {
        if (directory.isDirectory) return directory

        if (!directory.mkdirs() && !directory.isDirectory) {
            throw AppError.FileWriteError(
                "Could not create directory: ${directory.name}"
            )
        }

        return directory
    }

    private fun sanitizeTaskId(taskId: String): String {
        return taskId
            .replace(Regex("[^A-Za-z0-9_-]"), "_")
            .take(80)
            .ifBlank { "download_${System.currentTimeMillis()}" }
    }

    /**
     * Renames a completed media file without moving it to another directory.
     * Returns the URI that should be stored in Room after the rename.
     */
    fun renameMedia(uriString: String, requestedName: String, mimeType: String?): Pair<String, String> {
        if (uriString.isBlank()) throw IOException("The saved file location is missing")

        val fallbackExtension = SafeFileName.getExtensionFromMime(mimeType)
        val safeName = SafeFileName.sanitize(requestedName, fallbackExtension)
        val uri = Uri.parse(uriString)
        val resolver = appContext.contentResolver

        return when (uri.scheme) {
            "file" -> {
                val currentFile = File(uri.path ?: throw IOException("Invalid saved file path"))
                if (!currentFile.exists() || !currentFile.isFile) {
                    throw IOException("The saved file could not be found")
                }
                val parent = currentFile.parentFile ?: throw IOException("The saved file folder is unavailable")
                val destination = File(parent, safeName)
                if (currentFile.name == safeName) {
                    uri.toString() to currentFile.name
                } else {
                    if (destination.exists()) throw IOException("A file with this name already exists")
                    if (!currentFile.renameTo(destination)) {
                        throw IOException("Android could not rename this file. Check storage access and try again")
                    }
                    Uri.fromFile(destination).toString() to destination.name
                }
            }
            "content" -> {
                if (queryMediaDisplayName(uri, "") == safeName) {
                    return uri.toString() to safeName
                }
                // SAF document providers can return a replacement URI after a rename.
                if (runCatching { DocumentsContract.isDocumentUri(appContext, uri) }.getOrDefault(false)) {
                    val renamedDocument = runCatching {
                        DocumentsContract.renameDocument(resolver, uri, safeName)
                    }.getOrNull()
                    if (renamedDocument != null) {
                        val actualName = queryMediaDisplayName(renamedDocument, safeName)
                        return renamedDocument.toString() to actualName
                    }
                }

                // MediaStore-owned downloads are renamed by updating DISPLAY_NAME.
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, safeName)
                }
                val updatedRows = runCatching {
                    resolver.update(uri, values, null, null)
                }.getOrDefault(0)
                if (updatedRows > 0) {
                    uri.toString() to queryMediaDisplayName(uri, safeName)
                } else {
                    throw IOException("Android could not rename this saved file. The storage provider may be read-only")
                }
            }
            else -> throw IOException("This file location does not support renaming")
        }
    }

    private fun queryMediaDisplayName(uri: Uri, fallback: String): String {
        return runCatching {
            appContext.contentResolver.query(
                uri,
                arrayOf(OpenableColumns.DISPLAY_NAME),
                null,
                null,
                null
            )?.use { cursor ->
                val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (cursor.moveToFirst() && index >= 0) cursor.getString(index) else null
            }
        }.getOrNull()?.takeIf { it.isNotBlank() } ?: fallback
    }

    /**
     * Returns a URI that can be shared outside the app.
     * File URIs are wrapped through FileProvider.
     */
    fun getShareableUri(uriString: String): Uri? {
        return try {
            val uri = Uri.parse(uriString)

            when (uri.scheme) {
                "content" -> uri

                "file" -> {
                    val file = File(uri.path ?: return null)

                    FileProvider.getUriForFile(
                        appContext,
                        "${appContext.packageName}.fileprovider",
                        file
                    )
                }

                else -> null
            }
        } catch (_: Exception) {
            null
        }
    }

    /** Deletes a previously saved media item, using its stored URI. */
    fun deleteMedia(uriString: String?): Boolean {
        if (uriString.isNullOrBlank()) return false

        return try {
            val uri = Uri.parse(uriString)

            when (uri.scheme) {
                "content" -> {
                    val documentDeleted = runCatching {
                        if (DocumentsContract.isDocumentUri(appContext, uri)) {
                            DocumentsContract.deleteDocument(appContext.contentResolver, uri)
                        } else false
                    }.getOrDefault(false)
                    documentDeleted || appContext.contentResolver.delete(uri, null, null) > 0
                }
                "file" -> File(uri.path ?: return false).delete()
                else -> false
            }
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Removes only temporary files that do not belong to known download tasks.
     * Include QUEUED, DOWNLOADING, PAUSED, WAITING_FOR_NETWORK, and retryable FAILED
     * task IDs in retainedTaskIds so resumable data is preserved.
     */
    fun clearOrphanedTempFiles(retainedTaskIds: Set<String>) {
        val retainedIds = retainedTaskIds.map(::sanitizeTaskId).toSet()
        val downloadsDir = File(appContext.cacheDir, "downloads")
        val hlsDir = File(appContext.cacheDir, "hls_temp")

        downloadsDir.listFiles()?.forEach { file ->
            val belongsToRetainedTask = retainedIds.any { id ->
                file.name == "${id}.part" || file.name.startsWith("${id}_")
            }

            if (!belongsToRetainedTask) file.deleteRecursively()
        }

        hlsDir.listFiles()?.forEach { taskDir ->
            if (taskDir.name !in retainedIds) {
                taskDir.deleteRecursively()
            }
        }
    }

    /**
     * The old no-argument cleanup could delete resumable downloads.
     * It is now intentionally non-destructive.
     */
    @Deprecated(
        message = "Unsafe for resumable downloads; use clearOrphanedTempFiles(retainedTaskIds)",
        replaceWith = ReplaceWith("clearOrphanedTempFiles(retainedTaskIds)")
    )
    fun clearTempFiles() {
        // Intentionally do nothing: deleting all temporary files could destroy partial downloads.
    }
}
