package com.mahabub.downloder

import android.Manifest
import android.content.Intent
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.tween
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.mahabub.downloder.ui.components.AnimatedBrandBottomNavigation
import com.mahabub.downloder.ui.components.LocalBottomBarContentPadding
import com.mahabub.downloder.ui.screens.AboutPrivacyScreen
import com.mahabub.downloder.ui.screens.BookmarksScreen
import com.mahabub.downloder.ui.screens.BrowserHistoryScreen
import com.mahabub.downloder.ui.screens.CompletedScreen
import com.mahabub.downloder.ui.screens.CustomizeHomeScreen
import com.mahabub.downloder.ui.screens.DownloadDetailsScreen
import com.mahabub.downloder.ui.screens.DownloadsScreen
import com.mahabub.downloder.ui.screens.HomeBrowserScreen
import com.mahabub.downloder.ui.screens.OfflinePlayerScreen
import com.mahabub.downloder.ui.screens.SettingsScreen
import com.mahabub.downloder.ui.theme.VideoDownloaderTheme
import com.mahabub.downloder.ui.viewmodel.BrowserViewModel
import com.mahabub.downloder.ui.viewmodel.CompletedViewModel
import com.mahabub.downloder.ui.viewmodel.DownloadsViewModel
import com.mahabub.downloder.ui.viewmodel.HistoryBookmarksViewModel
import com.mahabub.downloder.ui.viewmodel.SettingsViewModel
import java.net.URLDecoder
import java.net.URLEncoder

sealed class Screen(val route: String, val titleRes: Int? = null) {
    data object Browser : Screen("browser", R.string.nav_tab)
    data object Downloads : Screen("downloads", R.string.nav_progress)
    data object Completed : Screen("completed", R.string.nav_finished)
    data object Settings : Screen("settings", R.string.nav_settings)
    data object CustomizeHome : Screen("customize_home")
    data object History : Screen("history")
    data object Bookmarks : Screen("bookmarks")
    data object Player : Screen("player/{mediaUri}/{mediaTitle}") {
        fun createRoute(uri: String, title: String): String {
            val encodedUri = URLEncoder.encode(uri, "UTF-8")
            val encodedTitle = URLEncoder.encode(title, "UTF-8")
            return "player/$encodedUri/$encodedTitle"
        }
    }
    data object Details : Screen("details/{taskId}") {
        fun createRoute(taskId: String): String = "details/$taskId"
    }
    data object About : Screen("about")
}

private val PRIMARY_TAB_ROUTES = setOf(
    Screen.Browser.route,
    Screen.Downloads.route,
    Screen.Completed.route,
    Screen.Settings.route
)

class MainActivity : ComponentActivity() {

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(AppLocaleManager.wrap(newBase))
    }

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ -> }

    private var initialSharedUrl: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Legacy Android requires WRITE_EXTERNAL_STORAGE for the public root folder.
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissionLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }

        // Check POST_NOTIFICATIONS on Android 13+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        handleShareIntent(intent)

        val app = application as VideoDownloaderApp
        val container = app.container

        setContent {
            val settingsVm: SettingsViewModel = viewModel(factory = SettingsViewModel.Factory(container))
            val darkMode by settingsVm.darkMode.collectAsState()
            val homeAccentColor by settingsVm.homeAccentColor.collectAsState()
            val useDarkSystemBars = when (darkMode) {
                "light" -> false
                "amoled", "dark", "normal_dark" -> true
                else -> isSystemInDarkTheme()
            }

            SideEffect {
                val insetsController = WindowCompat.getInsetsController(window, window.decorView)
                insetsController.isAppearanceLightStatusBars = !useDarkSystemBars
                insetsController.isAppearanceLightNavigationBars = !useDarkSystemBars
                window.statusBarColor = android.graphics.Color.TRANSPARENT
                window.navigationBarColor = android.graphics.Color.TRANSPARENT
            }

            VideoDownloaderTheme(themeMode = darkMode, accentColor = homeAccentColor) {
                val navController = rememberNavController()
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentRoute = navBackStackEntry?.destination?.route

                val browserVm: BrowserViewModel = viewModel(factory = BrowserViewModel.Factory(container))
                val downloadsVm: DownloadsViewModel = viewModel(factory = DownloadsViewModel.Factory(container))
                val completedVm: CompletedViewModel = viewModel(factory = CompletedViewModel.Factory(container))
                val historyBookmarksVm: HistoryBookmarksViewModel = viewModel(factory = HistoryBookmarksViewModel.Factory(container))

                val activeDownloads by downloadsVm.activeDownloads.collectAsState()
                val completedDownloads by completedVm.completedDownloads.collectAsState()
                val browserUiState by browserVm.uiState.collectAsState()

                // Handle shared link if received on startup
                LaunchedEffect(initialSharedUrl) {
                    initialSharedUrl?.let { url ->
                        browserVm.analyzeExternalUrl(url)
                        navController.navigate(Screen.Browser.route) {
                            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                            launchSingleTop = true
                        }
                        initialSharedUrl = null
                    }
                }

                // Four primary destinations. Detail pages continue to use the existing back stack.
                val bottomNavItems = listOf(
                    Screen.Browser,
                    Screen.Downloads,
                    Screen.Completed,
                    Screen.Settings
                )

                val showBottomBar = currentRoute in bottomNavItems.map { it.route } &&
                    !(currentRoute == Screen.Browser.route && browserUiState.showTabsOverview)

                val navigationBarInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
                val bottomBarContentPadding = if (showBottomBar) 102.dp + navigationBarInset else 0.dp

                val rootWindowInsets = if (showBottomBar) {
                    WindowInsets.safeDrawing.only(WindowInsetsSides.Top + WindowInsetsSides.Horizontal)
                } else {
                    WindowInsets.safeDrawing
                }

                CompositionLocalProvider(
                    LocalBottomBarContentPadding provides bottomBarContentPadding
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .windowInsetsPadding(rootWindowInsets)
                    ) {
                        NavHost(
                            modifier = Modifier.fillMaxSize(),
                            navController = navController,
                            startDestination = Screen.Browser.route,
                            enterTransition = {
                                val isTabToTab = initialState.destination.route.orEmpty() in PRIMARY_TAB_ROUTES &&
                                    targetState.destination.route.orEmpty() in PRIMARY_TAB_ROUTES
                                if (isTabToTab) EnterTransition.None else fadeIn(tween(220))
                            },
                            exitTransition = {
                                val isTabToTab = initialState.destination.route.orEmpty() in PRIMARY_TAB_ROUTES &&
                                    targetState.destination.route.orEmpty() in PRIMARY_TAB_ROUTES
                                if (isTabToTab) ExitTransition.None else fadeOut(tween(180))
                            },
                            popEnterTransition = {
                                val isTabToTab = initialState.destination.route.orEmpty() in PRIMARY_TAB_ROUTES &&
                                    targetState.destination.route.orEmpty() in PRIMARY_TAB_ROUTES
                                if (isTabToTab) EnterTransition.None else fadeIn(tween(220))
                            },
                            popExitTransition = {
                                val isTabToTab = initialState.destination.route.orEmpty() in PRIMARY_TAB_ROUTES &&
                                    targetState.destination.route.orEmpty() in PRIMARY_TAB_ROUTES
                                if (isTabToTab) ExitTransition.None else fadeOut(tween(180))
                            }
                        ) {
                            composable(Screen.Browser.route) {
                                HomeBrowserScreen(
                                    container = container,
                                    viewModel = browserVm,
                                    onNavigateToHistory = { navController.navigate(Screen.History.route) },
                                    onNavigateToBookmarks = { navController.navigate(Screen.Bookmarks.route) },
                                    onNavigateToSettings = { navController.navigate(Screen.Settings.route) }
                                )
                            }

                            composable(Screen.Downloads.route) {
                                DownloadsScreen(
                                    viewModel = downloadsVm,
                                    entryAnimationKey = currentRoute.orEmpty(),
                                    isCurrentDestination = currentRoute == Screen.Downloads.route,
                                    onNavigateToDetails = { taskId ->
                                        navController.navigate(Screen.Details.createRoute(taskId))
                                    },
                                    onOpenBrowserUrl = { url ->
                                        browserVm.loadUrl(url)
                                        navController.navigate(Screen.Browser.route) {
                                            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                            launchSingleTop = true
                                        }
                                    }
                                )
                            }

                            composable(Screen.Completed.route) {
                                CompletedScreen(
                                    viewModel = completedVm,
                                    onPlayMedia = { uri, title ->
                                        navController.navigate(Screen.Player.createRoute(uri, title))
                                    },
                                    onNavigateToDetails = { taskId ->
                                        navController.navigate(Screen.Details.createRoute(taskId))
                                    }
                                )
                            }

                            composable(Screen.Settings.route) {
                                SettingsScreen(
                                    viewModel = settingsVm,
                                    entryAnimationKey = currentRoute.orEmpty(),
                                    isCurrentDestination = currentRoute == Screen.Settings.route,
                                    onNavigateBack = { navController.popBackStack() },
                                    onNavigateToAbout = { navController.navigate(Screen.About.route) },
                                    onNavigateToCustomizeHome = { navController.navigate(Screen.CustomizeHome.route) }
                                )
                            }

                            composable(Screen.CustomizeHome.route) {
                                CustomizeHomeScreen(
                                    viewModel = settingsVm,
                                    onNavigateBack = { navController.popBackStack() }
                                )
                            }

                            composable(Screen.History.route) {
                                BrowserHistoryScreen(
                                    viewModel = historyBookmarksVm,
                                    onSelectUrl = { url ->
                                        browserVm.loadUrl(url)
                                        navController.popBackStack()
                                    },
                                    onBack = { navController.popBackStack() }
                                )
                            }

                            composable(Screen.Bookmarks.route) {
                                BookmarksScreen(
                                    viewModel = historyBookmarksVm,
                                    onSelectUrl = { url ->
                                        browserVm.loadUrl(url)
                                        navController.popBackStack()
                                    },
                                    onBack = { navController.popBackStack() }
                                )
                            }

                            composable(
                                route = Screen.Player.route,
                                arguments = listOf(
                                    navArgument("mediaUri") { type = NavType.StringType },
                                    navArgument("mediaTitle") { type = NavType.StringType }
                                )
                            ) { backStackEntry ->
                                val encodedUri = backStackEntry.arguments?.getString("mediaUri") ?: ""
                                val encodedTitle = backStackEntry.arguments?.getString("mediaTitle") ?: ""
                                val decodedUri = try { URLDecoder.decode(encodedUri, "UTF-8") } catch (_: Exception) { encodedUri }
                                val decodedTitle = try { URLDecoder.decode(encodedTitle, "UTF-8") } catch (_: Exception) { encodedTitle }

                                OfflinePlayerScreen(
                                    mediaUriString = decodedUri,
                                    mediaTitle = decodedTitle,
                                    onBack = { navController.popBackStack() }
                                )
                            }

                            composable(
                                route = Screen.Details.route,
                                arguments = listOf(navArgument("taskId") { type = NavType.StringType })
                            ) { backStackEntry ->
                                val taskId = backStackEntry.arguments?.getString("taskId") ?: ""
                                DownloadDetailsScreen(
                                    container = container,
                                    taskId = taskId,
                                    onBack = { navController.popBackStack() }
                                )
                            }

                            composable(Screen.About.route) {
                                AboutPrivacyScreen(onBack = { navController.popBackStack() })
                            }
                        }

                        if (showBottomBar) {
                            AnimatedBrandBottomNavigation(
                                modifier = Modifier.align(Alignment.BottomCenter),
                                selectedRoute = currentRoute ?: Screen.Browser.route,
                                activeDownloadCount = activeDownloads.size,
                                finishedCount = completedDownloads.size,
                                onBrowse = {
                                    if (currentRoute != Screen.Browser.route) {
                                        navController.navigate(Screen.Browser.route) {
                                            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    }
                                },
                                onProgress = {
                                    if (currentRoute != Screen.Downloads.route) {
                                        navController.navigate(Screen.Downloads.route) {
                                            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    }
                                },
                                onFinished = {
                                    if (currentRoute != Screen.Completed.route) {
                                        navController.navigate(Screen.Completed.route) {
                                            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    }
                                },
                                onSettings = {
                                    if (currentRoute != Screen.Settings.route) {
                                        navController.navigate(Screen.Settings.route) {
                                            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleShareIntent(intent)
    }

    private fun handleShareIntent(intent: Intent?) {
        if (intent?.action == Intent.ACTION_SEND && intent.type == "text/plain") {
            val sharedText = intent.getStringExtra(Intent.EXTRA_TEXT)
            if (!sharedText.isNullOrBlank()) {
                val url = extractUrlFromText(sharedText)
                if (!url.isNullOrBlank()) {
                    initialSharedUrl = url
                }
            }
        }
    }

    private fun extractUrlFromText(text: String): String? {
        val parts = text.split("\\s+".toRegex())
        for (part in parts) {
            if (part.startsWith("http://") || part.startsWith("https://")) {
                return part
            }
        }
        return null
    }
}

