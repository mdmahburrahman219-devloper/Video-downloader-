package com.mahabub.downloder.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Public
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

/** Reusable website favicon with a neutral globe fallback; no fabricated site logos. */
@Composable
fun WebsiteFavicon(
    url: String,
    size: Dp = 42.dp,
    modifier: Modifier = Modifier
) {
    val host = remember(url) {
        runCatching {
            val normalized = if (url.startsWith("http://") || url.startsWith("https://")) url else "https://$url"
            java.net.URI(normalized).host?.lowercase()?.removePrefix("www.")
        }.getOrNull()
    }
    val faviconUrl = remember(host) {
        host?.let {
            val encoded = URLEncoder.encode(it, StandardCharsets.UTF_8.toString())
            "https://www.google.com/s2/favicons?domain=$encoded&sz=128"
        }
    }
    var failed by remember(faviconUrl) { mutableStateOf(false) }

    Box(
        modifier = modifier.size(size).clip(CircleShape)
            .background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center
    ) {
        if (faviconUrl != null && !failed) {
            AsyncImage(
                model = faviconUrl,
                contentDescription = "Website icon",
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize().padding(size * 0.18f),
                onError = { failed = true }
            )
        } else {
            Icon(
                imageVector = Icons.Default.Public,
                contentDescription = "Website icon unavailable",
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(size * 0.48f)
            )
        }
    }
}
