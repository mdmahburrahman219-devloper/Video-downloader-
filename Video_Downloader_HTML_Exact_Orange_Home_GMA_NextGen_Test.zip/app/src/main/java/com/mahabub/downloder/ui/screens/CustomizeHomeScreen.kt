package com.mahabub.downloder.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Public
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mahabub.downloder.preferences.HomeShortcut
import com.mahabub.downloder.ui.components.WebsiteFavicon
import com.mahabub.downloder.ui.viewmodel.SettingsViewModel
import java.net.URI

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun CustomizeHomeScreen(
    viewModel: SettingsViewModel,
    onNavigateBack: () -> Unit
) {
    val shortcutsFromStore by viewModel.homeShortcuts.collectAsState()
    val showQuickAccess by viewModel.showQuickAccess.collectAsState()
    val showRecentWebsites by viewModel.showRecentWebsites.collectAsState()
    val homeBackground by viewModel.homeBackground.collectAsState()

    var shortcuts by remember { mutableStateOf(shortcutsFromStore) }
    var showAddDialog by remember { mutableStateOf(false) }
    var urlInput by remember { mutableStateOf("") }
    var validationMessage by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(shortcutsFromStore) { shortcuts = shortcutsFromStore }
    BackHandler { onNavigateBack() }

    fun saveShortcuts(updated: List<HomeShortcut>) {
        shortcuts = updated
        viewModel.setHomeShortcuts(updated)
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Customize Home", fontWeight = FontWeight.SemiBold)
                        Text("Personalize your browser start page", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            HomeCustomizationCard(title = "Home sections", subtitle = "Choose which sections appear on the start page") {
                HomeToggleRow(
                    title = "Social Apps",
                    subtitle = "Show the supported platform shortcuts on Home",
                    checked = showQuickAccess,
                    onCheckedChange = viewModel::setShowQuickAccess
                )
                Divider(color = MaterialTheme.colorScheme.outlineVariant)
                HomeToggleRow(
                    title = "Recently visited",
                    subtitle = "Show websites from your real browsing history",
                    checked = showRecentWebsites,
                    onCheckedChange = viewModel::setShowRecentWebsites
                )
            }

            HomeCustomizationCard(title = "Home background", subtitle = "This changes the Home screen only") {
                val options = listOf(
                    "light" to "White",
                    "ice" to "Ice",
                    "lavender" to "Lavender",
                    "warm" to "Warm"
                )
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.fillMaxWidth()) {
                    options.forEach { (id, label) ->
                        FilterChip(
                            selected = homeBackground == id,
                            onClick = { viewModel.setHomeBackground(id) },
                            label = { Text(label, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    listOf(
                        "light" to Color(0xFFFFFFFF),
                        "ice" to Color(0xFFF1F6FF),
                        "lavender" to Color(0xFFF5F0FF),
                        "warm" to Color(0xFFFFF8F0)
                    ).forEach { (id, color) ->
                        Box(
                            modifier = Modifier.size(32.dp).clip(CircleShape)
                                .background(color)
                                .border(
                                    width = if (homeBackground == id) 2.dp else 1.dp,
                                    color = if (homeBackground == id) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                                    shape = CircleShape
                                )
                                .clickable { viewModel.setHomeBackground(id) }
                        )
                    }
                }
            }

            HomeCustomizationCard(
                title = "Quick Access websites",
                subtitle = "Add a website URL or remove a shortcut. The name and favicon are detected automatically.",
                trailing = {
                    IconButton(onClick = { urlInput = ""; validationMessage = null; showAddDialog = true }) {
                        Icon(Icons.Default.Add, contentDescription = "Add website", tint = MaterialTheme.colorScheme.primary)
                    }
                }
            ) {
                if (shortcuts.isEmpty()) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 18.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.Public, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(34.dp))
                        Spacer(Modifier.height(8.dp))
                        Text("No quick links yet", color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Medium)
                        Text("Add a website using the + button", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                    }
                } else {
                    shortcuts.forEachIndexed { index, shortcut ->
                        if (index > 0) Divider(color = MaterialTheme.colorScheme.outlineVariant)
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 9.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(11.dp)
                        ) {
                            WebsiteFavicon(url = shortcut.url, size = 42.dp)
                            Column(modifier = Modifier.weight(1f)) {
                                Text(shortcut.name, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(shortcutHost(shortcut.url), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            IconButton(onClick = { saveShortcuts(shortcuts.filterNot { it.url == shortcut.url }) }) {
                                Icon(Icons.Default.Close, contentDescription = "Remove ${shortcut.name}", tint = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }
                Text(
                    "${shortcuts.size} / 20 shortcuts",
                    modifier = Modifier.align(Alignment.End),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(Modifier.height(8.dp))
        }
    }

    if (showAddDialog) {
        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("Add Quick Link", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Enter a website address. Its display name and icon will be added automatically.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                    OutlinedTextField(
                        value = urlInput,
                        onValueChange = { urlInput = it.take(2048); validationMessage = null },
                        label = { Text("Website URL") },
                        placeholder = { Text("example.com") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    validationMessage?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 12.sp) }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val candidate = makeShortcut(urlInput)
                    when {
                        candidate == null -> validationMessage = "Enter a valid website address."
                        shortcuts.size >= 20 -> validationMessage = "You can add up to 20 shortcuts."
                        shortcuts.any { shortcutHost(it.url) == shortcutHost(candidate.url) } -> validationMessage = "This website is already in Quick Access."
                        else -> {
                            saveShortcuts(shortcuts + candidate)
                            showAddDialog = false
                        }
                    }
                }) { Text("Add", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold) }
            },
            dismissButton = { TextButton(onClick = { showAddDialog = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun HomeCustomizationCard(
    title: String,
    subtitle: String,
    trailing: (@Composable () -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(title, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                    Spacer(Modifier.height(3.dp))
                    Text(subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                trailing?.invoke()
            }
            Spacer(Modifier.height(12.dp))
            content()
        }
    }
}

@Composable
private fun HomeToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
            Text(title, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
            Text(subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

private fun makeShortcut(raw: String): HomeShortcut? {
    val trimmed = raw.trim()
    if (trimmed.isBlank() || trimmed.any { it.isWhitespace() }) return null
    val normalized = if (trimmed.startsWith("https://", true) || trimmed.startsWith("http://", true)) trimmed else "https://$trimmed"
    val uri = runCatching { URI(normalized) }.getOrNull() ?: return null
    if (uri.scheme?.lowercase() !in listOf("http", "https") || uri.host.isNullOrBlank()) return null
    val host = uri.host.lowercase().trimEnd('.')
        .removePrefix("www.").removePrefix("m.").removePrefix("mobile.")
    val label = host.substringBefore('.').replace('-', ' ').split(' ').filter { it.isNotBlank() }
        .joinToString(" ") { word -> word.replaceFirstChar { it.uppercase() } }
        .ifBlank { host }
    return HomeShortcut(label.take(48), normalized)
}

private fun shortcutHost(url: String): String =
    runCatching {
        URI(url).host?.lowercase()?.trimEnd('.')?.removePrefix("www.")?.removePrefix("m.")?.removePrefix("mobile.") ?: url.lowercase()
    }.getOrDefault(url.lowercase())
