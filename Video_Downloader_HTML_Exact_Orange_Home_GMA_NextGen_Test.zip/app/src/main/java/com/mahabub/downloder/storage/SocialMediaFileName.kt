package com.mahabub.downloder.storage

import com.mahabub.downloder.model.MediaCandidate
import com.mahabub.downloder.model.PlatformSource
import com.mahabub.downloder.model.StreamType
import java.security.SecureRandom
import java.util.Locale

/**
 * Short, filesystem-safe default names for supported social-platform video downloads.
 * TikTok intentionally retains its existing title-based naming behavior.
 */
object SocialMediaFileName {
    private val secureRandom = SecureRandom()

    private val platformPrefixes = mapOf(
        PlatformSource.INSTAGRAM to "instagram",
        PlatformSource.FACEBOOK to "facebook",
        PlatformSource.TWITTER_X to "twitter_x",
        PlatformSource.PINTEREST to "pinterest",
        PlatformSource.REDDIT to "reddit",
        PlatformSource.THREADS to "threads"
    )

    /** Returns null when this candidate should keep the app's existing filename behavior. */
    fun forVideo(candidate: MediaCandidate): String? {
        val prefix = platformPrefixes[candidate.sourcePlatform] ?: return null
        val mime = candidate.mimeType
            ?.substringBefore(';')
            ?.trim()
            ?.lowercase(Locale.ROOT)
            .orEmpty()

        // Do not rename social images or audio as video files. HLS candidates are treated as
        // video because the app's HLS output is saved as a single MP4-compatible media file.
        val mediaPath = runCatching { java.net.URI(candidate.url).path.orEmpty().lowercase(Locale.ROOT) }
            .getOrDefault("")
        val pathLooksLikeVideo = listOf(".mp4", ".m4v", ".webm", ".mov", ".3gp", ".mkv", ".ts")
            .any(mediaPath::endsWith)
        val mimeIsGenericBinary = mime == "application/octet-stream" || mime == "application/mp4"
        val isVideo = candidate.streamType == StreamType.HLS ||
            mime.startsWith("video/") ||
            (candidate.streamType == StreamType.PROGRESSIVE &&
                (mime.isBlank() || mimeIsGenericBinary || pathLooksLikeVideo))
        if (!isVideo || mime.startsWith("image/") || mime.startsWith("audio/")) return null

        val extension = if (candidate.streamType == StreamType.HLS) {
            "mp4"
        } else {
            SafeFileName.getExtensionFromMime(mime.ifBlank { "video/mp4" })
        }
        return "${prefix}_${randomThirteenDigitNumber()}.$extension"
    }

    private fun randomThirteenDigitNumber(): String = synchronized(secureRandom) {
        buildString(capacity = 13) {
            append(secureRandom.nextInt(9) + 1)
            repeat(12) { append(secureRandom.nextInt(10)) }
        }
    }
}
