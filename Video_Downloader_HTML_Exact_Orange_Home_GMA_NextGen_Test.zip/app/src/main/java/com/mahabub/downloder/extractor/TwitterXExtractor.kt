package com.mahabub.downloder.extractor

import com.mahabub.downloder.extractor.ExtractorUtils.unescapeHtml
import com.mahabub.downloder.model.MediaCandidate
import com.mahabub.downloder.model.PlatformSource
import com.mahabub.downloder.model.StreamType
import okhttp3.OkHttpClient
import java.util.regex.Pattern

class TwitterXExtractor(private val okHttpClient: OkHttpClient) : PlatformExtractor {

    override val platform: PlatformSource = PlatformSource.TWITTER_X

    override fun matches(url: String): Boolean {
        val lower = url.lowercase()
        return lower.contains("twitter.com") || lower.contains("x.com")
    }

    override suspend fun extract(url: String): MediaCandidate? {
        return try {
            val request = ExtractorUtils.buildRequest(url)
            val response = okHttpClient.newCall(request).execute()
            if (!response.isSuccessful) return null

            val html = response.body?.string() ?: return null

            var videoUrl = ExtractorUtils.extractMetaTag(html, "og:video:url")
                ?: ExtractorUtils.extractMetaTag(html, "twitter:player:stream")
                ?: ExtractorUtils.extractMetaTag(html, "og:video")

            if (videoUrl.isNullOrBlank()) {
                // Match video.twimg.com direct mp4 links
                val twimgPattern = Pattern.compile("(https?://video\\.twimg\\.com/[^\"'\\s]+\\.mp4)")
                val matcher = twimgPattern.matcher(html)
                if (matcher.find()) {
                    videoUrl = matcher.group(1)?.unescapeHtml()
                }
            }

            if (videoUrl.isNullOrBlank()) return null

            val title = ExtractorUtils.extractTitle(html) ?: "Twitter / X Post"
            val poster = ExtractorUtils.extractMetaTag(html, "og:image")
            val isHls = videoUrl.contains(".m3u8")

            MediaCandidate(
                id = ExtractorUtils.generateMediaId(),
                url = videoUrl,
                title = title,
                mimeType = if (isHls) "application/vnd.apple.mpegurl" else "video/mp4",
                sourcePageUrl = url,
                sourcePlatform = PlatformSource.TWITTER_X,
                streamType = if (isHls) StreamType.HLS else StreamType.PROGRESSIVE,
                thumbnailUrl = poster,
                isDirectDownload = !isHls
            )
        } catch (_: Exception) {
            null
        }
    }
}
