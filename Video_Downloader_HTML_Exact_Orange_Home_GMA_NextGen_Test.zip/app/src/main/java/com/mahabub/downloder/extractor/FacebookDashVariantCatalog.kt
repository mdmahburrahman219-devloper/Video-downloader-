package com.mahabub.downloder.extractor

import android.net.Uri
import androidx.media3.common.C
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.dash.manifest.DashManifestParser
import com.mahabub.downloder.model.MediaCandidate
import com.mahabub.downloder.model.MediaDetectionSource
import com.mahabub.downloder.model.PlatformSource
import com.mahabub.downloder.model.StreamType
import java.io.ByteArrayInputStream

/**
 * Reads the non-DRM, static single-period DASH catalog that Facebook exposes in its own page
 * response. It does not make network requests. Representation indexes match the flattened order
 * used by HlsDownloader.downloadDash().
 */
@OptIn(UnstableApi::class)
internal object FacebookDashVariantCatalog {
    data class Option(
        val representationIndex: Int,
        val qualityLabel: String,
        val width: Int,
        val height: Int,
        val bitrate: Long,
        val estimatedSizeBytes: Long?,
        val isAudioOnly: Boolean,
        val audioRepresentationIndex: Int? = null
    )

    fun parse(manifestText: String, manifestBaseUrl: String, durationSeconds: Double): List<Option> {
        if (manifestText.isBlank() || manifestText.length > 1_500_000) return emptyList()
        if (Regex("(?i)<!DOCTYPE|<!ENTITY|<ContentProtection\\b").containsMatchIn(manifestText)) return emptyList()
        return runCatching {
            val manifest = DashManifestParser().parse(
                Uri.parse(manifestBaseUrl),
                ByteArrayInputStream(manifestText.toByteArray(Charsets.UTF_8))
            )
            if (manifest.dynamic || manifest.periodCount != 1) return@runCatching emptyList()
            val period = manifest.getPeriod(0)
            val video = period.adaptationSets
                .filter { it.type == C.TRACK_TYPE_VIDEO }
                .flatMap { it.representations }
                .filter { it.format.sampleMimeType.orEmpty().startsWith("video/") }
            val audio = period.adaptationSets
                .filter { it.type == C.TRACK_TYPE_AUDIO }
                .flatMap { it.representations }
                .filter { it.format.sampleMimeType.orEmpty().startsWith("audio/") }
            if (video.isEmpty()) return@runCatching emptyList()

            val duration = durationSeconds.takeIf { it.isFinite() && it > 0.0 }
                ?: manifest.getPeriodDurationUs(0).takeIf { it > 0L && it != C.TIME_UNSET }
                    ?.div(1_000_000.0)
                ?: manifest.durationMs.takeIf { it > 0L && it != C.TIME_UNSET }?.div(1_000.0)
                ?: 0.0
            val audioIndex = audio.indices.maxByOrNull { audio[it].format.averageBitrate.coerceAtLeast(0) }
            val options = mutableListOf<Option>()
            val bestByQuality = linkedMapOf<String, Pair<Int, Option>>()
            video.forEachIndexed { index, representation ->
                val format = representation.format
                val width = format.width.coerceAtLeast(0)
                val height = format.height.coerceAtLeast(0)
                val label = height.takeIf { it > 0 }?.let { "${it}p" }
                    ?: extractQualityLabel(manifestText, format.id)
                    ?: return@forEachIndexed
                val bitrate = format.peakBitrate.takeIf { it > 0 }?.toLong()
                    ?: format.averageBitrate.takeIf { it > 0 }?.toLong() ?: 0L
                // The downloaded MP4 contains both selected tracks. Include the selected
                // audio bitrate in the estimate instead of reporting video-only bytes.
                val audioBitrateForMux = audioIndex?.let { audioRepresentationBitrate(audio[it].format) } ?: 0L
                val combinedBitrate = safeAddBitrates(bitrate, audioBitrateForMux)
                val estimate = estimateSize(combinedBitrate, duration)
                val option = Option(
                    representationIndex = index,
                    qualityLabel = label,
                    width = width,
                    height = height,
                    bitrate = bitrate,
                    estimatedSizeBytes = estimate,
                    isAudioOnly = false,
                    audioRepresentationIndex = audioIndex
                )
                val compatibility = if (format.codecs.orEmpty().startsWith("avc1", true)) 1 else 0
                val existing = bestByQuality[label]
                if (existing == null || compatibility > existing.first ||
                    (compatibility == existing.first && bitrate > existing.second.bitrate)) {
                    bestByQuality[label] = compatibility to option
                }
            }
            options += bestByQuality.values.map { it.second }
                .sortedWith(compareByDescending<Option> { it.height }.thenByDescending { it.bitrate })

            if (audioIndex != null) {
                val audioFormat = audio[audioIndex].format
                val audioBitrate = audioFormat.peakBitrate.takeIf { it > 0 }?.toLong()
                    ?: audioFormat.averageBitrate.takeIf { it > 0 }?.toLong() ?: 0L
                options += Option(
                    representationIndex = -1,
                    qualityLabel = "Audio",
                    width = 0,
                    height = 0,
                    bitrate = audioBitrate,
                    estimatedSizeBytes = estimateSize(audioBitrate, duration),
                    isAudioOnly = true,
                    audioRepresentationIndex = audioIndex
                )
            }
            options
        }.getOrDefault(emptyList())
    }

    fun toCandidate(
        option: Option,
        selectedUrl: String,
        title: String,
        sourcePageUrl: String,
        userAgent: String?,
        referer: String?,
        thumbnailUrl: String?,
        durationSeconds: Double,
        groupId: String
    ): MediaCandidate = MediaCandidate(
        id = java.util.UUID.randomUUID().toString(),
        url = selectedUrl,
        title = title,
        mimeType = "application/dash+xml",
        userAgent = userAgent,
        referer = referer,
        sourcePageUrl = sourcePageUrl,
        sourcePlatform = PlatformSource.FACEBOOK,
        streamType = StreamType.DASH,
        isDirectDownload = false,
        thumbnailUrl = thumbnailUrl,
        durationSeconds = durationSeconds.takeIf { it.isFinite() && it > 0.0 && it < 86_400.0 },
        resolution = if (option.width > 0 && option.height > 0) "${option.width}x${option.height}" else null,
        detectionSource = MediaDetectionSource.SCRIPT_RESOURCE,
        detectionConfidence = 100,
        videoGroupId = groupId,
        qualityLabel = option.qualityLabel,
        bitrate = option.bitrate.takeIf { it > 0L },
        estimatedSizeBytes = option.estimatedSizeBytes,
        sizeIsEstimated = option.estimatedSizeBytes != null
    )

    private fun extractQualityLabel(xml: String, representationId: String?): String? {
        val id = representationId?.takeIf { it.isNotBlank() } ?: return null
        val representationRegex = Regex("(?is)<Representation\\b([^>]*)>(.*?)</Representation>")
        return representationRegex.findAll(xml).firstNotNullOfOrNull { match ->
            val attrs = match.groupValues[1]
            val idMatch = Regex("(?i)\\bid\\s*=\\s*[\"']([^\"']+)[\"']").find(attrs)
            if (idMatch?.groupValues?.getOrNull(1) != id) return@firstNotNullOfOrNull null
            Regex("(?i)\\bFBQualityLabel\\s*=\\s*[\"']([^\"']+)[\"']")
                .find(attrs)?.groupValues?.getOrNull(1)?.trim()
        }
    }

    private fun audioRepresentationBitrate(format: androidx.media3.common.Format): Long =
        format.peakBitrate.takeIf { it > 0 }?.toLong()
            ?: format.averageBitrate.takeIf { it > 0 }?.toLong()
            ?: 0L

    private fun safeAddBitrates(first: Long, second: Long): Long? {
        if (first < 0L || second < 0L) return null
        return if (Long.MAX_VALUE - first < second) null else first + second
    }

    private fun estimateSize(bitrate: Long?, durationSeconds: Double): Long? {
        if (bitrate == null || bitrate <= 0L || durationSeconds <= 0.0 || !durationSeconds.isFinite()) return null
        if (bitrate <= 0L || durationSeconds <= 0.0 || !durationSeconds.isFinite()) return null
        val estimate = bitrate.toDouble() * durationSeconds / 8.0
        return estimate.takeIf { it.isFinite() && it in 1.0..Long.MAX_VALUE.toDouble() }?.toLong()
    }
}
