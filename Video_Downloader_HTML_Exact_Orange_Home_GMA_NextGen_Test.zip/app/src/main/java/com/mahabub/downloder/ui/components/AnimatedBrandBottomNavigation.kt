package com.mahabub.downloder.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.Spring
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsBottomHeight
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mahabub.downloder.R
import com.mahabub.downloder.Screen

val LocalBottomBarContentPadding = compositionLocalOf { 0.dp }

/**
 * Full-width curved bottom bar matching Curved Nav Demo.html.
 * One spring-driven value positions both the floating selection bubble and the Canvas notch.
 */
@Composable
fun AnimatedBrandBottomNavigation(
    selectedRoute: String,
    activeDownloadCount: Int,
    finishedCount: Int,
    onBrowse: () -> Unit,
    onProgress: () -> Unit,
    onFinished: () -> Unit,
    onSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val destinations = listOf(
        BottomNavDestination(Screen.Browser.route, stringResource(R.string.nav_browse), Icons.Default.Language, 0, onBrowse),
        BottomNavDestination(Screen.Downloads.route, stringResource(R.string.nav_progress), Icons.Default.Download, activeDownloadCount, onProgress),
        BottomNavDestination(Screen.Completed.route, stringResource(R.string.nav_videos), Icons.Default.Folder, finishedCount, onFinished),
        BottomNavDestination(Screen.Settings.route, stringResource(R.string.nav_settings), Icons.Default.Settings, 0, onSettings)
    )

    val selectedIndex = destinations.indexOfFirst { it.route == selectedRoute }
        .takeIf { it >= 0 } ?: 0

    // Current navigation motion: damping ratio 0.50, stiffness 50, mass 1.
    // The same animated index drives the circle and the curved notch so they cannot drift apart.
    val animatedIndex by animateFloatAsState(
        targetValue = selectedIndex.toFloat(),
        animationSpec = spring(
            // Preserve the requested half-speed navigation motion. Lower stiffness
            // lengthens the spring travel while keeping the same damping character.
            dampingRatio = 0.5f,
            stiffness = 50f
        ),
        label = "bottomNavSelectionSpring"
    )

    val barColor = MaterialTheme.colorScheme.surface
    val barOutline = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.18f)
    val inactiveColor = MaterialTheme.colorScheme.onSurfaceVariant
    val selectedLabelColor = MaterialTheme.colorScheme.primary
    val indicatorColor = MaterialTheme.colorScheme.primary
    val indicatorContentColor = MaterialTheme.colorScheme.onPrimary

    Column(modifier = modifier.fillMaxWidth()) {
        // The 22dp overhang is inside this overlay only; the NavHost remains full-screen.
        Spacer(Modifier.height(22.dp))
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxWidth()
                .height(80.dp)
        ) {
            val itemWidth = maxWidth / destinations.size
            val indicatorSize = 44.dp
            val indicatorRadius = indicatorSize / 2f
            val indicatorX = itemWidth * (animatedIndex + 0.5f) - indicatorRadius
            val selectedDestination = destinations[selectedIndex]

            Canvas(modifier = Modifier.fillMaxSize()) {
                drawReferenceNavShape(
                    selectedCenterX = size.width * ((animatedIndex + 0.5f) / destinations.size),
                    fillColor = barColor,
                    outlineColor = barOutline
                )
            }

            Row(
                modifier = Modifier.fillMaxSize(),
                horizontalArrangement = Arrangement.Start,
                verticalAlignment = Alignment.Top
            ) {
                destinations.forEach { destination ->
                    val selected = destination.route == selectedDestination.route
                    val iconAlpha by animateFloatAsState(
                        targetValue = if (selected) 0f else 1f,
                        animationSpec = if (selected) {
                            tween(durationMillis = 80)
                        } else {
                            tween(durationMillis = 200, delayMillis = 100)
                        },
                        label = "bottomNavTabIconAlpha_${destination.route}"
                    )
                    val labelColor by animateColorAsState(
                        targetValue = if (selected) selectedLabelColor else inactiveColor,
                        animationSpec = tween(durationMillis = 200),
                        label = "bottomNavLabelColor_${destination.route}"
                    )

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                    ) {
                        // A compact 64x60dp hit area surrounds the icon and label.
                        // It is intentionally larger than the visible content so taps
                        // near an option are still recognized, while the wider blank
                        // portions of the navigation bar remain non-interactive.
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopCenter)
                                .size(width = 64.dp, height = 60.dp)
                                .clip(RoundedCornerShape(18.dp))
                                .clickable(
                                    role = Role.Tab,
                                    onClick = destination.onClick
                                )
                        )

                        // Keep all visual elements at their original coordinates.
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 4.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Top
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(24.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Box(contentAlignment = Alignment.TopEnd) {
                                    Icon(
                                        imageVector = destination.icon,
                                        contentDescription = destination.label,
                                        tint = inactiveColor,
                                        modifier = Modifier
                                            .size(24.dp)
                                            .graphicsLayer { alpha = iconAlpha }
                                    )
                                    if (!selected && destination.badgeCount > 0) {
                                        CountBadge(
                                            count = destination.badgeCount,
                                            modifier = Modifier.offset(x = 9.dp, y = (-7).dp)
                                        )
                                    }
                                }
                            }

                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = destination.label,
                                color = labelColor,
                                fontSize = 12.sp,
                                lineHeight = 16.sp,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                maxLines = 1,
                                // The surrounding destination hit area handles label taps.
                            )
                        }

                        // The transparent rounded target above handles the icon, label,
                        // and a small margin around them; distant empty bar space does not.
                    }
                }
            }

            // The circle sits on the bar's upper edge, as in the reference demo.
            Box(
                modifier = Modifier
                    .offset(x = indicatorX, y = (-22).dp)
                    .size(indicatorSize),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .shadow(5.dp, CircleShape)
                        .clip(CircleShape)
                        .background(indicatorColor),
                    contentAlignment = Alignment.Center
                ) {
                    AnimatedContent(
                        targetState = selectedDestination.route,
                        transitionSpec = {
                            // Show the newly selected destination icon immediately; keep only
                            // a very short fade so the icon feels instant without a delayed pop-in.
                            fadeIn(tween(durationMillis = 60)) togetherWith
                                fadeOut(tween(durationMillis = 100))
                        },
                        label = "bottomNavSelectedIcon"
                    ) { destinationRoute ->
                        val iconDestination = destinations.firstOrNull { it.route == destinationRoute }
                            ?: destinations[0]
                        Icon(
                            imageVector = iconDestination.icon,
                            contentDescription = iconDestination.label,
                            tint = indicatorContentColor,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }

                // Keep existing active/completed counters visible without changing their behavior.
                if (selectedDestination.badgeCount > 0) {
                    CountBadge(
                        count = selectedDestination.badgeCount,
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .offset(x = 6.dp, y = (-4).dp)
                    )
                }
            }
        }

        // Extend the same surface behind Android's gesture / three-button navigation inset.
        Spacer(
            Modifier
                .fillMaxWidth()
                .background(barColor)
                .windowInsetsBottomHeight(WindowInsets.navigationBars)
        )
    }
}

@Composable
private fun CountBadge(count: Int, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .width(if (count > 99) 26.dp else if (count > 9) 20.dp else 18.dp)
            .height(18.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(MaterialTheme.colorScheme.error),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = if (count > 99) "99+" else count.toString(),
            color = MaterialTheme.colorScheme.onError,
            fontSize = if (count > 99) 7.sp else if (count > 9) 8.sp else 9.sp,
            lineHeight = 10.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1
        )
    }
}

private data class BottomNavDestination(
    val route: String,
    val label: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val badgeCount: Int,
    val onClick: () -> Unit
)

private fun DrawScope.drawReferenceNavShape(
    selectedCenterX: Float,
    fillColor: Color,
    outlineColor: Color
) {
    val top = 0f
    val halfNotchWidth = 52.dp.toPx()
    val notchDepth = 29.dp.toPx()
    val controlOffset = halfNotchWidth * 0.45f
    val center = selectedCenterX.coerceIn(22.dp.toPx(), size.width - 22.dp.toPx())
    val left = center - halfNotchWidth
    val right = center + halfNotchWidth

    val path = Path().apply {
        moveTo(0f, top)
        lineTo(left, top)
        cubicTo(
            left + controlOffset, top,
            center - controlOffset, top + notchDepth,
            center, top + notchDepth
        )
        cubicTo(
            center + controlOffset, top + notchDepth,
            right - controlOffset, top,
            right, top
        )
        lineTo(size.width, top)
        lineTo(size.width, size.height)
        lineTo(0f, size.height)
        close()
    }

    drawPath(path = path, color = fillColor)

    // An open outline follows only the upper rim and notch. The side and bottom edges
    // are intentionally not stroked so the gesture area joins the bar without seams.
    val topOutline = Path().apply {
        moveTo(0f, top)
        lineTo(left, top)
        cubicTo(
            left + controlOffset, top,
            center - controlOffset, top + notchDepth,
            center, top + notchDepth
        )
        cubicTo(
            center + controlOffset, top + notchDepth,
            right - controlOffset, top,
            right, top
        )
        lineTo(size.width, top)
    }
    drawPath(path = topOutline, color = outlineColor, style = Stroke(width = 1.dp.toPx()))
}
