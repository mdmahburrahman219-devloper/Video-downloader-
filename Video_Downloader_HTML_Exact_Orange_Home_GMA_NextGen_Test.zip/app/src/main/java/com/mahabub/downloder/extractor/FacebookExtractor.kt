package com.mahabub.downloder.extractor

import com.mahabub.downloder.model.MediaCandidate
import com.mahabub.downloder.model.PlatformSource
import okhttp3.OkHttpClient

/** Facebook-specific page extractor. It only parses media URLs present in the returned page. */
class FacebookExtractor(private val okHttpClient: OkHttpClient) : PlatformExtractor {
    override val platform: PlatformSource = PlatformSource.FACEBOOK

    override fun matches(url: String): Boolean {
        val host = runCatching { java.net.URI(url).host.orEmpty().lowercase() }.getOrDefault("")
        return host == "facebook.com" || host.endsWith(".facebook.com") ||
            host == "fb.watch" || host.endsWith(".fb.watch") || host == "fb.com" || host.endsWith(".fb.com")
    }

    override suspend fun extract(url: String): MediaCandidate? = extract(url, null)

    override suspend fun extract(url: String, userAgentOverride: String?): MediaCandidate? = try {
        val request = ExtractorUtils.buildRequest(
            url = url,
            referer = url,
            userAgent = userAgentOverride?.takeIf { it.isNotBlank() } ?: ExtractorUtils.USER_AGENT
        )
        okHttpClient.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return null
            val html = response.body?.string()?.take(5_000_000) ?: return null
            MetaMediaPageParser.extract(html, url, platform, userAgentOverride?.takeIf { it.isNotBlank() } ?: ExtractorUtils.USER_AGENT)
        }
    } catch (_: Exception) {
        null
    }
}
