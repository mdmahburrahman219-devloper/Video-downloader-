package com.mahabub.downloder.ui.viewmodel

import android.content.Context
import android.webkit.CookieManager
import android.webkit.WebStorage
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.mahabub.downloder.AppContainer
import com.mahabub.downloder.AppLocaleManager
import com.mahabub.downloder.model.MediaQuality
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class SettingsViewModel(
    private val container: AppContainer
) : ViewModel() {

    val isWifiOnly: StateFlow<Boolean> =
        container.preferenceManager.isWifiOnly
            .stateIn(
                viewModelScope,
                SharingStarted.WhileSubscribed(5000),
                false
            )

    val maxConcurrentDownloads: StateFlow<Int> =
        container.preferenceManager.maxConcurrentDownloads
            .stateIn(
                viewModelScope,
                SharingStarted.WhileSubscribed(5000),
                2
            )

    val preferredQuality: StateFlow<MediaQuality> =
        container.preferenceManager.preferredQuality
            .stateIn(
                viewModelScope,
                SharingStarted.WhileSubscribed(5000),
                MediaQuality.HIGHEST
            )

    val askBeforeDownload: StateFlow<Boolean> =
        container.preferenceManager.askBeforeDownload
            .stateIn(
                viewModelScope,
                SharingStarted.WhileSubscribed(5000),
                true
            )

    val isPrivateDownloads: StateFlow<Boolean> =
        container.preferenceManager.isPrivateDownloads
            .stateIn(
                viewModelScope,
                SharingStarted.WhileSubscribed(5000),
                false
            )

    val darkMode: StateFlow<String> =
        container.preferenceManager.darkMode
            .stateIn(
                viewModelScope,
                SharingStarted.WhileSubscribed(5000),
                "system"
            )

    val searchEngine: StateFlow<String> =
        container.preferenceManager.searchEngine
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "Google")

    val customSearchUrl: StateFlow<String> =
        container.preferenceManager.customSearchUrl
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "https://www.google.com/search?q=%s")

    val blockAds: StateFlow<Boolean> =
        container.preferenceManager.blockAds
            .stateIn(
                viewModelScope,
                SharingStarted.WhileSubscribed(5000),
                true
            )

    val showRecentWebsites: StateFlow<Boolean> =
        container.preferenceManager.showRecentWebsites
            .stateIn(
                viewModelScope,
                SharingStarted.WhileSubscribed(5000),
                true
            )

    val homeShortcuts = container.preferenceManager.homeShortcuts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), com.mahabub.downloder.preferences.HomeShortcutDefaults.items)

    val showQuickAccess = container.preferenceManager.showQuickAccess
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

    val homeAccentColor = container.preferenceManager.homeAccentColor
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "purple")

    val homeBackground = container.preferenceManager.homeBackground
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "ice")

    val syncToGallery: StateFlow<Boolean> =
        container.preferenceManager.syncToGallery
            .stateIn(
                viewModelScope,
                SharingStarted.WhileSubscribed(5000),
                false
            )

    val downloadLocation: StateFlow<String> =
        container.preferenceManager.downloadLocation
            .stateIn(
                viewModelScope,
                SharingStarted.WhileSubscribed(5000),
                "/storage/emulated/0/Video downloader"
            )

    val downloadFolderTreeUri: StateFlow<String> =
        container.preferenceManager.downloadFolderTreeUri
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "")

    val language: StateFlow<String> =
        container.preferenceManager.language
            .stateIn(
                viewModelScope,
                SharingStarted.WhileSubscribed(5000),
                "Default"
            )

    fun setWifiOnly(enabled: Boolean) {
        viewModelScope.launch {
            container.preferenceManager.setWifiOnly(enabled)
            container.downloadRepository.checkAndTriggerQueue()
        }
    }

    fun setMaxConcurrent(count: Int) {
        viewModelScope.launch {
            container.preferenceManager.setMaxConcurrentDownloads(count)
            container.downloadRepository.checkAndTriggerQueue()
        }
    }

    fun setPreferredQuality(quality: MediaQuality) {
        viewModelScope.launch {
            container.preferenceManager.setPreferredQuality(quality)
        }
    }

    fun setAskBeforeDownload(enabled: Boolean) {
        viewModelScope.launch {
            container.preferenceManager.setAskBeforeDownload(enabled)
        }
    }

    fun setPrivateDownloads(enabled: Boolean) {
        viewModelScope.launch {
            container.preferenceManager.setPrivateDownloads(enabled)
        }
    }

    fun setDarkMode(mode: String) {
        viewModelScope.launch {
            container.preferenceManager.setDarkMode(mode)
        }
    }

    fun setSearchEngine(name: String) {
        viewModelScope.launch { container.preferenceManager.setSearchEngine(name) }
    }

    fun setCustomSearchUrl(url: String) {
        viewModelScope.launch { container.preferenceManager.setCustomSearchUrl(url) }
    }

    fun setBlockAds(enabled: Boolean) {
        viewModelScope.launch {
            container.preferenceManager.setBlockAds(enabled)
        }
    }

    fun setShowRecentWebsites(enabled: Boolean) {
        viewModelScope.launch {
            container.preferenceManager.setShowRecentWebsites(enabled)
        }
    }

    fun setHomeShortcuts(shortcuts: List<com.mahabub.downloder.preferences.HomeShortcut>) {
        viewModelScope.launch { container.preferenceManager.setHomeShortcuts(shortcuts) }
    }

    fun setShowQuickAccess(enabled: Boolean) {
        viewModelScope.launch { container.preferenceManager.setShowQuickAccess(enabled) }
    }

    fun setHomeAccentColor(color: String) {
        viewModelScope.launch { container.preferenceManager.setHomeAccentColor(color) }
    }

    fun setHomeBackground(background: String) {
        viewModelScope.launch { container.preferenceManager.setHomeBackground(background) }
    }

    fun setSyncToGallery(enabled: Boolean) {
        viewModelScope.launch {
            container.preferenceManager.setSyncToGallery(enabled)
        }
    }

    fun setDownloadLocation(path: String) {
        viewModelScope.launch {
            container.preferenceManager.setDownloadLocation(path)
        }
    }

    fun setDownloadFolderTreeUri(uri: String?) {
        viewModelScope.launch {
            container.preferenceManager.setDownloadFolderTreeUri(uri)
        }
    }

    fun setLanguage(lang: String, onApplied: () -> Unit = {}) {
        viewModelScope.launch {
            container.preferenceManager.setLanguage(lang)
            AppLocaleManager.persist(container.context, lang)
            withContext(Dispatchers.Main.immediate) { onApplied() }
        }
    }

    /**
     * Clears browser Web Storage only.
     *
     * Important:
     * Do not delete downloader temporary files here.
     * Those files may contain partially downloaded media
     * required for resuming interrupted downloads.
     */
    fun clearBrowserCache(activityContext: Context) {
        // WebStorage and the HTTP cache are separate stores; clear both.
        try {
            WebStorage.getInstance().deleteAllData()
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                runCatching {
                    val cleaner = android.webkit.WebView(activityContext)
                    cleaner.clearCache(true)
                    cleaner.destroy()
                }
            }
        } catch (_: Exception) {
            // Browser storage cleanup should never crash the app.
        }
    }

    fun clearCookies() {
        try {
            CookieManager.getInstance().removeAllCookies(null)
            CookieManager.getInstance().flush()
        } catch (_: Exception) {
            // Cookie cleanup should not crash the app.
        }
    }

    fun clearBrowserHistory() {
        viewModelScope.launch {
            container.database.browserHistoryDao().clearHistory()
        }
    }

    class Factory(
        private val container: AppContainer
    ) : ViewModelProvider.Factory {

        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(
            modelClass: Class<T>
        ): T {
            return SettingsViewModel(container) as T
        }
    }
}