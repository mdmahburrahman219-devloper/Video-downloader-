
package com.mahabub.downloder.storage

import java.util.Locale

/**
 * Creates a safe, portable filename for downloaded media.
 * Path separators and control characters are never kept in the result.
 */
object SafeFileName {

    private val reservedCharsRegex = Regex("[\\\\/:*?\"<>|\\x00-\\x1F\\x7F]")
    private val repeatedDotsRegex = Regex("\\.{2,}")
    private val validExtensionRegex = Regex("^[A-Za-z0-9]{1,10}$")

    // Keep names safely below common filesystem limits after UTF-8 encoding.
    // This matters for CJK titles where one visible character may use 3 UTF-8 bytes.
    private const val MAX_BASE_NAME_UTF8_BYTES = 120

    private val supportedExtensions = setOf(
        "mp4", "m4v", "webm", "3gp", "mov", "avi", "mkv",
        "wmv", "flv", "ts", "mpg", "mpeg", "ogv",
        "mp3", "m4a", "aac", "ogg", "oga", "opus", "wav", "flac", "aiff", "amr",
        "jpg", "jpeg", "png", "gif", "webp", "bmp", "avif"
    )

    /**
     * Sanitizes a name and guarantees a usable extension.
     * HLS/DASH manifest extensions are replaced with the requested output
     * extension because those manifests are not the downloaded media file.
     */
    fun sanitize(
        rawName: String?,
        fallbackExtension: String = "mp4"
    ): String {
        val fallback = normalizeFallbackExtension(fallbackExtension)

        var name = rawName
            ?.trim()
            .orEmpty()
            .ifBlank { "video_${System.currentTimeMillis()}" }

        // If a URL was accidentally passed as a name, do not include query data.
        name = name.substringBefore('?').substringBefore('#')

        var cleaned = reservedCharsRegex.replace(name, "_")
        cleaned = repeatedDotsRegex.replace(cleaned, "_")
        cleaned = cleaned.trim().trimEnd('.', ' ')

        if (cleaned.isBlank() || cleaned == "_") {
            cleaned = "video_${System.currentTimeMillis()}"
        }

        val dotIndex = cleaned.lastIndexOf('.')
        val suffix = if (dotIndex > 0 && dotIndex < cleaned.lastIndex) {
            cleaned.substring(dotIndex + 1)
        } else {
            ""
        }
        val suffixLower = suffix.lowercase(Locale.ROOT)

        val isManifestExtension = suffixLower in setOf("m3u8", "mpd", "m3u")
        val hasSupportedExtension = suffixLower in supportedExtensions

        val baseName = when {
            isManifestExtension || hasSupportedExtension ->
                cleaned.substring(0, dotIndex)

            dotIndex > 0 && validExtensionRegex.matches(suffix) ->
                cleaned.substring(0, dotIndex)

            else -> cleaned
        }.trim().trimEnd('.', ' ')

        val finalBase = truncateUtf8(
            baseName.ifBlank { "video_${System.currentTimeMillis()}" },
            MAX_BASE_NAME_UTF8_BYTES
        ).ifBlank { "video_${System.currentTimeMillis()}" }

        val extension = when {
            isManifestExtension -> fallback
            hasSupportedExtension -> suffixLower
            else -> fallback
        }

        return "$finalBase.$extension"
    }


    /** Truncates by UTF-8 bytes without splitting a Unicode surrogate pair. */
    private fun truncateUtf8(value: String, maxBytes: Int): String {
        if (maxBytes <= 0) return ""
        val result = StringBuilder()
        var index = 0
        var bytesUsed = 0
        while (index < value.length) {
            val codePoint = value.codePointAt(index)
            val charCount = Character.charCount(codePoint)
            val piece = String(Character.toChars(codePoint))
            val pieceBytes = piece.toByteArray(Charsets.UTF_8).size
            if (bytesUsed + pieceBytes > maxBytes) break
            result.append(piece)
            bytesUsed += pieceBytes
            index += charCount
        }
        return result.toString()
    }

    /** Returns a suitable filename extension for a MIME type. */
    fun getExtensionFromMime(mimeType: String?): String {
        val mime = mimeType
            ?.substringBefore(';')
            ?.trim()
            ?.lowercase(Locale.ROOT)
            ?: return "mp4"

        return when (mime) {
            "video/mp4", "application/mp4" -> "mp4"
            "video/webm" -> "webm"
            "video/3gpp", "audio/3gpp" -> "3gp"
            "video/quicktime" -> "mov"
            "video/x-msvideo" -> "avi"
            "video/x-matroska" -> "mkv"
            "video/x-ms-wmv" -> "wmv"
            "video/x-flv" -> "flv"
            "video/mp2t" -> "ts"
            "video/mpeg" -> "mpg"
            "video/ogg" -> "ogv"
            "audio/mpeg" -> "mp3"
            "audio/mp4" -> "m4a"
            "audio/aac", "audio/x-aac" -> "aac"
            "audio/ogg", "application/ogg" -> "ogg"
            "audio/wav", "audio/x-wav", "audio/wave" -> "wav"
            "audio/flac", "audio/x-flac" -> "flac"
            "audio/opus" -> "opus"
            "audio/amr" -> "amr"
            "image/jpeg" -> "jpg"
            "image/png" -> "png"
            "image/gif" -> "gif"
            "image/webp" -> "webp"
            "image/bmp" -> "bmp"
            "image/avif" -> "avif"

            "application/vnd.apple.mpegurl",
            "application/x-mpegurl",
            "audio/mpegurl",
            "audio/x-mpegurl",
            "application/dash+xml" -> "mp4"

            else -> "mp4"
        }
    }

    private fun normalizeFallbackExtension(extension: String): String {
        val normalized = extension
            .trim()
            .removePrefix(".")
            .lowercase(Locale.ROOT)

        return if (
            validExtensionRegex.matches(normalized) &&
            normalized !in setOf("m3u8", "mpd", "m3u")
        ) {
            normalized
        } else {
            "mp4"
        }
    }
}
