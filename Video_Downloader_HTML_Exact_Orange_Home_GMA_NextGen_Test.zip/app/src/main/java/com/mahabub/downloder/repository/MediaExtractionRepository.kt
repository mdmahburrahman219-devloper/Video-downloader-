
package com.mahabub.downloder.repository

import android.webkit.MimeTypeMap
import com.mahabub.downloder.browser.TikTokBrowserMode
import com.mahabub.downloder.extractor.ExtractorUtils
import com.mahabub.downloder.extractor.GenericWebExtractor
import com.mahabub.downloder.extractor.HlsPlaylistParser
import com.mahabub.downloder.extractor.PlatformExtractor
import com.mahabub.downloder.model.MediaCandidate
import com.mahabub.downloder.model.MediaCandidateGrouping
import com.mahabub.downloder.model.PlatformSource
import com.mahabub.downloder.model.StreamType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.URI

class MediaExtractionRepository(
    private val okHttpClient: OkHttpClient,
    private val extractors: Set<PlatformExtractor>
) {
    private val genericExtractor = GenericWebExtractor(okHttpClient)

    /**
     * Returns all known media alternatives for a platform page when the UI needs quality choices.
     * Non-TikTok extractors retain the original one-candidate behavior. The ordinary download path
     * continues to use resolveMedia(), so this does not change other sites' handling.
     */
    suspend fun resolveMediaCandidates(
        url: String,
        userAgentOverride: String? = null
    ): List<MediaCandidate> = withContext(Dispatchers.IO) {
        val cleanUrl = url.trim()
        if (cleanUrl.isBlank() || !isHttpUrl(cleanUrl)) return@withContext emptyList()
        if (TikTokBrowserMode.isTikTokUrl(cleanUrl)) return@withContext emptyList()
        checkDirectMedia(cleanUrl)?.let { return@withContext listOf(normalizeOutputCandidate(it)) }

        val single = resolveMedia(cleanUrl, userAgentOverride)
        if (single == null) emptyList() else listOf(single)
    }

    suspend fun resolveMedia(url: String, userAgentOverride: String? = null): MediaCandidate? =
        withContext(Dispatchers.IO) {
            val cleanUrl = url.trim()

            if (cleanUrl.isBlank() || !isHttpUrl(cleanUrl) || TikTokBrowserMode.isTikTokUrl(cleanUrl)) {
                return@withContext null
            }

            // 1. Check common direct media extensions first.
            checkDirectMedia(cleanUrl)?.let { directCandidate ->
                return@withContext normalizeOutputCandidate(directCandidate)
            }

            // 2. Try platform-specific extractors.
            // A failing extractor must not prevent other extractors from running.
            for (extractor in extractors) {
                if (
                    extractor is GenericWebExtractor ||
                    !extractor.matches(cleanUrl)
                ) {
                    continue
                }

                val candidate = try {
                    extractor.extract(cleanUrl, userAgentOverride)
                } catch (_: Exception) {
                    null
                }

                if (candidate != null) {
                    return@withContext probeCandidate(candidate)
                }
            }

            // 3. Generic fallback for HTML video tags and Open Graph media.
            val genericCandidate = try {
                genericExtractor.extract(cleanUrl)
            } catch (_: Exception) {
                null
            }

            if (genericCandidate != null) {
                return@withContext probeCandidate(genericCandidate)
            }

            null
        }

    /**
     * Resolves a browser-detected candidate for the automatic download UI. It probes extensionless
     * URLs, expands HLS master playlists, and enriches each VOD media playlist with duration from
     * EXTINF entries. HLS output size cannot be known exactly before remux/download, so the UI keeps
     * a bitrate-derived estimate marked as approximate; direct-file Content-Length remains exact
     * when the server exposes it.
     */
    suspend fun resolveCandidateForDetection(
        candidate: MediaCandidate,
        cookieHeader: String? = null
    ): List<MediaCandidate> = withContext(Dispatchers.IO) {
        val probed = when (candidate.streamType) {
            StreamType.HLS, StreamType.DASH -> candidate
            else -> probeCandidate(candidate, cookieHeader)
        }

        when (probed.streamType) {
            StreamType.HLS -> {
                val variants = resolveHlsVariants(probed, cookieHeader)
                val expanded = variants.any { it.url.substringBefore('#') != probed.url.substringBefore('#') }
                val groupId = probed.videoGroupId ?: "hls-master:${probed.url.hashCode()}"
                val resolved = variants.map { variant ->
                    // enrichHlsVariant can read the VOD duration from EXTINF entries. Preserve
                    // that result instead of overwriting it with a null duration from the master URL.
                    val enriched = enrichHlsVariant(variant, cookieHeader)
                    enriched.copy(
                        videoGroupId = variant.videoGroupId ?: groupId,
                        title = variant.title?.takeIf { it.isNotBlank() && !isGenericStreamTitle(it) }
                            ?: probed.title?.takeIf { it.isNotBlank() && !isGenericStreamTitle(it) }
                            ?: "Detected video",
                        thumbnailUrl = variant.thumbnailUrl ?: probed.thumbnailUrl,
                        durationSeconds = enriched.durationSeconds ?: variant.durationSeconds ?: probed.durationSeconds
                    )
                }
                if (expanded) resolved else resolved.ifEmpty { listOf(probed) }
            }
            else -> listOf(probed)
        }
    }

    private fun enrichHlsVariant(candidate: MediaCandidate, cookieHeader: String?): MediaCandidate {
        val requestBuilder = Request.Builder()
            .url(candidate.url)
            .get()
            .header("User-Agent", candidate.userAgent?.takeIf { it.isNotBlank() } ?: ExtractorUtils.USER_AGENT)
            .header("Accept", "application/vnd.apple.mpegurl, application/x-mpegURL, */*")
        candidate.referer?.takeIf { it.isNotBlank() }?.let { requestBuilder.header("Referer", it) }
        cookieHeader?.takeIf { it.isNotBlank() }?.let { requestBuilder.header("Cookie", it) }

        return try {
            okHttpClient.newCall(requestBuilder.build()).execute().use { response ->
                if (!response.isSuccessful) return@use candidate
                val body = response.body?.string()?.take(1_000_000).orEmpty()
                if (!body.trimStart().startsWith("#EXTM3U")) return@use candidate
                val playlist = runCatching { HlsPlaylistParser.parseMediaPlaylist(body, candidate.url) }.getOrNull()
                    ?: return@use candidate
                // For live playlists the listed segments are only a moving window, not the total duration.
                val isVod = playlist.isEndList || playlist.playlistType.equals("VOD", ignoreCase = true)
                val duration = playlist.segments.sumOf { it.durationSeconds }.takeIf { isVod && it > 0.0 }
                val estimate = if (duration != null && (candidate.bitrate ?: 0L) > 0L) {
                    ((candidate.bitrate!!.toDouble() * duration) / 8.0)
                        .takeIf { it.isFinite() && it > 0.0 && it < Long.MAX_VALUE.toDouble() }
                        ?.toLong()
                } else null
                candidate.copy(
                    durationSeconds = candidate.durationSeconds ?: duration,
                    estimatedSizeBytes = candidate.estimatedSizeBytes ?: estimate,
                    sizeIsEstimated = candidate.sizeIsEstimated || estimate != null
                )
            }
        } catch (_: Exception) {
            candidate
        }
    }

    private fun isGenericStreamTitle(title: String): Boolean {
        val trimmed = title.trim()
        val looksLikeMediaFile = Regex("(?i)\\.(?:m3u8|mpd|mp4|m4v|webm|mov|mkv|avi|mp3|m4a|aac|ogg|wav|flac)$")
            .containsMatchIn(trimmed) && trimmed.none { it.isWhitespace() }
        val normalized = trimmed.substringBeforeLast('.').trim().lowercase()
        return looksLikeMediaFile || normalized in setOf(
            "video", "detected video", "detected media stream", "master", "playlist", "index", "stream"
        ) || normalized.matches(Regex("(?:hls|stream|index|video|playlist|master)(?:[-_.][a-z0-9]+)*"))
    }

    /**
     * Expands an HLS master playlist into its selectable video variants. If the URL is a media
     * playlist already, or the website blocks this metadata request, the original candidate is kept.
     * The playlist body is read only; media segments are not downloaded by this method.
     */
    suspend fun resolveHlsVariants(
        candidate: MediaCandidate,
        cookieHeader: String? = null
    ): List<MediaCandidate> = withContext(Dispatchers.IO) {
        if (candidate.streamType != StreamType.HLS) return@withContext listOf(candidate)

        try {
            val requestBuilder = Request.Builder()
                .url(candidate.url)
                .get()
                .header("User-Agent", candidate.userAgent?.takeIf { it.isNotBlank() } ?: ExtractorUtils.USER_AGENT)
                .header("Accept", "application/vnd.apple.mpegurl, application/x-mpegURL, */*")
            candidate.referer?.takeIf { it.isNotBlank() }?.let { requestBuilder.header("Referer", it) }
            cookieHeader?.takeIf { it.isNotBlank() }?.let { requestBuilder.header("Cookie", it) }

            okHttpClient.newCall(requestBuilder.build()).execute().use { response ->
                if (!response.isSuccessful) return@withContext listOf(candidate)
                val playlist = response.body?.string()?.take(1_000_000).orEmpty()
                if (!playlist.trimStart().startsWith("#EXTM3U") || !playlist.contains("#EXT-X-STREAM-INF")) {
                    return@withContext listOf(candidate)
                }

                val parsedMaster = HlsPlaylistParser.parseMaster(playlist, candidate.url)
                val parsedVariants = parsedMaster.variants
                val variants = parsedVariants.mapIndexed { index, variant ->
                    val height = variant.resolution?.substringAfter('x')?.toIntOrNull()
                    val label = height?.let { "${it}p" } ?: "Variant ${index + 1}"
                    val audioUrl = variant.audioGroupId?.let { groupId ->
                        parsedMaster.audioRenditions
                            .filter { it.groupId == groupId && it.url != null }
                            .sortedWith(
                                compareByDescending<com.mahabub.downloder.extractor.HlsPlaylistParser.AudioRendition> { it.isDefault }
                                    .thenByDescending { it.isAutoselect }
                            )
                            .firstOrNull()?.url
                    }
                    candidate.copy(
                        id = ExtractorUtils.generateMediaId(),
                        url = variant.url,
                        mimeType = "application/vnd.apple.mpegurl",
                        contentLength = null,
                        streamType = StreamType.HLS,
                        isDirectDownload = false,
                        resolution = variant.resolution,
                        qualityLabel = label,
                        bitrate = variant.bandwidth.takeIf { it > 0L },
                        videoGroupId = candidate.videoGroupId ?: "hls-master:${candidate.url.hashCode()}",
                        hlsAudioPlaylistUrl = audioUrl,
                        detectionConfidence = (candidate.detectionConfidence + (variant.bandwidth / 1_000_000L).coerceIn(0L, 15L).toInt()).coerceAtMost(100),
                        detectedAt = System.currentTimeMillis()
                    )
                }

                if (variants.isEmpty()) listOf(candidate)
                else variants.distinctBy { it.url }.sortedWith(
                    compareByDescending<MediaCandidate> { MediaCandidateGrouping.qualityRank(it) }
                        .thenByDescending { it.detectionConfidence }
                )
            }
        } catch (_: Exception) {
            listOf(candidate)
        }
    }

    private fun isHttpUrl(url: String): Boolean {
        return try {
            val uri = URI(url)

            (
                uri.scheme.equals("http", ignoreCase = true) ||
                    uri.scheme.equals("https", ignoreCase = true)
                ) && !uri.host.isNullOrBlank()
        } catch (_: Exception) {
            false
        }
    }

    private fun checkDirectMedia(url: String): MediaCandidate? {
        val uri = try {
            URI(url)
        } catch (_: Exception) {
            return null
        }

        val path = uri.path ?: return null
        val extension = path.substringAfterLast('.', "").lowercase()

        val streamType = when (extension) {
            "m3u8" -> StreamType.HLS
            "mpd" -> StreamType.DASH

            "mp4", "webm", "mov", "m4v", "avi", "mkv",
            "mp3", "m4a", "aac", "ogg", "wav" ->
                StreamType.PROGRESSIVE

            else -> return null
        }

        val sourceMimeType = MimeTypeMap.getSingleton()
            .getMimeTypeFromExtension(extension)
            ?: when (streamType) {
                StreamType.HLS -> "application/vnd.apple.mpegurl"
                StreamType.DASH -> "application/dash+xml"
                StreamType.PROGRESSIVE -> "video/mp4"
                else -> "video/mp4"
            }

        val lastPathComponent = path.substringAfterLast('/').ifBlank {
            "Media_${System.currentTimeMillis()}"
        }

        // HLS is remuxed to MP4. Remove the manifest extension so output
        // naming can produce "video.mp4" instead of "video.m3u8".
        val title = when (streamType) {
            StreamType.HLS ->
                lastPathComponent.removeSuffixIgnoreCase(".m3u8")

            StreamType.DASH ->
                lastPathComponent.removeSuffixIgnoreCase(".mpd")

            else -> lastPathComponent
        }.ifBlank {
            "Media_${System.currentTimeMillis()}"
        }

        val outputMimeType = when (streamType) {
            StreamType.HLS -> "video/mp4"

            StreamType.DASH -> "video/mp4"
            else -> sourceMimeType
        }

        return MediaCandidate(
            id = ExtractorUtils.generateMediaId(),
            url = url,
            title = title,
            mimeType = outputMimeType,
            sourcePageUrl = url,
            sourcePlatform = PlatformSource.DIRECT,
            streamType = streamType,
            isDirectDownload = streamType == StreamType.PROGRESSIVE
        )
    }

    private data class ProbeMetadata(
        val contentLength: Long?,
        val mimeType: String?,
        val contentDisposition: String?
    )

    private fun probeCandidate(candidate: MediaCandidate, cookieHeader: String? = null): MediaCandidate {
        val normalizedCandidate = normalizeOutputCandidate(candidate)

        // The playlist MIME type describes the manifest, not the final file.
        // HLS output is written as MP4 by HlsDownloader.
        if (
            normalizedCandidate.streamType == StreamType.HLS ||
            normalizedCandidate.streamType == StreamType.DASH
        ) {
            return normalizedCandidate
        }

        return try {
            val headMetadata = probeHeaders(
                normalizedCandidate,
                useHead = true,
                cookieHeader = cookieHeader
            )
            // Some CDNs return application/octet-stream (or no Content-Type) for HEAD but reveal
            // the real MIME type on a tiny Range GET. Probe that path before treating an
            // extensionless player URL as an ordinary progressive file.
            val headMime = headMetadata?.mimeType.orEmpty().lowercase()
            val needsRangeProbe = headMetadata == null || headMetadata.contentLength == null || headMime.isBlank() ||
                headMime == "application/octet-stream" || headMime == "binary/octet-stream" ||
                headMime.startsWith("text/html")
            val metadata = if (needsRangeProbe) {
                probeHeaders(normalizedCandidate, useHead = false, cookieHeader = cookieHeader) ?: headMetadata
            } else headMetadata

            if (metadata == null) {
                normalizedCandidate
            } else {
                val responseMime = metadata.mimeType ?: normalizedCandidate.mimeType
                val loweredMime = responseMime.orEmpty().lowercase()
                val resolvedType = when {
                    loweredMime.contains("mpegurl") || loweredMime.contains("vnd.apple.mpegurl") -> StreamType.HLS
                    loweredMime.contains("dash+xml") -> StreamType.DASH
                    else -> normalizedCandidate.streamType
                }
                normalizedCandidate.copy(
                    contentLength = metadata.contentLength ?: normalizedCandidate.contentLength,
                    mimeType = if (resolvedType == StreamType.HLS) "application/vnd.apple.mpegurl" else responseMime,
                    contentDisposition = metadata.contentDisposition ?: normalizedCandidate.contentDisposition,
                    streamType = resolvedType,
                    isDirectDownload = resolvedType == StreamType.PROGRESSIVE
                )
            }
        } catch (_: Exception) {
            normalizedCandidate
        }
    }

    private fun probeHeaders(
        candidate: MediaCandidate,
        useHead: Boolean,
        cookieHeader: String? = null
    ): ProbeMetadata? {
        val requestBuilder = Request.Builder()
            .url(candidate.url)
            .header(
                "User-Agent",
                candidate.userAgent?.takeIf { it.isNotBlank() }
                    ?: ExtractorUtils.USER_AGENT
            )

        candidate.referer?.takeIf { it.isNotBlank() }?.let {
            requestBuilder.header("Referer", it)
        }
        cookieHeader?.takeIf { it.isNotBlank() }?.let { requestBuilder.header("Cookie", it) }

        if (useHead) {
            requestBuilder.head()
        } else {
            // A one-byte Range request is a fallback for servers that reject HEAD.
            // The response is closed immediately; the media is not saved here.
            requestBuilder
                .header("Range", "bytes=0-0")
                .get()
        }

        val response = okHttpClient.newCall(
            requestBuilder.build()
        ).execute()

        return response.use { res ->
            if (!res.isSuccessful && res.code != 206) {
                return@use null
            }

            val contentRangeTotal = res.header("Content-Range")
                ?.let { range ->
                    Regex(
                        """bytes\s+\d+-\d+/(\d+|\*)""",
                        RegexOption.IGNORE_CASE
                    )
                        .matchEntire(range.trim())
                        ?.groupValues
                        ?.getOrNull(1)
                        ?.takeIf { it != "*" }
                        ?.toLongOrNull()
                }

            // On a successful Range fallback, Content-Length may be just the one requested byte.
            // Only Content-Range's total is an exact full-file length for HTTP 206 responses.
            val contentLength = contentRangeTotal ?: if (res.code == 206) {
                null
            } else {
                res.header("Content-Length")?.toLongOrNull()
            }

            ProbeMetadata(
                contentLength = contentLength,
                mimeType = res.header("Content-Type")
                    ?.substringBefore(';')
                    ?.trim(),
                contentDisposition = res.header("Content-Disposition")
            )
        }
    }

    private fun normalizeOutputCandidate(
        candidate: MediaCandidate
    ): MediaCandidate {
        return when (candidate.streamType) {
            StreamType.HLS -> candidate.copy(
                title = candidate.title.removeSuffixIgnoreCase(".m3u8"),
                mimeType = "video/mp4",
                isDirectDownload = false
            )

            StreamType.DASH -> candidate.copy(
                title = candidate.title.removeSuffixIgnoreCase(".mpd"),
                isDirectDownload = false
            )

            else -> candidate
        }
    }

    private fun String?.removeSuffixIgnoreCase(
        suffix: String
    ): String {
        val value = this ?: return ""

        return if (value.endsWith(suffix, ignoreCase = true)) {
            value.dropLast(suffix.length)
        } else {
            value
        }
    }
}
