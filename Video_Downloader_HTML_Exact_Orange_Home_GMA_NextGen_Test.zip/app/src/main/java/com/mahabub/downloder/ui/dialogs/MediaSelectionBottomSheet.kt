package com.mahabub.downloder.ui.dialogs

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.outlined.Cancel
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.mahabub.downloder.R
import com.mahabub.downloder.model.MediaCandidate
import com.mahabub.downloder.model.MediaCandidateGrouping
import com.mahabub.downloder.model.SmartFilterSettings
import com.mahabub.downloder.model.SmartMediaFilter
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MediaSelectionBottomSheet(
    candidate: MediaCandidate,
    candidates: List<MediaCandidate> = listOf(candidate),
    allDetectedCandidates: List<MediaCandidate> = candidates,
    currentPageUrl: String? = candidate.sourcePageUrl,
    platformName: String = "Video",
    isParsing: Boolean = false,
    enableOtherDetected: Boolean = true,
    onDismiss: () -> Unit,
    onSelectOtherCandidates: (List<MediaCandidate>) -> Unit = {},
    onConfirmDownload: (selectedCandidate: MediaCandidate, customTitle: String, rememberSession: Boolean) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val popupBackground = MaterialTheme.colorScheme.surface
    val popupText = MaterialTheme.colorScheme.onSurface
    val popupMuted = MaterialTheme.colorScheme.onSurfaceVariant
    val popupBorder = MaterialTheme.colorScheme.outlineVariant
    val popupThumbnailBackground = MaterialTheme.colorScheme.surfaceVariant
    val popupBlue = MaterialTheme.colorScheme.primary
    val popupSelectedBackground = MaterialTheme.colorScheme.primaryContainer
    var currentTitle by remember(candidate.id) {
        val defaultPrefix = if (candidate.mimeType?.startsWith("image/", true) == true) "image" else "video"
        mutableStateOf(candidate.title?.takeIf { it.isNotBlank() } ?: "${defaultPrefix}_${System.currentTimeMillis()}")
    }
    var localParsingState by remember { mutableStateOf(isParsing) }
    var showOtherDetected by remember { mutableStateOf(false) }

    // Rule toggles live in Other Detected. They affect the review list immediately; selecting an
    // item there opens that candidate's available quality options in this same download sheet.
    var filterLowResolution by remember { mutableStateOf(true) }
    var filterShortVideos by remember { mutableStateOf(true) }
    var filterSmallFiles by remember { mutableStateOf(true) }
    var preferMostQualityOptions by remember { mutableStateOf(true) }

    val filterSettings = SmartFilterSettings(
        filterLowResolution = filterLowResolution,
        filterShortVideos = filterShortVideos,
        filterSmallFiles = filterSmallFiles,
        preferMostQualityOptions = preferMostQualityOptions
    )
    val filterResult = remember(allDetectedCandidates, currentPageUrl, filterSettings) {
        SmartMediaFilter.apply(allDetectedCandidates, currentPageUrl, filterSettings)
    }
    val rawOptionList = remember(candidates, candidate) {
        (candidates + candidate).distinctBy { it.url.substringBefore('#') }
            .sortedWith(
                compareByDescending<MediaCandidate> { MediaCandidateGrouping.qualityRank(it) }
                    .thenByDescending { it.isPlaying }
                    .thenByDescending { it.detectionConfidence }
                    .thenByDescending { it.contentLength ?: it.estimatedSizeBytes ?: 0L }
            )
    }
    // HLS variants may be resolved after the first detection. Apply the low-resolution filter
    // again to these late options, except on social platforms and when the user disables the rule.
    val optionList = remember(rawOptionList, currentPageUrl, filterLowResolution) {
        SmartMediaFilter.filterLowResolutionOptions(rawOptionList, currentPageUrl, filterLowResolution)
    }
    var selectedOption by remember(candidates, candidate.url) {
        mutableStateOf(candidates.firstOrNull { it.url == candidate.url } ?: candidate)
    }
    val otherItems = remember(filterResult, candidates) {
        SmartMediaFilter.otherDetectedItems(filterResult, candidates)
    }

    LaunchedEffect(isParsing) { localParsingState = isParsing }
    LaunchedEffect(optionList, candidate.url) {
        selectedOption = optionList.firstOrNull { it.url == candidate.url } ?: optionList.firstOrNull() ?: candidate
    }

    val formattedSize = remember(selectedOption.contentLength, selectedOption.estimatedSizeBytes, selectedOption.sizeIsEstimated) {
        val bytes = selectedOption.contentLength?.takeIf { it > 0L }
            ?: selectedOption.estimatedSizeBytes?.takeIf { it > 0L }
        if (bytes != null) {
            val label = formatBytes(bytes)
            if (selectedOption.contentLength == null && selectedOption.estimatedSizeBytes != null) "≈ $label" else label
        } else {
            "Size unknown"
        }
    }

    val isImageSelection = selectedOption.mimeType?.startsWith("image/", ignoreCase = true) == true
    val displayThumbnail = selectedOption.thumbnailUrl?.takeIf { it.isNotBlank() }
        ?: if (isImageSelection) selectedOption.url else candidates.firstNotNullOfOrNull { it.thumbnailUrl?.takeIf(String::isNotBlank) }
    val displayDurationSeconds = if (isImageSelection) null else (
        selectedOption.durationSeconds?.takeIf { it > 0.0 }
            ?: candidates.firstNotNullOfOrNull { it.durationSeconds?.takeIf { seconds -> seconds > 0.0 } }
        )

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = popupBackground,
        contentColor = popupText,
        scrimColor = Color.Black.copy(alpha = 0.72f),
        dragHandle = null,
        shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
    ) {
        if (localParsingState) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(vertical = 32.dp, horizontal = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(platformName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(16.dp))
                Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                Spacer(Modifier.height(36.dp))
                Text(stringResource(R.string.parsing_url), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(24.dp))
                CircularProgressIndicator(modifier = Modifier.size(44.dp), color = MaterialTheme.colorScheme.primary.copy(alpha = 0.7f), strokeWidth = 3.5.dp)
                Spacer(Modifier.height(32.dp))
            }
        } else {
            Column(
                modifier = Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 16.dp)
            ) {
                // Poster at the left, title and estimated/known size on the right. Duration is
                // overlaid on the poster rather than rendered as a second title underneath it.
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(width = 118.dp, height = 82.dp)
                            .clip(RoundedCornerShape(9.dp))
                            .background(popupThumbnailBackground),
                        contentAlignment = Alignment.Center
                    ) {
                        if (!displayThumbnail.isNullOrBlank()) {
                            AsyncImage(
                                model = displayThumbnail,
                                contentDescription = if (isImageSelection) "Image preview" else "Video thumbnail",
                                modifier = Modifier.matchParentSize(),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Icon(if (isImageSelection) Icons.Default.Image else Icons.Default.Movie, contentDescription = null, tint = popupMuted, modifier = Modifier.size(32.dp))
                        }
                        val durationLabel = displayDurationSeconds?.let(::formatDuration)
                        if (durationLabel != null) {
                            Surface(
                                modifier = Modifier.align(Alignment.BottomEnd).padding(3.dp),
                                color = Color.Black.copy(alpha = 0.82f),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    durationLabel,
                                    modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp),
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            currentTitle,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = popupText,
                            maxLines = 3,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(Modifier.height(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(if (isImageSelection) Icons.Default.Image else Icons.Default.Movie, contentDescription = null, modifier = Modifier.size(16.dp), tint = popupMuted)
                            Text(
                                formattedSize,
                                style = MaterialTheme.typography.bodySmall,
                                color = popupMuted,
                                fontWeight = FontWeight.Medium,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }

                Spacer(Modifier.height(18.dp))
                Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp)) {
                    Text(if (isImageSelection) "Image file" else "Video quality", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = popupText)
                    Spacer(Modifier.height(8.dp))
                    if (isImageSelection) {
                        Surface(
                            modifier = Modifier.fillMaxWidth().height(54.dp),
                            shape = RoundedCornerShape(10.dp),
                            color = popupSelectedBackground,
                            border = BorderStroke(1.dp, popupBlue)
                        ) {
                            Row(Modifier.padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Image, contentDescription = null, tint = popupBlue)
                                Spacer(Modifier.width(10.dp))
                                Text("Original image", color = popupText, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                                Text(formattedSize, color = popupMuted, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    } else optionList.chunked(3).forEach { rowOptions ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            rowOptions.forEach { option ->
                                val isSelected = option.url == selectedOption.url
                                val optionLabel = MediaCandidateGrouping.qualityLabel(option)
                                val optionBytes = option.contentLength?.takeIf { it > 0L }
                                    ?: option.estimatedSizeBytes?.takeIf { it > 0L }
                                val optionSize = optionBytes?.let { bytes ->
                                    val label = formatBytes(bytes)
                                    if (option.contentLength == null && option.estimatedSizeBytes != null) "≈ $label" else label
                                } ?: "Size unknown"
                                Surface(
                                    modifier = Modifier.weight(1f).height(66.dp).clickable { selectedOption = option },
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (isSelected) popupSelectedBackground else popupBackground,
                                    border = BorderStroke(
                                        width = if (isSelected) 2.dp else 1.dp,
                                        color = if (isSelected) popupBlue else popupBorder
                                    )
                                ) {
                                    Box(modifier = Modifier.fillMaxWidth()) {
                                        Column(
                                            modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 10.dp),
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                            verticalArrangement = Arrangement.Center
                                        ) {
                                            Text(
                                                optionLabel,
                                                style = MaterialTheme.typography.titleMedium,
                                                fontWeight = FontWeight.Bold,
                                                color = if (isSelected) popupBlue else popupText,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Spacer(Modifier.height(3.dp))
                                            Text(optionSize, style = MaterialTheme.typography.labelSmall, color = popupMuted, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        }
                                        if (isSelected) {
                                            Icon(Icons.Default.CheckCircle, contentDescription = "Selected quality", tint = popupBlue, modifier = Modifier.align(Alignment.TopEnd).size(18.dp))
                                        }
                                    }
                                }
                            }
                            repeat((3 - rowOptions.size).coerceAtLeast(0)) { Spacer(Modifier.weight(1f)) }
                        }
                        Spacer(Modifier.height(8.dp))
                    }

                }

                Spacer(Modifier.height(16.dp))
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.weight(1f).clickable { onDismiss() }.padding(vertical = 6.dp).testTag("media_sheet_close")
                    ) {
                        Icon(Icons.Outlined.Cancel, contentDescription = stringResource(R.string.btn_close), tint = popupMuted, modifier = Modifier.size(26.dp))
                        Spacer(Modifier.height(4.dp))
                        Text(stringResource(R.string.btn_close), style = MaterialTheme.typography.labelMedium, color = popupMuted)
                    }
                    if (!isImageSelection && enableOtherDetected) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.weight(1.25f).clickable { showOtherDetected = true }.padding(vertical = 6.dp).testTag("media_sheet_other_detected")
                        ) {
                            Icon(Icons.Default.FilterList, contentDescription = "Other Detected", tint = popupBlue, modifier = Modifier.size(26.dp))
                            Spacer(Modifier.height(4.dp))
                            Text("Other Detected", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold, color = popupBlue, textAlign = TextAlign.Center, maxLines = 2)
                        }
                    } else {
                        Spacer(Modifier.weight(1.25f))
                    }
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.weight(1f).clickable {
                            onConfirmDownload(selectedOption, currentTitle, true)
                        }.padding(vertical = 6.dp).testTag("media_sheet_download")
                    ) {
                        val downloadColor = popupBlue
                        Icon(Icons.Default.FileDownload, contentDescription = stringResource(R.string.btn_download), tint = downloadColor, modifier = Modifier.size(26.dp))
                        Spacer(Modifier.height(4.dp))
                        Text(stringResource(R.string.btn_download), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold, color = downloadColor)
                    }
                }
            }
        }
    }

    if (showOtherDetected) {
        AlertDialog(
            onDismissRequest = { showOtherDetected = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.FilterList, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Text("Other Detected")
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth().heightIn(max = 520.dp).verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("Smart filters", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                    if (filterResult.isSocialMediaBypass) {
                        Text(
                            "Smart filtering is disabled on social media. All detected streams remain available.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            style = MaterialTheme.typography.bodySmall
                        )
                    } else {
                        FilterSettingRow("Below 240p (except 144p / 180p)", filterLowResolution, { filterLowResolution = it })
                        FilterSettingRow("Duration under 3 minutes", filterShortVideos, { filterShortVideos = it })
                        FilterSettingRow("File size under 12 MB", filterSmallFiles, { filterSmallFiles = it })
                        FilterSettingRow("Prefer the video with most quality options", preferMostQualityOptions, { preferMostQualityOptions = it })
                        Text(
                            "Duration and size rules apply only when multiple videos are detected. Unknown duration or size is not treated as a match.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }

                    Divider(color = MaterialTheme.colorScheme.outlineVariant)
                    Text("Other detected videos / streams", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                    if (otherItems.isEmpty()) {
                        Text(
                            "No other streams are currently hidden. You can turn off a filter above to review more detections.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            style = MaterialTheme.typography.bodySmall
                        )
                    } else {
                        otherItems.forEach { item ->
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.surface,
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().clickable {
                                        showOtherDetected = false
                                        onSelectOtherCandidates(item.candidates)
                                    }.padding(9.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    val thumbnail = item.candidates.firstOrNull { !it.thumbnailUrl.isNullOrBlank() }?.thumbnailUrl
                                    Box(
                                        modifier = Modifier.size(width = 66.dp, height = 50.dp).clip(RoundedCornerShape(7.dp)).background(popupThumbnailBackground),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        if (!thumbnail.isNullOrBlank()) {
                                            AsyncImage(model = thumbnail, contentDescription = null, modifier = Modifier.matchParentSize(), contentScale = ContentScale.Crop)
                                        } else {
                                            Icon(Icons.Default.Movie, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    }
                                    Spacer(Modifier.width(9.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(item.title, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
                                        Spacer(Modifier.height(3.dp))
                                        Text(item.reasons.joinToString(" · "), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelSmall, maxLines = 3, overflow = TextOverflow.Ellipsis)
                                        Spacer(Modifier.height(3.dp))
                                        Text(
                                            item.candidates.map { MediaCandidateGrouping.qualityLabel(it) }.distinct().take(5).joinToString(" · "),
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            style = MaterialTheme.typography.labelSmall
                                        )
                                    }
                                    Icon(Icons.Default.FileDownload, contentDescription = "Use detected stream", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showOtherDetected = false }) { Text("Done") } }
        )
    }
}

@Composable
private fun FilterSettingRow(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth().clickable { onCheckedChange(!checked) }.padding(vertical = 1.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(checked = checked, onCheckedChange = onCheckedChange)
        Spacer(Modifier.width(4.dp))
        Text(label, color = MaterialTheme.colorScheme.onSurface, style = MaterialTheme.typography.bodySmall)
    }
}

private fun formatBytes(bytes: Long): String {
    val value: Double
    val unit: String
    when {
        bytes >= 1024L * 1024L * 1024L -> {
            value = bytes.toDouble() / (1024.0 * 1024.0 * 1024.0)
            unit = "GB"
        }
        bytes >= 1024L * 1024L -> {
            value = bytes.toDouble() / (1024.0 * 1024.0)
            unit = "MB"
        }
        bytes >= 1024L -> {
            value = bytes.toDouble() / 1024.0
            unit = "KB"
        }
        else -> return "$bytes B"
    }
    val formatted = "%.2f".format(Locale.US, value).trimEnd('0').trimEnd('.')
    return "$formatted $unit"
}

private fun formatDuration(secondsValue: Double): String {
    val seconds = secondsValue.toInt().coerceAtLeast(0)
    return if (seconds >= 3600) {
        "%d:%02d:%02d".format(Locale.US, seconds / 3600, (seconds / 60) % 60, seconds % 60)
    } else {
        "%d:%02d".format(Locale.US, seconds / 60, seconds % 60)
    }
}
