package com.mahabub.downloder.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.mahabub.downloder.MainActivity
import com.mahabub.downloder.R
import com.mahabub.downloder.db.DownloadEntity
import com.mahabub.downloder.model.DownloadStatus

class DownloadNotificationManager(private val context: Context) {

    companion object {
        const val CHANNEL_ID = "channel_media_downloads"
        const val FOREGROUND_SERVICE_NOTIF_ID = 9001
    }

    private val notificationManager =
        context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    init {
        createNotificationChannel()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                context.getString(R.string.notif_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = context.getString(R.string.notif_channel_desc)
                setShowBadge(false)
            }
            notificationManager.createNotificationChannel(channel)
        }
    }

    fun buildForegroundServiceNotification(): Notification {
        val openAppIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(context, CHANNEL_ID)
            .setContentTitle(context.getString(R.string.app_name))
            .setContentText(context.getString(R.string.notif_channel_desc))
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setSilent(true)
            .build()
    }

    fun showProgressNotification(download: DownloadEntity, speedFormatted: String) {
        val notificationId = download.id.hashCode()

        val openAppIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingOpen = PendingIntent.getActivity(
            context,
            notificationId,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Pause action
        val pauseIntent = Intent(context, DownloadService::class.java).apply {
            action = DownloadService.ACTION_PAUSE
            putExtra(DownloadService.EXTRA_TASK_ID, download.id)
        }
        val pendingPause = PendingIntent.getService(
            context,
            notificationId + 1,
            pauseIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Cancel action
        val cancelIntent = Intent(context, DownloadService::class.java).apply {
            action = DownloadService.ACTION_CANCEL
            putExtra(DownloadService.EXTRA_TASK_ID, download.id)
        }
        val pendingCancel = PendingIntent.getService(
            context,
            notificationId + 2,
            cancelIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val converting = download.status == DownloadStatus.CONVERTING
        val percent = download.progressPercent
        val statusText = if (converting) {
            "Converting ${download.fileName}…"
        } else {
            context.getString(R.string.notif_downloading, download.fileName, percent, speedFormatted)
        }

        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setContentTitle(download.fileName)
            .setContentText(statusText)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setProgress(if (converting) 0 else 100, percent, converting || percent == 0)
            .setContentIntent(pendingOpen)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
        if (!converting) {
            builder.addAction(android.R.drawable.ic_media_pause, context.getString(R.string.notif_action_pause), pendingPause)
        }
        builder.addAction(android.R.drawable.ic_menu_close_clear_cancel, context.getString(R.string.notif_action_cancel), pendingCancel)

        try {
            notificationManager.notify(notificationId, builder.build())
        } catch (_: SecurityException) {}
    }

    fun showCompletedNotification(download: DownloadEntity) {
        val notificationId = download.id.hashCode()

        val openAppIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingOpen = PendingIntent.getActivity(
            context,
            notificationId,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setContentTitle(context.getString(R.string.status_completed))
            .setContentText(context.getString(R.string.notif_completed, download.fileName))
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentIntent(pendingOpen)
            .setAutoCancel(true)
            .setOngoing(false)

        try {
            notificationManager.notify(notificationId, builder.build())
        } catch (_: SecurityException) {}
    }

    fun showFailedNotification(download: DownloadEntity, errorMsg: String) {
        val notificationId = download.id.hashCode()

        val retryIntent = Intent(context, DownloadService::class.java).apply {
            action = DownloadService.ACTION_RETRY
            putExtra(DownloadService.EXTRA_TASK_ID, download.id)
        }
        val pendingRetry = PendingIntent.getService(
            context,
            notificationId + 3,
            retryIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setContentTitle(context.getString(R.string.status_failed))
            .setContentText(errorMsg)
            .setSmallIcon(android.R.drawable.stat_notify_error)
            .setAutoCancel(true)
            .setOngoing(false)
            .addAction(android.R.drawable.ic_menu_rotate, context.getString(R.string.btn_retry), pendingRetry)

        try {
            notificationManager.notify(notificationId, builder.build())
        } catch (_: SecurityException) {}
    }

    fun cancelNotification(taskId: String) {
        notificationManager.cancel(taskId.hashCode())
    }
}
