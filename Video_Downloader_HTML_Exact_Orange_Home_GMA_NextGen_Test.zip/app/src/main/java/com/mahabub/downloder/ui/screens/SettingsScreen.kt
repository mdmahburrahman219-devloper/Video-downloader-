package com.mahabub.downloder.ui.screens

import android.app.Activity
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import com.mahabub.downloder.ui.components.LocalBottomBarContentPadding
import com.mahabub.downloder.ui.components.StaggeredEntry
import com.mahabub.downloder.ui.components.StaggeredFadeEntry
import com.mahabub.downloder.ui.viewmodel.SettingsViewModel

private data class AccentOption(val id: String, val label: String, val color: Color)

private val accentOptions = listOf(
    AccentOption("purple", "Purple", Color(0xFF7A00FF)),
    AccentOption("blue", "Blue", Color(0xFF1E70EB)),
    AccentOption("teal", "Teal", Color(0xFF007E87)),
    AccentOption("green", "Green", Color(0xFF168A58)),
    AccentOption("orange", "Orange", Color(0xFFD65C12)),
    AccentOption("rose", "Rose", Color(0xFFD33663))
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel,
    onNavigateBack: () -> Unit = {},
    onNavigateToAbout: () -> Unit = {},
    onNavigateToCustomizeHome: () -> Unit = {},
    entryAnimationKey: Any = "settings",
    isCurrentDestination: Boolean = true
) {
    val context = LocalContext.current
    val isWifiOnly by viewModel.isWifiOnly.collectAsState()
    val blockAds by viewModel.blockAds.collectAsState()
    val searchEngine by viewModel.searchEngine.collectAsState()
    val customSearchUrl by viewModel.customSearchUrl.collectAsState()
    val syncToGallery by viewModel.syncToGallery.collectAsState()
    val darkMode by viewModel.darkMode.collectAsState()
    val accentColor by viewModel.homeAccentColor.collectAsState()
    val downloadLocation by viewModel.downloadLocation.collectAsState()
    val language by viewModel.language.collectAsState()

    var showSearchEngineDialog by remember { mutableStateOf(false) }
    var showClearHistoryDialog by remember { mutableStateOf(false) }
    var showLocationDialog by remember { mutableStateOf(false) }
    var showThemeDialog by remember { mutableStateOf(false) }
    var locationInput by remember(downloadLocation) { mutableStateOf(downloadLocation) }
    var showLanguageDropdown by remember { mutableStateOf(false) }


    BackHandler { onNavigateBack() }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets(0.dp),
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("Settings", fontWeight = FontWeight.SemiBold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(top = 12.dp)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
                .padding(top = 12.dp, bottom = LocalBottomBarContentPadding.current + 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            StaggeredEntry(
                index = 0,
                animationKey = entryAnimationKey,
                enabled = isCurrentDestination
            ) {
                Column(modifier = Modifier.padding(horizontal = 4.dp)) {
                    Text("Make it yours", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Control the appearance, browser and download behavior of the app.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            SettingsSection(
                title = "Appearance",
                icon = Icons.Default.Palette,
                firstItemIndex = 1,
                animationKey = entryAnimationKey,
                animationEnabled = isCurrentDestination
            ) {
                SettingsActionRow(
                    title = "App theme",
                    subtitle = themeLabel(darkMode),
                    icon = Icons.Default.Settings,
                    onClick = { showThemeDialog = true },
                    entryIndex = 1,
                    animationKey = entryAnimationKey,
                    animationEnabled = isCurrentDestination
                )
                SectionDivider()
                SettingsActionRow(
                    title = "Customize Home",
                    subtitle = "Quick Access, recent websites and home background",
                    icon = Icons.Default.Tune,
                    onClick = onNavigateToCustomizeHome,
                    entryIndex = 2,
                    animationKey = entryAnimationKey,
                    animationEnabled = isCurrentDestination
                )
                SectionDivider()
                StaggeredEntry(
                    index = 3,
                    animationKey = entryAnimationKey,
                    enabled = isCurrentDestination
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Accent color", fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                    Text(
                        "Applied across the entire app",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        accentOptions.forEach { option ->
                            val selected = accentColor == option.id
                            Box(
                                modifier = Modifier.size(40.dp).clip(CircleShape)
                                    .clickable { viewModel.setHomeAccentColor(option.id) },
                                contentAlignment = Alignment.Center
                            ) {
                                Box(
                                    modifier = Modifier.size(if (selected) 34.dp else 30.dp)
                                        .clip(CircleShape)
                                        .background(option.color)
                                        .then(
                                            if (selected) Modifier.border(2.dp, MaterialTheme.colorScheme.onSurface, CircleShape)
                                            else Modifier
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (selected) Text("✓", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                }
                            }
                        }
                    }
                    Text(
                        accentOptions.firstOrNull { it.id == accentColor }?.label ?: "Purple",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    }
                }
            }

            SettingsSection(
                title = "Downloads",
                icon = Icons.Default.Folder,
                firstItemIndex = 4,
                animationKey = entryAnimationKey,
                animationEnabled = isCurrentDestination
            ) {
                SettingsActionRow(
                    title = "Download location",
                    subtitle = downloadLocation,
                    icon = Icons.Default.Folder,
                    onClick = {
                        locationInput = downloadLocation
                        showLocationDialog = true
                    },
                    entryIndex = 4,
                    animationKey = entryAnimationKey,
                    animationEnabled = isCurrentDestination
                )
                SectionDivider()
                SettingsSwitchRow(
                    title = "Wi-Fi only",
                    subtitle = "Wait for Wi-Fi before starting queued downloads",
                    icon = Icons.Default.Wifi,
                    checked = isWifiOnly,
                    onCheckedChange = viewModel::setWifiOnly,
                    entryIndex = 5,
                    animationKey = entryAnimationKey,
                    animationEnabled = isCurrentDestination
                )
                SectionDivider()
                SettingsSwitchRow(
                    title = "Sync to gallery",
                    subtitle = "Make completed media visible in the device gallery",
                    icon = Icons.Default.PhotoLibrary,
                    checked = syncToGallery,
                    onCheckedChange = viewModel::setSyncToGallery,
                    entryIndex = 6,
                    animationKey = entryAnimationKey,
                    animationEnabled = isCurrentDestination
                )
            }

            SettingsSection(
                title = "Browser",
                icon = Icons.Default.Security,
                firstItemIndex = 7,
                animationKey = entryAnimationKey,
                animationEnabled = isCurrentDestination
            ) {
                SettingsSwitchRow(
                    title = "Block ads and pop-ups",
                    subtitle = "Use the built-in browser filtering rules",
                    icon = Icons.Default.Shield,
                    checked = blockAds,
                    onCheckedChange = viewModel::setBlockAds,
                    entryIndex = 7,
                    animationKey = entryAnimationKey,
                    animationEnabled = isCurrentDestination
                )
                SectionDivider()
                SettingsActionRow(
                    title = "Search engine",
                    subtitle = searchEngine,
                    icon = Icons.Default.Search,
                    onClick = { showSearchEngineDialog = true },
                    entryIndex = 8,
                    animationKey = entryAnimationKey,
                    animationEnabled = isCurrentDestination
                )
                SectionDivider()
                SettingsActionRow(
                    title = "Clear cache",
                    subtitle = "Remove temporary browser web data",
                    icon = Icons.Default.CleaningServices,
                    onClick = {
                        viewModel.clearBrowserCache(context)
                        Toast.makeText(context, "Browser cache cleared", Toast.LENGTH_SHORT).show()
                    },
                    entryIndex = 9,
                    animationKey = entryAnimationKey,
                    animationEnabled = isCurrentDestination
                )
                SectionDivider()
                SettingsActionRow(
                    title = "Clear browsing history",
                    subtitle = "Remove visited pages saved by the browser",
                    icon = Icons.Default.DeleteSweep,
                    onClick = { showClearHistoryDialog = true },
                    entryIndex = 10,
                    animationKey = entryAnimationKey,
                    animationEnabled = isCurrentDestination
                )
                SectionDivider()
                SettingsActionRow(
                    title = "Clear cookies",
                    subtitle = "Sign-in sessions on websites may be removed",
                    icon = Icons.Default.Security,
                    onClick = {
                        viewModel.clearCookies()
                        Toast.makeText(context, "Cookies cleared", Toast.LENGTH_SHORT).show()
                    },
                    entryIndex = 11,
                    animationKey = entryAnimationKey,
                    animationEnabled = isCurrentDestination
                )
            }

            SettingsSection(
                title = "General",
                icon = Icons.Default.Language,
                firstItemIndex = 12,
                animationKey = entryAnimationKey,
                animationEnabled = isCurrentDestination
            ) {
                Box {
                    SettingsActionRow(
                        title = "Language",
                        subtitle = languageLabel(language),
                        icon = Icons.Default.Language,
                        trailingLabel = "Change",
                        onClick = { showLanguageDropdown = true },
                        entryIndex = 12,
                        animationKey = entryAnimationKey,
                        animationEnabled = isCurrentDestination
                    )
                    DropdownMenu(
                        expanded = showLanguageDropdown,
                        onDismissRequest = { showLanguageDropdown = false }
                    ) {
                        listOf("Default", "English", "বাংলা").forEach { option ->
                            DropdownMenuItem(
                                text = { Text(languageLabel(option)) },
                                onClick = {
                                    viewModel.setLanguage(option) { (context as? Activity)?.recreate() }
                                    showLanguageDropdown = false
                                }
                            )
                        }
                    }
                }
                SectionDivider()
                SettingsActionRow(
                    title = "About & Privacy",
                    subtitle = "App information, usage and privacy standards",
                    icon = Icons.Default.Info,
                    onClick = onNavigateToAbout,
                    entryIndex = 13,
                    animationKey = entryAnimationKey,
                    animationEnabled = isCurrentDestination
                )
            }
            Spacer(Modifier.height(10.dp))
        }
    }

    if (showSearchEngineDialog) {
        val searchEngines = listOf(
            "Custom URL", "Google", "Ask", "Bing", "Yahoo", "StartPage",
            "StartPage (Mobile)", "DuckDuckGo (Privacy)", "DuckDuckGo Lite (Privacy)",
            "Baidu (Chinese)", "Yandex (Russian)"
        )
        var selectedEngine by remember(searchEngine) { mutableStateOf(searchEngine) }
        var customUrlInput by remember(customSearchUrl) { mutableStateOf(customSearchUrl) }

        AlertDialog(
            onDismissRequest = { showSearchEngineDialog = false },
            title = { Text("Search engine", fontWeight = FontWeight.Bold) },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    searchEngines.forEach { engine ->
                        Row(
                            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                                .clickable { selectedEngine = engine }
                                .padding(vertical = 5.dp, horizontal = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(selected = selectedEngine == engine, onClick = { selectedEngine = engine })
                            Text(engine, modifier = Modifier.padding(start = 8.dp), color = MaterialTheme.colorScheme.onSurface)
                        }
                    }
                    if (selectedEngine == "Custom URL") {
                        OutlinedTextField(
                            value = customUrlInput,
                            onValueChange = { customUrlInput = it },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            label = { Text("Custom search URL") },
                            placeholder = { Text("https://example.com/search?q=%s") },
                            supportingText = { Text("Use %s as the search query placeholder.") }
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (selectedEngine == "Custom URL") {
                        val customValue = customUrlInput.trim()
                        val valid = customValue.contains("%s") && runCatching {
                            val candidate = java.net.URI(customValue.replace("%s", "query"))
                            candidate.scheme in listOf("https", "http") && !candidate.host.isNullOrBlank()
                        }.getOrDefault(false)
                        if (!valid) {
                            Toast.makeText(context, "Enter a valid URL containing %s", Toast.LENGTH_LONG).show()
                            return@TextButton
                        }
                        viewModel.setCustomSearchUrl(customValue)
                    }
                    viewModel.setSearchEngine(selectedEngine)
                    showSearchEngineDialog = false
                }) { Text("Save", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold) }
            },
            dismissButton = { TextButton(onClick = { showSearchEngineDialog = false }) { Text("Cancel") } }
        )
    }

    if (showClearHistoryDialog) {
        AlertDialog(
            onDismissRequest = { showClearHistoryDialog = false },
            title = { Text("Clear browsing history?") },
            text = { Text("This removes the saved list of visited pages. Bookmarks and downloaded files are not affected.") },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.clearBrowserHistory()
                    showClearHistoryDialog = false
                    Toast.makeText(context, "History cleared", Toast.LENGTH_SHORT).show()
                }) { Text("Clear history", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { showClearHistoryDialog = false }) { Text("Cancel") } }
        )
    }

    if (showThemeDialog) {
        val themeOptions = listOf(
            "system" to "System default",
            "light" to "Light",
            "normal_dark" to "Normal dark",
            "amoled" to "AMOLED black"
        )
        AlertDialog(
            onDismissRequest = { showThemeDialog = false },
            title = { Text("App theme") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    themeOptions.forEach { (value, label) ->
                        Row(
                            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                                .clickable { viewModel.setDarkMode(value); showThemeDialog = false }
                                .padding(vertical = 6.dp, horizontal = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = darkMode == value || (value == "amoled" && darkMode == "dark"),
                                onClick = { viewModel.setDarkMode(value); showThemeDialog = false }
                            )
                            Text(label, modifier = Modifier.padding(start = 8.dp), color = MaterialTheme.colorScheme.onSurface)
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showThemeDialog = false }) { Text("Done") } }
        )
    }

    if (showLocationDialog) {
        AlertDialog(
            onDismissRequest = { showLocationDialog = false },
            title = { Text("Download location") },
            text = {
                OutlinedTextField(
                    value = locationInput,
                    onValueChange = { locationInput = it.take(512) },
                    singleLine = true,
                    label = { Text("Storage path") },
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    if (locationInput.isNotBlank()) {
                        viewModel.setDownloadLocation(locationInput.trim())
                        Toast.makeText(context, "Download location saved", Toast.LENGTH_SHORT).show()
                    }
                    showLocationDialog = false
                }) { Text("Save", color = MaterialTheme.colorScheme.primary) }
            },
            dismissButton = { TextButton(onClick = { showLocationDialog = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun SettingsSection(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    firstItemIndex: Int,
    animationKey: Any,
    animationEnabled: Boolean,
    content: @Composable () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp)) {
            StaggeredFadeEntry(
                firstItemIndex = firstItemIndex,
                animationKey = animationKey,
                enabled = animationEnabled
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier.size(34.dp).clip(RoundedCornerShape(11.dp))
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.10f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(19.dp))
                    }
                    Text(
                        title,
                        modifier = Modifier.padding(start = 11.dp),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
            Spacer(Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
private fun SettingsActionRow(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    trailingLabel: String? = null,
    onClick: () -> Unit,
    entryIndex: Int = 8,
    animationKey: Any = "settings",
    animationEnabled: Boolean = true
) {
    StaggeredEntry(
        index = entryIndex,
        animationKey = animationKey,
        enabled = animationEnabled
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick)
                .padding(vertical = 10.dp, horizontal = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(21.dp))
            Column(modifier = Modifier.weight(1f).padding(start = 12.dp, end = 8.dp)) {
                Text(title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
                Text(
                    subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
            if (trailingLabel != null) {
                Text(trailingLabel, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
            }
            Icon(Icons.Default.ArrowForwardIos, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.65f), modifier = Modifier.padding(start = 7.dp).size(13.dp))
        }
    }
}

@Composable
private fun SettingsSwitchRow(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    entryIndex: Int = 8,
    animationKey: Any = "settings",
    animationEnabled: Boolean = true
) {
    StaggeredEntry(
        index = entryIndex,
        animationKey = animationKey,
        enabled = animationEnabled
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(21.dp))
            Column(modifier = Modifier.weight(1f).padding(start = 12.dp, end = 8.dp)) {
                Text(title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Switch(checked = checked, onCheckedChange = onCheckedChange)
        }
    }
}

@Composable
private fun SectionDivider() {
    Spacer(Modifier.height(2.dp))
    Box(Modifier.fillMaxWidth().height(1.dp).background(MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.75f)))
    Spacer(Modifier.height(2.dp))
}

private fun themeLabel(mode: String): String = when (mode.lowercase()) {
    "light" -> "Light theme"
    "normal_dark", "dark_grey", "dark_normal" -> "Normal dark theme"
    "amoled", "dark" -> "AMOLED black theme"
    else -> "Follow system theme"
}

private fun languageLabel(language: String): String = when (language) {
    "বাংলা" -> "বাংলা (Bengali)"
    "English" -> "English"
    else -> "System default"
}
