package com.mahabub.downloder.extractor

import android.webkit.CookieManager
import okhttp3.OkHttp
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.util.UUID
import java.util.regex.Pattern

object ExtractorUtils {
    const val USER_AGENT = "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36"

    fun buildRequest(
        url: String,
        referer: String? = null,
        userAgent: String = USER_AGENT
    ): Request {
        val builder = Request.Builder()
            .url(url)
            .header("User-Agent", userAgent.ifBlank { USER_AGENT })
            .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")

        if (referer != null) {
            builder.header("Referer", referer)
        }

        try {
            val cookies = CookieManager.getInstance().getCookie(url)
            if (!cookies.isNullOrBlank()) {
                builder.header("Cookie", cookies)
            }
        } catch (_: Exception) {}

        return builder.build()
    }

    fun extractMetaTag(html: String, property: String): String? {
        val pattern1 = Pattern.compile("<meta\\s+property=[\"']${Pattern.quote(property)}[\"']\\s+content=[\"']([^\"']+)[\"']", Pattern.CASE_INSENSITIVE)
        val matcher1 = pattern1.matcher(html)
        if (matcher1.find()) return matcher1.group(1)?.unescapeHtml()

        val pattern2 = Pattern.compile("<meta\\s+content=[\"']([^\"']+)[\"']\\s+property=[\"']${Pattern.quote(property)}[\"']", Pattern.CASE_INSENSITIVE)
        val matcher2 = pattern2.matcher(html)
        if (matcher2.find()) return matcher2.group(1)?.unescapeHtml()

        val pattern3 = Pattern.compile("<meta\\s+name=[\"']${Pattern.quote(property)}[\"']\\s+content=[\"']([^\"']+)[\"']", Pattern.CASE_INSENSITIVE)
        val matcher3 = pattern3.matcher(html)
        if (matcher3.find()) return matcher3.group(1)?.unescapeHtml()

        return null
    }

    fun extractTitle(html: String): String? {
        val ogTitle = extractMetaTag(html, "og:title")
        if (!ogTitle.isNullOrBlank()) return ogTitle

        val titlePattern = Pattern.compile("<title>([^<]+)</title>", Pattern.CASE_INSENSITIVE)
        val matcher = titlePattern.matcher(html)
        if (matcher.find()) {
            return matcher.group(1)?.trim()?.unescapeHtml()
        }
        return null
    }

    fun String.unescapeHtml(): String {
        return this.replace("&amp;", "&")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&quot;", "\"")
            .replace("&#39;", "'")
            .replace("\\u0026", "&")
            .replace("\\/", "/")
    }

    fun imageMimeType(url: String): String {
        val path = runCatching { java.net.URI(url).path.orEmpty() }.getOrDefault("").lowercase()
        return when (path.substringAfterLast('.', "")) {
            "png" -> "image/png"
            "webp" -> "image/webp"
            "gif" -> "image/gif"
            "avif" -> "image/avif"
            "bmp" -> "image/bmp"
            else -> "image/jpeg"
        }
    }

    fun generateMediaId(): String = UUID.randomUUID().toString()
}
