package com.mahabub.downloder.browser

/**
 * Tiny TikTok-only playback gate. It does not inspect media URLs, patch page APIs, or start any
 * download work. It confirms actual HTML video timeline progress before phase two can begin.
 */
object TikTokPlaybackObserverScript {
    val JAVASCRIPT = """
        (function () {
            'use strict';
            try {
                var host = String(location.hostname || '').toLowerCase();
                if (host !== 'tiktok.com' && !host.endsWith('.tiktok.com')) return;
            } catch (e) { return; }

            if (window.__vdTikTokPlaybackObserverInstalled) return;
            window.__vdTikTokPlaybackObserverInstalled = true;
            window.__vdTikTokPlaybackConfirmed = false;

            var watched = typeof WeakSet === 'function' ? new WeakSet() : null;
            var pending = typeof WeakSet === 'function' ? new WeakSet() : null;

            function isActuallyPlaying(video) {
                try {
                    return !!video && !video.paused && !video.ended &&
                        video.readyState >= 2 && isFinite(video.currentTime) && video.currentTime > 0.08;
                } catch (e) { return false; }
            }

            function confirmPlayback(video) {
                if (!isActuallyPlaying(video) || window.__vdTikTokPlaybackConfirmed) return;
                window.__vdTikTokPlaybackConfirmed = true;
                window.__vdTikTokPostPlaybackEnabled = true;
                try {
                    var bridge = window.AndroidMediaBridge;
                    if (bridge && typeof bridge.onTikTokPlaybackStarted === 'function') {
                        bridge.onTikTokPlaybackStarted(String(location.href || ''));
                    }
                } catch (e) {}
            }

            function scheduleConfirmation(video) {
                if (!video || window.__vdTikTokPlaybackConfirmed) return;
                try {
                    if (pending && pending.has(video)) return;
                    if (pending) pending.add(video);
                    var initialTime = Number(video.currentTime) || 0;
                    setTimeout(function () {
                        if (pending) pending.delete(video);
                        // Require actual timeline progress, not just a queued `playing` event.
                        var currentTime = Number(video.currentTime) || 0;
                        if (isActuallyPlaying(video) && currentTime > initialTime + 0.04) {
                            confirmPlayback(video);
                        }
                    }, 650);
                } catch (e) {}
            }

            function watchVideo(video) {
                if (!video || String(video.tagName || '').toUpperCase() !== 'VIDEO') return;
                try {
                    if (watched && watched.has(video)) return;
                    if (watched) watched.add(video);
                    video.addEventListener('playing', function () { scheduleConfirmation(video); }, true);
                    video.addEventListener('timeupdate', function () { scheduleConfirmation(video); }, true);
                    video.addEventListener('loadeddata', function () { scheduleConfirmation(video); }, true);
                } catch (e) {}
                if (isActuallyPlaying(video)) scheduleConfirmation(video);
            }

            function scanVideos(root) {
                try {
                    var scope = root && root.querySelectorAll ? root : document;
                    if (scope.matches && scope.matches('video')) watchVideo(scope);
                    var videos = scope.querySelectorAll ? scope.querySelectorAll('video') : [];
                    for (var i = 0; i < Math.min(videos.length, 80); i++) watchVideo(videos[i]);
                } catch (e) {}
            }

            try {
                document.addEventListener('playing', function (event) {
                    if (event && event.target) watchVideo(event.target);
                    scheduleConfirmation(event && event.target);
                }, true);
                document.addEventListener('timeupdate', function (event) {
                    if (event && event.target) scheduleConfirmation(event.target);
                }, true);
                scanVideos(document);
                if (window.MutationObserver && document.documentElement) {
                    var observer = new MutationObserver(function (mutations) {
                        for (var i = 0; i < mutations.length; i++) {
                            var nodes = mutations[i].addedNodes || [];
                            for (var j = 0; j < nodes.length; j++) scanVideos(nodes[j]);
                        }
                    });
                    observer.observe(document.documentElement, { childList: true, subtree: true });
                }
                // Catch a player that begins immediately before this observer is attached.
                setTimeout(function () { scanVideos(document); }, 900);
                setTimeout(function () { scanVideos(document); }, 2400);
            } catch (e) {}
        })();
    """.trimIndent()
}
