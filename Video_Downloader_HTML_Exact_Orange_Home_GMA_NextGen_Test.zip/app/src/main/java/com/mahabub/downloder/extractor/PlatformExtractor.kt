package com.mahabub.downloder.extractor

import com.mahabub.downloder.model.MediaCandidate
import com.mahabub.downloder.model.PlatformSource

interface PlatformExtractor {
    val platform: PlatformSource
    fun matches(url: String): Boolean
    suspend fun extract(url: String): MediaCandidate?

    /** Allows the active WebView UA to be reused for signed-in first-party page requests. */
    suspend fun extract(url: String, userAgentOverride: String?): MediaCandidate? = extract(url)
}
