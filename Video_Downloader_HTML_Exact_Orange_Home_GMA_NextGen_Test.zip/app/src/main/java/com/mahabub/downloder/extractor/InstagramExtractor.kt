package com.mahabub.downloder.extractor

import android.webkit.CookieManager
import com.mahabub.downloder.model.MediaCandidate
import com.mahabub.downloder.model.PlatformSource
import okhttp3.OkHttpClient
import java.io.ByteArrayOutputStream
import java.net.URI
import java.nio.charset.StandardCharsets
import java.util.Locale

/**
 * Instagram page metadata extractor.
 *
 * This only reads the page URL explicitly provided by the user and parses media URLs that the
 * returned public/authorized HTML already exposes. It does not call private endpoints, rotate
 * identities, evade rate limits, or bypass login/access controls.
 */
class InstagramExtractor(private val okHttpClient: OkHttpClient) : PlatformExtractor {
    override val platform: PlatformSource = PlatformSource.INSTAGRAM

    override fun matches(url: String): Boolean {
        val uri = runCatching { URI(url) }.getOrNull() ?: return false
        if (!uri.scheme.equals("https", true) && !uri.scheme.equals("http", true)) return false
        if (!isInstagramHost(uri.host.orEmpty())) return false
        val segments = uri.path.orEmpty().split('/').filter { it.isNotBlank() }.map { it.lowercase(Locale.ROOT) }
        return segments.firstOrNull() in SUPPORTED_ROUTES ||
            (segments.firstOrNull() == "share" && segments.size >= 2)
    }

    override suspend fun extract(url: String): MediaCandidate? = extract(url, null)

    override suspend fun extract(url: String, userAgentOverride: String?): MediaCandidate? {
        if (!matches(url)) return null

        return try {
            // Keep the request in sync with the user's own WebView session when the user has
            // already authenticated there. CookieManager only returns cookies scoped to this URL.
            runCatching { CookieManager.getInstance().flush() }
            val ua = userAgentOverride?.takeIf { it.isNotBlank() } ?: ExtractorUtils.USER_AGENT
            val request = ExtractorUtils.buildRequest(url = url, referer = url, userAgent = ua)

            okHttpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return null

                val finalUrl = response.request.url
                if (!isInstagramHost(finalUrl.host)) return null
                val finalPath = finalUrl.encodedPath.lowercase(Locale.ROOT)
                // Do not parse login, checkpoint, or challenge interstitials as media pages.
                if (finalPath.contains("/accounts/login") || finalPath.contains("/challenge") ||
                    finalPath.contains("/checkpoint")) return null

                val contentType = response.header("Content-Type")
                    ?.substringBefore(';')?.trim()?.lowercase(Locale.ROOT).orEmpty()
                if (contentType.isNotBlank() && contentType !in HTML_CONTENT_TYPES) return null

                val body = response.body ?: return null
                val html = body.byteStream().use { input -> readBoundedUtf8(input, MAX_HTML_BYTES) } ?: return null
                if (!looksLikeHtml(html) || isAuthenticationInterstitial(html)) return null

                MetaMediaPageParser.extract(html, finalUrl.toString(), platform, ua)
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun isInstagramHost(host: String): Boolean {
        val normalized = host.lowercase(Locale.ROOT).trimEnd('.')
        return normalized == "instagram.com" || normalized.endsWith(".instagram.com") ||
            normalized == "instagr.am" || normalized.endsWith(".instagr.am")
    }

    private fun readBoundedUtf8(input: java.io.InputStream, maxBytes: Int): String? {
        val output = ByteArrayOutputStream(minOf(maxBytes, 32 * 1024))
        val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
        var total = 0
        while (true) {
            val read = input.read(buffer)
            if (read < 0) break
            total += read
            if (total > maxBytes) return null
            output.write(buffer, 0, read)
        }
        return output.toByteArray().toString(StandardCharsets.UTF_8)
    }

    private fun looksLikeHtml(value: String): Boolean {
        val prefix = value.trimStart().take(512).lowercase(Locale.ROOT)
        return prefix.startsWith("<!doctype html") || prefix.startsWith("<html") ||
            prefix.startsWith("<head") || prefix.startsWith("<meta") || prefix.startsWith("<!doctype")
    }

    private fun isAuthenticationInterstitial(html: String): Boolean {
        val prefix = html.take(500_000).lowercase(Locale.ROOT)
        return prefix.contains("action=\"/accounts/login") ||
            prefix.contains("action='/accounts/login") ||
            prefix.contains("challenge_required") ||
            prefix.contains("checkpoint_required") ||
            prefix.contains("<form id=\"loginform\"")
    }

    private companion object {
        const val MAX_HTML_BYTES = 5 * 1024 * 1024
        val HTML_CONTENT_TYPES = setOf("text/html", "application/xhtml+xml")
        val SUPPORTED_ROUTES = setOf("p", "reel", "reels", "tv", "stories")
    }
}
