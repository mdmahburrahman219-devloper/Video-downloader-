package com.mahabub.downloder.ui.theme

import androidx.compose.ui.graphics.Color

// Product brand palette. Keep this as the single source of truth for the default accent.
// Primary brand purple: #7A00FF.
val BrandBlue = Color(0xFF7A00FF)
val BrandBlueDark = Color(0xFF4B00B3)
val BrandBlueLight = Color(0xFFB388FF)
val BrandBlueContainer = Color(0xFFF0E5FF)
val BrandBlueOnContainer = Color(0xFF2E075E)

// Semantic status colors. Red is reserved for errors and destructive actions.
val AccentRed = Color(0xFFE5484D)
val AccentRedContainer = Color(0xFFFFE8E8)

// Informational warning surface. Keep the warmer tone subtle and theme-independent.
val PeachBackground = Color(0xFFFFF2EC)
val PeachOnBackground = Color(0xFF442014)
val PeachIcon = Color(0xFFE66A3D)

// Player timeline accent.
val PlayerGreen = Color(0xFF16A765)

// Light theme: a soft neutral canvas with clean white cards.
val LightBg = Color(0xFFF7F6FA)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceSubtle = Color(0xFFF4F2F8)
val LightCardBg = Color(0xFFF0EEF4)
val LightBorder = Color(0xFFE6E2EC)
val LightTextPrimary = Color(0xFF19171F)
val LightTextSecondary = Color(0xFF686471)
val LightTextTertiary = Color(0xFF92909B)

// Normal dark theme: elevated charcoal surfaces with readable separation.
val DarkBg = Color(0xFF121116)
val DarkSurface = Color(0xFF1D1B23)
val DarkSurfaceSubtle = Color(0xFF24212B)
val DarkCardBg = Color(0xFF2B2833)
val DarkBorder = Color(0xFF403B49)
val DarkTextPrimary = Color(0xFFF5F2FA)
val DarkTextSecondary = Color(0xFFB8B3C1)
val DarkTextTertiary = Color(0xFF898491)

// AMOLED mode: true black canvas with subtly elevated near-black surfaces.
val AmoledBg = Color(0xFF000000)
val AmoledSurface = Color(0xFF000000)
val AmoledSurfaceSubtle = Color(0xFF08070B)
val AmoledCardBg = Color(0xFF101014)
val AmoledBorder = Color(0xFF29252F)
