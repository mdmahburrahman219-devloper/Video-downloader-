package com.mahabub.downloder.model

import java.net.URI
import java.util.Locale

/** User-configurable rules used only on non-social websites. */
data class SmartFilterSettings(
    val filterLowResolution: Boolean = true,
    val filterShortVideos: Boolean = true,
    val filterSmallFiles: Boolean = true,
    val preferMostQualityOptions: Boolean = true
)

/** An item kept out of the main result list, with a human-readable explanation. */
data class SmartFilteredItem(
    val title: String,
    val candidates: List<MediaCandidate>,
    val reasons: List<String>
)

data class SmartMediaFilterResult(
    val visibleGroups: List<MediaVideoGroup>,
    val filteredItems: List<SmartFilteredItem>,
    val isSocialMediaBypass: Boolean,
    val hadMultipleVideoGroups: Boolean
)

/**
 * Heuristic ad/stream filtering for ordinary web pages. Social platforms bypass every rule.
 * Unknown duration/size values are not treated as proof that an item is an ad.
 */
object SmartMediaFilter {
    private const val THREE_MINUTES_SECONDS = 180.0
    private const val TWELVE_MIB_BYTES = 12L * 1024L * 1024L

    private val socialPlatforms = setOf(
        PlatformSource.INSTAGRAM,
        PlatformSource.TIKTOK,
        PlatformSource.FACEBOOK,
        PlatformSource.TWITTER_X,
        PlatformSource.PINTEREST,
        PlatformSource.REDDIT,
        PlatformSource.THREADS
    )

    private val socialDomains = setOf(
        "facebook.com", "fb.watch", "instagram.com", "tiktok.com",
        "twitter.com", "x.com", "pinterest.com", "pin.it", "reddit.com",
        "redd.it", "threads.net", "threads.com", "youtube.com", "youtu.be", "vimeo.com",
        "dailymotion.com", "twitch.tv", "kick.com", "bilibili.com", "snapchat.com",
        "linkedin.com", "tumblr.com", "vk.com", "weibo.com"
    )

    fun apply(
        candidates: List<MediaCandidate>,
        pageUrl: String? = null,
        settings: SmartFilterSettings = SmartFilterSettings()
    ): SmartMediaFilterResult {
        val uniqueCandidates = candidates.distinctBy { canonicalUrl(it.url) }
        if (uniqueCandidates.isEmpty()) {
            return SmartMediaFilterResult(emptyList(), emptyList(), isSocialMediaBypass = false, hadMultipleVideoGroups = false)
        }

        // Include all raw detections here. Rules below, rather than the old generic ad flag,
        // decide what belongs in the main list. On social sites nothing is hidden by these rules.
        val originalGroups = MediaCandidateGrouping.group(uniqueCandidates, includeLikelyAds = true)
        val isSocial = isSocialMediaPage(pageUrl, uniqueCandidates)
        if (isSocial) {
            return SmartMediaFilterResult(
                visibleGroups = originalGroups,
                filteredItems = emptyList(),
                isSocialMediaBypass = true,
                hadMultipleVideoGroups = originalGroups.size > 1
            )
        }

        val multipleVideosOnPage = originalGroups.size > 1
        val hasNonAdCandidate = uniqueCandidates.any { !it.isLikelyAd }
        val filtered = mutableListOf<SmartFilteredItem>()
        val resolutionEligibleGroups = mutableListOf<MediaVideoGroup>()

        // Resolution filtering is applied to quality options on generic web pages, even when only
        // one logical video was detected. 144p and 180p are explicit exceptions.
        originalGroups.forEach { group ->
            // Preserve the detector's existing advert signal, but only hide it when a page also
            // exposes at least one candidate not marked as an advert. If everything is flagged,
            // do not blank the entire result list on a false positive.
            if (multipleVideosOnPage && hasNonAdCandidate && group.candidates.all { it.isLikelyAd }) {
                filtered += SmartFilteredItem(
                    title = group.title,
                    candidates = group.candidates.map { it.copy(title = group.title) },
                    reasons = listOf("Marked as a probable advert by stream heuristics")
                )
                return@forEach
            }
            val lowResolution = if (settings.filterLowResolution) {
                group.candidates.filter { isDisallowedLowResolution(it) }
            } else emptyList()
            lowResolution.forEach { option ->
                filtered += SmartFilteredItem(
                    title = "${group.title} · ${MediaCandidateGrouping.qualityLabel(option)}",
                    candidates = listOf(option.copy(title = group.title)),
                    reasons = listOf("Resolution below 240p (except 144p and 180p)")
                )
            }

            val allowed = group.candidates.filterNot { candidate -> lowResolution.any { it.url == candidate.url } }
            if (allowed.isNotEmpty()) {
                val sorted = allowed.sortedWith(
                    compareByDescending<MediaCandidate> { MediaCandidateGrouping.qualityRank(it) }
                        .thenByDescending { it.isPlaying }
                        .thenByDescending { it.detectionConfidence }
                        .thenByDescending { it.contentLength ?: it.estimatedSizeBytes ?: 0L }
                )
                resolutionEligibleGroups += group.copy(candidates = sorted, primary = sorted.first())
            }
        }

        // Duration and file-size heuristics only apply when the page exposed multiple logical
        // video groups. For a group of quality variants, size is the largest known variant size;
        // a tiny 240p variant must not cause an otherwise full-length video to be discarded.
        val durationAndSizeEligible = mutableListOf<MediaVideoGroup>()
        resolutionEligibleGroups.forEach { group ->
            val reasons = mutableListOf<String>()
            if (multipleVideosOnPage && settings.filterShortVideos) {
                val duration = group.candidates.mapNotNull { it.durationSeconds?.takeIf { value -> value > 0.0 } }.maxOrNull()
                if (duration != null && duration < THREE_MINUTES_SECONDS) {
                    reasons += "Duration under 3 minutes"
                }
            }
            if (multipleVideosOnPage && settings.filterSmallFiles) {
                val largestKnownSize = group.candidates.mapNotNull { candidate ->
                    candidate.contentLength?.takeIf { it > 0L }
                        ?: candidate.estimatedSizeBytes?.takeIf { it > 0L }
                }.maxOrNull()
                if (largestKnownSize != null && largestKnownSize < TWELVE_MIB_BYTES) {
                    reasons += "File size below 12 MB"
                }
            }

            if (reasons.isEmpty()) {
                durationAndSizeEligible += group
            } else {
                filtered += SmartFilteredItem(
                    title = group.title,
                    candidates = group.candidates.map { it.copy(title = group.title) },
                    reasons = reasons
                )
            }
        }

        var visibleGroups: List<MediaVideoGroup> = durationAndSizeEligible.toList()
        if (multipleVideosOnPage && settings.preferMostQualityOptions && durationAndSizeEligible.size > 1) {
            val ranked = durationAndSizeEligible.sortedWith(
                compareByDescending<MediaVideoGroup> { qualityOptionCount(it) }
                    .thenByDescending { it.primary.isPlaying }
                    .thenByDescending { it.primary.detectionConfidence }
                    .thenByDescending { it.primary.detectedAt }
            )
            val first = ranked.first()
            val firstCount = qualityOptionCount(first)
            val runnerUpCount = ranked.getOrNull(1)?.let(::qualityOptionCount) ?: 0

            // A uniquely largest group with at least two distinct quality options becomes the
            // primary video. Ties remain available; filtered alternatives can be recovered below.
            if (firstCount >= 2 && firstCount > runnerUpCount) {
                ranked.drop(1).forEach { group ->
                    filtered += SmartFilteredItem(
                        title = group.title,
                        candidates = group.candidates.map { it.copy(title = group.title) },
                        reasons = listOf("Fewer quality options than the primary video")
                    )
                }
                visibleGroups = listOf(first)
            } else {
                visibleGroups = ranked
            }
        } else {
            visibleGroups = visibleGroups.sortedWith(
                compareByDescending<MediaVideoGroup> { qualityOptionCount(it) }
                    .thenByDescending { it.primary.isPlaying }
                    .thenByDescending { it.primary.detectionConfidence }
                    .thenByDescending { it.primary.detectedAt }
            )
        }

        return SmartMediaFilterResult(
            visibleGroups = visibleGroups,
            filteredItems = deduplicateFilteredItems(filtered),
            isSocialMediaBypass = false,
            hadMultipleVideoGroups = multipleVideosOnPage
        )
    }

    /** Applies the resolution rule to late-resolved quality options inside the download popup. */
    fun filterLowResolutionOptions(
        candidates: List<MediaCandidate>,
        pageUrl: String?,
        enabled: Boolean
    ): List<MediaCandidate> {
        if (!enabled || isSocialMediaPage(pageUrl, candidates)) return candidates
        return candidates.filterNot(::isDisallowedLowResolution)
    }

    /** All excluded candidates plus any alternate groups not currently selected by the user. */
    fun otherDetectedItems(
        result: SmartMediaFilterResult,
        selectedCandidates: List<MediaCandidate>
    ): List<SmartFilteredItem> {
        val selectedUrls = selectedCandidates.map { canonicalUrl(it.url) }.toSet()
        val items = mutableListOf<SmartFilteredItem>()
        items += result.filteredItems

        result.visibleGroups.forEach { group ->
            val hasSelectedOption = group.candidates.any { canonicalUrl(it.url) in selectedUrls }
            val hasUnselectedOption = group.candidates.any { canonicalUrl(it.url) !in selectedUrls }
            if (!hasSelectedOption) {
                items += SmartFilteredItem(
                    title = group.title,
                    candidates = group.candidates.map { it.copy(title = group.title) },
                    reasons = listOf("Other detected video")
                )
            } else if (hasUnselectedOption) {
                items += SmartFilteredItem(
                    title = group.title,
                    candidates = group.candidates.map { it.copy(title = group.title) },
                    reasons = listOf("Additional stream options")
                )
            }
        }
        return deduplicateFilteredItems(items)
    }

    fun qualityOptionCount(group: MediaVideoGroup): Int = group.candidates
        .map { MediaCandidateGrouping.qualityLabel(it).trim().lowercase(Locale.ROOT) }
        .filter { label -> label.isNotBlank() && label != "auto" && label != "original" && label != "audio" }
        .distinct()
        .size

    private fun isDisallowedLowResolution(candidate: MediaCandidate): Boolean {
        // Inspect this source's filename first: resolution metadata can come from the active
        // <video> element and therefore describe a different variant than the candidate URL.
        val fileName = runCatching { URI(candidate.url).path.orEmpty().substringAfterLast('/') }
            .getOrDefault("")
        val filenameHeight = Regex("(?i)(?:^|[-_.])(\\d{2,4})p(?=$|[-_.])").find(fileName)
            ?.groupValues?.getOrNull(1)?.toIntOrNull()
        val filenameDimensionsHeight = Regex("(?i)(?:^|[-_.])\\d{2,5}x(\\d{2,5})(?=$|[-_.])")
            .find(fileName)?.groupValues?.getOrNull(1)?.toIntOrNull()
        val height = filenameHeight ?: filenameDimensionsHeight ?: candidate.qualityLabel?.trim()?.let { rawLabel ->
            Regex("(?i)^(\\d{2,4})p$").matchEntire(rawLabel)
                ?.groupValues?.getOrNull(1)?.toIntOrNull()
        } ?: candidate.resolution?.let { resolution ->
            Regex("(?i)^\\d{2,5}x(\\d{2,5})$").matchEntire(resolution.trim())
                ?.groupValues?.getOrNull(1)?.toIntOrNull()
        } ?: return false
        return height < 240 && height != 144 && height != 180
    }

    private fun isSocialMediaPage(pageUrl: String?, candidates: List<MediaCandidate>): Boolean {
        if (candidates.any { it.sourcePlatform in socialPlatforms }) return true
        val pageUrls = buildList {
            pageUrl?.takeIf { it.isNotBlank() }?.let(::add)
            candidates.mapNotNull { it.sourcePageUrl?.takeIf(String::isNotBlank) }.forEach(::add)
        }
        return pageUrls.any { isSocialUrl(it) }
    }

    private fun isSocialUrl(url: String): Boolean {
        val host = runCatching { URI(url).host.orEmpty().lowercase(Locale.ROOT).removePrefix("www.") }
            .getOrDefault("")
        return socialDomains.any { domain -> host == domain || host.endsWith(".$domain") }
    }

    private fun deduplicateFilteredItems(items: List<SmartFilteredItem>): List<SmartFilteredItem> {
        val result = LinkedHashMap<String, SmartFilteredItem>()
        items.forEach { item ->
            val urls = item.candidates.map { canonicalUrl(it.url) }.distinct().sorted().joinToString("|")
            val key = "$urls::${item.reasons.sorted().joinToString(";")}"
            val old = result[key]
            if (old == null) result[key] = item
        }
        return result.values.toList()
    }

    private fun canonicalUrl(url: String): String = url.trim().substringBefore('#')
}
