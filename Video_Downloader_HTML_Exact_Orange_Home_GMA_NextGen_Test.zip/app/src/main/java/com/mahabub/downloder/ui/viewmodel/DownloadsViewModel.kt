package com.mahabub.downloder.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.mahabub.downloder.AppContainer
import com.mahabub.downloder.db.DownloadEntity
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class DownloadsViewModel(private val container: AppContainer) : ViewModel() {

    val activeDownloads: StateFlow<List<DownloadEntity>> = container.downloadRepository.activeDownloads
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val failedDownloads: StateFlow<List<DownloadEntity>> = container.downloadRepository.failedDownloads
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun pauseDownload(id: String) {
        viewModelScope.launch {
            container.downloadRepository.pauseDownload(id)
        }
    }

    fun resumeDownload(id: String) {
        viewModelScope.launch {
            container.downloadRepository.resumeDownload(id)
        }
    }

    fun cancelDownload(id: String) {
        viewModelScope.launch {
            container.downloadRepository.cancelDownload(id)
        }
    }

    fun retryDownload(id: String) {
        viewModelScope.launch {
            container.downloadRepository.retryDownload(id)
        }
    }

    fun deleteDownload(id: String) {
        viewModelScope.launch {
            container.downloadRepository.deleteDownload(id, deleteFile = true)
        }
    }

    fun pauseAll() {
        viewModelScope.launch {
            container.downloadRepository.pauseAll()
        }
    }

    fun resumeAll() {
        viewModelScope.launch {
            container.downloadRepository.resumeAll()
        }
    }

    class Factory(private val container: AppContainer) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return DownloadsViewModel(container) as T
        }
    }
}
