package com.mahabub.downloder.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColorScheme = lightColorScheme(
    primary = BrandBlue,
    onPrimary = Color.White,
    primaryContainer = BrandBlueContainer,
    onPrimaryContainer = BrandBlueOnContainer,
    secondary = BrandBlue,
    onSecondary = Color.White,
    background = LightBg,
    onBackground = LightTextPrimary,
    surface = LightSurface,
    onSurface = LightTextPrimary,
    surfaceVariant = LightCardBg,
    onSurfaceVariant = LightTextSecondary,
    outline = LightBorder,
    outlineVariant = LightBorder,
    error = AccentRed,
    onError = Color.White,
    errorContainer = AccentRedContainer,
    onErrorContainer = Color(0xFF6F171B)
)

private val DarkColorScheme = darkColorScheme(
    primary = BrandBlueLight,
    onPrimary = Color(0xFF26004D),
    primaryContainer = BrandBlueDark,
    onPrimaryContainer = Color(0xFFF3E9FF),
    secondary = BrandBlueLight,
    onSecondary = Color(0xFF26004D),
    background = DarkBg,
    onBackground = DarkTextPrimary,
    surface = DarkSurface,
    onSurface = DarkTextPrimary,
    surfaceVariant = DarkCardBg,
    onSurfaceVariant = DarkTextSecondary,
    outline = DarkBorder,
    outlineVariant = DarkBorder,
    error = Color(0xFFFF8A8A),
    onError = Color(0xFF4B0005),
    errorContainer = Color(0xFF641B20),
    onErrorContainer = Color(0xFFFFDAD7)
)

private val AmoledColorScheme = darkColorScheme(
    primary = BrandBlueLight,
    onPrimary = Color(0xFF26004D),
    primaryContainer = Color(0xFF27123F),
    onPrimaryContainer = Color(0xFFF0E2FF),
    secondary = BrandBlueLight,
    onSecondary = Color(0xFF26004D),
    background = AmoledBg,
    onBackground = DarkTextPrimary,
    surface = AmoledSurface,
    onSurface = DarkTextPrimary,
    surfaceVariant = AmoledCardBg,
    onSurfaceVariant = DarkTextSecondary,
    outline = AmoledBorder,
    outlineVariant = AmoledBorder,
    error = Color(0xFFFF8A8A),
    onError = Color(0xFF4B0005),
    errorContainer = Color(0xFF641B20),
    onErrorContainer = Color(0xFFFFDAD7)
)

@Composable
fun VideoDownloaderTheme(
    themeMode: String = "system",
    dynamicColor: Boolean = false,
    accentColor: String = "purple",
    content: @Composable () -> Unit
) {
    // System dark mode intentionally resolves to AMOLED. Normal Dark remains an
    // explicit choice so users can select elevated charcoal surfaces when desired.
    val isSystemDark = isSystemInDarkTheme()
    val resolvedMode = when (themeMode.lowercase()) {
        "light" -> "light"
        "normal_dark", "dark_grey", "dark_normal" -> "normal_dark"
        "amoled", "dark" -> "amoled" // Preserve the legacy 'dark' preference.
        else -> if (isSystemDark) "amoled" else "light"
    }
    val isDark = resolvedMode != "light"
    val isAmoled = resolvedMode == "amoled"

    val accent = when (accentColor.lowercase()) {
        "blue" -> AccentPalette(Color(0xFF1E70EB), Color(0xFF76A8FF), Color(0xFFE8F1FE), Color(0xFF1558B0), Color(0xFF0F3B7A))
        "purple" -> AccentPalette(BrandBlue, BrandBlueLight, BrandBlueContainer, BrandBlueDark, BrandBlueOnContainer)
        "teal" -> AccentPalette(Color(0xFF007E87), Color(0xFF66D5DC), Color(0xFFDDF5F5), Color(0xFF005D64), Color(0xFF003F44))
        "green" -> AccentPalette(Color(0xFF168A58), Color(0xFF65D6A0), Color(0xFFDDF5E8), Color(0xFF116341), Color(0xFF0B472E))
        "orange" -> AccentPalette(Color(0xFFD65C12), Color(0xFFFFB27B), Color(0xFFFFEFE1), Color(0xFF91410D), Color(0xFF63300C))
        "rose" -> AccentPalette(Color(0xFFD33663), Color(0xFFFF93AF), Color(0xFFFFE5EC), Color(0xFF941C42), Color(0xFF64102A))
        else -> AccentPalette(BrandBlue, BrandBlueLight, BrandBlueContainer, BrandBlueDark, BrandBlueOnContainer)
    }

    val baseScheme = when {
        !isDark -> LightColorScheme
        isAmoled -> AmoledColorScheme
        else -> DarkColorScheme
    }
    val colorScheme = baseScheme.copy(
        primary = if (isDark) accent.light else accent.primary,
        onPrimary = if (isDark) Color(0xFF240044) else Color.White,
        secondary = if (isDark) accent.light else accent.primary,
        onSecondary = if (isDark) Color(0xFF240044) else Color.White,
        primaryContainer = if (isDark) accent.dark else accent.container,
        onPrimaryContainer = if (isDark) Color.White else accent.onContainer
    )

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

private data class AccentPalette(
    val primary: Color,
    val light: Color,
    val container: Color,
    val dark: Color,
    val onContainer: Color
)
