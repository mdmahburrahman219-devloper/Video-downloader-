package com.mahabub.downloder.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Mirrors the reference demo: only the first eight content items receive the staggered motion. */
const val MAX_STAGGERED_ENTRY_ITEMS = 8
private const val ITEM_DURATION_MS = 520
private const val ITEM_STAGGER_MS = 80L
private const val ITEM_RISE_DP = 16f
private const val LABEL_DELAY_MS = 240L
private const val LABEL_DURATION_MS = 500

/**
 * Fades an item in while it rises 16dp. The item index controls a 40ms stagger.
 * Change [animationKey] whenever the owning destination is entered again.
 */
@Composable
fun StaggeredEntry(
    index: Int,
    animationKey: Any,
    enabled: Boolean,
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    val shouldAnimate = enabled && index in 0 until MAX_STAGGERED_ENTRY_ITEMS
    val alpha = remember(animationKey, index, shouldAnimate) {
        Animatable(if (shouldAnimate) 0f else 1f)
    }
    val translationY = remember(animationKey, index, shouldAnimate) {
        Animatable(if (shouldAnimate) ITEM_RISE_DP else 0f)
    }

    LaunchedEffect(animationKey, index, shouldAnimate) {
        if (shouldAnimate) {
            delay(index * ITEM_STAGGER_MS)
            coroutineScope {
                launch {
                    alpha.animateTo(
                        targetValue = 1f,
                        animationSpec = tween(ITEM_DURATION_MS, easing = FastOutSlowInEasing)
                    )
                }
                launch {
                    translationY.animateTo(
                        targetValue = 0f,
                        animationSpec = tween(ITEM_DURATION_MS, easing = FastOutSlowInEasing)
                    )
                }
            }
        } else {
            alpha.snapTo(1f)
            translationY.snapTo(0f)
        }
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .graphicsLayer {
                this.alpha = alpha.value
                this.translationY = translationY.value.dp.toPx()
            },
        content = content
    )
}

/** Section captions fade in 120ms after their first associated item begins entering. */
@Composable
fun StaggeredFadeEntry(
    firstItemIndex: Int,
    animationKey: Any,
    enabled: Boolean,
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    val shouldAnimate = enabled
    val alpha = remember(animationKey, firstItemIndex, shouldAnimate) {
        Animatable(if (shouldAnimate) 0f else 1f)
    }

    LaunchedEffect(animationKey, firstItemIndex, shouldAnimate) {
        if (shouldAnimate) {
            val cappedIndex = firstItemIndex.coerceIn(0, MAX_STAGGERED_ENTRY_ITEMS)
            delay(cappedIndex * ITEM_STAGGER_MS + LABEL_DELAY_MS)
            alpha.animateTo(
                targetValue = 1f,
                animationSpec = tween(LABEL_DURATION_MS, easing = FastOutSlowInEasing)
            )
        } else {
            alpha.snapTo(1f)
        }
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .graphicsLayer { this.alpha = alpha.value },
        content = content
    )
}
