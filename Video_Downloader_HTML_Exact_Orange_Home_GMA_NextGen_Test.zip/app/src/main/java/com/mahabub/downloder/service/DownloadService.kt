package com.mahabub.downloder.service

import android.app.Service
import android.content.Intent
import android.os.IBinder
import com.mahabub.downloder.VideoDownloaderApp
import com.mahabub.downloder.db.DownloadEntity
import com.mahabub.downloder.extractor.ExtractorUtils
import com.mahabub.downloder.extractor.InlineDashManifestStore
import com.mahabub.downloder.downloader.HlsDownloader
import com.mahabub.downloder.downloader.HttpDownloader
import com.mahabub.downloder.model.AppError
import com.mahabub.downloder.model.DownloadStatus
import com.mahabub.downloder.model.StreamType
import com.mahabub.downloder.model.PlatformSource
import com.mahabub.downloder.storage.MediaMetadataUtils
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.io.File
import java.util.concurrent.ConcurrentHashMap

class DownloadService : Service() {

    companion object {
        const val ACTION_START =
            "com.mahabub.downloder.ACTION_START"

        const val ACTION_PAUSE =
            "com.mahabub.downloder.ACTION_PAUSE"

        const val ACTION_RESUME =
            "com.mahabub.downloder.ACTION_RESUME"

        const val ACTION_CANCEL =
            "com.mahabub.downloder.ACTION_CANCEL"

        const val ACTION_RETRY =
            "com.mahabub.downloder.ACTION_RETRY"

        const val EXTRA_TASK_ID = "extra_task_id"
    }

    private val serviceScope =
        CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val activeJobs =
        ConcurrentHashMap<String, Job>()

    private lateinit var notificationManager: DownloadNotificationManager
    private lateinit var httpDownloader: HttpDownloader
    private lateinit var hlsDownloader: HlsDownloader

    override fun onCreate() {
        super.onCreate()

        notificationManager = DownloadNotificationManager(this)

        val app = application as VideoDownloaderApp

        httpDownloader = HttpDownloader(
            app.container.okHttpClient
        )

        hlsDownloader = HlsDownloader(
            app.container.okHttpClient
        )

        startForeground(
            DownloadNotificationManager.FOREGROUND_SERVICE_NOTIF_ID,
            notificationManager.buildForegroundServiceNotification()
        )
    }

    override fun onStartCommand(
        intent: Intent?,
        flags: Int,
        startId: Int
    ): Int {

        val taskId = intent?.getStringExtra(EXTRA_TASK_ID)
        val action = intent?.action

        if (taskId.isNullOrBlank() || action == null) {
            stopSelf(startId)
            return START_NOT_STICKY
        }

        when (action) {
            ACTION_START,
            ACTION_RESUME,
            ACTION_RETRY -> {
                startDownloadTask(taskId)
            }

            ACTION_PAUSE -> {
                pauseDownloadTask(taskId)
            }

            ACTION_CANCEL -> {
                cancelDownloadTask(taskId)
            }
        }

        return START_NOT_STICKY
    }

    /**
     * Starts at most one coroutine for each task ID.
     *
     * A lazy coroutine is registered before it starts.
     * This prevents the job map from containing a task
     * whose coroutine has already completed.
     */
    private fun startDownloadTask(taskId: String) {
        val app = application as VideoDownloaderApp

        var downloadForError: DownloadEntity? = null

        val job = serviceScope.launch(
            start = CoroutineStart.LAZY
        ) {
            val downloadDao =
                app.container.database.downloadDao()

            try {
                val download =
                    downloadDao.getDownloadById(taskId)
                        ?: return@launch

                downloadForError = download

                // Enforce the Wi-Fi-only preference.
                val wifiOnly =
                    app.container.preferenceManager
                        .isWifiOnly.first()

                if (
                    wifiOnly &&
                    !app.container.downloadRepository.isWifiConnected()
                ) {
                    downloadDao.updateStatus(
                        taskId,
                        DownloadStatus.WAITING_FOR_NETWORK
                    )

                    notificationManager.cancelNotification(taskId)

                    return@launch
                }

                downloadDao.updateStatus(
                    taskId,
                    DownloadStatus.DOWNLOADING
                )

                when (download.streamType) {

                    StreamType.PROGRESSIVE -> {
                        executeHttpTask(download)
                    }

                    StreamType.HLS -> {
                        executeHlsTask(download)
                    }

                    // Temporarily disabled: keep the implementation in the project, but
                    // do not create corrupt/partial files while DASH is being investigated.
                    // Progressive and HLS downloads remain unchanged.
                    StreamType.DASH -> throw AppError.UnsupportedMedia

                    StreamType.UNSUPPORTED_PROTECTED -> {
                        throw AppError.ProtectedMedia
                    }
                }

            } catch (ce: CancellationException) {
                notificationManager.cancelNotification(taskId)

            } catch (e: AppError) {
                handleDownloadFailure(
                    taskId = taskId,
                    error = e,
                    fallback = downloadForError
                )

            } catch (e: Exception) {
                handleDownloadFailure(
                    taskId = taskId,
                    error = AppError.UnknownError(e),
                    fallback = downloadForError
                )

            } finally {
                // Remove only this coroutine's own entry.
                // It must not remove a newer job for the same task.
                val currentJob =
                    currentCoroutineContext()[Job]

                if (currentJob != null) {
                    activeJobs.remove(taskId, currentJob)
                }

                checkIdleAndTriggerNext()
            }
        }

        val previousJob = activeJobs.putIfAbsent(
            taskId,
            job
        )

        if (previousJob != null) {
            job.cancel()
            return
        }

        job.start()
    }

    /**
     * Records a failed download and displays its notification.
     */
    private suspend fun handleDownloadFailure(
        taskId: String,
        error: AppError,
        fallback: DownloadEntity?
    ) {
        val app = application as VideoDownloaderApp
        val downloadDao = app.container.database.downloadDao()
        val existing = downloadDao.getDownloadById(taskId) ?: fallback

        if (existing == null) {
            notificationManager.cancelNotification(taskId)
            return
        }

        val errorMessage = if (
            existing.sourcePlatform == com.mahabub.downloder.model.PlatformSource.TIKTOK &&
            error is AppError.Forbidden
        ) {
            "TikTok/CDN rejected the selected media request (HTTP 403). Reopen the public video, let it play, and detect a fresh stream; some restricted or expired media URLs cannot be downloaded."
        } else {
            error.getUserFriendlyMessage(this@DownloadService)
        }

        downloadDao.markFailed(taskId, errorMessage)

        val updated = downloadDao.getDownloadById(taskId)
            ?: existing.copy(
                status = DownloadStatus.FAILED,
                errorMessage = errorMessage
            )

        notificationManager.showFailedNotification(updated, errorMessage)
    }

    /**
     * Perform the selected media request once. TikTok page extraction/refresh is intentionally
     * disabled; a denied or expired stream is reported instead of invoking a native TikTok extractor.
     */
    private suspend fun executeHttpTask(download: DownloadEntity) {
        executeHttpTaskOnce(download)
    }

    /** Performs one HTTP attempt and saves the completed file only after the transfer succeeds. */
    private suspend fun executeHttpTaskOnce(
        download: DownloadEntity
    ) {
        val app = application as VideoDownloaderApp

        val downloadDao =
            app.container.database.downloadDao()

        val storageManager =
            app.container.storageManager

        val isPrivate =
            app.container.preferenceManager
                .isPrivateDownloads.first()
        val syncToGallery = app.container.preferenceManager.syncToGallery.first()
        val downloadLocation = app.container.preferenceManager.downloadLocation.first()
        val downloadFolderTreeUri = app.container.preferenceManager.downloadFolderTreeUri.first()

        val tempFile = storageManager.createTempFile(download.id)

        val completedTempFile = httpDownloader.download(
            url = download.sourceUrl,
            tempFile = tempFile,
            userAgent = download.userAgent?.takeIf { it.isNotBlank() } ?: ExtractorUtils.USER_AGENT,
            referer = download.referer?.takeIf { it.isNotBlank() } ?: download.sourcePageUrl,
            cachedEtag = download.etag,

            onProgress = {
                    downloadedBytes,
                    totalBytes,
                    speedBytesPerSec ->

                downloadDao.updateProgress(
                    download.id,
                    downloadedBytes,
                    totalBytes,
                    speedBytesPerSec
                )

                val current = download.copy(
                    downloadedBytes = downloadedBytes,
                    totalBytes = totalBytes,
                    speedBytesPerSec = speedBytesPerSec
                )

                notificationManager.showProgressNotification(
                    current,
                    formatSpeed(speedBytesPerSec)
                )
            }
        )

        // Capture the real final file size before StorageManager moves/copies the temp file.
        val actualFileSizeBytes = completedTempFile.length()
        val actualDurationMs = MediaMetadataUtils.durationMs(completedTempFile)
        val localUri = storageManager.saveCompletedMedia(
            sourceFile = completedTempFile,
            desiredFileName = download.fileName,
            mimeType = download.mimeType,
            isPrivate = isPrivate,
            syncToGallery = syncToGallery,
            downloadLocation = downloadLocation,
            downloadFolderTreeUri = downloadFolderTreeUri
        )

        downloadDao.markCompleted(
            download.id,
            localUri,
            actualFileSizeBytes = actualFileSizeBytes,
            durationMs = actualDurationMs
        )

        val finalItem =
            downloadDao.getDownloadById(download.id)
                ?: download

        notificationManager.cancelNotification(
            download.id
        )

        notificationManager.showCompletedNotification(
            finalItem
        )
    }

    /**
     * Downloads an HLS playlist and remuxes its segments.
     */
    private suspend fun executeHlsTask(
        download: DownloadEntity
    ) {
        val app = application as VideoDownloaderApp

        val downloadDao =
            app.container.database.downloadDao()

        val storageManager =
            app.container.storageManager

        val isPrivate =
            app.container.preferenceManager
                .isPrivateDownloads.first()
        val syncToGallery = app.container.preferenceManager.syncToGallery.first()
        val downloadLocation = app.container.preferenceManager.downloadLocation.first()
        val downloadFolderTreeUri = app.container.preferenceManager.downloadFolderTreeUri.first()

        val preferredQuality =
            app.container.preferenceManager
                .preferredQuality.first()

        // A playlist's estimated size is not a real Content-Length. Clear it while
        // downloading HLS so the UI never shows a fabricated total such as 0.00/10.00 MB.
        downloadDao.updateSegmentProgress(download.id, 0, 0, 0L, 0L)

        val tempDir = storageManager.createHlsTempDir(
            download.id
        )

        val outputMp4File = File(
            tempDir.parentFile,
            "${download.id}_remuxed.mp4"
        )

        hlsDownloader.download(
            manifestUrl = download.sourceUrl,
            tempDir = tempDir,
            outputMp4File = outputMp4File,
            preferredQuality = preferredQuality,
            audioPlaylistUrl = download.hlsAudioPlaylistUrl,
            referer = download.referer ?: download.sourcePageUrl,
            userAgent = download.userAgent,
            useWebViewCookies = download.sourcePlatform in setOf(
                PlatformSource.FACEBOOK, PlatformSource.INSTAGRAM, PlatformSource.THREADS
            ),

            onProgress = {
                    completedSegments,
                    totalSegments,
                    downloadedBytes,
                    speedBytesPerSec ->

                downloadDao.updateSegmentProgress(
                    download.id,
                    completedSegments,
                    totalSegments,
                    downloadedBytes,
                    speedBytesPerSec
                )

                val current = download.copy(
                    completedSegments = completedSegments,
                    totalSegments = totalSegments,
                    downloadedBytes = downloadedBytes,
                    speedBytesPerSec = speedBytesPerSec
                )

                notificationManager.showProgressNotification(
                    current,
                    formatSpeed(speedBytesPerSec)
                )
            },
            onConverting = {
                downloadDao.updateStatus(download.id, DownloadStatus.CONVERTING)
                val convertingItem = download.copy(
                    status = DownloadStatus.CONVERTING,
                    speedBytesPerSec = 0L
                )
                notificationManager.showProgressNotification(convertingItem, "Converting…")
            }
        )

        // The exact remuxed MP4 size and its media-metadata duration are available only after muxing.
        val actualFileSizeBytes = outputMp4File.length()
        val actualDurationMs = MediaMetadataUtils.durationMs(outputMp4File)
        val localUri = storageManager.saveCompletedMedia(
            sourceFile = outputMp4File,
            desiredFileName = download.fileName,
            mimeType = "video/mp4",
            isPrivate = isPrivate,
            syncToGallery = syncToGallery,
            downloadLocation = downloadLocation,
            downloadFolderTreeUri = downloadFolderTreeUri
        )

        downloadDao.markCompleted(
            download.id,
            localUri,
            actualFileSizeBytes = actualFileSizeBytes,
            durationMs = actualDurationMs
        )

        val finalItem =
            downloadDao.getDownloadById(download.id)
                ?: download

        notificationManager.cancelNotification(
            download.id
        )

        notificationManager.showCompletedNotification(
            finalItem
        )
    }

    private suspend fun executeDashTask(download: DownloadEntity) {
        val app = application as VideoDownloaderApp
        val downloadDao = app.container.database.downloadDao()
        val storageManager = app.container.storageManager
        val isPrivate = app.container.preferenceManager.isPrivateDownloads.first()
        val syncToGallery = app.container.preferenceManager.syncToGallery.first()
        val downloadLocation = app.container.preferenceManager.downloadLocation.first()
        val downloadFolderTreeUri = app.container.preferenceManager.downloadFolderTreeUri.first()
        val preferredQuality = app.container.preferenceManager.preferredQuality.first()

        downloadDao.updateSegmentProgress(download.id, 0, 0, 0L, 0L)
        val tempDir = storageManager.createHlsTempDir(download.id)
        val outputMp4File = File(tempDir.parentFile, "${download.id}_dash_remuxed.mp4")

        val inlineDashRecord = InlineDashManifestStore.read(applicationContext, download.sourceUrl)
        val inlineDashSelection = InlineDashManifestStore.selection(download.sourceUrl)
        val effectiveManifestUrl = inlineDashRecord?.manifestBaseUrl ?: download.sourceUrl

        hlsDownloader.downloadDash(
            manifestUrl = effectiveManifestUrl,
            tempDir = tempDir,
            outputMp4File = outputMp4File,
            preferredQuality = preferredQuality,
            referer = download.referer ?: download.sourcePageUrl,
            userAgent = download.userAgent,
            useWebViewCookies = download.sourcePlatform in setOf(
                PlatformSource.FACEBOOK, PlatformSource.INSTAGRAM, PlatformSource.THREADS
            ),
            onProgress = { completedSegments, totalSegments, downloadedBytes, speedBytesPerSec ->
                downloadDao.updateSegmentProgress(
                    download.id, completedSegments, totalSegments, downloadedBytes, speedBytesPerSec
                )
                val current = download.copy(
                    completedSegments = completedSegments,
                    totalSegments = totalSegments,
                    downloadedBytes = downloadedBytes,
                    speedBytesPerSec = speedBytesPerSec
                )
                notificationManager.showProgressNotification(current, formatSpeed(speedBytesPerSec))
            },
            onConverting = {
                downloadDao.updateStatus(download.id, DownloadStatus.CONVERTING)
                notificationManager.showProgressNotification(
                    download.copy(status = DownloadStatus.CONVERTING, speedBytesPerSec = 0L),
                    "Converting…"
                )
            },
            inlineManifestText = inlineDashRecord?.manifestText,
            selectedVideoRepresentationIndex = inlineDashSelection.videoRepresentationIndex,
            selectedAudioRepresentationIndex = inlineDashSelection.audioRepresentationIndex,
            audioOnly = inlineDashSelection.audioOnly
        )

        val actualFileSizeBytes = outputMp4File.length()
        val actualDurationMs = MediaMetadataUtils.durationMs(outputMp4File)
        val localUri = storageManager.saveCompletedMedia(
            sourceFile = outputMp4File,
            desiredFileName = download.fileName,
            mimeType = "video/mp4",
            isPrivate = isPrivate,
            syncToGallery = syncToGallery,
            downloadLocation = downloadLocation,
            downloadFolderTreeUri = downloadFolderTreeUri
        )
        downloadDao.markCompleted(
            download.id,
            localUri,
            actualFileSizeBytes = actualFileSizeBytes,
            durationMs = actualDurationMs
        )
        InlineDashManifestStore.delete(applicationContext, download.sourceUrl)
        val finalItem = downloadDao.getDownloadById(download.id) ?: download
        notificationManager.cancelNotification(download.id)
        notificationManager.showCompletedNotification(finalItem)
    }

    private fun pauseDownloadTask(taskId: String) {
        val job = activeJobs.remove(taskId)

        job?.cancel()

        notificationManager.cancelNotification(taskId)

        serviceScope.launch {
            val app = application as VideoDownloaderApp

            app.container.database.downloadDao()
                .updateStatus(
                    taskId,
                    DownloadStatus.PAUSED
                )

            checkIdleAndTriggerNext()
        }
    }

    private fun cancelDownloadTask(taskId: String) {
        val job = activeJobs.remove(taskId)

        job?.cancel()

        notificationManager.cancelNotification(taskId)

        serviceScope.launch {
            val app = application as VideoDownloaderApp

            app.container.database.downloadDao()
                .updateStatus(
                    taskId,
                    DownloadStatus.CANCELED
                )

            checkIdleAndTriggerNext()
        }
    }

    /**
     * Continues queued downloads and stops the service when idle.
     */
    private fun checkIdleAndTriggerNext() {
        val app = application as VideoDownloaderApp

        serviceScope.launch {
            val repository =
                app.container.downloadRepository

            val downloadDao =
                app.container.database.downloadDao()

            repository.checkAndTriggerQueue()

            if (activeJobs.isEmpty()) {
                val currentlyDownloading =
                    downloadDao.getCurrentlyDownloading()

                val queuedDownloads =
                    downloadDao.getQueuedDownloads()

                if (
                    currentlyDownloading.isEmpty() &&
                    queuedDownloads.isEmpty()
                ) {
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelf()
                }
            }
        }
    }

    private fun formatSpeed(bytesPerSec: Long): String {
        return when {
            bytesPerSec >= 1024L * 1024L ->
                "%.1f MB/s".format(
                    bytesPerSec.toDouble() / (1024L * 1024L)
                )

            bytesPerSec >= 1024L ->
                "%.1f KB/s".format(
                    bytesPerSec.toDouble() / 1024L
                )

            else ->
                "$bytesPerSec B/s"
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        serviceScope.cancel()
        super.onDestroy()
    }
}