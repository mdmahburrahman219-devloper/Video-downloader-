package com.mahabub.downloder.extractor

import com.mahabub.downloder.model.MediaCandidate
import com.mahabub.downloder.model.MediaDetectionSource
import com.mahabub.downloder.model.PlatformSource
import com.mahabub.downloder.model.StreamType
import java.net.URI
import java.util.regex.Pattern

/**
 * Conservative parser for media URLs already present in a Meta page response.
 * It does not call private endpoints, replay signatures, bypass access controls, or decrypt streams.
 */
internal object MetaMediaPageParser {
    private data class UrlHit(val url: String, val key: String, val rank: Int)

    private val commonVideoKeys = listOf(
        "playable_url_quality_hd", "browser_native_hd_url", "video_dash_manifest_url",
        "video_dash_manifest", "dash_manifest_url", "hls_manifest_url", "hls_url",
        "playable_url", "video_url", "videoUrl", "playback_url", "video_url_original",
        "post_video_url", "video_playable_url", "player_video_url", "play_addr", "playAddr",
        "download_url", "download_addr", "manifest_url", "video_manifest_url"
    )

    fun extract(
        html: String,
        pageUrl: String,
        platform: PlatformSource,
        userAgent: String = ExtractorUtils.USER_AGENT
    ): MediaCandidate? {
        if (html.isBlank() || html.length > MAX_HTML_CHARS) return null
        val title = ExtractorUtils.extractTitle(html)?.takeIf { it.isNotBlank() } ?: defaultTitle(platform)
        val poster = sequenceOf(
            ExtractorUtils.extractMetaTag(html, "og:image:secure_url"),
            ExtractorUtils.extractMetaTag(html, "og:image"),
            ExtractorUtils.extractMetaTag(html, "twitter:image")
        ).firstOrNull { isHttpUrl(it) }

        val hits = LinkedHashMap<String, UrlHit>()
        fun add(raw: String?, key: String, rank: Int) {
            val clean = normalizeMediaUrl(raw) ?: return
            val stream = streamTypeFor(clean, key)
            // DASH is currently paused app-wide. Do not let a high-ranked MPD hide an
            // available MP4/HLS alternative in this single-candidate page parser.
            if (stream == null || stream == StreamType.DASH) return
            if (platform == PlatformSource.INSTAGRAM && !isAllowedInstagramMediaHost(clean)) return
            val previous = hits[clean]
            if (previous == null || rank > previous.rank) hits[clean] = UrlHit(clean, key, rank)
        }

        add(ExtractorUtils.extractMetaTag(html, "og:video:secure_url"), "og:video:secure_url", 95)
        add(ExtractorUtils.extractMetaTag(html, "og:video"), "og:video", 94)
        add(ExtractorUtils.extractMetaTag(html, "og:video:url"), "og:video:url", 93)
        add(ExtractorUtils.extractMetaTag(html, "twitter:player:stream"), "twitter:player:stream", 85)

        // Native media elements and preload declarations that are present in server-rendered markup.
        collectAttribute(html, "video", listOf("src", "data-src", "data-video-src"), hits)
        collectAttribute(html, "source", listOf("src", "data-src"), hits)
        collectExplicitVideoDataAttributes(html, hits)
        collectVideoJsonLd(html, hits)
        collectLinkPreloads(html, hits)

        val keys = keysFor(platform)
        val escapedKeyList = keys.joinToString("|") { Pattern.quote(it) }
        val jsonPair = Pattern.compile(
            "[\\\"']($escapedKeyList)[\\\"']\\s*:\\s*[\\\"']((?:\\\\.|[^\\\"'\\\\]){8,8192})[\\\"']",
            Pattern.CASE_INSENSITIVE
        )
        val matcher = jsonPair.matcher(html)
        var inspected = 0
        while (matcher.find() && inspected++ < MAX_JSON_HITS) {
            val key = matcher.group(1).orEmpty()
            val value = matcher.group(2).orEmpty()
            add(value, key, rankForKey(key))
        }

        // `video_versions` / `video_resources` are arrays of video objects. Only inspect their
        // bounded local JSON windows; do not treat arbitrary page `url` fields as media.
        collectVideoVersionObjects(html, "video_versions", hits)
        collectVideoVersionObjects(html, "video_resources", hits)

        val selected = hits.values
            .asSequence()
            // Helper collectors also write hits directly, so enforce the app-wide DASH pause
            // and Instagram CDN host boundary at the final selection point as well.
            .filter { streamTypeFor(it.url, it.key) != StreamType.DASH }
            .filter { platform != PlatformSource.INSTAGRAM || isAllowedInstagramMediaHost(it.url) }
            .sortedWith(
                // Prefer a single-file progressive stream, then HLS. Rank is a secondary
                // signal: a manifest field must never outrank an available direct MP4.
                compareByDescending<UrlHit> { typePreference(streamTypeFor(it.url, it.key)) }
                    .thenByDescending { it.rank }
            )
            .firstOrNull()

        if (selected != null) {
            val streamType = streamTypeFor(selected.url, selected.key) ?: StreamType.PROGRESSIVE
            val mime = when (streamType) {
                StreamType.HLS -> "application/vnd.apple.mpegurl"
                StreamType.DASH -> "application/dash+xml"
                else -> "video/mp4"
            }
            return MediaCandidate(
                id = ExtractorUtils.generateMediaId(),
                url = selected.url,
                title = title,
                mimeType = mime,
                sourcePageUrl = pageUrl,
                sourcePlatform = platform,
                referer = pageUrl,
                userAgent = userAgent,
                streamType = streamType,
                thumbnailUrl = poster,
                isDirectDownload = streamType == StreamType.PROGRESSIVE,
                detectionSource = MediaDetectionSource.EXTRACTOR,
                detectionConfidence = minOf(98, selected.rank)
            )
        }

        // User-approved fallback policy: after no video source is exposed in the page response,
        // a specific Story/Reel/video route may return its page thumbnail as an image candidate.
        // This deliberately does not substitute another post's media URL.
        if (isVideoOrStoryRoute(pageUrl, html) && isHttpUrl(poster)) {
            return MediaCandidate(
                id = ExtractorUtils.generateMediaId(),
                url = poster!!,
                title = "$title thumbnail",
                mimeType = ExtractorUtils.imageMimeType(poster),
                sourcePageUrl = pageUrl,
                sourcePlatform = platform,
                referer = pageUrl,
                userAgent = userAgent,
                streamType = StreamType.PROGRESSIVE,
                isDirectDownload = true,
                detectionSource = MediaDetectionSource.EXTRACTOR,
                detectionConfidence = 35
            )
        }
        return null
    }

    private fun keysFor(platform: PlatformSource): List<String> = when (platform) {
        PlatformSource.FACEBOOK -> commonVideoKeys + listOf(
            "browser_native_sd_url", "playable_url_sd", "video_hd_url", "video_sd_url",
            "dash_manifest", "hls_manifest", "video_playable_url", "sd_src", "hd_src",
            "progressive_url", "video_manifest_url", "manifest_url"
        )
        PlatformSource.INSTAGRAM -> commonVideoKeys + listOf(
            "video_versions", "video_resources", "video_dash_manifest", "video_hls_manifest",
            "clips_music_attribution_info", "media_url", "video_playable_url", "play_addr",
            "download_url", "progressive_url", "manifest_url"
        )
        PlatformSource.THREADS -> commonVideoKeys + listOf(
            "video_versions", "video_resources", "video_dash_manifest", "video_hls_manifest",
            "media_url", "playback_url", "video_playable_url", "play_addr", "download_url",
            "progressive_url", "manifest_url"
        )
        else -> commonVideoKeys
    }.distinct()

    private fun rankForKey(key: String): Int = when (key.lowercase()) {
        "playable_url_quality_hd", "browser_native_hd_url", "video_hd_url" -> 100
        "video_dash_manifest_url", "video_dash_manifest", "dash_manifest_url", "dash_manifest" -> 90
        "hls_manifest_url", "hls_url", "video_hls_manifest" -> 88
        "playable_url", "video_url", "videourl", "playback_url", "video_url_original", "post_video_url" -> 82
        "browser_native_sd_url", "playable_url_sd", "video_sd_url" -> 70
        "twitter:player:stream" -> 65
        else -> 60
    }

    private fun typePreference(type: StreamType?): Int = when (type) {
        StreamType.PROGRESSIVE -> 3
        StreamType.HLS -> 2
        StreamType.DASH -> 0
        else -> 0
    }

    private fun isAllowedInstagramMediaHost(rawUrl: String): Boolean = runCatching {
        val host = URI(rawUrl).host.orEmpty().lowercase()
        listOf("instagram.com", "instagr.am", "cdninstagram.com", "fbcdn.net", "fbsbx.com")
            .any { host == it || host.endsWith(".$it") }
    }.getOrDefault(false)

    private fun streamTypeFor(url: String, key: String): StreamType? {
        val normalizedKey = key.lowercase()
        val pathAndQuery = url.lowercase()
        val path = runCatching { URI(url).path.orEmpty().lowercase() }.getOrDefault("")
        val imageExtension = path.substringAfterLast('.', "") in setOf("jpg", "jpeg", "png", "webp", "gif", "avif", "bmp", "heic")
        return when {
            pathAndQuery.contains(".m3u8") || normalizedKey.contains("hls") -> StreamType.HLS
            pathAndQuery.contains(".mpd") || normalizedKey.contains("dash") -> StreamType.DASH
            isHttpUrl(url) && !imageExtension -> StreamType.PROGRESSIVE
            else -> null
        }
    }

    private fun collectAttribute(
        html: String,
        tag: String,
        attributes: List<String>,
        hits: MutableMap<String, UrlHit>
    ) {
        val tagPattern = Pattern.compile("<$tag\\b([^>]{0,5000})>", Pattern.CASE_INSENSITIVE)
        val tags = tagPattern.matcher(html)
        var count = 0
        while (tags.find() && count++ < 120) {
            val attrs = tags.group(1).orEmpty()
            for (attribute in attributes) {
                val value = attributeValue(attrs, attribute) ?: continue
                val clean = normalizeMediaUrl(value) ?: continue
                if (streamTypeFor(clean, attribute) == null) continue
                val rank = when (attribute) { "src" -> 78; else -> 68 }
                hits[clean] = UrlHit(clean, attribute, rank)
            }
        }
    }

    /** Explicit video data attributes commonly used by lazy-loaded player shells. */
    private fun collectExplicitVideoDataAttributes(html: String, hits: MutableMap<String, UrlHit>) {
        val pattern = Pattern.compile("<[a-z][^>]{0,5000}>", Pattern.CASE_INSENSITIVE)
        val matcher = pattern.matcher(html)
        var count = 0
        val attributes = listOf(
            "data-video-url", "data-video-src", "data-playback-url", "data-mp4",
            "data-m3u8", "data-hls", "data-mpd", "data-dash"
        )
        while (matcher.find() && count++ < 800) {
            val attrs = matcher.group().orEmpty()
            for (attribute in attributes) {
                val raw = attributeValue(attrs, attribute) ?: continue
                val clean = normalizeMediaUrl(raw) ?: continue
                if (streamTypeFor(clean, attribute) == null) continue
                val rank = when {
                    attribute.contains("m3u8", true) || attribute.contains("hls", true) -> 89
                    attribute.contains("mpd", true) || attribute.contains("dash", true) -> 89
                    else -> 76
                }
                hits[clean] = UrlHit(clean, attribute, rank)
            }
        }
    }

    /** Read only VideoObject contentUrl fields from JSON-LD script blocks. */
    private fun collectVideoJsonLd(html: String, hits: MutableMap<String, UrlHit>) {
        val scripts = Pattern.compile(
            """<script\b[^>]*type=["']application/ld\+json["'][^>]*>(.*?)</script>""",
            Pattern.CASE_INSENSITIVE or Pattern.DOTALL
        ).matcher(html)
        var count = 0
        while (scripts.find() && count++ < 40) {
            val json = scripts.group(1).orEmpty().take(500_000)
            if (!json.contains("VideoObject", true)) continue
            val contentUrl = Pattern.compile(
                """["']contentUrl["']\s*:\s*["']((?:\\.|[^"'\\]){8,8192})["']""",
                Pattern.CASE_INSENSITIVE
            ).matcher(json)
            if (contentUrl.find()) {
                val clean = normalizeMediaUrl(contentUrl.group(1)) ?: continue
                if (streamTypeFor(clean, "contentUrl") != null) hits[clean] = UrlHit(clean, "contentUrl", 80)
            }
        }
    }

    private fun collectLinkPreloads(html: String, hits: MutableMap<String, UrlHit>) {
        val linkPattern = Pattern.compile("<link\\b([^>]{0,5000})>", Pattern.CASE_INSENSITIVE)
        val matcher = linkPattern.matcher(html)
        var count = 0
        while (matcher.find() && count++ < 120) {
            val attrs = matcher.group(1).orEmpty()
            val asVideo = attributeValue(attrs, "as")?.equals("video", true) == true ||
                attributeValue(attrs, "rel")?.contains("video", true) == true
            if (!asVideo) continue
            val href = attributeValue(attrs, "href") ?: continue
            val clean = normalizeMediaUrl(href) ?: continue
            if (streamTypeFor(clean, "preload") != null) hits[clean] = UrlHit(clean, "preload", 72)
        }
    }

    private fun collectVideoVersionObjects(html: String, arrayKey: String, hits: MutableMap<String, UrlHit>) {
        val keyPattern = Pattern.compile("[\\\"']${Pattern.quote(arrayKey)}[\\\"']\\s*:\\s*\\[", Pattern.CASE_INSENSITIVE)
        val keyMatcher = keyPattern.matcher(html)
        var windows = 0
        while (keyMatcher.find() && windows++ < 20) {
            val start = keyMatcher.end()
            val end = (start + MAX_VERSION_WINDOW).coerceAtMost(html.length)
            val window = html.substring(start, end)
            val urlMatcher = Pattern.compile("[\\\"'](?:url|src|uri)[\\\"']\\s*:\\s*[\\\"']((?:\\\\.|[^\\\"'\\\\]){8,8192})[\\\"']", Pattern.CASE_INSENSITIVE).matcher(window)
            var count = 0
            while (urlMatcher.find() && count++ < 30) {
                val clean = normalizeMediaUrl(urlMatcher.group(1)) ?: continue
                if (streamTypeFor(clean, arrayKey) != null) {
                    val rank = if (arrayKey == "video_versions") 84 else 80
                    hits[clean] = UrlHit(clean, arrayKey, rank)
                }
            }
        }
    }

    private fun attributeValue(attrs: String, name: String): String? {
        val regex = Pattern.compile("(?:^|\\s)${Pattern.quote(name)}\\s*=\\s*([\\\"'])(.*?)\\1", Pattern.CASE_INSENSITIVE or Pattern.DOTALL)
        return regex.matcher(attrs).let { if (it.find()) it.group(2) else null }
    }

    private fun normalizeMediaUrl(raw: String?): String? {
        if (raw.isNullOrBlank()) return null
        var value = raw.trim()
            .replace("\\/", "/")
            .replace("\\u0026", "&", true)
            .replace("\\u003d", "=", true)
            .replace("\\u003a", ":", true)
            .replace("\\u002f", "/", true)
            .replace("&amp;", "&")
            .replace("\\\\", "\\")
            .trim()
        value = decodeJsonUnicode(value)
        if (!isHttpUrl(value)) return null
        return value.takeIf { it.length <= 8192 && !it.contains("\\n") && !it.contains("\\r") }
    }

    private fun decodeJsonUnicode(value: String): String {
        val pattern = Pattern.compile("\\\\u([0-9a-fA-F]{4})")
        val matcher = pattern.matcher(value)
        val out = StringBuffer()
        while (matcher.find()) {
            val charValue = matcher.group(1)?.toIntOrNull(16)?.toChar()?.toString().orEmpty()
            matcher.appendReplacement(out, MatcherQuote.quoteReplacement(charValue))
        }
        matcher.appendTail(out)
        return out.toString()
    }

    private fun isHttpUrl(value: String?): Boolean = runCatching {
        val uri = URI(value ?: return false)
        (uri.scheme.equals("https", true) || uri.scheme.equals("http", true)) && !uri.host.isNullOrBlank()
    }.getOrDefault(false)

    private fun isVideoOrStoryRoute(url: String, html: String): Boolean {
        val lower = url.lowercase()
        val route = listOf(
            "/stories/", "/story.php", "/reel/", "/reels/", "/tv/", "/watch/", "/videos/",
            "/posts/", "/permalink.php", "/post/", "/p/"
        ).any { lower.contains(it) }
        val videoMarker = Regex("(?i)(?:\\\"is_video\\\"\\s*:\\s*true|og:video|videoobject|video_versions|video_dash_manifest|video_url)")
            .containsMatchIn(html)
        return route && (videoMarker || lower.contains("/stories/") || lower.contains("/reel") || lower.contains("/story.php"))
    }

    private fun defaultTitle(platform: PlatformSource): String = when (platform) {
        PlatformSource.FACEBOOK -> "Facebook media"
        PlatformSource.INSTAGRAM -> "Instagram media"
        PlatformSource.THREADS -> "Threads media"
        else -> "Social media"
    }

    private const val MAX_HTML_CHARS = 5_000_000
    private const val MAX_JSON_HITS = 200
    private const val MAX_VERSION_WINDOW = 160_000

    private object MatcherQuote {
        fun quoteReplacement(value: String): String = java.util.regex.Matcher.quoteReplacement(value)
    }
}
