package com.mahabub.downloder

import android.content.Context
import android.content.res.Configuration
import android.content.res.Resources
import android.os.LocaleList
import java.util.Locale

/** Applies the language preference to Android resource-backed UI after Activity recreation. */
object AppLocaleManager {
    private const val PREFS_NAME = "app_locale"
    private const val KEY_LANGUAGE = "language"

    fun persist(context: Context, language: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_LANGUAGE, language)
            .apply()
    }

    fun wrap(context: Context): Context {
        val selected = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_LANGUAGE, "Default") ?: "Default"
        val locale = when (selected) {
            "English" -> Locale.ENGLISH
            "বাংলা", "Bengali (বাংলা)" -> Locale.forLanguageTag("bn")
            else -> Resources.getSystem().configuration.locales[0] ?: Locale.ENGLISH
        }
        Locale.setDefault(locale)
        val configuration = Configuration(context.resources.configuration)
        configuration.setLocale(locale)
        configuration.setLocales(LocaleList(locale))
        configuration.setLayoutDirection(locale)
        return context.createConfigurationContext(configuration)
    }
}
