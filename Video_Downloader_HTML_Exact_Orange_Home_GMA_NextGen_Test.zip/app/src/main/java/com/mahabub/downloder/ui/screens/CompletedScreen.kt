package com.mahabub.downloder.ui.screens

import android.content.Intent
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.mahabub.downloder.db.DownloadEntity
import com.mahabub.downloder.storage.MediaMetadataUtils
import com.mahabub.downloder.ui.components.LocalBottomBarContentPadding
import com.mahabub.downloder.ui.viewmodel.CompletedViewModel
import kotlinx.coroutines.launch
import java.util.Locale

private enum class MediaFilter(val label: String) {
    ALL("All"),
    VIDEO("Videos"),
    IMAGE("Images"),
    AUDIO("Audio")
}

private enum class MediaSort(val label: String) {
    NEWEST("Newest first"),
    OLDEST("Oldest first"),
    LARGEST("Largest first"),
    SMALLEST("Smallest first")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CompletedScreen(
    viewModel: CompletedViewModel,
    onPlayMedia: (uriString: String, title: String) -> Unit,
    onNavigateToDetails: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val completedList by viewModel.completedDownloads.collectAsState()
    var itemToDelete by remember { mutableStateOf<DownloadEntity?>(null) }
    var itemToRename by remember { mutableStateOf<DownloadEntity?>(null) }
    var renameInput by remember { mutableStateOf("") }
    var renameError by remember { mutableStateOf<String?>(null) }
    var renameBusy by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf(MediaFilter.ALL) }
    var selectedSort by remember { mutableStateOf(MediaSort.NEWEST) }
    var showSortMenu by remember { mutableStateOf(false) }

    val filteredList = remember(completedList, selectedFilter, selectedSort, searchQuery) {
        val query = searchQuery.trim().lowercase(Locale.ROOT)
        val matching = completedList.filter { item ->
            val categoryMatches = selectedFilter == MediaFilter.ALL || mediaFilterFor(item) == selectedFilter
            val queryMatches = query.isBlank() ||
                item.fileName.lowercase(Locale.ROOT).contains(query) ||
                item.sourcePageUrl.orEmpty().lowercase(Locale.ROOT).contains(query) ||
                item.sourcePlatform.name.lowercase(Locale.ROOT).contains(query)
            categoryMatches && queryMatches
        }
        when (selectedSort) {
            MediaSort.NEWEST -> matching.sortedByDescending { it.completedAt ?: it.createdAt }
            MediaSort.OLDEST -> matching.sortedBy { it.completedAt ?: it.createdAt }
            MediaSort.LARGEST -> matching.sortedByDescending { mediaBytes(it) }
            MediaSort.SMALLEST -> matching.sortedBy { mediaBytes(it) }
        }
    }

    Scaffold(
        contentWindowInsets = WindowInsets(0.dp),
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Videos",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = (-0.35).sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "${completedList.size} saved file${if (completedList.size == 1) "" else "s"}",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Box {
                        IconButton(onClick = { showSortMenu = true }) {
                            Icon(
                                imageVector = Icons.Default.Sort,
                                contentDescription = "Sort saved media",
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        DropdownMenu(
                            expanded = showSortMenu,
                            onDismissRequest = { showSortMenu = false }
                        ) {
                            MediaSort.entries.forEach { sort ->
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            text = sort.label,
                                            color = if (selectedSort == sort) MaterialTheme.colorScheme.primary
                                            else MaterialTheme.colorScheme.onSurface
                                        )
                                    },
                                    leadingIcon = if (selectedSort == sort) {
                                        { Icon(Icons.Default.Sort, contentDescription = null, tint = MaterialTheme.colorScheme.primary) }
                                    } else null,
                                    onClick = {
                                        selectedSort = sort
                                        showSortMenu = false
                                    }
                                )
                            }
                        }
                    }
                }

                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 10.dp),
                    singleLine = true,
                    shape = RoundedCornerShape(15.dp),
                    placeholder = { Text("Search saved media", fontSize = 13.sp) },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    },
                    trailingIcon = if (searchQuery.isNotEmpty()) {
                        {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Close, contentDescription = "Clear search")
                            }
                        }
                    } else null
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 10.dp)
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    MediaFilter.entries.forEach { filter ->
                        val count = when (filter) {
                            MediaFilter.ALL -> completedList.size
                            else -> completedList.count { mediaFilterFor(it) == filter }
                        }
                        FilterChip(
                            selected = selectedFilter == filter,
                            onClick = { selectedFilter = filter },
                            label = { Text("${filter.label} ($count)", fontSize = 12.sp) }
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        when {
            completedList.isEmpty() -> {
                EmptyVideosState(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding),
                    title = "No saved media yet",
                    message = "Completed downloads will appear here. Open a downloaded video to play it offline."
                )
            }
            filteredList.isEmpty() -> {
                EmptyVideosState(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding),
                    title = "No matching media",
                    message = "Try another search or choose a different media filter.",
                    actionLabel = "Clear filters",
                    onAction = {
                        searchQuery = ""
                        selectedFilter = MediaFilter.ALL
                    }
                )
            }
            else -> {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    contentPadding = PaddingValues(bottom = LocalBottomBarContentPadding.current + 16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    itemsIndexed(filteredList, key = { _, item -> item.id }) { index, item ->
                        AnimatedVisibility(
                            visible = true,
                            enter = fadeIn(
                                animationSpec = tween(
                                    durationMillis = 440,
                                    delayMillis = (index * 48).coerceAtMost(288)
                                )
                            ) + slideInVertically(
                                animationSpec = tween(
                                    durationMillis = 500,
                                    delayMillis = (index * 48).coerceAtMost(288)
                                ),
                                initialOffsetY = { height -> height / 12 }
                            ) + scaleIn(
                                initialScale = 0.985f,
                                animationSpec = tween(
                                    durationMillis = 460,
                                    delayMillis = (index * 48).coerceAtMost(288)
                                )
                            )
                        ) {
                            FinishedVideoItemCard(
                                item = item,
                                onPlay = {
                                    val uriToPlay = item.localUri ?: item.temporaryPath.orEmpty()
                                    if (item.mimeType?.startsWith("image/", ignoreCase = true) == true) {
                                        val shareUri = viewModel.getShareUri(uriToPlay)
                                        if (shareUri != null) {
                                            val imageIntent = Intent(Intent.ACTION_VIEW).apply {
                                                setDataAndType(shareUri, item.mimeType)
                                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                            }
                                            runCatching { context.startActivity(imageIntent) }.onFailure {
                                                Toast.makeText(context, "No image viewer is available", Toast.LENGTH_SHORT).show()
                                            }
                                        } else {
                                            Toast.makeText(context, "Could not open this image", Toast.LENGTH_SHORT).show()
                                        }
                                    } else {
                                        onPlayMedia(uriToPlay, item.fileName)
                                    }
                                },
                                onShare = {
                                    val uri = viewModel.getShareUri(item.localUri ?: item.temporaryPath)
                                    if (uri != null) {
                                        val mime = item.mimeType
                                            ?.substringBefore(';')
                                            ?.trim()
                                            ?.takeIf { it.contains('/') }
                                            ?: "application/octet-stream"
                                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                            type = mime
                                            putExtra(Intent.EXTRA_STREAM, uri)
                                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        }
                                        runCatching {
                                            context.startActivity(Intent.createChooser(shareIntent, "Share ${mediaTypeLabel(item)}"))
                                        }.onFailure {
                                            Toast.makeText(context, "No app can share this file", Toast.LENGTH_SHORT).show()
                                        }
                                    } else {
                                        Toast.makeText(context, "Cannot share this file", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                onRename = {
                                    itemToRename = item
                                    renameInput = item.fileName
                                    renameError = null
                                },
                                onDelete = { itemToDelete = item },
                                onDetails = { onNavigateToDetails(item.id) }
                            )
                        }
                    }
                    item { Spacer(modifier = Modifier.height(8.dp)) }
                }
            }
        }
    }

    itemToDelete?.let { item ->
        AlertDialog(
            onDismissRequest = { itemToDelete = null },
            title = { Text("Delete file?") },
            text = {
                Text("Delete \"${item.fileName}\" from your device? This also removes its entry from Videos.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteCompleted(item.id)
                        itemToDelete = null
                        Toast.makeText(context, "File deleted", Toast.LENGTH_SHORT).show()
                    }
                ) { Text("Delete") }
            },
            dismissButton = {
                TextButton(onClick = { itemToDelete = null }) { Text("Cancel") }
            }
        )
    }

    itemToRename?.let { item ->
        AlertDialog(
            onDismissRequest = {
                if (!renameBusy) itemToRename = null
            },
            title = { Text("Rename file") },
            text = {
                Column {
                    Text(
                        text = "The file will be renamed in device storage. Its original format and extension will be kept.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = renameInput,
                        onValueChange = {
                            renameInput = it
                            renameError = null
                        },
                        singleLine = true,
                        label = { Text("File name") },
                        modifier = Modifier.fillMaxWidth(),
                        isError = renameError != null
                    )
                    renameError?.let {
                        Spacer(modifier = Modifier.height(5.dp))
                        Text(
                            text = it,
                            color = MaterialTheme.colorScheme.error,
                            fontSize = 12.sp
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    enabled = !renameBusy && renameInput.isNotBlank(),
                    onClick = {
                        scope.launch {
                            renameBusy = true
                            val result = runCatching {
                                viewModel.renameCompleted(item.id, renameInput.trim())
                            }
                            renameBusy = false
                            result.onSuccess {
                                itemToRename = null
                                Toast.makeText(context, "File renamed", Toast.LENGTH_SHORT).show()
                            }.onFailure { error ->
                                renameError = error.message?.takeIf { it.isNotBlank() }
                                    ?: "Could not rename this file. Check storage access and try again."
                            }
                        }
                    }
                ) {
                    Text(if (renameBusy) "Saving…" else "Save")
                }
            },
            dismissButton = {
                TextButton(
                    enabled = !renameBusy,
                    onClick = { itemToRename = null }
                ) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun EmptyVideosState(
    modifier: Modifier = Modifier,
    title: String,
    message: String,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null
) {
    Box(modifier = modifier.padding(28.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                modifier = Modifier
                    .size(76.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Movie,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                    modifier = Modifier.size(35.dp)
                )
            }
            Spacer(modifier = Modifier.height(17.dp))
            Text(
                text = title,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = message,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (actionLabel != null && onAction != null) {
                Spacer(modifier = Modifier.height(14.dp))
                TextButton(onClick = onAction) { Text(actionLabel) }
            }
        }
    }
}

@Composable
fun FinishedVideoItemCard(
    item: DownloadEntity,
    onPlay: () -> Unit,
    onShare: () -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit,
    onDetails: () -> Unit = {}
) {
    var showMenu by remember { mutableStateOf(false) }
    val category = mediaFilterFor(item)
    val typeIcon = when (category) {
        MediaFilter.IMAGE -> Icons.Default.Image
        MediaFilter.AUDIO -> Icons.Default.AudioFile
        else -> Icons.Default.Movie
    }
    val displayBytes = mediaBytes(item)
    val durationText = item.durationMs
        ?.takeIf { it > 0L }
        ?.let(MediaMetadataUtils::formatDuration)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(19.dp))
            .clickable(onClick = onPlay)
            .testTag("completed_item_${item.id}"),
        shape = RoundedCornerShape(19.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(width = 108.dp, height = 78.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surface),
                contentAlignment = Alignment.Center
            ) {
                when {
                    !item.thumbnailUrl.isNullOrBlank() -> {
                        AsyncImage(
                            model = item.thumbnailUrl,
                            contentDescription = "${mediaTypeLabel(item)} thumbnail",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    }
                    category == MediaFilter.IMAGE && !item.localUri.isNullOrBlank() -> {
                        AsyncImage(
                            model = item.localUri,
                            contentDescription = "Saved image preview",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    }
                    else -> {
                        Icon(
                            imageVector = typeIcon,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                }
                if (durationText != null) {
                    Surface(
                        modifier = Modifier.align(Alignment.BottomEnd).padding(5.dp),
                        color = Color.Black.copy(alpha = 0.78f),
                        shape = RoundedCornerShape(5.dp)
                    ) {
                        Text(
                            text = durationText,
                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp),
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.fileName,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = typeIcon,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(15.dp)
                    )
                    Text(
                        text = mediaTypeLabel(item),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text("·", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                    Text(
                        text = if (displayBytes > 0L) MediaMetadataUtils.formatFileSize(displayBytes) else "Size unknown",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1
                    )
                }
                if (durationText != null) {
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = "Duration $durationText",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Box {
                IconButton(
                    onClick = { showMenu = true },
                    modifier = Modifier.size(34.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.MoreVert,
                        contentDescription = "File options",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(21.dp)
                    )
                }
                DropdownMenu(
                    expanded = showMenu,
                    onDismissRequest = { showMenu = false }
                ) {
                    DropdownMenuItem(
                        text = { Text("Play") },
                        leadingIcon = { Icon(Icons.Default.PlayArrow, null) },
                        onClick = { showMenu = false; onPlay() }
                    )
                    DropdownMenuItem(
                        text = { Text("Details") },
                        leadingIcon = { Icon(Icons.Default.Info, null) },
                        onClick = { showMenu = false; onDetails() }
                    )
                    DropdownMenuItem(
                        text = { Text("Share") },
                        leadingIcon = { Icon(Icons.Default.Share, null) },
                        onClick = { showMenu = false; onShare() }
                    )
                    DropdownMenuItem(
                        text = { Text("Rename") },
                        leadingIcon = { Icon(Icons.Default.Edit, null) },
                        onClick = { showMenu = false; onRename() }
                    )
                    DropdownMenuItem(
                        text = { Text("Delete") },
                        leadingIcon = { Icon(Icons.Default.Delete, null, tint = MaterialTheme.colorScheme.error) },
                        onClick = { showMenu = false; onDelete() }
                    )
                }
            }
        }
    }
}

private fun mediaFilterFor(item: DownloadEntity): MediaFilter? {
    val mime = item.mimeType?.substringBefore(';')?.trim()?.lowercase(Locale.ROOT).orEmpty()
    if (mime.startsWith("video/")) return MediaFilter.VIDEO
    if (mime.startsWith("image/")) return MediaFilter.IMAGE
    if (mime.startsWith("audio/")) return MediaFilter.AUDIO

    return when (item.fileName.substringAfterLast('.', "").lowercase(Locale.ROOT)) {
        "mp4", "m4v", "webm", "3gp", "mov", "avi", "mkv", "wmv", "flv", "ts", "mpg", "mpeg", "ogv" -> MediaFilter.VIDEO
        "jpg", "jpeg", "png", "gif", "webp", "bmp", "avif" -> MediaFilter.IMAGE
        "mp3", "m4a", "aac", "ogg", "oga", "opus", "wav", "flac", "aiff", "amr" -> MediaFilter.AUDIO
        else -> null
    }
}

private fun mediaBytes(item: DownloadEntity): Long =
    item.totalBytes.takeIf { it > 0L } ?: item.downloadedBytes.coerceAtLeast(0L)

private fun mediaTypeLabel(item: DownloadEntity): String = when (mediaFilterFor(item)) {
    MediaFilter.VIDEO -> "Video"
    MediaFilter.IMAGE -> "Image"
    MediaFilter.AUDIO -> "Audio"
    else -> "Media"
}
