package com.mahabub.downloder.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Public
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import coil.compose.AsyncImage
import com.mahabub.downloder.R
import com.mahabub.downloder.db.DownloadEntity
import com.mahabub.downloder.model.DownloadStatus
import com.mahabub.downloder.storage.MediaMetadataUtils
import com.mahabub.downloder.ui.components.LocalBottomBarContentPadding
import com.mahabub.downloder.ui.components.StaggeredEntry
import com.mahabub.downloder.ui.components.StaggeredFadeEntry
import com.mahabub.downloder.ui.viewmodel.DownloadsViewModel

@Composable
fun DownloadsScreen(
    viewModel: DownloadsViewModel,
    onNavigateToDetails: (String) -> Unit,
    onOpenBrowserUrl: (String) -> Unit = {},
    entryAnimationKey: Any = "downloads",
    isCurrentDestination: Boolean = true
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val activeDownloads by viewModel.activeDownloads.collectAsState()
    val failedDownloads by viewModel.failedDownloads.collectAsState()
    val powerManager = remember(context) {
        context.getSystemService(Context.POWER_SERVICE) as PowerManager
    }
    var stabilitySettingSatisfied by remember {
        mutableStateOf(
            Build.VERSION.SDK_INT < Build.VERSION_CODES.M ||
                powerManager.isIgnoringBatteryOptimizations(context.packageName)
        )
    }
    var showStabilityDialog by remember { mutableStateOf(false) }
    var itemToCancel by remember { mutableStateOf<DownloadEntity?>(null) }

    DisposableEffect(lifecycleOwner, context) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                stabilitySettingSatisfied = Build.VERSION.SDK_INT < Build.VERSION_CODES.M ||
                    powerManager.isIgnoringBatteryOptimizations(context.packageName)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val hasDownloading = activeDownloads.any {
        it.status == DownloadStatus.DOWNLOADING || it.status == DownloadStatus.CONVERTING
    }
    val hasPaused = activeDownloads.any { it.status == DownloadStatus.PAUSED }

    Scaffold(
        contentWindowInsets = WindowInsets(0.dp),
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(start = 20.dp, end = 16.dp, top = 14.dp, bottom = 12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Downloads",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = (-0.35).sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = when {
                                activeDownloads.isNotEmpty() && failedDownloads.isNotEmpty() ->
                                    "${activeDownloads.size} in queue · ${failedDownloads.size} failed"
                                activeDownloads.isNotEmpty() -> "${activeDownloads.size} download${if (activeDownloads.size == 1) "" else "s"} in queue"
                                failedDownloads.isNotEmpty() -> "${failedDownloads.size} failed download${if (failedDownloads.size == 1) "" else "s"}"
                                else -> "Your download queue"
                            },
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 12.sp
                        )
                    }
                    if (hasDownloading) {
                        IconButton(onClick = viewModel::pauseAll) {
                            Icon(
                                imageVector = Icons.Default.Pause,
                                contentDescription = "Pause all downloads",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                    if (hasPaused) {
                        IconButton(onClick = viewModel::resumeAll) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "Resume all downloads",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (!stabilitySettingSatisfied) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .clickable { showStabilityDialog = true }
                        .testTag("stability_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.secondaryContainer
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 11.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSecondaryContainer,
                            modifier = Modifier.size(19.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = stringResource(R.string.improve_download_stability),
                            modifier = Modifier.weight(1f),
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = "Open battery settings",
                            tint = MaterialTheme.colorScheme.onSecondaryContainer,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            if (activeDownloads.isEmpty() && failedDownloads.isEmpty()) {
                StaggeredEntry(
                    index = 0,
                    animationKey = entryAnimationKey,
                    enabled = isCurrentDestination,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(28.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(
                                modifier = Modifier
                                    .size(76.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primaryContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Download,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                    modifier = Modifier.size(34.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(18.dp))
                            Text(
                                text = "No active downloads",
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Start a download from Browser. Its progress and status will appear here.",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    contentPadding = PaddingValues(bottom = LocalBottomBarContentPadding.current + 16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    if (activeDownloads.isNotEmpty()) {
                        item(key = "active-section-title") {
                            StaggeredFadeEntry(
                                firstItemIndex = 0,
                                animationKey = entryAnimationKey,
                                enabled = isCurrentDestination
                            ) {
                                SectionLabel(
                                    title = "DOWNLOAD QUEUE",
                                    count = activeDownloads.size,
                                    modifier = Modifier.padding(start = 2.dp, top = 2.dp, bottom = 1.dp)
                                )
                            }
                        }
                        itemsIndexed(activeDownloads, key = { _, item -> "active:${item.id}" }) { index, item ->
                            StaggeredEntry(
                                index = index,
                                animationKey = entryAnimationKey,
                                enabled = isCurrentDestination
                            ) {
                                ProgressDownloadItemCard(
                                    item = item,
                                    onPause = { viewModel.pauseDownload(item.id) },
                                    onResume = { viewModel.resumeDownload(item.id) },
                                    onCancel = { itemToCancel = item },
                                    onOpenUrl = { onOpenBrowserUrl(item.sourcePageUrl ?: item.sourceUrl) },
                                    onDetails = { onNavigateToDetails(item.id) }
                                )
                            }
                        }
                    }

                    if (failedDownloads.isNotEmpty()) {
                        item(key = "failed-section-title") {
                            StaggeredFadeEntry(
                                firstItemIndex = activeDownloads.size,
                                animationKey = entryAnimationKey,
                                enabled = isCurrentDestination
                            ) {
                                SectionLabel(
                                    title = "FAILED DOWNLOADS",
                                    count = failedDownloads.size,
                                    modifier = Modifier.padding(start = 2.dp, top = 10.dp, bottom = 1.dp),
                                    isError = true
                                )
                            }
                        }
                        itemsIndexed(failedDownloads, key = { _, item -> "failed:${item.id}" }) { index, item ->
                            StaggeredEntry(
                                index = activeDownloads.size + index,
                                animationKey = entryAnimationKey,
                                enabled = isCurrentDestination
                            ) {
                                FailedDownloadItemCard(
                                    item = item,
                                    onRetry = { viewModel.retryDownload(item.id) },
                                    onOpenUrl = { onOpenBrowserUrl(item.sourcePageUrl ?: item.sourceUrl) },
                                    onDetails = { onNavigateToDetails(item.id) }
                                )
                            }
                        }
                    }
                    item { Spacer(modifier = Modifier.height(8.dp)) }
                }
            }
        }
    }

    itemToCancel?.let { item ->
        AlertDialog(
            onDismissRequest = { itemToCancel = null },
            title = { Text("Cancel download?") },
            text = { Text("Stop downloading \"${item.fileName}\"? The partial download will not appear in Videos.") },
            confirmButton = {
                Button(onClick = {
                    viewModel.cancelDownload(item.id)
                    itemToCancel = null
                }) {
                    Text("Cancel download")
                }
            },
            dismissButton = {
                TextButton(onClick = { itemToCancel = null }) { Text("Keep downloading") }
            }
        )
    }

    if (showStabilityDialog) {
        AlertDialog(
            onDismissRequest = { showStabilityDialog = false },
            title = { Text(stringResource(R.string.improve_download_stability)) },
            text = {
                Text(
                    "Allow unrestricted battery use for this app to reduce the chance that Android pauses long downloads in the background. Android will ask you to confirm this setting."
                )
            },
            confirmButton = {
                Button(onClick = {
                    showStabilityDialog = false
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                        !powerManager.isIgnoringBatteryOptimizations(context.packageName)
                    ) {
                        val request = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                            data = Uri.parse("package:${context.packageName}")
                        }
                        try {
                            context.startActivity(request)
                        } catch (_: Exception) {
                            val details = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                                data = Uri.parse("package:${context.packageName}")
                            }
                            runCatching { context.startActivity(details) }
                        }
                    }
                }) {
                    Text("Open settings")
                }
            },
            dismissButton = {
                TextButton(onClick = { showStabilityDialog = false }) { Text("Not now") }
            }
        )
    }
}

@Composable
private fun SectionLabel(
    title: String,
    count: Int,
    modifier: Modifier = Modifier,
    isError: Boolean = false
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        Text(
            text = title,
            fontSize = 11.sp,
            letterSpacing = 0.8.sp,
            fontWeight = FontWeight.Bold,
            color = if (isError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant
        )
        Surface(
            shape = CircleShape,
            color = if (isError) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.surfaceVariant
        ) {
            Text(
                text = count.toString(),
                modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp),
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = if (isError) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun FailedDownloadItemCard(
    item: DownloadEntity,
    onRetry: () -> Unit,
    onOpenUrl: () -> Unit,
    onDetails: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(15.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.error,
                    modifier = Modifier.size(19.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Download failed",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onErrorContainer
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = item.fileName,
                fontWeight = FontWeight.SemiBold,
                fontSize = 14.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                color = MaterialTheme.colorScheme.onErrorContainer,
                modifier = Modifier.clickable(onClick = onDetails)
            )
            item.errorMessage?.takeIf { it.isNotBlank() }?.let { message ->
                Spacer(modifier = Modifier.height(5.dp))
                Text(
                    text = message,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onErrorContainer.copy(alpha = 0.82f),
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = onDetails) { Text("Details") }
                TextButton(onClick = onOpenUrl) { Text("Open page") }
                Button(onClick = onRetry) { Text("Retry") }
            }
        }
    }
}

@Composable
fun ProgressDownloadItemCard(
    item: DownloadEntity,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onCancel: () -> Unit,
    onOpenUrl: () -> Unit,
    onDetails: () -> Unit = {}
) {
    val progress = item.progressPercent.coerceIn(0, 100) / 100f
    val animatedProgress by animateFloatAsState(
        targetValue = progress,
        animationSpec = tween(durationMillis = 420),
        label = "downloadProgress"
    )
    val statusLabel = when (item.status) {
        DownloadStatus.DOWNLOADING -> "Downloading"
        DownloadStatus.CONVERTING -> "Preparing file"
        DownloadStatus.PAUSED -> "Paused"
        DownloadStatus.WAITING_FOR_NETWORK -> "Waiting for network"
        DownloadStatus.QUEUED -> "Queued"
        else -> item.status.name.lowercase().replace('_', ' ').replaceFirstChar { it.uppercase() }
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp)),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(13.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(width = 104.dp, height = 76.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surface),
                    contentAlignment = Alignment.Center
                ) {
                    if (!item.thumbnailUrl.isNullOrBlank()) {
                        AsyncImage(
                            model = item.thumbnailUrl,
                            contentDescription = "Download thumbnail",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.Movie,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(30.dp)
                        )
                    }
                    item.durationMs?.takeIf { it > 0L }?.let { duration ->
                        Surface(
                            modifier = Modifier.align(Alignment.BottomEnd).padding(5.dp),
                            color = Color.Black.copy(alpha = 0.78f),
                            shape = RoundedCornerShape(5.dp)
                        ) {
                            Text(
                                text = MediaMetadataUtils.formatDuration(duration),
                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp),
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = item.fileName,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.clickable(onClick = onDetails)
                    )
                    Spacer(modifier = Modifier.height(7.dp))
                    Surface(
                        shape = RoundedCornerShape(7.dp),
                        color = if (item.status == DownloadStatus.WAITING_FOR_NETWORK) {
                            MaterialTheme.colorScheme.secondaryContainer
                        } else if (item.status == DownloadStatus.PAUSED) {
                            MaterialTheme.colorScheme.surface
                        } else {
                            MaterialTheme.colorScheme.primaryContainer
                        }
                    ) {
                        Text(
                            text = statusLabel,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = when (item.status) {
                                DownloadStatus.WAITING_FOR_NETWORK -> MaterialTheme.colorScheme.onSecondaryContainer
                                DownloadStatus.PAUSED -> MaterialTheme.colorScheme.onSurfaceVariant
                                else -> MaterialTheme.colorScheme.onPrimaryContainer
                            },
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                IconButton(
                    onClick = onCancel,
                    modifier = Modifier.size(34.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Cancel download",
                        tint = MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(19.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            if (item.status == DownloadStatus.CONVERTING) {
                androidx.compose.material3.LinearProgressIndicator(
                    modifier = Modifier.fillMaxWidth(),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = MaterialTheme.colorScheme.surface
                )
                Spacer(modifier = Modifier.height(7.dp))
                Text(
                    text = "Finalizing downloaded media…",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Medium
                )
            } else {
                SegmentedProgressBar(
                    progress = animatedProgress,
                    segments = 4,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(7.dp))
                val amountText = when {
                    item.totalBytes > 0L -> "${MediaMetadataUtils.formatFileSize(item.downloadedBytes)} / ${MediaMetadataUtils.formatFileSize(item.totalBytes)}"
                    item.totalSegments > 0 -> "${item.completedSegments.coerceAtMost(item.totalSegments)} / ${item.totalSegments} segments"
                    item.downloadedBytes > 0L -> "${MediaMetadataUtils.formatFileSize(item.downloadedBytes)} downloaded"
                    else -> "Waiting for download data"
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = amountText,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "${item.progressPercent.coerceIn(0, 100)}%",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                val speedText = when {
                    item.status == DownloadStatus.PAUSED -> "Paused"
                    item.status == DownloadStatus.WAITING_FOR_NETWORK -> "Waiting for network"
                    item.status == DownloadStatus.QUEUED -> "In queue"
                    item.status == DownloadStatus.CONVERTING -> "Almost done"
                    item.speedBytesPerSec > 0L -> "${formatDownloadSpeed(item.speedBytesPerSec)} · ${item.progressPercent}%"
                    else -> "Connecting…"
                }
                Text(
                    text = speedText,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.primary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onDetails,
                        modifier = Modifier.size(34.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "Download details",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(19.dp)
                        )
                    }
                    IconButton(
                        onClick = onOpenUrl,
                        modifier = Modifier.size(34.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Public,
                            contentDescription = "Open source page",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(19.dp)
                        )
                    }
                    when (item.status) {
                        DownloadStatus.DOWNLOADING, DownloadStatus.CONVERTING -> {
                            if (item.status == DownloadStatus.DOWNLOADING) {
                                IconButton(
                                    onClick = onPause,
                                    modifier = Modifier.size(34.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Pause,
                                        contentDescription = "Pause download",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                        DownloadStatus.PAUSED -> {
                            IconButton(
                                onClick = onResume,
                                modifier = Modifier.size(34.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PlayArrow,
                                    contentDescription = "Resume download",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        else -> Unit
                    }
                }
            }
        }
    }
}

private fun formatDownloadSpeed(bytesPerSecond: Long): String {
    val value = bytesPerSecond.coerceAtLeast(0L).toDouble()
    return when {
        value >= 1024.0 * 1024.0 -> String.format(java.util.Locale.US, "%.2f MB/s", value / (1024.0 * 1024.0))
        value >= 1024.0 -> String.format(java.util.Locale.US, "%.0f KB/s", value / 1024.0)
        else -> "${value.toLong()} B/s"
    }
}

@Composable
fun SegmentedProgressBar(
    progress: Float,
    segments: Int = 4,
    modifier: Modifier = Modifier
) {
    val safeProgress = progress.coerceIn(0f, 1f)
    Row(
        modifier = modifier.height(5.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        val segmentCount = segments.coerceAtLeast(1)
        val segmentFraction = 1f / segmentCount
        for (index in 0 until segmentCount) {
            val start = index * segmentFraction
            val end = (index + 1) * segmentFraction
            val fill = when {
                safeProgress >= end -> 1f
                safeProgress <= start -> 0f
                else -> (safeProgress - start) / segmentFraction
            }
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(5.dp)
                    .clip(RoundedCornerShape(50))
                    .background(MaterialTheme.colorScheme.outlineVariant)
            ) {
                if (fill > 0f) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(fill)
                            .height(5.dp)
                            .clip(RoundedCornerShape(50))
                            .background(MaterialTheme.colorScheme.primary)
                    )
                }
            }
        }
    }
}
