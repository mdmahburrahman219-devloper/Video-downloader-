package com.mahabub.downloder.model

import android.content.Context
import com.mahabub.downloder.R

sealed class AppError(open val customMessage: String? = null) : Exception(customMessage) {
    data object InvalidUrl : AppError()
    data object UnsupportedScheme : AppError()
    data object NetworkUnavailable : AppError()
    data class HttpError(val code: Int) : AppError("HTTP $code")
    data object Unauthorized : AppError()
    data object Forbidden : AppError()
    data object NotFound : AppError()
    data object ServerError : AppError()
    data object ResumeNotSupported : AppError()
    data object InsufficientStorage : AppError()
    data class FileWriteError(val reason: String? = null) : AppError(reason)
    data object UnsupportedMedia : AppError()
    data object ProtectedMedia : AppError()
    data class UnsupportedHlsFeature(val feature: String) : AppError(feature)
    data class PlaylistParseError(val reason: String? = null) : AppError(reason)
    data class SegmentDownloadError(val segmentIndex: Int, val reason: String? = null) : AppError("Segment $segmentIndex: $reason")
    data class MuxingFailed(val reason: String? = null) : AppError(reason)
    data object Canceled : AppError()
    data class UnknownError(val underlying: Throwable? = null) : AppError(underlying?.message)

    fun getUserFriendlyMessage(context: Context): String {
        return when (this) {
            is InvalidUrl -> context.getString(R.string.err_invalid_url)
            is UnsupportedScheme -> context.getString(R.string.err_unsupported_scheme)
            is NetworkUnavailable -> context.getString(R.string.err_network_unavailable)
            is HttpError -> context.getString(R.string.err_http_error, code)
            is Unauthorized -> context.getString(R.string.err_unauthorized)
            is Forbidden -> context.getString(R.string.err_forbidden)
            is NotFound -> context.getString(R.string.err_not_found)
            is ServerError -> context.getString(R.string.err_server_error)
            is ResumeNotSupported -> context.getString(R.string.err_resume_not_supported)
            is InsufficientStorage -> context.getString(R.string.err_insufficient_storage)
            is FileWriteError -> context.getString(R.string.err_file_write)
            is UnsupportedMedia -> context.getString(R.string.err_unsupported_media)
            is ProtectedMedia -> context.getString(R.string.err_protected_media)
            is UnsupportedHlsFeature -> context.getString(R.string.err_hls_unsupported, feature)
            is PlaylistParseError -> context.getString(R.string.err_playlist_parse)
            is SegmentDownloadError -> context.getString(R.string.err_segment_download)
            is MuxingFailed -> context.getString(R.string.err_muxing_failed)
            is Canceled -> context.getString(R.string.err_canceled)
            is UnknownError -> customMessage ?: context.getString(R.string.err_unknown)
        }
    }
}
