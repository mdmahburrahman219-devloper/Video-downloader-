package com.mahabub.downloder

import android.app.Application
import com.mahabub.downloder.ads.AdMobSdk

class VideoDownloaderApp : Application() {

    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        // Initialize once before HomeNativeAdCard requests the Google Native TEST Ad.
        AdMobSdk.initialize(this)
    }
}
