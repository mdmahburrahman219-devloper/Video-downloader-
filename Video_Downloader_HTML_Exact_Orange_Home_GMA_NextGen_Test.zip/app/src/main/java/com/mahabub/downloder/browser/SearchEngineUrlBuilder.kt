package com.mahabub.downloder.browser

import java.net.URLEncoder

/** Builds real search URLs for the engines exposed in Settings. */
object SearchEngineUrlBuilder {
    fun build(query: String, engine: String, customTemplate: String = ""): String {
        val encoded = URLEncoder.encode(query.trim(), "UTF-8")
        val template = when (engine) {
            "Ask" -> "https://www.ask.com/web?q=%s"
            "Bing" -> "https://www.bing.com/search?q=%s"
            "Yahoo" -> "https://search.yahoo.com/search?p=%s"
            "StartPage" -> "https://www.startpage.com/sp/search?query=%s"
            "StartPage (Mobile)" -> "https://www.startpage.com/do/m/mobilesearch?query=%s"
            "DuckDuckGo (Privacy)" -> "https://duckduckgo.com/?q=%s"
            "DuckDuckGo Lite (Privacy)" -> "https://lite.duckduckgo.com/lite/?q=%s"
            "Baidu (Chinese)" -> "https://www.baidu.com/s?wd=%s"
            "Yandex (Russian)" -> "https://yandex.com/search/?text=%s"
            "Custom URL" -> validatedCustomTemplate(customTemplate)
            else -> "https://www.google.com/search?q=%s"
        }
        return template.replace("%s", encoded)
    }

    private fun validatedCustomTemplate(raw: String): String {
        val candidate = raw.trim()
        if (!candidate.contains("%s")) return "https://www.google.com/search?q=%s"
        val base = candidate.replace("%s", "probe")
        val valid = runCatching {
            val uri = java.net.URI(base)
            uri.scheme.equals("https", true) || uri.scheme.equals("http", true)
        }.getOrDefault(false)
        return if (valid) candidate else "https://www.google.com/search?q=%s"
    }
}
