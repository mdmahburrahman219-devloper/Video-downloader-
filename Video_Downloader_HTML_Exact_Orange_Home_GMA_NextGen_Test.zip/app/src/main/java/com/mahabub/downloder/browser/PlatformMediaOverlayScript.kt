package com.mahabub.downloder.browser

import com.mahabub.downloder.model.PlatformSource
import java.net.URI
import java.util.Locale

/**
 * Per-media download overlay used only on Facebook, Instagram and Threads pages.
 * The script never enumerates hidden API payloads or bypasses page access controls: it attaches
 * an explicit user action to image/video elements that the signed-in WebView has rendered.
 */
object PlatformMediaOverlayScript {
    fun platformForUrl(rawUrl: String?): PlatformSource? {
        val value = rawUrl?.trim()?.takeIf { it.isNotBlank() } ?: return null
        val uri = runCatching { URI(value) }.getOrNull() ?: return null
        if (!uri.scheme.equals("https", true) && !uri.scheme.equals("http", true)) return null
        val host = uri.host?.lowercase(Locale.ROOT).orEmpty()
        return when {
            host == "facebook.com" || host.endsWith(".facebook.com") || host == "fb.watch" || host.endsWith(".fb.watch") || host == "fb.com" || host.endsWith(".fb.com") -> PlatformSource.FACEBOOK
            host == "instagram.com" || host.endsWith(".instagram.com") || host == "instagr.am" || host.endsWith(".instagr.am") -> PlatformSource.INSTAGRAM
            host == "threads.com" || host.endsWith(".threads.com") || host == "threads.net" || host.endsWith(".threads.net") -> PlatformSource.THREADS
            else -> null
        }
    }

    fun supportsUrl(rawUrl: String?): Boolean = platformForUrl(rawUrl) != null

    fun isSingleMediaPostUrl(rawUrl: String?): Boolean {
        val platform = platformForUrl(rawUrl) ?: return false
        val value = rawUrl?.trim()?.takeIf { it.isNotBlank() } ?: return false
        val parsed = runCatching { URI(value) }.getOrNull() ?: return false
        val path = parsed.path.orEmpty().lowercase(Locale.ROOT)
        val host = parsed.host.orEmpty().lowercase(Locale.ROOT)
        return when (platform) {
            PlatformSource.FACEBOOK -> host == "fb.watch" || listOf("/watch", "/videos/", "/video.php", "/reel/", "/reels/", "/posts/", "/permalink.php", "/photo", "/photos/", "/stories/", "/story.php", "/share/").any { path.contains(it) }
            PlatformSource.INSTAGRAM -> listOf("/p/", "/reel/", "/reels/", "/tv/", "/stories/", "/share/").any { path.contains(it) }
            PlatformSource.THREADS -> path.contains("/post/") || path.contains("/t/")
            else -> false
        }
    }

    fun isAllowedMediaUrl(platform: PlatformSource, rawUrl: String?): Boolean {
        val value = rawUrl?.trim()?.takeIf { it.isNotBlank() } ?: return false
        val uri = runCatching { URI(value) }.getOrNull() ?: return false
        if (!uri.scheme.equals("https", true) && !uri.scheme.equals("http", true)) return false
        val host = uri.host?.lowercase(Locale.ROOT).orEmpty()
        if (host.isBlank()) return false
        val suffixes = when (platform) {
            PlatformSource.FACEBOOK -> listOf("facebook.com", "fb.com", "fb.watch", "fbcdn.net", "fbsbx.com")
            PlatformSource.INSTAGRAM -> listOf("instagram.com", "instagr.am", "cdninstagram.com", "fbcdn.net", "fbsbx.com")
            PlatformSource.THREADS -> listOf("threads.net", "threads.com", "cdninstagram.com", "fbcdn.net", "fbsbx.com")
            else -> emptyList()
        }
        return suffixes.any { host == it || host.endsWith(".$it") }
    }

    val JAVASCRIPT = """
        (function () {
          'use strict';
          var host = String(location.hostname || '').toLowerCase();
          var allowed = host === 'facebook.com' || host.endsWith('.facebook.com') ||
            host === 'fb.watch' || host.endsWith('.fb.watch') || host === 'fb.com' || host.endsWith('.fb.com') ||
            host === 'instagram.com' || host.endsWith('.instagram.com') || host === 'instagr.am' || host.endsWith('.instagr.am') ||
            host === 'threads.net' || host.endsWith('.threads.net') || host === 'threads.com' || host.endsWith('.threads.com');
          if (!allowed || !document.documentElement) return;
          if (window.__vdPlatformMediaOverlay) {
            try { window.__vdPlatformMediaOverlay.scan(); } catch (e) {}
            return;
          }
          window.__vdPlatformMediaOverlay = { installed: true };

          var MAX_BUTTONS = 500;
          var buttonByElement = new WeakMap();
          var elements = new Set();
          var observedElements = new WeakSet();
          var scanTimer = 0;
          var updateScheduled = false;
          var intersectionObserver = null;
          var root = document.createElement('div');
          root.setAttribute('data-vd-overlay-root', '1');
          root.style.cssText = 'position:fixed;inset:0;z-index:2147483000;pointer-events:none;contain:layout style;';
          var shadow = root.attachShadow ? root.attachShadow({mode:'closed'}) : root;
          var style = document.createElement('style');
          style.textContent = '.vd-btn{position:absolute;display:flex;align-items:center;justify-content:center;width:42px;height:42px;border:0;border-radius:50%;padding:0;background:#f3293b;color:#fff;box-shadow:0 2px 7px rgba(0,0,0,.34);pointer-events:auto;touch-action:manipulation;z-index:2;cursor:pointer;-webkit-tap-highlight-color:transparent}.vd-btn:active{transform:scale(.94)}.vd-btn svg{width:24px;height:24px;fill:none;stroke:#fff;stroke-width:2.5;stroke-linecap:round;stroke-linejoin:round}.vd-btn[hidden]{display:none!important}';
          shadow.appendChild(style);
          document.documentElement.appendChild(root);

          function absoluteHttpUrl(raw) {
            if (!raw || typeof raw !== 'string' || /^(?:blob:|data:|javascript:)/i.test(raw)) return '';
            try {
              var u = new URL(raw, document.baseURI);
              return (u.protocol === 'https:' || u.protocol === 'http:') ? u.href.split('#')[0] : '';
            } catch (e) { return ''; }
          }

          function isAllowedMediaUrl(raw) {
            var url = absoluteHttpUrl(raw);
            if (!url) return false;
            try {
              var mediaHost = new URL(url).hostname.toLowerCase();
              function matches(suffix) { return mediaHost === suffix || mediaHost.endsWith('.' + suffix); }
              if (host === 'facebook.com' || host.endsWith('.facebook.com') || host === 'fb.watch' || host.endsWith('.fb.watch') || host === 'fb.com' || host.endsWith('.fb.com')) {
                return matches('facebook.com') || matches('fb.com') || matches('fb.watch') || matches('fbcdn.net') || matches('fbsbx.com');
              }
              if (host === 'instagram.com' || host.endsWith('.instagram.com') || host === 'instagr.am' || host.endsWith('.instagr.am')) {
                return matches('instagram.com') || matches('instagr.am') || matches('cdninstagram.com') || matches('fbcdn.net') || matches('fbsbx.com');
              }
              if (host === 'threads.com' || host.endsWith('.threads.com') || host === 'threads.net' || host.endsWith('.threads.net')) {
                return matches('threads.com') || matches('threads.net') || matches('cdninstagram.com') || matches('fbcdn.net') || matches('fbsbx.com');
              }
            } catch (e) {}
            return false;
          }

          function bestSrcset(srcset) {
            if (!srcset) return '';
            var entries = String(srcset).split(',');
            var best = null;
            for (var i = 0; i < entries.length; i++) {
              var part = entries[i].trim();
              if (!part) continue;
              var match = /^(\S+)(?:\s+(\d+(?:\.\d+)?)(w|x))?$/.exec(part);
              if (!match) continue;
              var score = match[2] ? Number(match[2]) * (match[3] === 'x' ? 1000 : 1) : 1;
              if (!best || score > best.score) best = {url: match[1], score: score};
            }
            return best ? best.url : '';
          }

          function getImageUrl(img) {
            var raw = '';
            try {
              var tag = String(img.tagName || '').toUpperCase();
              if (tag === 'IMG') {
                raw = bestSrcset(img.getAttribute('srcset') || '') || img.currentSrc || img.getAttribute('data-original') ||
                  img.getAttribute('data-src') || img.getAttribute('src') || '';
                if (!raw) {
                  var picture = img.closest && img.closest('picture');
                  var source = picture && picture.querySelector('source[srcset]');
                  if (source) raw = bestSrcset(source.getAttribute('srcset'));
                }
              } else {
                var bg = getComputedStyle(img).backgroundImage || '';
                var match = /url\([\"']?(.*?)[\"']?\)/i.exec(bg);
                if (match) raw = match[1] || '';
              }
            } catch (e) {}
            return absoluteHttpUrl(raw);
          }

          function getVideoUrl(video) {
            var raw = '';
            try {
              raw = video.currentSrc || video.getAttribute('src') || '';
              if (!raw && video.querySelector) {
                var source = video.querySelector('source[src],source[data-src]');
                if (source) raw = source.src || source.getAttribute('data-src') || '';
              }
              if (!raw) {
                var attrs = ['data-video-src','data-video-url','data-playback-url','data-mp4','data-m3u8','data-hls'];
                for (var ai = 0; ai < attrs.length && !raw; ai++) raw = video.getAttribute(attrs[ai]) || '';
              }
              if (!absoluteHttpUrl(raw)) raw = video.__vdLastMediaResourceUrl || '';
              if (!absoluteHttpUrl(raw)) {
                var list = window.__vdPlatformMediaResources || [];
                var recent = list.filter(function (r) {
                  return r && r.url && (Date.now() - Number(r.at || 0)) < 180000 &&
                    /^(?:video\/|application\/(?:vnd\.apple\.mpegurl|x-mpegurl|dash\+xml))/i.test(String(r.mime || ''));
                });
                var playing = !video.paused && !video.ended;
                if (playing) recent = recent.filter(function(r){ return !!r.playing; });
                // Never guess across several feed videos. Use a network candidate only when this
                // is the sole visible video, or there is exactly one active playback candidate.
                var visibleVideos = Array.prototype.filter.call(document.querySelectorAll('video'), function(v){
                  var r=v.getBoundingClientRect(); return r.width>70 && r.height>70 && r.bottom>0 && r.top<innerHeight;
                });
                var unique = {};
                recent.forEach(function(r){ unique[r.url]=r; });
                var candidates = Object.keys(unique).map(function(k){return unique[k];});
                if ((playing && candidates.length === 1) || (visibleVideos.length === 1 && candidates.length === 1)) {
                  raw = candidates[0].url;
                }
              }
            } catch (e) {}
            return absoluteHttpUrl(raw);
          }

          function findAncestor(el, predicate, maxDepth) {
            var node = el;
            for (var depth = 0; node && depth < (maxDepth || 8); depth++, node = node.parentElement) {
              try { if (predicate(node)) return node; } catch (e) {}
            }
            return null;
          }

          function isFriendRequestCard(el) {
            return !!findAncestor(el, function(node) {
              var text = String(node.innerText || '').replace(/\s+/g, ' ').trim();
              if (!text || text.length > 900) return false;
              return /(?:add friend|confirm|accept request|accept|decline|delete request|cancel request)/i.test(text) &&
                !!(node.querySelector && node.querySelector('button,[role="button"]'));
            }, 7);
          }

          function isReelOrStoryVisual(el) {
            var pagePath = String(location.pathname || '').toLowerCase();
            if (/\/(?:reel|reels)\//.test(pagePath)) return 'reel';
            if (/\/stories\//.test(pagePath) || /story\.php/i.test(pagePath)) return 'story';
            var link = null;
            try { link = el.closest && el.closest('a[href]'); } catch (e) {}
            var href = link ? String(link.href || link.getAttribute('href') || '').toLowerCase() : '';
            if (/\/(?:reel|reels)\//.test(href)) return 'reel';
            if (/\/stories\//.test(href) || /story\.php/i.test(href)) return 'story';
            var hints = '';
            try {
              var node = findAncestor(el, function(n) {
                var value = [n.getAttribute && n.getAttribute('aria-label'), n.getAttribute && n.getAttribute('data-pagelet'),
                  n.getAttribute && n.getAttribute('data-testid'), n.className].join(' ');
                return /\b(reel|story|stories)\b/i.test(String(value));
              }, 6);
              if (node) hints = [node.getAttribute('aria-label'), node.getAttribute('data-pagelet'), node.getAttribute('data-testid'), node.className].join(' ');
            } catch (e) {}
            if (/\breel\b/i.test(hints)) return 'reel';
            if (/\bstor(?:y|ies)\b/i.test(hints)) return 'story';
            return '';
          }

          function isExcludedUiImage(el) {
            if (isFriendRequestCard(el)) return false;
            try {
              var rect = el.getBoundingClientRect();
              var width = rect.width || 0, height = rect.height || 0;
              var maxSide = Math.max(width, height);
              var minSide = Math.min(width, height);
              var ratio = maxSide > 0 ? minSide / maxSide : 0;
              var label = [el.getAttribute('alt'), el.getAttribute('title'), el.getAttribute('aria-label'),
                el.getAttribute('data-testid'), el.className].join(' ').toLowerCase();
              if (/(?:profile.?pic|avatar|reaction|emoji|emoticon|sticker|like.?icon|comment.?icon|share.?icon|create.?story)/i.test(label)) return true;

              var action = el.closest && el.closest('button,[role="button"]');
              if (action) {
                var actionText = String(action.innerText || action.getAttribute('aria-label') || '').trim();
                if (/(?:like|comment|share|react|reply|create story|add story|menu|more options)/i.test(actionText)) return true;
              }
              var commentRegion = findAncestor(el, function(node) {
                var aria = String(node.getAttribute && node.getAttribute('aria-label') || '');
                var test = String(node.getAttribute && node.getAttribute('data-testid') || '');
                var cls = String(node.className || '');
                return /comment/i.test(aria + ' ' + test + ' ' + cls);
              }, 5);
              // Profile avatars in comment threads are small and nearly square; keep genuine
              // attached comment photos eligible when they are larger or clearly landscape/portrait.
              if (commentRegion && maxSide <= 76 && ratio > 0.72) return true;

              // Avatars and reaction artwork are small, near-square assets. Preserve tall/wide
              // story/reel thumbnails and genuine post images even when their rendered size is modest.
              if (maxSide <= 76 && ratio > 0.72) return true;
              if (maxSide <= 128 && ratio > 0.82) {
                var profileLink = el.closest && el.closest('a[href]');
                var href = String(profileLink && (profileLink.href || profileLink.getAttribute('href')) || '').toLowerCase();
                var profilePath = '';
                try { profilePath = new URL(href, location.href).pathname.replace(/^\/+|\/+$/g, ''); } catch (e) {}
                var singleProfilePath = profilePath && profilePath.indexOf('/') < 0 &&
                  !/^(?:p|reel|reels|stories|watch|videos|photo|photos|explore|direct|accounts|settings|friends|groups|marketplace)$/i.test(profilePath);
                var roundness = String(getComputedStyle(el).borderRadius || '');
                if (/(?:profile\.php|\/profile\/|\/people\/|\/user\/|\/users\/)/.test(href) ||
                    ((host.indexOf('instagram') >= 0 || host.indexOf('facebook') >= 0) && singleProfilePath) ||
                    (/(?:50%|9999px)/.test(roundness) && maxSide <= 112)) return true;
              }
            } catch (e) {}
            return false;
          }

          function nearestMediaContainer(el) {
            return findAncestor(el, function(node) {
              if (!node.querySelector) return false;
              var selector = 'a[href*="/reel/"],a[href*="/reels/"],a[href*="/stories/"]';
              var link = node.matches && node.matches(selector) ? node : node.querySelector(selector);
              var videoCount = node.querySelectorAll ? node.querySelectorAll('video').length : 0;
              return !!link || videoCount > 0;
            }, 8) || (el && el.parentElement) || el;
          }

          function getVideoUrlForVisual(el) {
            if (String(el.tagName || '').toUpperCase() === 'VIDEO') return getVideoUrl(el);
            var visualUrl = getImageUrl(el);
            var container = nearestMediaContainer(el);
            if (container && container.querySelectorAll) {
              var videos = container.querySelectorAll('video');
              if (videos.length === 1) {
                var exact = getVideoUrl(videos[0]);
                if (exact) return exact;
              } else if (videos.length > 1 && visualUrl) {
                for (var i = 0; i < videos.length; i++) {
                  var poster = absoluteHttpUrl(videos[i].poster || videos[i].getAttribute('poster') || '');
                  if (poster && poster === visualUrl) {
                    var matched = getVideoUrl(videos[i]);
                    if (matched) return matched;
                  }
                }
              }
              var attrs = ['data-video-url','data-video-src','data-playback-url','data-mp4','data-m3u8','data-hls'];
              var dataNode = container.querySelector('[data-video-url],[data-video-src],[data-playback-url],[data-mp4],[data-m3u8],[data-hls]');
              for (var j = 0; j < attrs.length; j++) {
                var candidate = absoluteHttpUrl((container.getAttribute && container.getAttribute(attrs[j])) ||
                  (dataNode && dataNode.getAttribute && dataNode.getAttribute(attrs[j])));
                if (candidate && isAllowedMediaUrl(candidate)) return candidate;
              }
            }
            // The clickable story/reel poster and its player may be siblings. Walk only a few
            // nearby ancestors; never scan the entire feed and guess which of several videos belongs here.
            var parentContainer = container && container.parentElement;
            for (var depth = 0; parentContainer && depth < 4 && parentContainer !== document.body; depth++, parentContainer = parentContainer.parentElement) {
              if (!parentContainer.querySelectorAll) continue;
              var nearbyVideos = parentContainer.querySelectorAll('video');
              if (nearbyVideos.length === 1) {
                var nearbyUrl = getVideoUrl(nearbyVideos[0]);
                if (nearbyUrl) return nearbyUrl;
              } else if (nearbyVideos.length > 1 && visualUrl) {
                for (var nv = 0; nv < nearbyVideos.length; nv++) {
                  var nearbyPoster = absoluteHttpUrl(nearbyVideos[nv].poster || nearbyVideos[nv].getAttribute('poster') || '');
                  if (nearbyPoster && nearbyPoster === visualUrl) {
                    var nearbyMatch = getVideoUrl(nearbyVideos[nv]);
                    if (nearbyMatch) return nearbyMatch;
                  }
                }
              }
            }
            // Some platform layouts render the poster separately from the one active player.
            // Match the poster URL exactly before considering a single visible player fallback.
            if (visualUrl) {
              var allVideos = document.querySelectorAll('video');
              for (var vi = 0; vi < allVideos.length; vi++) {
                var knownPoster = absoluteHttpUrl(allVideos[vi].poster || allVideos[vi].getAttribute('poster') || '');
                if (knownPoster && knownPoster === visualUrl) {
                  var posterMatchUrl = getVideoUrl(allVideos[vi]);
                  if (posterMatchUrl) return posterMatchUrl;
                }
              }
              var visiblePlayers = Array.prototype.filter.call(allVideos, function(v) {
                var r = v.getBoundingClientRect();
                return r.width > 70 && r.height > 70 && r.bottom > 0 && r.top < innerHeight && r.right > 0 && r.left < innerWidth;
              });
              if (visiblePlayers.length === 1) {
                var onlyPlayerUrl = getVideoUrl(visiblePlayers[0]);
                if (onlyPlayerUrl) return onlyPlayerUrl;
              }
            }
            // A carousel tile can expose only its poster before the actual video is loaded.
            // Do not mislabel that poster as a video or download the thumbnail as a substitute.
            return '';
          }

          function posterUrlForVisual(el) {
            try {
              if (String(el.tagName || '').toUpperCase() === 'VIDEO') {
                var ownPoster = absoluteHttpUrl(el.poster || el.getAttribute('poster') ||
                  el.getAttribute('data-poster') || el.getAttribute('data-thumbnail') || '');
                if (ownPoster) return ownPoster;
              }
              var image = getImageUrl(el);
              if (image) return image;
              var container = nearestMediaContainer(el);
              if (container && container.querySelectorAll) {
                var imgs = container.querySelectorAll('img');
                for (var i = 0; i < Math.min(imgs.length, 8); i++) {
                  var candidate = getImageUrl(imgs[i]);
                  if (candidate && isAllowedMediaUrl(candidate)) return candidate;
                }
                var videos = container.querySelectorAll('video');
                for (var j = 0; j < Math.min(videos.length, 4); j++) {
                  var poster = absoluteHttpUrl(videos[j].poster || videos[j].getAttribute('poster') || '');
                  if (poster) return poster;
                }
              }
            } catch (e) {}
            return '';
          }

          function facebookDashEntryForVisual(el) {
            try {
              if (!(host === 'facebook.com' || host.endsWith('.facebook.com') || host === 'fb.com' ||
                    host.endsWith('.fb.com') || host === 'fb.watch' || host.endsWith('.fb.watch'))) return null;
              var api = window.__vdFacebookMse;
              if (!api || typeof api.entryForVideo !== 'function') return null;
              var tag = String(el && el.tagName || '').toUpperCase();
              if (tag === 'VIDEO') return api.entryForVideo(el);
              var poster = getImageUrl(el);
              var container = nearestMediaContainer(el);
              if (container && container.querySelectorAll) {
                var videos = container.querySelectorAll('video');
                if (poster) {
                  for (var i = 0; i < videos.length; i++) {
                    var candidatePoster = absoluteHttpUrl(videos[i].poster || videos[i].getAttribute('poster') || '');
                    if (candidatePoster && candidatePoster === poster) {
                      var exactEntry = api.entryForVideo(videos[i]);
                      if (exactEntry) return exactEntry;
                    }
                  }
                }
                if (videos.length === 1) return api.entryForVideo(videos[0]);
              }
            } catch (e) {}
            return null;
          }

          function contentItemPageUrl(el) {
            function isTargetLink(raw) {
              try {
                var u = new URL(raw, location.href);
                if (u.protocol !== 'https:' && u.protocol !== 'http:') return false;
                var h = u.hostname.toLowerCase();
                var samePlatformHost =
                  ((host === 'facebook.com' || host.endsWith('.facebook.com') || host === 'fb.watch' || host.endsWith('.fb.watch') || host === 'fb.com' || host.endsWith('.fb.com')) &&
                    (h === 'facebook.com' || h.endsWith('.facebook.com') || h === 'fb.watch' || h.endsWith('.fb.watch') || h === 'fb.com' || h.endsWith('.fb.com'))) ||
                  ((host === 'instagram.com' || host.endsWith('.instagram.com') || host === 'instagr.am' || host.endsWith('.instagr.am')) &&
                    (h === 'instagram.com' || h.endsWith('.instagram.com') || h === 'instagr.am' || h.endsWith('.instagr.am'))) ||
                  ((host === 'threads.com' || host.endsWith('.threads.com') || host === 'threads.net' || host.endsWith('.threads.net')) &&
                    (h === 'threads.com' || h.endsWith('.threads.com') || h === 'threads.net' || h.endsWith('.threads.net')));
                if (!samePlatformHost) return false;
                var path = u.pathname.toLowerCase();
                return /\/(?:reel|reels|stories|story\.php|watch|videos?|video\.php|p|tv|post)\//.test(path) ||
                  /(?:story_fbid|fbid|v|video_id)=/i.test(u.search);
              } catch (e) { return false; }
            }
            try {
              var anchor = el.closest && el.closest('a[href]');
              if (anchor && isTargetLink(anchor.href || anchor.getAttribute('href') || '')) return new URL(anchor.href || anchor.getAttribute('href'), location.href).href;
              var container = nearestMediaContainer(el);
              if (container && container.querySelectorAll) {
                var links = container.querySelectorAll('a[href]');
                for (var i = 0; i < Math.min(links.length, 24); i++) {
                  var href = links[i].href || links[i].getAttribute('href') || '';
                  if (isTargetLink(href)) return new URL(href, location.href).href;
                }
              }
              var pagePath = String(location.pathname || '').toLowerCase();
              if (/\/(?:reel|reels|stories|story\.php|watch|videos?|video\.php|p|tv|post)\//.test(pagePath) ||
                  /(?:story_fbid|fbid|v|video_id)=/i.test(location.search || '')) return location.href;
            } catch (e) {}
            return '';
          }

          function hasAssociatedVideoElement(el) {
            if (String(el.tagName || '').toUpperCase() === 'VIDEO') return true;
            var container = nearestMediaContainer(el);
            var selector = 'video,[data-video-url],[data-video-src],[data-playback-url],[data-mp4],[data-m3u8],[data-hls]';
            if (container && container.querySelector && container.querySelector(selector)) return true;
            var parent = container && container.parentElement;
            for (var depth = 0; parent && depth < 3 && parent !== document.body; depth++, parent = parent.parentElement) {
              var videos = parent.querySelectorAll ? parent.querySelectorAll('video') : [];
              if (videos.length === 1) return true;
            }
            return false;
          }

          function mediaKindFor(el) {
            var tag = String(el.tagName || '').toUpperCase();
            if (tag === 'VIDEO') return 'video';
            var mediaContext = isReelOrStoryVisual(el);
            if (mediaContext === 'reel') return 'video';
            if (mediaContext === 'story' && (hasAssociatedVideoElement(el) || getVideoUrlForVisual(el))) return 'video';
            return 'image';
          }

          function titleFor(el, kind) {
            try {
              var value = kind === 'image' ? (el.getAttribute('alt') || el.getAttribute('aria-label') || el.getAttribute('title')) :
                (el.getAttribute('aria-label') || el.getAttribute('title'));
              if (!value) {
                var parent = el.closest && el.closest('article,[role="article"],section');
                if (parent) {
                  var text = String(parent.innerText || '').replace(/\s+/g,' ').trim();
                  if (text) value = text.slice(0, 100);
                }
              }
              return String(value || document.title || (kind === 'image' ? 'Social image' : 'Social video')).slice(0,180);
            } catch (e) { return kind === 'image' ? 'Social image' : 'Social video'; }
          }

          function mimeFor(url, kind, el) {
            var text = String(url || '').toLowerCase().split('?')[0];
            var ext = (text.match(/\.([a-z0-9]+)$/) || [])[1] || '';
            var map = {jpg:'image/jpeg',jpeg:'image/jpeg',png:'image/png',webp:'image/webp',gif:'image/gif',avif:'image/avif',bmp:'image/bmp',mp4:'video/mp4',m4v:'video/mp4',webm:'video/webm',mov:'video/quicktime',m3u8:'application/vnd.apple.mpegurl',mpd:'application/dash+xml'};
            if (map[ext]) return map[ext];
            if (kind === 'video') return 'video/mp4';
            return 'image/jpeg';
          }

          function createButton(el, kind) {
            var existing = buttonByElement.get(el);
            if (existing) return existing;
            if (elements.size >= MAX_BUTTONS) return null;
            var button = document.createElement('button');
            button.className = 'vd-btn';
            button.type = 'button';
            button.setAttribute('aria-label', kind === 'image' ? 'Download image' : 'Download video');
            button.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3v11m0 0 4-4m-4 4-4-4M4 17v3h16v-3"/></svg>';
            button.addEventListener('pointerdown', function(e){e.preventDefault();e.stopPropagation();}, true);
            button.addEventListener('click', function(e){
              e.preventDefault(); e.stopPropagation(); if (e.stopImmediatePropagation) e.stopImmediatePropagation();
              var currentKind = mediaKindFor(el);
              var url = currentKind === 'image' ? getImageUrl(el) : getVideoUrlForVisual(el);
              if (url && !isAllowedMediaUrl(url)) url = '';
              var mime = mimeFor(url, currentKind, el);
              var title = titleFor(el, currentKind);
              var bridge = window.AndroidMediaBridge;
              if (bridge && typeof bridge.onPlatformMediaAction === 'function') {
                var posterTarget = currentKind === 'video' && String(el.tagName || '').toUpperCase() !== 'VIDEO';
                var poster = posterTarget ? posterUrlForVisual(el) : '';
                var itemPage = posterTarget ? contentItemPageUrl(el) : '';
                var fbDashEntry = currentKind === 'video' ? facebookDashEntryForVisual(el) : null;
                if (fbDashEntry) {
                  if (!itemPage && fbDashEntry.itemUrl) itemPage = fbDashEntry.itemUrl;
                  if (!poster && fbDashEntry.poster) poster = fbDashEntry.poster;
                  if ((!title || title === document.title) && fbDashEntry.title) title = fbDashEntry.title;
                }
                try {
                  bridge.onPlatformMediaAction(
                    currentKind, url || '', mime, title, Number(el.duration || (fbDashEntry && fbDashEntry.duration) || 0),
                    Number(el.naturalWidth || el.videoWidth || 0), Number(el.naturalHeight || el.videoHeight || 0),
                    posterTarget, poster, itemPage
                  );
                } catch (err) {}
              }
            }, true);
            shadow.appendChild(button);
            buttonByElement.set(el, button);
            elements.add(el);
            return button;
          }

          function visibleBox(el, kind) {
            try {
              if (!el || !el.isConnected) return null;
              var rect = el.getBoundingClientRect();
              var min = kind === 'image' ? 26 : 70;
              if (rect.width < min || rect.height < min || rect.bottom <= 0 || rect.top >= innerHeight || rect.right <= 0 || rect.left >= innerWidth) return null;
              var visibleWidth = Math.max(0, Math.min(rect.right, innerWidth) - Math.max(rect.left, 0));
              var visibleHeight = Math.max(0, Math.min(rect.bottom, innerHeight) - Math.max(rect.top, 0));
              var visibleRatio = (visibleWidth * visibleHeight) / Math.max(1, rect.width * rect.height);
              var largeVideoSurface = kind === 'video' && rect.height >= innerHeight * 0.45 && rect.width >= innerWidth * 0.55;
              // On a vertical Reels player, hide neighbouring/previous Reel media that is only
              // peeking into the viewport; the active full-size player owns the visible action.
              if (largeVideoSurface && visibleRatio < 0.62) return null;
              var style = getComputedStyle(el);
              if (style.display === 'none' || style.visibility === 'hidden' || Number(style.opacity) < 0.05) return null;
              return rect;
            } catch (e) { return null; }
          }

          function positionButton(el) {
            if (!el || !el.isConnected) {
              var stale = buttonByElement.get(el);
              if (stale && stale.parentNode) stale.parentNode.removeChild(stale);
              elements.delete(el);
              return;
            }
            var kind = mediaKindFor(el);
            var rect = visibleBox(el, kind);
            var button = buttonByElement.get(el);
            if (!rect) {
              // Keep the same element/button identity while it is temporarily off-screen.
              // It is hidden, not destroyed/recreated, so virtualized Reels do not cause button churn.
              if (button) button.hidden = true;
              return;
            }
            if (!button) button = createButton(el, kind);
            if (!button) return;
            button.hidden = false;
            button.setAttribute('aria-label', kind === 'image' ? 'Download image' : 'Download video');
            var size = 42;
            var mediaContext = isReelOrStoryVisual(el);
            var isFullScreenReel = rect.height >= innerHeight * 0.48 && rect.width >= innerWidth * 0.58 &&
              (mediaContext === 'reel' || String(el.tagName || '').toUpperCase() === 'VIDEO');
            var left = Math.max(3, Math.min(innerWidth - size - 3, rect.right - size - 7));
            // On a full-screen Reels player, align with the comment/action rail rather than
            // the bottom edge. The position stays identical as the next Reel occupies the player.
            var preferredTop = isFullScreenReel
              ? rect.top + rect.height * 0.69 - size / 2
              : rect.bottom - size - 7;
            var top = Math.max(3, Math.min(innerHeight - size - 3, preferredTop));
            button.style.left = Math.round(left) + 'px';
            button.style.top = Math.round(top) + 'px';
          }

          function observeMediaElement(el) {
            if (!el || observedElements.has(el)) return;
            observedElements.add(el);
            if (intersectionObserver) {
              try { intersectionObserver.observe(el); } catch (e) {}
            }
          }

          try {
            if ('IntersectionObserver' in window) {
              intersectionObserver = new IntersectionObserver(function(entries) {
                entries.forEach(function(entry) {
                  var target = entry.target;
                  if (!target || !target.isConnected) return;
                  // Off-screen buttons are hidden but retain their element identity.
                  positionButton(target);
                });
              }, { root: null, rootMargin: '0px', threshold: 0.01 });
            }
          } catch (e) { intersectionObserver = null; }

          function scan() {
            scanTimer = 0;
            try {
              var imgs = document.querySelectorAll('img');
              for (var i = 0; i < imgs.length; i++) {
                var img = imgs[i];
                var imageUrl = getImageUrl(img);
                if (!imageUrl || !isAllowedMediaUrl(imageUrl) || isExcludedUiImage(img)) continue;
                // Avoid a second button on a poster image when its media container already has
                // a real video player; that player owns the single download action.
                var owner = nearestMediaContainer(img);
                if (owner && owner.querySelectorAll) {
                  var ownerVideos = owner.querySelectorAll('video');
                  if (ownerVideos.length === 1) {
                    var ownerPoster = absoluteHttpUrl(ownerVideos[0].poster || ownerVideos[0].getAttribute('poster') || '');
                    if (!ownerPoster || ownerPoster === imageUrl) continue;
                  }
                }
                var r = img.getBoundingClientRect();
                if (r.width < 26 || r.height < 26) continue;
                observeMediaElement(img);
                positionButton(img);
              }
              // Some story/profile surfaces render as CSS background images instead of <img>.
              // Keep this fallback limited to inline background-image nodes and skip containers
              // that already contain a real image/video element to prevent duplicate buttons.
              var backgrounds = document.querySelectorAll('[style*="background-image"],[role="img"],[data-visualcompletion="media-vc-image"]');
              for (var b = 0; b < backgrounds.length; b++) {
                var bg = backgrounds[b];
                var backgroundUrl = getImageUrl(bg);
                if ((bg.querySelector && bg.querySelector('img,video')) || !backgroundUrl || !isAllowedMediaUrl(backgroundUrl) || isExcludedUiImage(bg)) continue;
                var br = bg.getBoundingClientRect();
                if (br.width < 48 || br.height < 48) continue;
                observeMediaElement(bg);
                positionButton(bg);
              }
              var videos = document.querySelectorAll('video');
              for (var j = 0; j < videos.length; j++) {
                var video = videos[j];
                if (video.getBoundingClientRect().width < 70) continue;
                observeMediaElement(video);
                positionButton(video);
              }
              elements.forEach(function(el){ if (!el.isConnected) { var b=buttonByElement.get(el); if(b&&b.parentNode)b.parentNode.removeChild(b); elements.delete(el); if(intersectionObserver) try{intersectionObserver.unobserve(el);}catch(e){} } });
            } catch (e) {}
          }

          function scheduleScan(delay) { if (scanTimer) return; scanTimer = setTimeout(scan, typeof delay === 'number' ? delay : 350); }
          function schedulePosition() {
            if (updateScheduled) return;
            updateScheduled = true;
            requestAnimationFrame(function(){ updateScheduled=false; elements.forEach(positionButton); });
          }

          try {
            new MutationObserver(function(mutations){
              var changed = false;
              for (var i=0;i<mutations.length;i++) {
                var m=mutations[i];
                if (m.type === 'attributes' && m.target && (/^(IMG|VIDEO|SOURCE)$/.test(m.target.tagName || '') || m.attributeName === 'style')) { changed=true; break; }
                if (m.addedNodes) for (var j=0;j<m.addedNodes.length;j++) {
                  var n=m.addedNodes[j];
                  if (n && n.nodeType===1 && ((n.matches && n.matches('img,video,[style*="background-image"],[role="img"],[data-visualcompletion="media-vc-image"]')) || (n.querySelector && n.querySelector('img,video,[style*="background-image"],[role="img"],[data-visualcompletion="media-vc-image"]')))) { changed=true; break; }
                }
                if (!changed && m.removedNodes && m.removedNodes.length) changed=true;
                if (changed) break;
              }
              if (changed) scheduleScan(320);
            }).observe(document.documentElement,{childList:true,subtree:true,attributes:true,attributeFilter:['src','srcset','data-src','data-original','poster','class','style']});
          } catch(e){}
          window.addEventListener('scroll',function(){
            schedulePosition();
            // IntersectionObserver brings newly visible feed media into the overlay without
            // forcing a complete DOM scan on every scroll frame. Older WebViews get a throttled fallback.
            if (!intersectionObserver) scheduleScan(650);
          },{passive:true,capture:true});
          window.addEventListener('resize',schedulePosition,{passive:true});
          document.addEventListener('load',function(e){ if(e.target && /^(IMG|VIDEO)$/.test(e.target.tagName || '')) scheduleScan(120); },true);
          ['loadedmetadata','emptied','play','pause'].forEach(function(name){
            document.addEventListener(name,function(e){
              if(e.target && String(e.target.tagName || '').toUpperCase()==='VIDEO') scheduleScan(80);
            },true);
          });
          document.addEventListener('visibilitychange',function(){if(document.visibilityState==='visible')scheduleScan(100);});
          window.__vdPlatformMediaOverlay.scan = function(){scheduleScan(0);};
          scan();
        })();
    """.trimIndent()
}
