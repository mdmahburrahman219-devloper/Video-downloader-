package com.mahabub.downloder.ads

import android.app.Activity
import android.content.Context
import android.graphics.Color as AndroidColor
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.util.Log
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.libraries.ads.mobile.sdk.common.AdChoicesView
import com.google.android.libraries.ads.mobile.sdk.common.LoadAdError
import com.google.android.libraries.ads.mobile.sdk.nativead.MediaView
import com.google.android.libraries.ads.mobile.sdk.nativead.NativeAd
import com.google.android.libraries.ads.mobile.sdk.nativead.NativeAdLoader
import com.google.android.libraries.ads.mobile.sdk.nativead.NativeAdLoaderCallback
import com.google.android.libraries.ads.mobile.sdk.nativead.NativeAdRequest
import com.google.android.libraries.ads.mobile.sdk.nativead.NativeAdView
import java.util.concurrent.atomic.AtomicBoolean

private const val TAG = "HomeNativeAd"
private val AdCardBackground = AndroidColor.rgb(233, 233, 233)
private val AdButtonOrange = AndroidColor.rgb(255, 78, 12)
private val AdTextPrimary = AndroidColor.rgb(17, 17, 17)
private val AdTextSecondary = AndroidColor.rgb(85, 85, 85)

/** Loads and displays Google's real Native TEST Ad in the HTML reference card layout. */
@Composable
fun HomeNativeAdCard(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val sdkInitialized by AdMobSdk.isInitialized.collectAsState()
    val sdkInitializationFinished by AdMobSdk.initializationFinished.collectAsState()
    var nativeAd by remember { mutableStateOf<NativeAd?>(null) }
    var nativeAdView by remember { mutableStateOf<NativeAdView?>(null) }
    var isLoading by remember { mutableStateOf(true) }
    var loadFailed by remember { mutableStateOf(false) }

    androidx.compose.runtime.LaunchedEffect(sdkInitializationFinished, sdkInitialized) {
        if (sdkInitializationFinished && !sdkInitialized) {
            isLoading = false
            loadFailed = true
        }
    }

    DisposableEffect(context, sdkInitialized) {
        if (!sdkInitialized) {
            onDispose { }
        } else {
            val disposed = AtomicBoolean(false)
            val mainHandler = Handler(Looper.getMainLooper())
            try {
                val request = NativeAdRequest.Builder(
                    AdMobConfig.TEST_NATIVE_AD_UNIT_ID,
                    listOf(NativeAd.NativeAdType.NATIVE)
                ).build()

                val callback = object : NativeAdLoaderCallback {
                    override fun onNativeAdLoaded(loadedAd: NativeAd) {
                        mainHandler.post {
                            val activity = context as? Activity
                            if (disposed.get() || activity?.isFinishing == true || activity?.isDestroyed == true) {
                                loadedAd.destroy()
                            } else {
                                nativeAd = loadedAd
                                isLoading = false
                                loadFailed = false
                            }
                        }
                    }

                    override fun onAdFailedToLoad(adError: LoadAdError) {
                        Log.w(TAG, "Native test ad failed to load: ${adError.message}")
                        mainHandler.post {
                            if (!disposed.get()) {
                                isLoading = false
                                loadFailed = true
                            }
                        }
                    }
                }
                NativeAdLoader.load(request, callback)
            } catch (error: Exception) {
                Log.e(TAG, "Could not request native test ad", error)
                isLoading = false
                loadFailed = true
            }
            onDispose { disposed.set(true) }
        }
    }

    // Release both SDK ad assets and the registered NativeAdView when the card is removed.
    DisposableEffect(nativeAd) {
        val adToDestroy = nativeAd
        onDispose { adToDestroy?.destroy() }
    }
    DisposableEffect(nativeAdView) {
        val viewToDestroy = nativeAdView
        onDispose { viewToDestroy?.destroy() }
    }

    when {
        nativeAd != null -> {
            val ad = nativeAd
            key(ad) {
                AndroidView(
                    modifier = modifier.fillMaxWidth().height(203.dp),
                    factory = { viewContext ->
                        createNativeAdView(viewContext, ad!!).also { nativeAdView = it }
                    },
                    update = { view ->
                        if (nativeAdView !== view) nativeAdView = view
                    }
                )
            }
        }
        loadFailed || (sdkInitializationFinished && !sdkInitialized) -> Unit // Never show a fake ad on failure.
        isLoading -> {
            Surface(
                modifier = modifier.fillMaxWidth().height(203.dp),
                shape = RoundedCornerShape(16.dp),
                color = Color(0xFFE9E9E9)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(22.dp),
                        color = Color(0xFFFF5A2E),
                        strokeWidth = 2.dp
                    )
                }
            }
        }
    }
}

private fun createNativeAdView(context: Context, ad: NativeAd): NativeAdView {
    val density = context.resources.displayMetrics.density
    fun dp(value: Int): Int = (value * density + 0.5f).toInt()
    fun roundedBackground(color: Int, radiusDp: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radiusDp).toFloat()
        }

    val adView = NativeAdView(context).apply {
        background = roundedBackground(AdCardBackground, 16)
        clipToOutline = true
        setPadding(0, 0, 0, 0)
    }

    val cardContent = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(22), dp(10), dp(20), dp(8))
    }
    adView.addView(
        cardContent,
        FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT)
    )

    val contentRow = LinearLayout(context).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.TOP
    }

    val mediaView = MediaView(context).apply {
        setImageScaleType(android.widget.ImageView.ScaleType.CENTER_CROP)
        setBackgroundColor(AndroidColor.rgb(238, 243, 251))
    }
    val mediaFrame = FrameLayout(context).apply {
        addView(
            mediaView,
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        )
    }
    contentRow.addView(mediaFrame, LinearLayout.LayoutParams(dp(167), dp(128)))
    contentRow.addView(View(context), LinearLayout.LayoutParams(dp(9), dp(1)))

    val copyColumn = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(0, 0, dp(24), 0) // preserve room for the SDK's AdChoices attribution.
    }
    val titleRow = LinearLayout(context).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }
    val adBadge = TextView(context).apply {
        text = "AD"
        textSize = 12f
        setTextColor(AndroidColor.rgb(42, 42, 42))
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        gravity = Gravity.CENTER
        setPadding(dp(5), 0, dp(5), 0)
        background = GradientDrawable().apply {
            setColor(AndroidColor.TRANSPARENT)
            setStroke(dp(1), AndroidColor.rgb(42, 42, 42))
            cornerRadius = dp(5).toFloat()
        }
    }
    titleRow.addView(adBadge, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(20)))

    val headlineView = TextView(context).apply {
        text = ad.headline
        textSize = 16.5f
        setTextColor(AdTextPrimary)
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        maxLines = 2
        ellipsize = android.text.TextUtils.TruncateAt.END
        setPadding(dp(7), 0, 0, 0)
    }
    titleRow.addView(
        headlineView,
        LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
    )
    copyColumn.addView(titleRow)

    val bodyView = TextView(context).apply {
        text = ad.body.orEmpty()
        textSize = 13f
        setTextColor(AdTextSecondary)
        setLineSpacing(dp(1).toFloat(), 1f)
        maxLines = 4
        ellipsize = android.text.TextUtils.TruncateAt.END
        if (ad.body.isNullOrBlank()) visibility = View.GONE
    }
    copyColumn.addView(
        bodyView,
        LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(5)
        }
    )
    contentRow.addView(copyColumn, LinearLayout.LayoutParams(0, dp(128), 1f))
    cardContent.addView(contentRow, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(128)))

    val ctaView = Button(context).apply {
        text = ad.callToAction.orEmpty()
        isAllCaps = true
        textSize = 18f
        setTextColor(AndroidColor.WHITE)
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        background = roundedBackground(AdButtonOrange, 23)
        minHeight = 0
        minimumHeight = 0
        setPadding(dp(10), 0, dp(10), 0)
        elevation = dp(5).toFloat()
        if (ad.callToAction.isNullOrBlank()) visibility = View.GONE
    }
    cardContent.addView(
        ctaView,
        LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(46)).apply {
            topMargin = dp(11)
        }
    )

    // Use the SDK-provided AdChoicesView so attribution is not hidden or replaced.
    val adChoicesView: AdChoicesView = adView.adChoicesView
    adChoicesView.layoutParams = FrameLayout.LayoutParams(dp(24), dp(24), Gravity.TOP or Gravity.END).apply {
        topMargin = dp(2)
        marginEnd = dp(3)
    }
    if (adChoicesView.parent == null) adView.addView(adChoicesView)

    adView.setHeadlineView(headlineView)
    adView.setBodyView(bodyView)
    adView.setCallToActionView(ctaView)
    adView.registerNativeAd(ad, mediaView)
    return adView
}
