package com.mahabub.downloder.browser

import android.webkit.JavascriptInterface

/**
 * Minimal, read-only JS bridge. Its methods accept only HTTP(S) media URLs and metadata; no file,
 * storage, reflection, download, or application-control methods are exposed to page JavaScript.
 */
class AndroidMediaBridge(
    private val onVideoDetected: (
        url: String,
        title: String?,
        durationSeconds: Double?,
        resolution: String?,
        posterUrl: String?,
        isPlaying: Boolean,
        mimeType: String?,
        videoGroupId: String?
    ) -> Unit,
    private val onResourceDetected: (url: String, mimeType: String?, isPlaying: Boolean) -> Unit = { _, _, _ -> },
    private val onPageMetadataDetected: (title: String?, posterUrl: String?, durationSeconds: Double?) -> Unit = { _, _, _ -> },
    private val onScanFinishedCallback: (reportedCount: Int) -> Unit = { _ -> },
    private val onTikTokPlaybackConfirmedCallback: (pageUrl: String?) -> Unit = { _ -> },
    private val onPlatformMediaActionDetected: (
        kind: String, url: String?, mimeType: String?, title: String?,
        durationSeconds: Double, width: Int, height: Int, isVideoPosterTarget: Boolean,
        thumbnailUrl: String?, contentItemUrl: String?
    ) -> Unit = { _, _, _, _, _, _, _, _, _, _ -> },
    private val onInlineDashManifestDetected: (
        manifestText: String, responseUrl: String?, title: String?, durationSeconds: Double,
        posterUrl: String?, contentItemUrl: String?
    ) -> Unit = { _, _, _, _, _, _ -> },
    private val onMetaVideoDetected: (
        url: String, title: String?, durationSeconds: Double, posterUrl: String?,
        isPlaying: Boolean, mimeType: String?, videoGroupId: String?, contentItemUrl: String?
    ) -> Unit = { _, _, _, _, _, _, _, _ -> }
) {
    @JavascriptInterface
    fun onVideoFound(
        url: String?,
        title: String?,
        durationSeconds: Double,
        resolution: String?,
        posterUrl: String?,
        isPlaying: Boolean,
        mimeType: String?,
        videoGroupId: String?
    ) {
        val safeUrl = normalizeMediaUrl(url) ?: return
        val safeTitle = title?.take(300)?.takeIf { it.isNotBlank() }
        val safeDuration = durationSeconds.takeIf { it.isFinite() && it > 0.0 && it < 86_400.0 }
        val safeResolution = resolution?.takeIf { it.matches(Regex("\\d{2,5}x\\d{2,5}")) }
        val safePoster = normalizeMediaUrl(posterUrl)
        val safeMime = mimeType?.substringBefore(';')?.trim()?.take(120)?.takeIf { it.isNotBlank() }
        runCatching {
            onVideoDetected(
                safeUrl, safeTitle, safeDuration, safeResolution, safePoster, isPlaying, safeMime,
                videoGroupId?.take(120)?.takeIf { it.isNotBlank() }
            )
        }
    }

    /**
     * Receives a video URL explicitly associated with a video object in a Meta page response.
     * This is separate from onVideoFound so the generic eight-argument bridge stays compatible.
     */
    @JavascriptInterface
    fun onMetaVideoFound(
        url: String?,
        title: String?,
        durationSeconds: Double,
        posterUrl: String?,
        isPlaying: Boolean,
        mimeType: String?,
        videoGroupId: String?,
        contentItemUrl: String?
    ) {
        val safeUrl = normalizeMediaUrl(url) ?: return
        val safeTitle = title?.replace(Regex("[\\r\\n\\t]+"), " ")?.trim()?.take(280)
            ?.takeIf { it.isNotBlank() }
        val safeDuration = durationSeconds.takeIf { it.isFinite() && it > 0.0 && it < 86_400.0 } ?: 0.0
        val safePoster = normalizeMediaUrl(posterUrl)
        val safeMime = mimeType?.substringBefore(';')?.trim()?.take(120)?.takeIf { it.isNotBlank() }
        val safeGroup = videoGroupId?.take(120)?.takeIf { it.isNotBlank() }
        val safeItemUrl = normalizeHttpUrl(contentItemUrl)
        runCatching {
            onMetaVideoDetected(safeUrl, safeTitle, safeDuration, safePoster, isPlaying, safeMime, safeGroup, safeItemUrl)
        }
    }

    @JavascriptInterface
    fun onMediaResourceFound(url: String?, mimeType: String?, isPlaying: Boolean) {
        val safeUrl = normalizeMediaUrl(url) ?: return
        val safeMime = mimeType?.substringBefore(';')?.trim()?.take(120)?.takeIf { it.isNotBlank() }
        runCatching { onResourceDetected(safeUrl, safeMime, isPlaying) }
    }



    /** A page overlay button only requests a selection sheet; it cannot start a download itself. */
    @JavascriptInterface
    fun onPlatformMediaAction(
        kind: String?,
        url: String?,
        mimeType: String?,
        title: String?,
        durationSeconds: Double,
        width: Double,
        height: Double,
        isVideoPosterTarget: Boolean,
        thumbnailUrl: String?,
        contentItemUrl: String?
    ) {
        val safeKind = kind?.trim()?.lowercase()?.takeIf { it == "image" || it == "video" } ?: return
        val safeUrl = normalizeMediaUrl(url)
        val safeMime = mimeType?.substringBefore(';')?.trim()?.take(120)?.takeIf { it.isNotBlank() }
        val safeTitle = title?.replace(Regex("[\r\n\t]+"), " ")?.trim()?.take(180)?.takeIf { it.isNotBlank() }
        val safeDuration = durationSeconds.takeIf { it.isFinite() && it > 0.0 && it < 86_400.0 } ?: 0.0
        val safeWidth = width.takeIf { it.isFinite() && it in 0.0..20_000.0 }?.toInt() ?: 0
        val safeHeight = height.takeIf { it.isFinite() && it in 0.0..20_000.0 }?.toInt() ?: 0
        val safeThumbnail = normalizeMediaUrl(thumbnailUrl)
        val safeItemUrl = contentItemUrl?.trim()?.take(8_192)?.takeIf {
            it.startsWith("https://", true) || it.startsWith("http://", true)
        }?.substringBefore('#')
        runCatching {
            onPlatformMediaActionDetected(
                safeKind, safeUrl, safeMime, safeTitle, safeDuration, safeWidth, safeHeight,
                isVideoPosterTarget, safeThumbnail, safeItemUrl
            )
        }
    }

    /**
     * Receives an MPD XML string already present in a first-party Meta page response.
     * The native layer validates the platform origin and stores it privately for the download queue.
     * This bridge does not accept DRM manifests or initiate network requests.
     */
    @JavascriptInterface
    fun onInlineDashManifestFound(
        manifestText: String?,
        responseUrl: String?,
        title: String?,
        durationSeconds: Double,
        posterUrl: String?,
        contentItemUrl: String?
    ) {
        val xml = manifestText?.trim()?.takeIf {
            it.isNotEmpty() && it.length <= 1_500_000 && it.contains("<MPD", true) &&
                it.contains("</MPD>", true) &&
                !Regex("(?i)<!DOCTYPE|<!ENTITY|<ContentProtection\\b").containsMatchIn(it)
        } ?: return
        val safeResponseUrl = normalizeHttpUrl(responseUrl) ?: return
        val safeTitle = title?.replace(Regex("[\\r\\n\\t]+"), " ")?.trim()?.take(180)
            ?.takeIf { it.isNotBlank() }
        val safeDuration = durationSeconds.takeIf { it.isFinite() && it > 0.0 && it < 86_400.0 } ?: 0.0
        val safePoster = normalizeHttpUrl(posterUrl)
        val safeItemUrl = normalizeHttpUrl(contentItemUrl)
        runCatching {
            onInlineDashManifestDetected(xml, safeResponseUrl, safeTitle, safeDuration, safePoster, safeItemUrl)
        }
    }

    @JavascriptInterface
    fun onPageMetadata(title: String?, posterUrl: String?, durationSeconds: Double) {
        val safeTitle = title?.replace(Regex("[\\r\\n\\t]+"), " ")
            ?.trim()?.take(300)?.takeIf { it.isNotBlank() }
        val safePoster = normalizeMediaUrl(posterUrl)
        val safeDuration = durationSeconds.takeIf { it.isFinite() && it > 0.0 && it < 86_400.0 }
        runCatching { onPageMetadataDetected(safeTitle, safePoster, safeDuration) }
    }

    @JavascriptInterface
    fun onSnifferScanCompleted(reportedCount: Int) {
        runCatching { onScanFinishedCallback(reportedCount.coerceIn(0, 1000)) }
    }

    /** Called only by the TikTok playback gate after a real video has advanced. */
    @JavascriptInterface
    fun onTikTokPlaybackStarted(pageUrl: String?) {
        val safePageUrl = pageUrl?.trim()?.take(8_192)?.takeIf { TikTokBrowserMode.isTikTokUrl(it) }
            ?: return
        runCatching { onTikTokPlaybackConfirmedCallback(safePageUrl) }
    }

    private fun normalizeHttpUrl(raw: String?): String? {
        val value = raw?.trim()?.takeIf { it.isNotBlank() && it.length <= 8_192 } ?: return null
        return runCatching {
            val uri = java.net.URI(value)
            if ((uri.scheme.equals("https", true) || uri.scheme.equals("http", true)) && !uri.host.isNullOrBlank()) {
                value.substringBefore('#')
            } else null
        }.getOrNull()
    }

    private fun normalizeMediaUrl(raw: String?): String? {
        val value = raw?.trim()?.takeIf { it.isNotBlank() && it.length <= 8_192 } ?: return null
        if (value.startsWith("http://", ignoreCase = true) || value.startsWith("https://", ignoreCase = true)) {
            return value.substringBefore('#')
        }
        return null
    }
}
