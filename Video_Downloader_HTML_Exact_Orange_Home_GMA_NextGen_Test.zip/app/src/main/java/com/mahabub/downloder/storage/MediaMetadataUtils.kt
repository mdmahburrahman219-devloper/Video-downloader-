package com.mahabub.downloder.storage

import android.media.MediaMetadataRetriever
import java.io.File
import java.util.Locale

/** Reads local media metadata. Unknown values stay unknown; the UI must not invent defaults. */
object MediaMetadataUtils {
    fun durationMs(file: File): Long? {
        if (!file.isFile || file.length() <= 0L) return null
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(file.absolutePath)
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull()
                ?.takeIf { it > 0L && it <= 86_400_000L }
        } catch (_: Exception) {
            null
        } finally {
            runCatching { retriever.release() }
        }
    }

    fun formatDuration(durationMs: Long): String {
        val totalSeconds = (durationMs.coerceAtLeast(0L) / 1000L)
        val seconds = totalSeconds % 60L
        val minutes = (totalSeconds / 60L) % 60L
        val hours = totalSeconds / 3600L
        return if (hours > 0L) {
            String.format(Locale.US, "%d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format(Locale.US, "%02d:%02d", totalSeconds / 60L, seconds)
        }
    }

    /** Formats bytes using units that remain readable for tiny transfers and large videos. */
    fun formatFileSize(bytes: Long): String {
        val safeBytes = bytes.coerceAtLeast(0L)
        return when {
            safeBytes < 1024L -> String.format(Locale.US, "%d B", safeBytes)
            safeBytes < 1024L * 1024L -> String.format(Locale.US, "%.1f KB", safeBytes / 1024.0)
            safeBytes < 1024L * 1024L * 1024L -> String.format(Locale.US, "%.2f MB", safeBytes / (1024.0 * 1024.0))
            else -> String.format(Locale.US, "%.2f GB", safeBytes / (1024.0 * 1024.0 * 1024.0))
        }
    }
}
