package com.mahabub.downloder.browser

import android.net.Uri
import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream
import java.util.Locale

/** Conservative network-level ad blocking. Same-site ad paths cannot safely be blocked generically. */
object AdBlocker {
    private val blockedDomains = setOf(
        "doubleclick.net",
        "googleads.g.doubleclick.net",
        "googlesyndication.com",
        "googleadservices.com",
        "adservice.google.com",
        "pagead2.googlesyndication.com",
        "adnxs.com",
        "adroll.com",
        "popads.net",
        "popcash.net",
        "propellerads.com",
        "taboola.com",
        "outbrain.com",
        "criteo.com",
        "rubiconproject.com",
        "admob.com",
        "adsafeprotected.com",
        "amazon-adsystem.com",
        "adsrvr.org",
        "adform.net",
        "advertising.com",
        "bidswitch.net",
        "casalemedia.com",
        "contextweb.com",
        "moatads.com",
        "openx.net",
        "pubmatic.com",
        "serving-sys.com",
        "smartadserver.com",
        "spotxchange.com",
        "undertone.com",
        "yieldmo.com",
        "yieldmanager.com",
        "zedo.com",
        "adsterra.com",
        "trafficjunky.net",
        "exoclick.com",
        "juicyads.com",
        "hilltopads.com",
        "adcash.com",
        "monetag.com",
        "onclkds.com",
        "ad-maven.com",
        "adnium.com",
        "trafficstars.com",
        "ad-delivery.net",
        "ad-score.com",
        "yllix.com",
        "popunder.net",
        "ero-advertising.com",
        "propeller-tracking.com",
        "onclicka.com",
        "onclickalgo.com",
        "megapopads.com",
        "adskeeper.co.uk",
        "dtscout.com",
        "exdynsrv.com",
        "tsyndicate.com"
    )

    fun isAdDomain(uri: Uri?): Boolean {
        val host = uri?.host?.lowercase(Locale.ROOT) ?: return false
        return blockedDomains.any { host == it || host.endsWith(".$it") }
    }

    fun createEmptyResponse(): WebResourceResponse {
        return WebResourceResponse(
            "text/plain",
            "UTF-8",
            ByteArrayInputStream(ByteArray(0))
        )
    }
}
