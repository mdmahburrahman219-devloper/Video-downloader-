package com.mahabub.downloder.browser

import android.os.Message
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebView

class SecureWebChromeClient(
    private val onProgressUpdate: (Int) -> Unit,
    private val onTitleReceived: (String) -> Unit
) : WebChromeClient() {

    override fun onProgressChanged(view: WebView?, newProgress: Int) {
        super.onProgressChanged(view, newProgress)
        onProgressUpdate(newProgress)
    }

    override fun onReceivedTitle(view: WebView?, title: String?) {
        super.onReceivedTitle(view, title)
        if (!title.isNullOrBlank()) {
            onTitleReceived(title)
        }
    }

    override fun onCreateWindow(
        view: WebView?,
        isDialog: Boolean,
        isUserGesture: Boolean,
        resultMsg: Message?
    ): Boolean {
        // Blocks window.open() popup windows for security and spam prevention
        return false
    }
}
