package com.mahabub.downloder.browser

import android.content.Context
import android.net.Uri
import android.webkit.WebSettings
import java.util.Locale

/**
 * TikTok gets a two-phase browser flow: untouched playback first, then page-side media detection
 * only after actual playback. Non-TikTok sites keep the app's existing detection pipeline.
 */
object TikTokBrowserMode {
    fun isTikTokUrl(rawUrl: String?): Boolean {
        if (rawUrl.isNullOrBlank()) return false
        val host = runCatching { Uri.parse(rawUrl).host?.lowercase(Locale.ROOT) }.getOrNull()
            ?: return false
        return host == "tiktok.com" || host.endsWith(".tiktok.com")
    }

    /**
     * Use the installed WebView Chromium version/device token, but omit Android WebView's
     * explicit `wv` and `Version/4.0` markers so the mobile UA follows Chrome's common format.
     * This is a Chrome-style UA, not a claim that WebView is the standalone Chrome app.
     */
    fun mobileBrowserUserAgent(context: Context): String {
        val runtimeUa = WebSettings.getDefaultUserAgent(context)
        return runtimeUa
            .replace(Regex(";\\s*wv(?=\\))", RegexOption.IGNORE_CASE), "")
            .replace(Regex("\\sVersion/4\\.0", RegexOption.IGNORE_CASE), "")
            .trim()
    }
}
