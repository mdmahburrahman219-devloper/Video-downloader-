
package com.mahabub.downloder.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.mahabub.downloder.model.DownloadStatus
import kotlinx.coroutines.flow.Flow

@Dao
interface DownloadDao {

    @Query("SELECT * FROM downloads ORDER BY createdAt DESC")
    fun getAllDownloads(): Flow<List<DownloadEntity>>

    @Query("SELECT * FROM downloads WHERE status IN ('QUEUED', 'DOWNLOADING', 'CONVERTING', 'PAUSED', 'WAITING_FOR_NETWORK') ORDER BY createdAt DESC")
    fun getActiveDownloads(): Flow<List<DownloadEntity>>

    @Query("SELECT * FROM downloads WHERE status = 'COMPLETED' ORDER BY completedAt DESC")
    fun getCompletedDownloads(): Flow<List<DownloadEntity>>

    /** Failed tasks are kept separate from the active queue so their error can be shown and retried. */
    @Query("SELECT * FROM downloads WHERE status = 'FAILED' ORDER BY updatedAt DESC")
    fun getFailedDownloads(): Flow<List<DownloadEntity>>

    @Query("SELECT * FROM downloads WHERE status IN ('DOWNLOADING', 'CONVERTING') ORDER BY createdAt ASC")
    suspend fun getCurrentlyDownloading(): List<DownloadEntity>

    @Query("SELECT COUNT(*) FROM downloads WHERE status IN ('DOWNLOADING', 'CONVERTING')")
    suspend fun getCurrentlyDownloadingCount(): Int

    @Query("SELECT * FROM downloads WHERE status = 'QUEUED' ORDER BY createdAt ASC")
    suspend fun getQueuedDownloads(): List<DownloadEntity>

    @Query("SELECT * FROM downloads WHERE status = 'WAITING_FOR_NETWORK' ORDER BY createdAt ASC")
    suspend fun getWaitingForNetworkDownloads(): List<DownloadEntity>

    @Query("SELECT * FROM downloads WHERE status = 'PAUSED' ORDER BY updatedAt DESC")
    suspend fun getPausedDownloads(): List<DownloadEntity>

    @Query("SELECT * FROM downloads WHERE id = :id")
    suspend fun getDownloadById(id: String): DownloadEntity?

    @Query("SELECT * FROM downloads WHERE id = :id")
    fun observeDownloadById(id: String): Flow<DownloadEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDownload(download: DownloadEntity)

    @Update
    suspend fun updateDownload(download: DownloadEntity)

    @Query("UPDATE downloads SET status = :status, speedBytesPerSec = 0, updatedAt = :timestamp WHERE id = :id")
    suspend fun updateStatus(
        id: String,
        status: DownloadStatus,
        timestamp: Long = System.currentTimeMillis()
    )

    /** Atomically claims a queued task so two queue checks cannot claim it twice. */
    @Query("UPDATE downloads SET status = 'DOWNLOADING', speedBytesPerSec = 0, updatedAt = :timestamp WHERE id = :id AND status = 'QUEUED'")
    suspend fun claimQueuedDownload(
        id: String,
        timestamp: Long = System.currentTimeMillis()
    ): Int

    /** Returns process-interrupted tasks to the queue without deleting resume progress. */
    @Query("UPDATE downloads SET status = 'QUEUED', speedBytesPerSec = 0, updatedAt = :timestamp WHERE status IN ('DOWNLOADING', 'CONVERTING')")
    suspend fun requeueInterruptedDownloads(
        timestamp: Long = System.currentTimeMillis()
    ): Int

    @Query("UPDATE downloads SET downloadedBytes = :downloaded, totalBytes = :total, speedBytesPerSec = :speed, updatedAt = :timestamp WHERE id = :id")
    suspend fun updateProgress(
        id: String,
        downloaded: Long,
        total: Long,
        speed: Long,
        timestamp: Long = System.currentTimeMillis()
    )

    @Query("UPDATE downloads SET completedSegments = :completedSegments, totalSegments = :totalSegments, downloadedBytes = :downloadedBytes, totalBytes = 0, speedBytesPerSec = :speed, updatedAt = :timestamp WHERE id = :id")
    suspend fun updateSegmentProgress(
        id: String,
        completedSegments: Int,
        totalSegments: Int,
        downloadedBytes: Long,
        speed: Long,
        timestamp: Long = System.currentTimeMillis()
    )

    @Query("UPDATE downloads SET status = 'COMPLETED', localUri = :localUri, totalBytes = CASE WHEN :actualFileSizeBytes > 0 THEN :actualFileSizeBytes ELSE totalBytes END, downloadedBytes = CASE WHEN :actualFileSizeBytes > 0 THEN :actualFileSizeBytes ELSE downloadedBytes END, durationMs = :durationMs, completedAt = :timestamp, updatedAt = :timestamp, speedBytesPerSec = 0, errorMessage = NULL WHERE id = :id")
    suspend fun markCompleted(
        id: String,
        localUri: String,
        actualFileSizeBytes: Long = 0L,
        durationMs: Long? = null,
        timestamp: Long = System.currentTimeMillis()
    )

    /** Replaces a stale media URL after a platform-specific resolver refreshes it. */
    @Query("UPDATE downloads SET sourceUrl = :sourceUrl, userAgent = :userAgent, referer = :referer, mimeType = :mimeType, totalBytes = 0, downloadedBytes = 0, speedBytesPerSec = 0, etag = NULL, lastModified = NULL, errorMessage = NULL, updatedAt = :timestamp WHERE id = :id")
    suspend fun updateResolvedMediaSource(
        id: String,
        sourceUrl: String,
        userAgent: String?,
        referer: String?,
        mimeType: String?,
        timestamp: Long = System.currentTimeMillis()
    )

    @Query("UPDATE downloads SET status = 'FAILED', errorMessage = :errorMessage, speedBytesPerSec = 0, updatedAt = :timestamp WHERE id = :id")
    suspend fun markFailed(
        id: String,
        errorMessage: String,
        timestamp: Long = System.currentTimeMillis()
    )

    @Query("UPDATE downloads SET fileName = :fileName, localUri = :localUri, updatedAt = :timestamp WHERE id = :id AND status = 'COMPLETED'")
    suspend fun updateCompletedFileName(
        id: String,
        fileName: String,
        localUri: String,
        timestamp: Long = System.currentTimeMillis()
    ): Int

    @Query("DELETE FROM downloads WHERE id = :id")
    suspend fun deleteDownloadById(id: String)

    /** Removes completed records only; saved media files are deliberately retained. */
    @Query("DELETE FROM downloads WHERE status = 'COMPLETED'")
    suspend fun clearCompleted()

    @Query("UPDATE downloads SET status = 'PAUSED', speedBytesPerSec = 0, updatedAt = :timestamp WHERE status IN ('DOWNLOADING', 'CONVERTING')")
    suspend fun pauseAllDownloading(
        timestamp: Long = System.currentTimeMillis()
    )
}
