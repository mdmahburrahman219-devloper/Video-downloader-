package com.mahabub.downloder.ui.viewmodel

import android.os.Bundle
import android.graphics.Bitmap
import android.webkit.WebView
import android.webkit.CookieManager
import com.mahabub.downloder.browser.TikTokBrowserMode
import com.mahabub.downloder.browser.PlatformMediaOverlayScript
import com.mahabub.downloder.browser.SearchEngineUrlBuilder
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.mahabub.downloder.AppContainer
import com.mahabub.downloder.db.BookmarkEntity
import com.mahabub.downloder.db.BrowserHistoryEntity
import com.mahabub.downloder.extractor.InlineDashManifestStore
import com.mahabub.downloder.extractor.FacebookDashVariantCatalog
import com.mahabub.downloder.model.MediaCandidate
import com.mahabub.downloder.model.MediaCandidateGrouping
import com.mahabub.downloder.model.PlatformSource
import com.mahabub.downloder.model.MediaDetectionSource
import com.mahabub.downloder.model.StreamType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit
import java.util.concurrent.ConcurrentHashMap
import org.json.JSONArray
import org.json.JSONObject

/** Metadata for a browser tab. WebView's navigation stack is saved separately by tab id. */
data class BrowserTab(
    val id: Long,
    val url: String = "",
    val title: String = "New tab",
    val isHomeView: Boolean = true,
    val isDesktopMode: Boolean = false,
    /** App-level private tab: omitted from browser history and bookmarks. WebView cookies are shared. */
    val isPrivate: Boolean = false,
    /** A small in-memory preview captured when the WebView is released for the tab overview. */
    val preview: Bitmap? = null
)

data class BrowserUiState(
    val currentUrl: String = "",
    val pageTitle: String = "New tab",
    val inputUrl: String = "",
    val loadProgress: Int = 0,
    val isLoading: Boolean = false,
    val canGoBack: Boolean = false,
    val canGoForward: Boolean = false,
    val isBookmarked: Boolean = false,
    val selectedCandidate: MediaCandidate? = null,
    val selectedCandidates: List<MediaCandidate> = emptyList(),
    val showMediaSheet: Boolean = false,
    val isResolvingVariants: Boolean = false,
    /** Download FAB reflects automatic/manual media metadata detection. */
    val isMediaDetectionLoading: Boolean = false,
    val mediaDetectionStage: String? = null,
    val isAnalyzingUrl: Boolean = false,
    val userNoticeAccepted: Boolean = false,
    val snackbarMessage: String? = null,
    val tabs: List<BrowserTab> = listOf(BrowserTab(id = 1L)),
    val activeTabId: Long = 1L,
    val isHomeView: Boolean = true,
    val showTabsOverview: Boolean = false,
    val isDesktopMode: Boolean = false,
    /** Incremented only for an explicit address-bar/navigation request. */
    val navigationRequestId: Long = 0L,
    /** TikTok's full media scan is gated until an HTML video has actually started playing. */
    val hasTikTokPlaybackStarted: Boolean = false,
    /** New value asks the browser screen to run the post-playback TikTok scan. */
    val tiktokPlaybackScanRequestId: Long = 0L
)

class BrowserViewModel(private val container: AppContainer) : ViewModel() {

    companion object {
        private const val MAX_TABS = 50
    }

    private val _uiState = MutableStateFlow(BrowserUiState())
    val uiState: StateFlow<BrowserUiState> = _uiState.asStateFlow()

    private val resolvedCandidates = MutableStateFlow<List<MediaCandidate>>(emptyList())
    private val expandedHlsMasterUrls = ConcurrentHashMap.newKeySet<String>()
    private val processedCandidateUrls = ConcurrentHashMap.newKeySet<String>()
    private var mediaDetectionGeneration = 0L
    private var pendingCandidateResolutions = 0
    /** Platform page resolvers run alongside the generic DOM/network sniffer. */
    private var snifferCompletedGeneration = -1L
    /** Set only for an explicitly shared/pasted Meta post link whose primary media should be selected. */
    private var pendingExternalMediaPageHost: String? = null
    private var pendingExternalMediaPageUrl: String? = null
    private var externalLinkSelectionGeneration = 0L
    private val candidateResolveSemaphore = Semaphore(4)
    /** Inline DASH manifests are indexed by their exact Reel/Story permalink, never by feed order. */
    private val metaVideoCandidatesByPage = ConcurrentHashMap<String, List<MediaCandidate>>()
    /** Fallback association for signed-in feed GraphQL nodes that expose a unique poster but no permalink. */
    private val metaVideoCandidatesByPoster = ConcurrentHashMap<String, List<MediaCandidate>>()
    private val ambiguousMetaPosterKeys = ConcurrentHashMap.newKeySet<String>()

    /** Raw browser detections plus enriched metadata/HLS variants, deduplicated by media URL. */
    val detectedMediaList: StateFlow<List<MediaCandidate>> = combine(
        container.mediaDetector.detectedMedia,
        resolvedCandidates
    ) { raw, resolved ->
        val expandedParents = raw.filter { expandedHlsMasterUrls.contains(canonicalMediaUrl(it.url)) }
        val visibleRaw = raw.filterNot { expandedHlsMasterUrls.contains(canonicalMediaUrl(it.url)) }
        // The source page can reveal its thumbnail/title/duration after the HLS variants have
        // already been expanded. Keep enriching those child options from their exact master URL
        // instead of leaving the bottom sheet stuck with a technical playlist filename.
        val enrichedResolved = resolved.map { child ->
            val parent = expandedParents.firstOrNull { master ->
                val childGroup = child.videoGroupId
                val masterGroup = master.videoGroupId
                if (!masterGroup.isNullOrBlank()) {
                    childGroup == masterGroup
                } else {
                    childGroup == "hls-master:${master.url.hashCode()}"
                }
            }
            if (parent == null) child else {
                val usefulParentTitle = parent.title?.takeIf {
                    it.isNotBlank() && !isFallbackCandidateTitle(it, parent.url)
                }
                child.copy(
                    title = if (child.title.isNullOrBlank() || isFallbackCandidateTitle(child.title, child.url)) {
                        usefulParentTitle ?: child.title
                    } else child.title,
                    thumbnailUrl = child.thumbnailUrl ?: parent.thumbnailUrl,
                    durationSeconds = child.durationSeconds ?: parent.durationSeconds,
                    sourcePageUrl = child.sourcePageUrl ?: parent.sourcePageUrl,
                    referer = child.referer ?: parent.referer,
                    userAgent = child.userAgent ?: parent.userAgent
                )
            }
        }
        val byUrl = LinkedHashMap<String, MediaCandidate>()
        (visibleRaw + enrichedResolved).forEach { candidate ->
            val key = canonicalMediaUrl(candidate.url)
            val old = byUrl[key]
            byUrl[key] = if (old == null) candidate else mergeCandidateMetadata(old, candidate)
        }
        byUrl.values.sortedWith(
            compareByDescending<MediaCandidate> { it.isPlaying }
                .thenByDescending { it.detectionConfidence }
                .thenByDescending { MediaCandidateGrouping.qualityRank(it) }
        )
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val recentHistory = container.database.browserHistoryDao().getAllHistory()

    // A Bundle retains the WebView back/forward list, form data and other restorable page state.
    // It is held by the ViewModel so changing the bottom navigation does not reset the browser.
    private val savedWebViewStates = mutableMapOf<Long, Bundle>()
    private val browserSessionWriteMutex = Mutex()
    private var mediaSelectionGeneration = 0L

    init {
        checkNoticeAccepted()
        observeDetectedCandidates()
        restorePersistedBrowserSession()
    }

    private fun checkNoticeAccepted() {
        viewModelScope.launch {
            val permanent = container.preferenceManager.isNoticeAcceptedPermanently.first()
            val session = container.preferenceManager.sessionNoticeAccepted
            _uiState.value = _uiState.value.copy(userNoticeAccepted = permanent || session)
        }
    }

    fun onInputUrlChanged(input: String) {
        _uiState.value = _uiState.value.copy(inputUrl = input)
    }

    fun loadUrl(rawInput: String) {
        val input = rawInput.trim()
        if (input.isEmpty()) return
        viewModelScope.launch {
            val engine = container.preferenceManager.searchEngine.first()
            val customTemplate = container.preferenceManager.customSearchUrl.first()
            val urlToLoad = normalizeUrl(input, engine, customTemplate) ?: return@launch
            navigateToUrl(urlToLoad)
        }
    }

    private fun navigateToUrl(urlToLoad: String) {
        val current = _uiState.value
        val activeId = current.activeTabId
        // An explicit navigation from Home starts a fresh navigation stack for this tab.
        savedWebViewStates.remove(activeId)
        val tabs = current.tabs.map { tab ->
            if (tab.id == activeId) tab.copy(url = urlToLoad, title = urlToLoad, isHomeView = false) else tab
        }
        _uiState.value = current.copy(
            currentUrl = urlToLoad,
            pageTitle = urlToLoad,
            inputUrl = urlToLoad,
            isLoading = true,
            loadProgress = 0,
            isMediaDetectionLoading = false,
            mediaDetectionStage = null,
            canGoBack = false,
            canGoForward = false,
            isBookmarked = false,
            isHomeView = false,
            showTabsOverview = false,
            tabs = tabs,
            navigationRequestId = current.navigationRequestId + 1L
        )
        persistBrowserSession()
    }

    private fun normalizeUrl(rawInput: String, searchEngine: String, customTemplate: String): String? {
        val trimmed = rawInput.trim()
        if (trimmed.isEmpty()) return null
        if (trimmed.startsWith("https://", ignoreCase = true) ||
            trimmed.startsWith("http://", ignoreCase = true)) return trimmed

        val looksLikeHost = trimmed.contains('.') && !trimmed.contains(' ') &&
            !trimmed.startsWith("about:", ignoreCase = true) &&
            !trimmed.startsWith("javascript:", ignoreCase = true)
        return if (looksLikeHost) {
            "https://$trimmed"
        } else {
            SearchEngineUrlBuilder.build(trimmed, searchEngine, customTemplate)
        }
    }

    private fun restorePersistedBrowserSession() {
        viewModelScope.launch {
            val raw = runCatching { container.preferenceManager.browserTabsSnapshot.first() }.getOrDefault("")
            if (raw.isBlank()) return@launch
            val restoredTabs = decodeBrowserTabs(raw).takeLast(MAX_TABS)
            if (restoredTabs.isEmpty()) return@launch
            val storedActiveId = runCatching { container.preferenceManager.activeBrowserTabId.first() }.getOrDefault(1L)
            val active = restoredTabs.firstOrNull { it.id == storedActiveId } ?: restoredTabs.last()
            val current = _uiState.value
            // Do not overwrite a session if the user already navigated while DataStore was loading.
            if (current.tabs.size != 1 || current.currentUrl.isNotBlank() || current.tabs.firstOrNull()?.id != 1L) return@launch
            _uiState.value = current.copy(
                tabs = restoredTabs,
                activeTabId = active.id,
                currentUrl = active.url,
                pageTitle = active.title,
                inputUrl = active.url,
                isHomeView = active.isHomeView,
                isDesktopMode = active.isDesktopMode,
                isLoading = !active.isHomeView,
                loadProgress = if (active.isHomeView) 0 else 0,
                canGoBack = false,
                canGoForward = false,
                showTabsOverview = false,
                navigationRequestId = current.navigationRequestId + if (active.isHomeView) 0L else 1L
            )
        }
    }

    private fun decodeBrowserTabs(raw: String): List<BrowserTab> = runCatching {
        val array = JSONArray(raw)
        buildList {
            for (index in 0 until array.length()) {
                val item = array.optJSONObject(index) ?: continue
                val id = item.optLong("id", -1L)
                if (id <= 0L) continue
                val url = item.optString("url", "").take(4096)
                val home = item.optBoolean("home", url.isBlank())
                if (!home && !(url.startsWith("https://", true) || url.startsWith("http://", true))) continue
                add(
                    BrowserTab(
                        id = id,
                        url = url,
                        title = item.optString("title", url.ifBlank { "New tab" }).take(300),
                        isHomeView = home,
                        isDesktopMode = item.optBoolean("desktop", false),
                        isPrivate = false
                    )
                )
            }
        }.distinctBy { it.id }
    }.getOrDefault(emptyList())

    /** Called when the browser screen is backgrounded so the latest URL/tab set is committed. */
    fun persistCurrentBrowserSession(activeWebView: WebView? = null) {
        val activeId = _uiState.value.activeTabId
        if (activeWebView != null) {
            saveWebViewState(activeId, activeWebView)
        }
        persistBrowserSession()
    }

    /** Debounced-by-lock persistent tab metadata. WebView instances themselves are never serialized. */
    private fun persistBrowserSession() {
        viewModelScope.launch {
            browserSessionWriteMutex.withLock {
                val snapshot = _uiState.value
                val normalTabs = snapshot.tabs.filterNot { it.isPrivate }.takeLast(MAX_TABS).ifEmpty {
                    listOf(BrowserTab(id = (snapshot.tabs.maxOfOrNull { it.id } ?: 0L) + 1L))
                }
                val active = normalTabs.firstOrNull { it.id == snapshot.activeTabId } ?: normalTabs.last()
                val json = JSONArray()
                normalTabs.forEach { tab ->
                    json.put(
                        JSONObject()
                            .put("id", tab.id)
                            .put("url", tab.url.take(4096))
                            .put("title", tab.title.take(300))
                            .put("home", tab.isHomeView)
                            .put("desktop", tab.isDesktopMode)
                    )
                }
                runCatching {
                    container.preferenceManager.setBrowserSession(json.toString(), active.id)
                }
            }
        }
    }

    private fun normalizedMetaHost(rawUrl: String?): String? {
        val value = rawUrl?.trim()?.takeIf { it.isNotBlank() } ?: return null
        val host = runCatching { java.net.URI(value).host?.lowercase() }.getOrNull() ?: return null
        return when (PlatformMediaOverlayScript.platformForUrl(value)) {
            PlatformSource.FACEBOOK -> "facebook.com"
            PlatformSource.INSTAGRAM -> "instagram.com"
            PlatformSource.THREADS -> "threads.com"
            else -> host
        }
    }

    fun onPageStarted(tabId: Long, url: String) {
        val before = _uiState.value
        if (before.tabs.none { it.id == tabId }) return
        if (tabId == before.activeTabId && before.isHomeView) return
        updateTab(tabId) { it.copy(url = url, isHomeView = false) }
        if (tabId != _uiState.value.activeTabId) return

        val requestedExternalHost = pendingExternalMediaPageHost
        val arrivedHost = normalizedMetaHost(url)
        if (requestedExternalHost != null && requestedExternalHost != arrivedHost) {
            pendingExternalMediaPageHost = null
            pendingExternalMediaPageUrl = null
            externalLinkSelectionGeneration += 1L
        }
        mediaDetectionGeneration += 1L
        pendingCandidateResolutions = 0
        snifferCompletedGeneration = -1L
        processedCandidateUrls.clear()
        expandedHlsMasterUrls.clear()
        resolvedCandidates.value = emptyList()
        metaVideoCandidatesByPage.clear()
        metaVideoCandidatesByPoster.clear()
        ambiguousMetaPosterKeys.clear()
        _uiState.value = _uiState.value.copy(
            currentUrl = url,
            inputUrl = url,
            isHomeView = false,
            isLoading = true,
            loadProgress = 10,
            isMediaDetectionLoading = false,
            mediaDetectionStage = null,
            hasTikTokPlaybackStarted = false
        )
        if (before.tabs.firstOrNull { it.id == tabId }?.isPrivate != true) checkIsBookmarked(url)
    }

    fun onPageFinished(tabId: Long, url: String, title: String?) {
        val before = _uiState.value
        if (before.tabs.none { it.id == tabId }) return
        if (tabId == before.activeTabId && before.isHomeView) return
        val displayTitle = title?.takeIf { it.isNotBlank() } ?: url
        updateTab(tabId) { it.copy(url = url, title = displayTitle, isHomeView = false) }
        val isPrivateTab = before.tabs.firstOrNull { it.id == tabId }?.isPrivate == true
        if (!isPrivateTab) {
            viewModelScope.launch {
                container.database.browserHistoryDao().insertHistory(
                    BrowserHistoryEntity(url = url, title = displayTitle)
                )
            }
        }
        if (tabId != _uiState.value.activeTabId) return
        // Non-TikTok pages keep the existing post-load discovery flow. TikTok stays idle here
        // until the playback observer confirms that a video has actually advanced.
        _uiState.value = _uiState.value.copy(
            currentUrl = url,
            pageTitle = displayTitle,
            inputUrl = url,
            isHomeView = false,
            isLoading = false,
            loadProgress = 100,
            isMediaDetectionLoading = !TikTokBrowserMode.isTikTokUrl(url),
            mediaDetectionStage = when {
                TikTokBrowserMode.isTikTokUrl(url) -> null
                pendingCandidateResolutions > 0 -> "Resolving video details…"
                else -> "Scanning page for video…"
            }
        )
        if (!isPrivateTab) checkIsBookmarked(url)
    }

    /**
     * TikTok-only second phase: called after an HTML video is demonstrably playing.
     * It starts detection only; it never starts a download.
     */
    fun onTikTokPlaybackConfirmed(tabId: Long, pageUrl: String) {
        val state = _uiState.value
        if (tabId != state.activeTabId ||
            !TikTokBrowserMode.isTikTokUrl(pageUrl) ||
            !TikTokBrowserMode.isTikTokUrl(state.currentUrl)
        ) return
        if (state.hasTikTokPlaybackStarted) return
        _uiState.value = state.copy(
            hasTikTokPlaybackStarted = true,
            isMediaDetectionLoading = true,
            mediaDetectionStage = "Video is playing • detecting download options…",
            snackbarMessage = null,
            tiktokPlaybackScanRequestId = state.tiktokPlaybackScanRequestId + 1L
        )
    }

    /** WebChromeClient can report a title more than once; do not restart media detection for it. */
    fun onPageTitleChanged(tabId: Long, url: String, title: String?) {
        val before = _uiState.value
        if (before.tabs.none { it.id == tabId }) return
        val displayTitle = title?.takeIf { it.isNotBlank() } ?: url
        updateTab(tabId) { it.copy(url = url, title = displayTitle, isHomeView = false) }
        if (tabId == _uiState.value.activeTabId) {
            _uiState.value = _uiState.value.copy(currentUrl = url, pageTitle = displayTitle)
        }
    }

    fun onPageMetadata(tabId: Long, title: String?, posterUrl: String?, durationSeconds: Double?, pageUrl: String?) {
        if (tabId != _uiState.value.activeTabId) return
        container.mediaDetector.onPageMetadata(title, posterUrl, durationSeconds, pageUrl)
        if (!title.isNullOrBlank() && title.length <= 300) {
            updateTab(tabId) { tab ->
                val useful = title.trim().takeIf { it.isNotBlank() }
                if (useful != null && (tab.title.isBlank() || tab.title == tab.url || tab.title == "New tab")) {
                    tab.copy(title = useful)
                } else tab
            }
        }
    }

    /** Invoked after an explicit DOM/resource scan has run inside the current document. */
    fun onSnifferScanCompleted(tabId: Long, reportedCount: Int) {
        if (tabId != _uiState.value.activeTabId || !_uiState.value.isMediaDetectionLoading) return
        snifferCompletedGeneration = mediaDetectionGeneration
        // Normal Meta browsing uses only per-item overlays. Do not leave the old page-level
        // detection spinner running while candidates remain intentionally unprobed in the feed.
        if (PlatformMediaOverlayScript.supportsUrl(_uiState.value.currentUrl) && pendingExternalMediaPageHost == null) {
            _uiState.value = _uiState.value.copy(isMediaDetectionLoading = false, mediaDetectionStage = null)
            return
        }
        // JavaScript bridge events are posted to the main handler in call order. No fixed
        // sleep/window is used: metadata resolution tasks determine when the FAB becomes ready.
        processDetectedCandidates(container.mediaDetector.detectedMedia.value)
        if (pendingCandidateResolutions == 0) {
            if (container.mediaDetector.detectedMedia.value.isEmpty() && resolvedCandidates.value.isEmpty()) {
                _uiState.value = _uiState.value.copy(
                    isMediaDetectionLoading = false,
                    mediaDetectionStage = null,
                    snackbarMessage = when {
                        TikTokBrowserMode.isTikTokUrl(_uiState.value.currentUrl) ->
                            "TikTok playback was detected, but no downloadable stream was exposed by the page."
                        reportedCount > 0 ->
                            "Media requests were observed, but no downloadable stream was resolved. Try playing the video and scan again."
                        else -> null
                    }
                )
                // For a pasted Meta post URL, resolve the one requested item or end cleanly;
                // never fall back to showing a page-wide list of unrelated feed media.
                tryCompleteExternalLinkSelection()
            } else {
                finishMediaDetectionIfReady()
            }
        }
    }

    /** Stops an unavailable manual scan instead of leaving the Download FAB spinning forever. */
    fun onSnifferScanUnavailable(tabId: Long) {
        if (tabId != _uiState.value.activeTabId) return
        if (pendingCandidateResolutions == 0 && container.mediaDetector.detectedMedia.value.isEmpty() && resolvedCandidates.value.isEmpty()) {
            _uiState.value = _uiState.value.copy(
                isMediaDetectionLoading = false,
                mediaDetectionStage = null,
                snackbarMessage = "This page did not expose a downloadable stream. Try playing the video and scan again."
            )
            pendingExternalMediaPageHost = null
            pendingExternalMediaPageUrl = null
            externalLinkSelectionGeneration += 1L
        }
    }

    fun startManualMediaScan() {
        val state = _uiState.value
        if (state.isHomeView) return
        if (TikTokBrowserMode.isTikTokUrl(state.currentUrl) && !state.hasTikTokPlaybackStarted) {
            _uiState.value = state.copy(
                isMediaDetectionLoading = false,
                mediaDetectionStage = null,
                snackbarMessage = "Play the TikTok video first. Download detection starts after playback."
            )
            return
        }
        _uiState.value = state.copy(
            isMediaDetectionLoading = true,
            mediaDetectionStage = if (TikTokBrowserMode.isTikTokUrl(state.currentUrl)) {
                "Scanning TikTok playback streams…"
            } else "Scanning this page for video…",
            snackbarMessage = null
        )

        // No TikTok extractor/resolver is started here. The post-playback scan uses page-visible
        // DOM, hydration data and browser resource timing only.
    }

    private fun observeDetectedCandidates() {
        viewModelScope.launch {
            container.mediaDetector.detectedMedia.collect { candidates ->
                processDetectedCandidates(candidates)
            }
        }
    }

    private fun processDetectedCandidates(candidates: List<MediaCandidate>) {
        if (candidates.isEmpty()) return
        // Meta feed pages can contain dozens of autoplay previews and image/video requests. Their
        // per-item overlay resolves only the media the user taps; avoid probing every feed item in
        // the background. A pasted single-post URL is the one exception: it keeps a pending target
        // and must resolve candidates once to select that specific post's video automatically.
        if (PlatformMediaOverlayScript.supportsUrl(_uiState.value.currentUrl) && pendingExternalMediaPageHost == null) {
            return
        }
        val newCandidates = candidates.filter { processedCandidateUrls.add(canonicalMediaUrl(it.url)) }
        if (newCandidates.isEmpty()) return
        _uiState.value = _uiState.value.copy(
            isMediaDetectionLoading = true,
            mediaDetectionStage = "Resolving video details…"
        )
        val generation = mediaDetectionGeneration
        pendingCandidateResolutions += newCandidates.size
        newCandidates.forEach { candidate ->
            viewModelScope.launch {
                val results = candidateResolveSemaphore.withPermit {
                    try {
                        val cookieHeader = webViewCookiesFor(candidate.url)
                        container.mediaExtractionRepository.resolveCandidateForDetection(candidate, cookieHeader)
                            .ifEmpty { listOf(candidate) }
                    } catch (_: Exception) {
                        listOf(candidate)
                    }
                }
                if (generation != mediaDetectionGeneration) return@launch
                val masterKey = canonicalMediaUrl(candidate.url)
                if (results.any { it.streamType == StreamType.HLS && canonicalMediaUrl(it.url) != masterKey }) {
                    expandedHlsMasterUrls.add(masterKey)
                }
                val merged = LinkedHashMap<String, MediaCandidate>()
                resolvedCandidates.value.forEach { merged[canonicalMediaUrl(it.url)] = it }
                results.forEach { item ->
                    val key = canonicalMediaUrl(item.url)
                    merged[key] = merged[key]?.let { old -> mergeCandidateMetadata(old, item) } ?: item
                }
                resolvedCandidates.value = merged.values.toList()
                pendingCandidateResolutions = (pendingCandidateResolutions - 1).coerceAtLeast(0)
                finishMediaDetectionIfReady()
            }
        }
    }

    private fun finishMediaDetectionIfReady() {
        if (pendingCandidateResolutions > 0) {
            _uiState.value = _uiState.value.copy(
                isMediaDetectionLoading = true,
                mediaDetectionStage = "Resolving video details…"
            )
            return
        }
        val raw = container.mediaDetector.detectedMedia.value
        val allRawProcessed = raw.all { processedCandidateUrls.contains(canonicalMediaUrl(it.url)) }
        if ((raw.isNotEmpty() && allRawProcessed) ||
            (raw.isEmpty() && resolvedCandidates.value.isEmpty() && snifferCompletedGeneration == mediaDetectionGeneration)) {
            _uiState.value = _uiState.value.copy(
                isMediaDetectionLoading = false,
                mediaDetectionStage = null
            )
            tryCompleteExternalLinkSelection()
        }
    }

    /**
     * For a specifically pasted/shared Meta post URL, select only its strongest page-visible
     * candidate after the first scan; never open the page-wide detected-media list.
     */
    private fun tryCompleteExternalLinkSelection() {
        val expectedHost = pendingExternalMediaPageHost ?: return
        val currentUrl = _uiState.value.currentUrl
        val currentHost = normalizedMetaHost(currentUrl)
        if (currentHost != expectedHost) return
        val requestedPlatform = PlatformMediaOverlayScript.platformForUrl(currentUrl) ?: return
        val requestedKeys = buildSet {
            pendingExternalMediaPageUrl?.let { add(metaItemPageKey(it)) }
            add(metaItemPageKey(currentUrl))
        }
        val candidates = (detectedMediaList.value + metaVideoCandidatesByPage.values.flatten())
            .distinctBy { it.url }
            .filter { candidate ->
                val sourceUrl = candidate.sourcePageUrl ?: candidate.referer
                val sourceHost = normalizedMetaHost(sourceUrl)
                val sameItem = sourceUrl != null && metaItemPageKey(sourceUrl) in requestedKeys
                sourceHost == expectedHost && sameItem && !candidate.isLikelyAd &&
                    (PlatformMediaOverlayScript.isAllowedMediaUrl(requestedPlatform, candidate.url) ||
                        InlineDashManifestStore.isInlineDashUrl(candidate.url)) &&
                    (candidate.mimeType.orEmpty().startsWith("video/") ||
                        candidate.streamType == StreamType.HLS || candidate.streamType == StreamType.DASH)
            }
        val selected = candidates.sortedWith(
            compareByDescending<MediaCandidate> { it.detectionConfidence }
                .thenByDescending { it.resolution?.substringAfter('x')?.toIntOrNull() ?: 0 }
                .thenByDescending { it.contentLength ?: 0L }
        ).take(12)
        if (selected.isNotEmpty()) {
            pendingExternalMediaPageHost = null
            pendingExternalMediaPageUrl = null
            externalLinkSelectionGeneration += 1L
            // Keep alternative qualities from this one post together; no page-wide candidates.
            selectCandidateGroupForDownload(selected)
        } else {
            // Keep this exact-link request pending briefly. A GraphQL/Story response can arrive
            // after the initial DOM scan completes; onMetaInlineDashManifest() retries selection.
            _uiState.value = _uiState.value.copy(
                snackbarMessage = "Still checking this post's own media resources…"
            )
        }
    }

    /** Read fresh WebView cookies for this exact URL without forwarding them to other hosts. */
    private fun webViewCookiesFor(url: String): String? {
        val manager = CookieManager.getInstance()
        runCatching { manager.flush() }
        return runCatching { manager.getCookie(url) }.getOrNull()
    }

    private fun canonicalMediaUrl(url: String): String = url.trim().substringBefore('#')

    private fun mergeCandidateMetadata(old: MediaCandidate, incoming: MediaCandidate): MediaCandidate = incoming.copy(
        title = when {
            incoming.title.isNullOrBlank() || isFallbackCandidateTitle(incoming.title, incoming.url) -> old.title
            old.title.isNullOrBlank() || isFallbackCandidateTitle(old.title, old.url) -> incoming.title
            else -> old.title
        },
        mimeType = incoming.mimeType ?: old.mimeType,
        contentLength = incoming.contentLength ?: old.contentLength,
        thumbnailUrl = incoming.thumbnailUrl ?: old.thumbnailUrl,
        durationSeconds = incoming.durationSeconds ?: old.durationSeconds,
        resolution = incoming.resolution ?: old.resolution,
        sourcePageUrl = incoming.sourcePageUrl ?: old.sourcePageUrl,
        referer = incoming.referer ?: old.referer,
        userAgent = incoming.userAgent ?: old.userAgent,
        videoGroupId = incoming.videoGroupId ?: old.videoGroupId,
        bitrate = incoming.bitrate ?: old.bitrate,
        estimatedSizeBytes = incoming.estimatedSizeBytes ?: old.estimatedSizeBytes,
        sizeIsEstimated = incoming.sizeIsEstimated || old.sizeIsEstimated
    )

    private fun isGenericCandidateTitle(value: String): Boolean {
        val trimmed = value.trim()
        val looksLikeMediaFile = Regex("(?i)\\.(?:m3u8|mpd|mp4|m4v|webm|mov|mkv|avi|mp3|m4a|aac|ogg|wav|flac)$")
            .containsMatchIn(trimmed) && trimmed.none { it.isWhitespace() }
        val normalized = trimmed.substringBeforeLast('.').lowercase()
        return looksLikeMediaFile || normalized in setOf(
            "video", "detected video", "detected media stream", "media", "stream", "master", "playlist", "index", "original"
        ) || normalized.matches(Regex("(?:hls|stream|index|video|playlist|master)(?:[-_.][a-z0-9]+)*"))
    }

    private fun stripMediaSuffixes(value: String): String = value.trim().replace(
        Regex("(?i)(?:\\.(?:m3u8|mpd|mp4|m4v|webm|mov|mkv|avi|mp3|m4a|aac|ogg|wav|flac))+$"),
        ""
    ).trim()

    private fun isFallbackCandidateTitle(value: String, url: String): Boolean {
        if (isGenericCandidateTitle(value)) return true
        val base = runCatching { java.net.URI(url).path.orEmpty().substringAfterLast('/') }.getOrDefault("")
        val normalizedBase = stripMediaSuffixes(base)
        val normalizedTitle = stripMediaSuffixes(value)
        if (normalizedBase.isNotBlank() && normalizedTitle.isNotBlank() &&
            normalizedTitle.equals(normalizedBase, ignoreCase = true)) return true
        val normalized = normalizedTitle.substringBeforeLast('.').trim()
        return normalized.matches(Regex("(?i)(?:[a-f0-9]{16,}|[a-f0-9]{8}-[a-f0-9-]{20,}|[a-z0-9_-]{32,})"))
    }

    fun onProgressChanged(tabId: Long, progress: Int) {
        if (tabId != _uiState.value.activeTabId) return
        _uiState.value = _uiState.value.copy(
            loadProgress = progress.coerceIn(0, 100),
            isLoading = progress < 100
        )
    }

    fun updateNavigationState(tabId: Long, canBack: Boolean, canForward: Boolean) {
        if (tabId != _uiState.value.activeTabId) return
        _uiState.value = _uiState.value.copy(canGoBack = canBack, canGoForward = canForward)
    }

    fun saveWebViewState(tabId: Long, webView: WebView) {
        // When Home was explicitly opened, do not let the outgoing WebView overwrite it.
        val trackedTab = _uiState.value.tabs.firstOrNull { it.id == tabId } ?: return
        if (trackedTab.isHomeView) {
            savedWebViewStates.remove(tabId)
            return
        }
        try {
            val bundle = Bundle()
            webView.saveState(bundle)
            if (!bundle.isEmpty) savedWebViewStates[tabId] = Bundle(bundle)
            val url = webView.url.orEmpty()
            val title = webView.title?.takeIf { it.isNotBlank() } ?: url
            if (url.isNotBlank()) {
                updateTab(tabId) { it.copy(url = url, title = title, isHomeView = false) }
            }
        } catch (_: Exception) {
            // A failed snapshot should never stop navigation or app closing.
        }
    }

    fun restoreWebViewState(tabId: Long, webView: WebView): Boolean {
        val saved = savedWebViewStates[tabId] ?: return false
        return try {
            val restored = webView.restoreState(Bundle(saved))
            if (restored != null) {
                webView.post {
                    updateNavigationState(tabId, webView.canGoBack(), webView.canGoForward())
                }
                true
            } else {
                savedWebViewStates.remove(tabId)
                false
            }
        } catch (_: Exception) {
            savedWebViewStates.remove(tabId)
            false
        }
    }

    fun openTabsOverview() {
        _uiState.value = _uiState.value.copy(showTabsOverview = true)
    }

    fun closeTabsOverview() {
        _uiState.value = _uiState.value.copy(showTabsOverview = false)
    }

    fun createNewTab(isPrivate: Boolean = false) {
        val current = _uiState.value
        if (current.tabs.size >= MAX_TABS) {
            _uiState.value = current.copy(snackbarMessage = "You can open up to $MAX_TABS tabs")
            return
        }
        val id = (current.tabs.maxOfOrNull { it.id } ?: 0L) + 1L
        val tab = BrowserTab(id = id, isDesktopMode = current.isDesktopMode, isPrivate = isPrivate)
        _uiState.value = current.copy(
            tabs = current.tabs + tab,
            activeTabId = id,
            currentUrl = "",
            pageTitle = if (isPrivate) "New private tab" else "New tab",
            inputUrl = "",
            isLoading = false,
            loadProgress = 0,
            canGoBack = false,
            canGoForward = false,
            isBookmarked = false,
            isHomeView = true,
            showTabsOverview = false,
            isDesktopMode = tab.isDesktopMode,
            navigationRequestId = current.navigationRequestId + 1L
        )
        persistBrowserSession()
    }

    /** Opens a URL in a new tab. Background tabs do not disturb the active WebView/navigation state. */
    fun openUrlInNewTab(rawUrl: String, activate: Boolean, isPrivate: Boolean? = null) {
        val input = rawUrl.trim()
        if (input.isEmpty()) return
        viewModelScope.launch {
            val engine = container.preferenceManager.searchEngine.first()
            val customTemplate = container.preferenceManager.customSearchUrl.first()
            val url = normalizeUrl(input, engine, customTemplate) ?: return@launch
            val current = _uiState.value
            if (current.tabs.size >= MAX_TABS) {
                _uiState.value = current.copy(snackbarMessage = "You can open up to $MAX_TABS tabs")
                return@launch
            }
            val privacy = isPrivate ?: current.tabs.firstOrNull { it.id == current.activeTabId }?.isPrivate ?: false
            val id = (current.tabs.maxOfOrNull { it.id } ?: 0L) + 1L
            val tab = BrowserTab(
                id = id,
                url = url,
                title = url,
                isHomeView = false,
                isDesktopMode = current.isDesktopMode,
                isPrivate = privacy
            )
            if (!activate) {
                _uiState.value = current.copy(tabs = current.tabs + tab, snackbarMessage = "Opened in background tab")
                persistBrowserSession()
                return@launch
            }
            savedWebViewStates.remove(current.activeTabId)
            _uiState.value = current.copy(
                tabs = current.tabs + tab,
                activeTabId = id,
                currentUrl = url,
                pageTitle = url,
                inputUrl = url,
                isLoading = true,
                loadProgress = 0,
                canGoBack = false,
                canGoForward = false,
                isBookmarked = false,
                isHomeView = false,
                showTabsOverview = false,
                isDesktopMode = tab.isDesktopMode,
                navigationRequestId = current.navigationRequestId + 1L
            )
            persistBrowserSession()
        }
    }

    /** Removes all tabs in the selected group while retaining another tab to keep the browser usable. */
    fun clearAllTabs(privateOnly: Boolean) {
        val current = _uiState.value
        val removing = current.tabs.filter { it.isPrivate == privateOnly }
        if (removing.isEmpty()) {
            _uiState.value = current.copy(snackbarMessage = if (privateOnly) "No private tabs to clear" else "No tabs to clear")
            return
        }
        removing.forEach { savedWebViewStates.remove(it.id) }
        var remaining = current.tabs.filterNot { it.isPrivate == privateOnly }
        if (remaining.isEmpty()) {
            val nextId = (current.tabs.maxOfOrNull { it.id } ?: 0L) + 1L
            remaining = listOf(BrowserTab(id = nextId, isPrivate = false, isDesktopMode = current.isDesktopMode))
        }
        val replacement = remaining.firstOrNull { it.id == current.activeTabId }
            ?: remaining.firstOrNull { !it.isPrivate }
            ?: remaining.first()
        val activeWasRemoved = current.tabs.any { it.id == current.activeTabId && it.isPrivate == privateOnly }
        _uiState.value = if (!activeWasRemoved) {
            current.copy(tabs = remaining, snackbarMessage = "Tabs cleared")
        } else {
            current.copy(
                tabs = remaining,
                activeTabId = replacement.id,
                currentUrl = replacement.url,
                pageTitle = replacement.title,
                inputUrl = replacement.url,
                isLoading = false,
                loadProgress = if (replacement.isHomeView) 0 else 100,
                canGoBack = false,
                canGoForward = false,
                isBookmarked = false,
                isHomeView = replacement.isHomeView,
                isDesktopMode = replacement.isDesktopMode,
                navigationRequestId = current.navigationRequestId + 1L,
                snackbarMessage = "Tabs cleared"
            )
        }
        persistBrowserSession()
    }

    fun updateTabPreview(tabId: Long, preview: Bitmap) {
        updateTab(tabId) { tab -> tab.copy(preview = preview) }
    }

    fun selectTab(tabId: Long) {
        val current = _uiState.value
        val tab = current.tabs.firstOrNull { it.id == tabId } ?: return
        _uiState.value = current.copy(
            activeTabId = tab.id,
            currentUrl = tab.url,
            pageTitle = tab.title,
            inputUrl = tab.url,
            isLoading = false,
            loadProgress = if (tab.isHomeView) 0 else 100,
            canGoBack = false,
            canGoForward = false,
            isBookmarked = false,
            isHomeView = tab.isHomeView,
            showTabsOverview = false,
            isDesktopMode = tab.isDesktopMode,
            navigationRequestId = current.navigationRequestId + 1L
        )
        if (!tab.isPrivate && !tab.isHomeView && tab.url.isNotBlank()) checkIsBookmarked(tab.url)
        persistBrowserSession()
    }

    fun closeTab(tabId: Long) {
        savedWebViewStates.remove(tabId)
        val current = _uiState.value
        val index = current.tabs.indexOfFirst { it.id == tabId }
        if (index < 0) return
        val remaining = current.tabs.filterNot { it.id == tabId }
        if (remaining.isEmpty()) {
            val nextId = (current.tabs.maxOfOrNull { it.id } ?: 0L) + 1L
            val fresh = BrowserTab(id = nextId, isDesktopMode = current.isDesktopMode)
            _uiState.value = current.copy(
                tabs = listOf(fresh), activeTabId = fresh.id,
                currentUrl = "", pageTitle = "New tab", inputUrl = "",
                isLoading = false, loadProgress = 0, canGoBack = false, canGoForward = false,
                isBookmarked = false, isHomeView = true,
                // Keep the Opera-style overview open when its final card is closed.
                showTabsOverview = current.showTabsOverview,
                isDesktopMode = fresh.isDesktopMode
            )
            persistBrowserSession()
            return
        }
        if (tabId != current.activeTabId) {
            _uiState.value = current.copy(tabs = remaining)
            persistBrowserSession()
            return
        }
        val replacement = remaining[(index - 1).coerceAtLeast(0).coerceAtMost(remaining.lastIndex)]
        _uiState.value = current.copy(
            tabs = remaining,
            activeTabId = replacement.id,
            currentUrl = replacement.url,
            pageTitle = replacement.title,
            inputUrl = replacement.url,
            isLoading = false,
            loadProgress = if (replacement.isHomeView) 0 else 100,
            canGoBack = false,
            canGoForward = false,
            isBookmarked = false,
            isHomeView = replacement.isHomeView,
            // Closing a card from the overview should keep the overview visible.
            showTabsOverview = current.showTabsOverview,
            isDesktopMode = replacement.isDesktopMode,
            navigationRequestId = current.navigationRequestId + 1L
        )
        if (!replacement.isPrivate && !replacement.isHomeView && replacement.url.isNotBlank()) checkIsBookmarked(replacement.url)
        persistBrowserSession()
    }

    fun setHomeView() {
        val current = _uiState.value
        savedWebViewStates.remove(current.activeTabId)
        updateTab(current.activeTabId) { it.copy(url = "", title = "New tab", isHomeView = true) }
        _uiState.value = _uiState.value.copy(
            currentUrl = "", pageTitle = "New tab", inputUrl = "",
            isHomeView = true, showTabsOverview = false,
            isLoading = false, loadProgress = 0,
            isMediaDetectionLoading = false, mediaDetectionStage = null,
            canGoBack = false, canGoForward = false, isBookmarked = false
        )
        persistBrowserSession()
    }

    fun setDesktopMode(enabled: Boolean) {
        val current = _uiState.value
        updateTab(current.activeTabId) { it.copy(isDesktopMode = enabled) }
        _uiState.value = _uiState.value.copy(isDesktopMode = enabled)
    }

    fun toggleBookmark() {
        val current = _uiState.value
        if (current.tabs.firstOrNull { it.id == current.activeTabId }?.isPrivate == true) {
            _uiState.value = current.copy(snackbarMessage = "Bookmarks are disabled in private tabs")
            return
        }
        val url = current.currentUrl
        if (!(url.startsWith("http://") || url.startsWith("https://"))) {
            _uiState.value = current.copy(snackbarMessage = "Open a website before adding a bookmark")
            return
        }
        val title = current.pageTitle
        viewModelScope.launch {
            if (_uiState.value.isBookmarked) {
                container.database.bookmarkDao().deleteBookmarkByUrl(url)
                _uiState.value = _uiState.value.copy(isBookmarked = false, snackbarMessage = "Bookmark removed")
            } else {
                container.database.bookmarkDao().insertBookmark(
                    BookmarkEntity(url = url, title = title)
                )
                _uiState.value = _uiState.value.copy(isBookmarked = true, snackbarMessage = "Bookmark added")
            }
        }
    }

    private fun checkIsBookmarked(url: String) {
        viewModelScope.launch {
            val isBookmarked = container.database.bookmarkDao().isBookmarked(url).first()
            if (_uiState.value.currentUrl == url) {
                _uiState.value = _uiState.value.copy(isBookmarked = isBookmarked)
            }
        }
    }

    private fun updateTab(tabId: Long, transform: (BrowserTab) -> BrowserTab) {
        val current = _uiState.value
        val updatedTabs = current.tabs.map { tab -> if (tab.id == tabId) transform(tab) else tab }
        if (updatedTabs == current.tabs) return
        val previousTab = current.tabs.firstOrNull { it.id == tabId }
        val updatedTab = updatedTabs.firstOrNull { it.id == tabId }
        _uiState.value = if (tabId == current.activeTabId && updatedTab != null) {
            current.copy(
                tabs = updatedTabs,
                currentUrl = updatedTab.url,
                pageTitle = updatedTab.title,
                isHomeView = updatedTab.isHomeView,
                isDesktopMode = updatedTab.isDesktopMode
            )
        } else {
            current.copy(tabs = updatedTabs)
        }
        if (previousTab != null && updatedTab != null && (
                previousTab.url != updatedTab.url ||
                previousTab.title != updatedTab.title ||
                previousTab.isHomeView != updatedTab.isHomeView ||
                previousTab.isDesktopMode != updatedTab.isDesktopMode ||
                previousTab.isPrivate != updatedTab.isPrivate
            )) {
            persistBrowserSession()
        }
    }

    fun selectCandidateForDownload(candidate: MediaCandidate) {
        selectCandidateGroupForDownload(listOf(candidate))
    }

    /** Opens one logical video's choices, expanding a lone HLS master into resolution variants. */
    fun selectCandidateGroupForDownload(candidates: List<MediaCandidate>) {
        // DASH is temporarily disabled app-wide. Keep its parser/implementation in place,
        // but never surface an MPD candidate as a downloadable option during this period.
        val distinct = candidates
            .filter { it.streamType != StreamType.DASH }
            .distinctBy { it.url.substringBefore('#') }
        if (distinct.isEmpty()) {
            _uiState.value = _uiState.value.copy(
                isResolvingVariants = false,
                snackbarMessage = "DASH downloads are temporarily paused. Try an available MP4 or HLS stream."
            )
            return
        }
        mediaSelectionGeneration += 1L
        val generation = mediaSelectionGeneration
        val initialOptions = sortMediaOptions(distinct)
        val primary = initialOptions.first()
        val shouldResolveHls = initialOptions.size == 1 && primary.streamType == StreamType.HLS
        _uiState.value = _uiState.value.copy(
            selectedCandidate = primary,
            selectedCandidates = initialOptions,
            showMediaSheet = true,
            isResolvingVariants = shouldResolveHls
        )

        if (!shouldResolveHls) return
        viewModelScope.launch {
            val cookieHeader = webViewCookiesFor(primary.url)
            val expanded = container.mediaExtractionRepository.resolveHlsVariants(primary, cookieHeader)
            if (generation != mediaSelectionGeneration || !_uiState.value.showMediaSheet) return@launch
            val options = sortMediaOptions(expanded.ifEmpty { listOf(primary) })
            _uiState.value = _uiState.value.copy(
                selectedCandidate = options.firstOrNull() ?: primary,
                selectedCandidates = options.ifEmpty { listOf(primary) },
                isResolvingVariants = false
            )
        }
    }

    /** Resolve one explicitly tapped Facebook/Instagram/Threads image or video. */
    fun selectPlatformMediaAction(
        kind: String,
        mediaUrl: String,
        mimeType: String?,
        title: String?,
        pageUrl: String,
        userAgent: String?,
        durationSeconds: Double = 0.0
    ) {
        val cleanUrl = mediaUrl.trim()
        val platform = PlatformMediaOverlayScript.platformForUrl(pageUrl) ?: return
        if (!(cleanUrl.startsWith("https://", true) || cleanUrl.startsWith("http://", true))) return
        if (cleanUrl.length > 8192 || !PlatformMediaOverlayScript.isAllowedMediaUrl(platform, cleanUrl)) return
        val cleanKind = kind.lowercase()
        if (cleanKind != "image" && cleanKind != "video") return

        // Reuse the already-enriched video candidate when the tapped element points at that URL.
        if (cleanKind == "video") {
            val existing = detectedMediaList.value.firstOrNull { it.url.substringBefore('#') == cleanUrl.substringBefore('#') }
            if (existing != null) {
                selectCandidateForDownload(existing)
                return
            }
        }

        val guessedMime = mimeType?.substringBefore(';')?.takeIf { it.isNotBlank() } ?:
            if (cleanKind == "image") "image/jpeg" else "video/mp4"
        val streamType = when {
            cleanUrl.substringBefore('?').contains(".m3u8", true) || guessedMime.contains("mpegurl", true) -> StreamType.HLS
            cleanUrl.substringBefore('?').contains(".mpd", true) || guessedMime.contains("dash+xml", true) -> StreamType.DASH
            else -> StreamType.PROGRESSIVE
        }
        val fallbackTitle = if (cleanKind == "image") "image_${System.currentTimeMillis()}" else "video_${System.currentTimeMillis()}"
        val candidate = MediaCandidate(
            id = java.util.UUID.randomUUID().toString(),
            url = cleanUrl,
            title = title?.trim()?.take(180)?.takeIf { it.isNotBlank() } ?: fallbackTitle,
            mimeType = guessedMime,
            userAgent = userAgent,
            referer = pageUrl,
            sourcePageUrl = pageUrl,
            sourcePlatform = platform,
            streamType = streamType,
            isDirectDownload = streamType == StreamType.PROGRESSIVE,
            durationSeconds = durationSeconds.takeIf { it.isFinite() && it > 0.0 && it < 86_400.0 },
            detectionSource = MediaDetectionSource.EXTRACTOR,
            detectionConfidence = 96
        )
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isResolvingVariants = true)
            val cookies = webViewCookiesFor(cleanUrl)
            val resolved = runCatching {
                container.mediaExtractionRepository.resolveCandidateForDetection(candidate, cookies)
            }.getOrDefault(listOf(candidate)).ifEmpty { listOf(candidate) }.map { resolvedCandidate ->
                val responseMime = resolvedCandidate.mimeType.orEmpty().substringBefore(';').trim().lowercase()
                val genericMime = responseMime.isBlank() || responseMime == "application/octet-stream" ||
                    responseMime == "binary/octet-stream" || responseMime == "application/binary"
                if (genericMime) {
                    resolvedCandidate.copy(mimeType = guessedMime)
                } else resolvedCandidate
            }
            val badResponse = resolved.firstOrNull { resolvedCandidate ->
                val responseMime = resolvedCandidate.mimeType.orEmpty().substringBefore(';').trim().lowercase()
                when (cleanKind) {
                    "image" -> responseMime.isNotBlank() && !responseMime.startsWith("image/")
                    else -> responseMime.startsWith("text/") || responseMime.contains("json") ||
                        (responseMime.startsWith("application/") && !responseMime.contains("mpegurl") &&
                            !responseMime.contains("dash+xml") && responseMime != "application/octet-stream" &&
                            responseMime != "application/binary")
                }
            }
            if (badResponse != null) {
                _uiState.value = _uiState.value.copy(
                    isResolvingVariants = false,
                    snackbarMessage = if (cleanKind == "image") {
                        "The selected item did not return an image file. It may be a preview or an access-restricted URL."
                    } else {
                        "The selected item did not return a downloadable video stream."
                    }
                )
                return@launch
            }
            _uiState.value = _uiState.value.copy(isResolvingVariants = false)
            selectCandidateGroupForDownload(resolved)
        }
    }

    private fun rememberMetaPageCandidates(itemPageUrl: String, candidates: List<MediaCandidate>) {
        val key = metaItemPageKey(itemPageUrl)
        val current = metaVideoCandidatesByPage[key].orEmpty()
        metaVideoCandidatesByPage[key] = (current + candidates)
            .distinctBy { it.url.substringBefore('#') }
            .takeLast(32)
    }

    private fun rememberMetaPosterCandidate(posterKey: String, candidate: MediaCandidate) {
        if (posterKey in ambiguousMetaPosterKeys) return
        val existing = metaVideoCandidatesByPoster[posterKey].orEmpty()
        val previous = existing.firstOrNull()
        if (previous != null) {
            val sameItem = previous.sourcePageUrl?.let(::metaItemPageKey) == candidate.sourcePageUrl?.let(::metaItemPageKey) &&
                previous.sourcePageUrl != null && candidate.sourcePageUrl != null
            val sameGroup = !previous.videoGroupId.isNullOrBlank() &&
                previous.videoGroupId != "meta-page" && previous.videoGroupId == candidate.videoGroupId
            if (existing.any { it.url != candidate.url } && !sameItem && !sameGroup) {
                metaVideoCandidatesByPoster.remove(posterKey)
                ambiguousMetaPosterKeys.add(posterKey)
                return
            }
        }
        metaVideoCandidatesByPoster[posterKey] = (existing + candidate)
            .distinctBy { it.url.substringBefore('#') }
            .takeLast(32)
    }

    /**
     * Associates a video URL found in a first-party Meta JSON response with the exact Story/Reel
     * object that exposed it. This lets a poster's button select its own pre-play MP4/HLS URL.
     */
    fun onMetaVideoCandidate(
        mediaUrl: String,
        title: String?,
        durationSeconds: Double,
        posterUrl: String?,
        isPlaying: Boolean,
        mimeType: String?,
        videoGroupId: String?,
        contentItemUrl: String?,
        pageUrl: String,
        userAgent: String?
    ) {
        val platform = PlatformMediaOverlayScript.platformForUrl(pageUrl) ?: return
        if (platform !in setOf(PlatformSource.FACEBOOK, PlatformSource.INSTAGRAM, PlatformSource.THREADS)) return
        val url = mediaUrl.trim().takeIf {
            (it.startsWith("https://", true) || it.startsWith("http://", true)) &&
                it.length <= 8192 && PlatformMediaOverlayScript.isAllowedMediaUrl(platform, it)
        } ?: return
        val itemUrl = contentItemUrl?.trim()?.takeIf {
            PlatformMediaOverlayScript.platformForUrl(it) == platform &&
                PlatformMediaOverlayScript.isSingleMediaPostUrl(it)
        }
        val poster = posterUrl?.trim()?.takeIf { PlatformMediaOverlayScript.isAllowedMediaUrl(platform, it) }
        val mime = mimeType?.substringBefore(';')?.trim()?.lowercase().orEmpty()
        val lowerUrl = url.lowercase()
        val streamType = when {
            lowerUrl.substringBefore('?').contains(".m3u8") || mime.contains("mpegurl") -> StreamType.HLS
            lowerUrl.substringBefore('?').contains(".mpd") || mime.contains("dash+xml") -> StreamType.DASH
            else -> StreamType.PROGRESSIVE
        }
        // Pause only DASH candidates. Progressive MP4 and HLS candidates from the same
        // signed-in Meta session must continue through the normal detection pipeline.
        if (streamType == StreamType.DASH) return
        val candidate = MediaCandidate(
            id = java.util.UUID.randomUUID().toString(),
            url = url,
            title = title?.trim()?.take(280)?.takeIf { it.isNotBlank() } ?: "${platform.name.lowercase()} video",
            mimeType = when (streamType) {
                StreamType.HLS -> "application/vnd.apple.mpegurl"
                StreamType.DASH -> "application/dash+xml"
                else -> mime.takeIf { it.startsWith("video/") } ?: "video/mp4"
            },
            userAgent = userAgent,
            referer = pageUrl,
            sourcePageUrl = itemUrl ?: pageUrl,
            sourcePlatform = platform,
            streamType = streamType,
            isDirectDownload = streamType == StreamType.PROGRESSIVE,
            thumbnailUrl = poster,
            durationSeconds = durationSeconds.takeIf { it.isFinite() && it > 0.0 && it < 86_400.0 },
            isPlaying = isPlaying,
            detectionSource = MediaDetectionSource.SCRIPT_RESOURCE,
            detectionConfidence = if (itemUrl != null) 99 else 94,
            videoGroupId = videoGroupId?.take(120)?.ifBlank { null }
        )
        if (itemUrl != null) rememberMetaPageCandidates(itemUrl, listOf(candidate))
        if (poster != null) rememberMetaPosterCandidate(poster.substringBefore('#'), candidate)
        container.mediaDetector.onExtractorCandidate(candidate)
        if (pendingExternalMediaPageHost != null) tryCompleteExternalLinkSelection()
    }

    /**
     * Persists a DASH MPD XML string already exposed in the active Meta page response.
     * The candidate is associated with its exact same-platform Story/Reel permalink so a feed
     * overlay cannot accidentally select a different item's manifest.
     */
    fun onMetaInlineDashManifest(
        manifestText: String,
        responseUrl: String?,
        title: String?,
        durationSeconds: Double,
        posterUrl: String?,
        contentItemUrl: String?,
        pageUrl: String,
        userAgent: String?
    ) {
        // DASH manifest capture is intentionally disabled while stabilizing Facebook downloads.
        // Keep this callback/API in place so DASH can be restored later without refactoring.
        return
        @Suppress("UNREACHABLE_CODE")
        val platform = PlatformMediaOverlayScript.platformForUrl(pageUrl) ?: return
        if (platform !in setOf(PlatformSource.FACEBOOK, PlatformSource.INSTAGRAM, PlatformSource.THREADS)) return
        val itemUrl = contentItemUrl?.trim()?.takeIf {
            PlatformMediaOverlayScript.platformForUrl(it) == platform &&
                PlatformMediaOverlayScript.isSingleMediaPostUrl(it)
        } ?: pageUrl.takeIf { PlatformMediaOverlayScript.isSingleMediaPostUrl(it) }
        val posterKey = posterUrl?.trim()?.takeIf { PlatformMediaOverlayScript.isAllowedMediaUrl(platform, it) }
            ?.substringBefore('#')
        if (itemUrl == null && posterKey == null) return
        val baseUrl = responseUrl?.takeIf { PlatformMediaOverlayScript.platformForUrl(it) == platform }
            ?: itemUrl ?: pageUrl

        viewModelScope.launch {
            val storedUrl = withContext(kotlinx.coroutines.Dispatchers.IO) {
                InlineDashManifestStore.save(container.context, platform, baseUrl, manifestText)
            } ?: return@launch
            val displayTitle = title?.takeIf { it.isNotBlank() }
                ?: "${platform.name.lowercase().replaceFirstChar { it.uppercase() }} video"
            val sourcePage = itemUrl ?: pageUrl
            val groupId = if (platform == PlatformSource.FACEBOOK) {
                "facebook-dash:${itemUrl?.let(::metaItemPageKey) ?: posterKey.hashCode()}"
            } else "meta-inline-dash:${storedUrl.substringAfterLast('/') }"

            val facebookOptions = if (platform == PlatformSource.FACEBOOK) {
                withContext(kotlinx.coroutines.Dispatchers.Default) {
                    FacebookDashVariantCatalog.parse(manifestText, baseUrl, durationSeconds)
                }
            } else emptyList()

            val candidates = if (platform == PlatformSource.FACEBOOK && facebookOptions.isNotEmpty()) {
                facebookOptions.map { option ->
                    val selectedUrl = InlineDashManifestStore.withSelection(
                        sourceUrl = storedUrl,
                        videoRepresentationIndex = option.representationIndex.takeIf { !option.isAudioOnly },
                        audioRepresentationIndex = option.audioRepresentationIndex,
                        audioOnly = option.isAudioOnly
                    )
                    FacebookDashVariantCatalog.toCandidate(
                        option = option,
                        selectedUrl = selectedUrl,
                        title = displayTitle,
                        sourcePageUrl = sourcePage,
                        userAgent = userAgent,
                        referer = pageUrl,
                        thumbnailUrl = posterKey,
                        durationSeconds = durationSeconds,
                        groupId = groupId
                    )
                }
            } else {
                listOf(
                    MediaCandidate(
                        id = java.util.UUID.randomUUID().toString(),
                        url = storedUrl,
                        title = displayTitle,
                        mimeType = "application/dash+xml",
                        userAgent = userAgent,
                        referer = pageUrl,
                        sourcePageUrl = sourcePage,
                        sourcePlatform = platform,
                        streamType = StreamType.DASH,
                        isDirectDownload = false,
                        thumbnailUrl = posterKey,
                        durationSeconds = durationSeconds.takeIf { it.isFinite() && it > 0.0 && it < 86_400.0 },
                        detectionSource = MediaDetectionSource.SCRIPT_RESOURCE,
                        detectionConfidence = 99,
                        videoGroupId = groupId
                    )
                )
            }

            if (itemUrl != null) rememberMetaPageCandidates(itemUrl, candidates)
            if (posterKey != null) candidates.forEach { rememberMetaPosterCandidate(posterKey, it) }
            candidates.forEach(container.mediaDetector::onExtractorCandidate)

            val removeGroupKey = itemUrl?.let(::metaItemPageKey)
            val current = resolvedCandidates.value.filterNot { existing ->
                existing.sourcePlatform == platform &&
                    (removeGroupKey != null && metaItemPageKey(existing.sourcePageUrl.orEmpty()) == removeGroupKey) &&
                    (InlineDashManifestStore.isInlineDashUrl(existing.url) || existing.videoGroupId == groupId)
            }
            resolvedCandidates.value = (current + candidates).takeLast(120)
            if (itemUrl != null) tryCompleteExternalLinkSelection()
        }
    }

    private fun metaItemPageKey(raw: String): String = runCatching {
        val uri = java.net.URI(raw)
        val platform = PlatformMediaOverlayScript.platformForUrl(raw)
        val path = uri.rawPath.orEmpty().trimEnd('/')
        // Host aliases (m./www.) and the Threads net/com transition must not split one item's key.
        val canonicalHost = when (platform) {
            PlatformSource.FACEBOOK -> "facebook"
            PlatformSource.INSTAGRAM -> "instagram"
            PlatformSource.THREADS -> "threads"
            else -> uri.host.orEmpty().lowercase()
        }
        // Story endpoints may encode the media identity in story_fbid/id query parameters.
        val storyQuery = if (path.contains("story.php", true) || path.contains("video.php", true)) {
            uri.rawQuery.orEmpty().split('&').filter { part ->
                part.substringBefore('=').lowercase() in setOf("story_fbid", "id", "v")
            }.sortedBy { it.substringBefore('=').lowercase() }.joinToString("&").takeIf { it.isNotBlank() }
        } else null
        buildString {
            append(canonicalHost)
            append(path)
            storyQuery?.let { append('?'); append(it) }
        }
    }.getOrDefault(raw.substringBefore('#').trimEnd('/'))

    /**
     * Resolve a tapped Meta Story/Reel poster against that exact item's permalink first.
     * The signed-in WebView cookies, browser User-Agent and Referer are reused by the platform
     * extractors. Only when no video stream is exposed does the exact tapped thumbnail become an
     * image download candidate; candidates from unrelated posts are never borrowed.
     */
    fun resolveMetaVideoOrThumbnail(
        itemPageUrl: String?,
        thumbnailUrl: String?,
        title: String?,
        pageUrl: String,
        userAgent: String?,
        durationSeconds: Double = 0.0
    ) {
        val platform = PlatformMediaOverlayScript.platformForUrl(pageUrl) ?: return
        val targetUrl = itemPageUrl?.trim()?.takeIf {
            PlatformMediaOverlayScript.platformForUrl(it) == platform &&
                (it.startsWith("https://", true) || it.startsWith("http://", true)) &&
                PlatformMediaOverlayScript.isSingleMediaPostUrl(it)
        } ?: pageUrl.takeIf { PlatformMediaOverlayScript.isSingleMediaPostUrl(it) }
        val safeThumbnail = thumbnailUrl?.trim()?.takeIf {
            PlatformMediaOverlayScript.isAllowedMediaUrl(platform, it)
        }

        mediaSelectionGeneration += 1L
        val generation = mediaSelectionGeneration
        _uiState.value = _uiState.value.copy(
            isResolvingVariants = true,
            snackbarMessage = "Looking for the original Story/Reels video…"
        )
        viewModelScope.launch {
            val targetPageKey = targetUrl?.let(::metaItemPageKey)
            fun exactVideoCandidates(): List<MediaCandidate> {
                val values = mutableListOf<MediaCandidate>()
                targetPageKey?.let { key -> values += metaVideoCandidatesByPage[key].orEmpty() }
                if (targetPageKey != null) {
                    values += detectedMediaList.value.filter { item ->
                        item.sourcePlatform == platform &&
                            metaItemPageKey(item.sourcePageUrl ?: item.referer ?: "") == targetPageKey
                    }
                }
                safeThumbnail?.substringBefore('#')?.let { key ->
                    if (key !in ambiguousMetaPosterKeys) values += metaVideoCandidatesByPoster[key].orEmpty()
                }
                return sortMediaOptions(values.filter { item ->
                    item.sourcePlatform == platform &&
                        (PlatformMediaOverlayScript.isAllowedMediaUrl(platform, item.url) || InlineDashManifestStore.isInlineDashUrl(item.url)) &&
                        (item.mimeType.orEmpty().startsWith("video/", true) ||
                            item.streamType == StreamType.HLS || item.streamType == StreamType.DASH)
                }).take(12)
            }

            var videoCandidates = exactVideoCandidates()
            // The in-page Story/Reels request may finish a moment after the overlay is tapped.
            // Wait briefly for that exact item's already-observed response, never for video playback.
            if (videoCandidates.isEmpty()) {
                videoCandidates = withTimeoutOrNull(1_400L) {
                    while (true) {
                        val found = exactVideoCandidates()
                        if (found.isNotEmpty()) return@withTimeoutOrNull found
                        delay(100L)
                    }
                    emptyList()
                }.orEmpty()
            }

            var pageThumbnail: MediaCandidate? = null
            if (targetUrl != null && videoCandidates.isEmpty()) {
                val extracted = runCatching {
                    container.mediaExtractionRepository.resolveMedia(targetUrl, userAgent)
                }.getOrNull()
                if (extracted != null && extracted.sourcePlatform == platform &&
                    (PlatformMediaOverlayScript.isAllowedMediaUrl(platform, extracted.url) || InlineDashManifestStore.isInlineDashUrl(extracted.url))) {
                    val mime = extracted.mimeType.orEmpty().substringBefore(';').lowercase()
                    val isVideo = mime.startsWith("video/") ||
                        extracted.streamType == StreamType.HLS || extracted.streamType == StreamType.DASH
                    if (isVideo) videoCandidates = listOf(extracted)
                    else if (mime.startsWith("image/")) pageThumbnail = extracted
                }
            }

            if (generation != mediaSelectionGeneration) return@launch
            if (videoCandidates.isNotEmpty()) {
                val resolved = mutableListOf<MediaCandidate>()
                for (candidate in videoCandidates) {
                    val cookieHeader = if (InlineDashManifestStore.isInlineDashUrl(candidate.url)) null
                        else webViewCookiesFor(candidate.url)
                    val candidateResults = runCatching {
                        container.mediaExtractionRepository.resolveCandidateForDetection(candidate, cookieHeader)
                    }.getOrDefault(listOf(candidate))
                    resolved += candidateResults.filter { item ->
                        (item.mimeType.orEmpty().startsWith("video/", true) ||
                            item.streamType == StreamType.HLS || item.streamType == StreamType.DASH) &&
                            (PlatformMediaOverlayScript.isAllowedMediaUrl(platform, item.url) || InlineDashManifestStore.isInlineDashUrl(item.url))
                    }
                }
                if (generation != mediaSelectionGeneration) return@launch
                val finalOptions = sortMediaOptions(resolved).take(12)
                if (finalOptions.isNotEmpty()) {
                    _uiState.value = _uiState.value.copy(isResolvingVariants = false, snackbarMessage = null)
                    selectCandidateGroupForDownload(finalOptions)
                    return@launch
                }
            }

            val fallback = pageThumbnail?.url ?: safeThumbnail
            if (fallback != null) {
                _uiState.value = _uiState.value.copy(isResolvingVariants = false, snackbarMessage = "Original video URL was not exposed. Downloading this item's thumbnail instead.")
                selectPlatformMediaAction(
                    kind = "image",
                    mediaUrl = fallback,
                    mimeType = pageThumbnail?.mimeType ?: "image/jpeg",
                    title = (title?.takeIf { it.isNotBlank() } ?: pageThumbnail?.title ?: "Story/Reels thumbnail"),
                    pageUrl = pageUrl,
                    userAgent = userAgent,
                    durationSeconds = durationSeconds
                )
            } else {
                _uiState.value = _uiState.value.copy(
                    isResolvingVariants = false,
                    snackbarMessage = "No video stream or thumbnail URL was exposed for this item."
                )
            }
        }
    }

    private fun sortMediaOptions(candidates: List<MediaCandidate>): List<MediaCandidate> =
        candidates.distinctBy { it.url.substringBefore('#') }.sortedWith(
            compareByDescending<MediaCandidate> { MediaCandidateGrouping.qualityRank(it) }
                .thenByDescending { it.isPlaying }
                .thenByDescending { it.detectionConfidence }
                .thenByDescending { it.contentLength ?: 0L }
        )

    fun dismissMediaSheet() {
        mediaSelectionGeneration += 1L
        _uiState.value = _uiState.value.copy(
            selectedCandidate = null,
            selectedCandidates = emptyList(),
            showMediaSheet = false,
            isResolvingVariants = false
        )
    }

    fun confirmDownload(candidate: MediaCandidate, customTitle: String, rememberSession: Boolean) {
        mediaSelectionGeneration += 1L
        viewModelScope.launch {
            if (rememberSession) {
                container.preferenceManager.sessionNoticeAccepted = true
                container.preferenceManager.setNoticeAcceptedPermanently(true)
            } else {
                container.preferenceManager.sessionNoticeAccepted = true
            }
            _uiState.value = _uiState.value.copy(
                userNoticeAccepted = true,
                showMediaSheet = false,
                selectedCandidate = null,
                selectedCandidates = emptyList(),
                isResolvingVariants = false,
                snackbarMessage = "Download started: $customTitle"
            )
            try {
                container.downloadRepository.enqueueDownload(candidate, customTitle)
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(snackbarMessage = e.message ?: "Failed to start download")
            }
        }
    }

    fun analyzeExternalUrl(sharedUrl: String) {
        mediaSelectionGeneration += 1L
        val targetHost = normalizedMetaHost(sharedUrl)
        val platformPage = PlatformMediaOverlayScript.supportsUrl(sharedUrl) &&
            PlatformMediaOverlayScript.isSingleMediaPostUrl(sharedUrl)
        pendingExternalMediaPageHost = if (platformPage) targetHost else null
        pendingExternalMediaPageUrl = if (platformPage) sharedUrl else null
        val selectionToken = ++externalLinkSelectionGeneration
        _uiState.value = _uiState.value.copy(isAnalyzingUrl = true, isResolvingVariants = false, snackbarMessage = "Analyzing media link…")
        if (platformPage) {
            viewModelScope.launch {
                delay(25_000L)
                if (selectionToken == externalLinkSelectionGeneration && pendingExternalMediaPageHost != null) {
                    pendingExternalMediaPageHost = null
                    pendingExternalMediaPageUrl = null
                    _uiState.value = _uiState.value.copy(
                        snackbarMessage = "No downloadable video stream was exposed for this link. The page may not have published an accessible media URL."
                    )
                }
            }
        }
        viewModelScope.launch {
            try {
                val extractedCandidate = container.mediaExtractionRepository.resolveMedia(sharedUrl)
                val requestedPlatform = PlatformMediaOverlayScript.platformForUrl(sharedUrl)
                val candidate = extractedCandidate?.takeIf {
                    if (requestedPlatform == null) true else {
                        PlatformMediaOverlayScript.isAllowedMediaUrl(requestedPlatform, it.url) &&
                            (it.mimeType.orEmpty().startsWith("video/", ignoreCase = true) ||
                                it.streamType == StreamType.HLS || it.streamType == StreamType.DASH)
                    }
                }
                if (candidate != null) {
                    pendingExternalMediaPageHost = null
                    pendingExternalMediaPageUrl = null
                    externalLinkSelectionGeneration += 1L
                    _uiState.value = _uiState.value.copy(
                        isAnalyzingUrl = false,
                        selectedCandidate = candidate,
                        selectedCandidates = listOf(candidate),
                        showMediaSheet = true,
                        isResolvingVariants = false,
                        snackbarMessage = null
                    )
                } else {
                    _uiState.value = _uiState.value.copy(
                        isAnalyzingUrl = false,
                        snackbarMessage = if (platformPage) "Opening this post in your signed-in browser session to inspect its visible media…" else "No direct media found on this page. Opening in browser…"
                    )
                    loadUrl(sharedUrl)
                }
            } catch (_: Exception) {
                _uiState.value = _uiState.value.copy(
                    isAnalyzingUrl = false,
                    snackbarMessage = "Could not analyze link. Loading in browser…"
                )
                loadUrl(sharedUrl)
            }
        }
    }

    fun clearSnackbar() {
        _uiState.value = _uiState.value.copy(snackbarMessage = null)
    }

    class Factory(private val container: AppContainer) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return BrowserViewModel(container) as T
        }
    }
}
