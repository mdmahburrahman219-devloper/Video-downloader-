package com.mahabub.downloder.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.mahabub.downloder.AppContainer
import com.mahabub.downloder.db.BookmarkEntity
import com.mahabub.downloder.db.BrowserHistoryEntity
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class HistoryBookmarksViewModel(private val container: AppContainer) : ViewModel() {

    val historyList: StateFlow<List<BrowserHistoryEntity>> = container.database.browserHistoryDao().getAllHistory()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val bookmarksList: StateFlow<List<BookmarkEntity>> = container.database.bookmarkDao().getAllBookmarks()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun deleteHistoryItem(id: Long) {
        viewModelScope.launch { container.database.browserHistoryDao().deleteHistoryById(id) }
    }

    fun clearAllHistory() {
        viewModelScope.launch { container.database.browserHistoryDao().clearHistory() }
    }

    fun addBookmark(url: String, title: String) {
        viewModelScope.launch {
            val dao = container.database.bookmarkDao()
            dao.deleteBookmarkByUrl(url)
            dao.insertBookmark(BookmarkEntity(url = url, title = title.ifBlank { url }))
        }
    }

    fun deleteBookmark(id: Long) {
        viewModelScope.launch { container.database.bookmarkDao().deleteBookmarkById(id) }
    }

    fun clearAllBookmarks() {
        viewModelScope.launch { container.database.bookmarkDao().clearBookmarks() }
    }

    class Factory(private val container: AppContainer) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return HistoryBookmarksViewModel(container) as T
        }
    }
}
