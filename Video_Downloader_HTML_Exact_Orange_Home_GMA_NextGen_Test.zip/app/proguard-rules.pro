# WebView JavaScript bridge methods are invoked by their source-level names.
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# Room discovers the generated implementation by its conventional class name.
# Keep RoomDatabase subclasses while allowing unused app/model members to be removed.
-keep class * extends androidx.room.RoomDatabase { *; }
