# TikTok Network Detection Update

This update focuses on finding extensionless video resources that an embedded browser may request even when the visible TikTok page says it is unavailable.

## Changes
- Added a narrow TikTok/ByteDance media URL heuristic for extensionless video paths (including `/video/tos/`, `/obj/tos-*`, and `/media-video-hvc1/`) and explicit video MIME query markers. It rejects common image/segment extensions and deceptive hostnames.
- `SecureWebViewClient` now reports matching extensionless TikTok GET resources to `MediaDetector` as video candidates without intercepting or changing the page response.
- `SnifferScript` detects the same resource class through Performance Resource Timing and observes first-party TikTok JSON responses from fetch/XHR without consuming the page's original response.
- Expanded native TikTok page parsing to retain the requested video ID after redirects and recognize more playback-address fields, including `play_addr_h264`, `play_addr_bytevc1`, and `bit_rate` arrays.
- The browser resolver now passes multiple TikTok candidates through the existing detector and download UI, while other platform and direct-download paths keep their prior behavior.
- The native page resolver uses the live WebView User-Agent when available and the existing `ExtractorUtils` cookie handling for the requested TikTok page. Manual “Scan again” also retries the native TikTok resolver when no earlier resolver job is still active.
- Added Kotlin unit tests for extensionless TikTok/ByteDance URL recognition and rejection of common false positives.

## Important limits
- This uses the TikTok page's own page data and browser-observed resource URLs; it does not call a third-party downloader API.
- `shouldInterceptRequest` does not expose `blob:` URLs and sees only initial URLs before redirects. The JavaScript JSON/resource scan supplements that path but cannot guarantee access to every player implementation.
- TikTok may change URL patterns, require session context, or restrict individual videos. A candidate being detected does not guarantee that the CDN will authorize the download.
- Full Android Gradle build and live-device TikTok tests must be run on a machine with Android SDK and Gradle wrapper available.
