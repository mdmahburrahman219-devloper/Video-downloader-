# Automatic video detection + Download FAB loading update

This update keeps the current Kotlin / Jetpack Compose app and custom downloader architecture.

## What changed

- **Document-start sniffer:** registers the existing sniffer with AndroidX WebKit's `DOCUMENT_START_SCRIPT` feature before a URL is loaded, when the installed Android System WebView supports it. The existing `onPageFinished` injection remains as a fallback/rescan.
- **Broader media candidates:** the JavaScript observer scans `<video>`/`<source>` and lazy media attributes, `fetch`/XHR response MIME types, resource timing, and extensionless video/audio resources reported by the browser. Extensionless player URLs are provisional candidates; native HTTP probing attempts to refine the stream MIME type.
- **More page metadata:** title, poster/thumbnail and duration are read from Open Graph/Twitter meta tags, JSON-LD `VideoObject`, and the actual HTML video element. Video-element duration is preferred when available.
- **HLS details before download:** the existing HLS resolver expands a master playlist into quality variants, reads VOD media-playlist duration, and estimates size from declared bitrate. Estimated sizes are marked as estimates; they are not used as actual download progress totals.
- **Candidate consolidation:** duplicate URLs are merged, stronger titles/posters/duration are preserved, and a single master-playlist candidate can be presented as multiple quality options.
- **Download FAB states:** after the webpage's main navigation completes, the FAB shows a spinner while the post-load scan and metadata-resolution jobs are still active. It returns to the download icon after those jobs finish. No fixed 1- or 5-second cutoff is used; individual HTTP calls still obey the app's configured network timeouts.
- **Manual fallback:** tapping the FAB when no candidate is available opens the detector panel and runs a fresh DOM/performance scan. The scan can be repeated after playing the video. If the sniffer is unavailable, the spinner is stopped and a message is shown rather than waiting forever.
- **Gradual enrichment:** later DOM events may add a duration, poster or additional quality after the first candidate was found; the UI uses updated candidate metadata when available.

## Main files changed

- `browser/SnifferScript.kt`
- `browser/AndroidMediaBridge.kt`
- `browser/MediaDetector.kt`
- `browser/SecureWebViewClient.kt` (existing fallback injection is retained)
- `repository/MediaExtractionRepository.kt`
- `model/MediaCandidate.kt`
- `model/MediaCandidateGrouping.kt`
- `ui/viewmodel/BrowserViewModel.kt`
- `ui/screens/HomeBrowserScreen.kt`
- `ui/dialogs/MediaSelectionBottomSheet.kt`
- `app/build.gradle.kts` (AndroidX WebKit dependency)

## How the loading state finishes

The FAB is not held for an arbitrary fixed delay. It stays in discovery mode while discovered candidate URLs are being probed and HLS variants are being resolved. When a webpage exposes no candidate, the completed scan ends the spinner. Metadata that the website never exposes is shown as unavailable/estimated rather than blocking forever. Per-request network timeouts are still necessary because a server can hang or never provide a response.

## Test checklist

1. Open a public test page containing a direct MP4 URL or HTML `<video>` with a poster and duration. After the page finishes loading, verify the FAB shows a spinner while candidate resolution is active, then becomes the download icon.
2. Open an HLS VOD master playlist page. Verify one logical video group is presented with its available resolutions, VOD duration when the media playlist exposes it, and estimated size when bitrate is declared.
3. Open a page with no media. Verify the spinner stops after the scan finishes and the empty detector panel offers “Scan again”.
4. Tap the FAB on a page where automatic detection found nothing. Verify a manual scan starts; then play the video and scan again if the website only reveals its source after interaction.
5. Test a video whose URL has no `.mp4`/`.m3u8` extension but whose `<video>` element or fetch/XHR response reveals a media MIME type.
6. Test slow/failed requests, multiple candidates, video ads/pre-roll, no thumbnail, missing duration, and a live playlist. Check that estimated values are labelled and the spinner does not remain indefinitely when scan/resolution completes or fails.

## Known limits

- Detection is best-effort: a site may not expose a reusable media URL until play, login, an authorized API call or a site-specific extractor is used.
- `fetch`/XHR hooks cannot inspect arbitrary cross-origin response bodies, and not every media player uses fetch/XHR. Some WebView internals and redirects are not visible to a JavaScript sniffer.
- A `blob:` MediaSource URL is not a reusable downloadable URL; the underlying media requests must be found separately.
- The page title may be a fallback when the website does not publish video-specific metadata. A thumbnail or duration cannot be guaranteed if the page/server never provides it.
- The app deliberately does not bypass DRM or access controls. Login/session requirements, signed URLs and server anti-bot measures may prevent probing or downloading.
- HLS metadata estimates are not exact final MP4 sizes. Exact output size is available only after the file has been produced.

## Build and verification notes

This source export does not include `gradlew`, `gradlew.bat`, or `gradle-wrapper.jar`. On a machine with JDK 17+, Android SDK 36 and Gradle 8.13 installed, run `gradle wrapper --gradle-version 8.13` once, then run `./gradlew assembleDebug test` (Windows: `gradlew.bat assembleDebug test`).

The preparation environment has no Gradle installation or Android SDK, so a complete Android build, Room/KSP generation, and real-device stream playback could not be run here. JavaScript syntax, XML parsing and the pure Kotlin HLS parser compilation/smoke tests were checked separately. Real device testing is still required.

## Follow-up revision: metadata and quality accuracy

See `DETECTION-METADATA-QUALITY-FIXES.md` for an additional revision that fixes metadata refresh suppression, prevents active-source dimensions from being copied to every alternate source, improves technical-filename fallback detection, uses manifest/actual dimensions before inferred quality labels, stabilizes same-player grouping, and collapses duplicate known quality choices. Regression cases have been added; full Android build/device validation remains required.
