# Facebook Reels DASH Detection Update

This update is deliberately Facebook-only. Instagram and Threads extraction logic has not been changed in this pass.

## What changed

- Fixed the embedded-script pre-filter so Facebook `dash_manifest` payloads are not dropped before JSON inspection.
- Kept the existing inline MPD parser and native DASH representation catalogue, allowing the bottom sheet to expose detected video qualities and an audio-only choice when the MPD actually contains supported representations.
- Added Facebook-only passive MSE correlation: inline MPDs are associated with Representation BaseURL / SegmentTemplate / SegmentList paths; matched page-request byte lengths can then associate a SourceBuffer with the MPD that supplied those segments; the resulting MediaSource is linked to its `blob:` video URL.
- Passed the correlated Reel permalink/poster/title back to the existing per-media overlay action so the selection sheet can look up the exact Reel instead of borrowing a nearby video's stream.
- Refused ambiguous segment-size mappings across different Reel identities to avoid attaching another Reel's manifest.
- Preserved the existing FFmpeg-free `MediaExtractor` / `MediaMuxer` remux path. HLS parsing and HLS remux methods were not rewritten.
- Fixed the Kotlin `fetchDashText()` missing-return compiler error by explicitly returning the response body string after size validation.

## Scope / limitations

- Facebook only. Instagram and Threads extractors remain unchanged.
- The MSE correlation is heuristic and depends on the page exposing a non-DRM MPD and matching segment requests to its MediaSource buffers. It cannot retrieve a stream the page itself never exposes.
- DRM-protected MPDs are rejected. Dynamic and multi-period DASH remain subject to the existing downloader limitations.
- Estimated option sizes are derived from MPD bitrate and duration when exact Content-Length is unavailable; they are labelled as estimates in the existing selection UI.

## Validation performed

- JavaScript syntax checked with Node.js for `SnifferScript` and `PlatformMediaOverlayScript`.
- Compiled the standalone Kotlin files `SnifferScript.kt`, `PlatformMediaOverlayScript.kt`, and `MediaCandidate.kt` with `kotlinc`.
- Parsed all 12 Android XML files.
- Verified the `fetchDashText()` function now explicitly returns a `String`.
- Full Android Gradle/APK build and live signed-in Facebook Reels testing were not available in this environment.


## DASH implementation status (updated)

The Android app contains a native DASH VOD path in `HlsDownloader.downloadDash()`:
- Parses static, non-DRM, single-period MPDs with Media3.
- Resolves SegmentTemplate/SegmentList indexes and SegmentBase SIDX indexes through Media3.
- Downloads initialization data and media byte ranges/segments with request headers and WebView cookies.
- Uses Android `MediaExtractor` + `MediaMuxer` to remux the selected audio/video tracks into MP4.
- Keeps DASH selection metadata in an app-private manifest store so queued downloads can be resumed after process recreation.

Current intentional limits: dynamic/live MPDs, DRM/CENC, multi-period presentations, and unsupported codecs/container layouts are not handled. This is a bounded VOD downloader, not a full DASH client. MediaMuxer is used for the final MP4; it is not a general-purpose fragmented-MP4 concatenator. A dedicated fragmented MP4 muxer can be evaluated separately, but changing muxer APIs requires end-to-end device validation before replacing the existing remux path.
