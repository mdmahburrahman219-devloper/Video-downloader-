# TikTok Two-Phase Update

Implemented in one update:

1. TikTok Browser Mode: normal WebView navigation, no ad/redirect filtering or request interception, and no TikTok extractor.
2. Playback gate: a small TikTok-only observer waits for actual video playback before signaling Android.
3. Post-playback detection: only after that signal does the existing sniffer inspect DOM video sources, hydration JSON, Resource Timing and future fetch/XHR metadata.
4. Download UI: detected candidates route into the app's existing selection popup; download still requires the user's confirmation.
5. Non-TikTok isolation: existing detection and download behavior remains on the original path.

Validation performed: JavaScript syntax checks passed for the TikTok playback observer and full sniffer; the new standalone Kotlin observer script compiled. A full Android Gradle build could not be run in this environment because Gradle and the Gradle wrapper JAR/script are not present in the archive/runtime.
