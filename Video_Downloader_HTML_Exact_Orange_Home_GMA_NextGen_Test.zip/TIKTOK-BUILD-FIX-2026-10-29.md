# TikTok Network Detection – Kotlin compile fix (2026-10-29)

## Fixed compile errors

- `TikTokExtractor.kt`: filter nullable quality/bitrate hint values with `filterNotNull()` before calling `isNotBlank()`.
- `TikTokExtractor.kt`: fixed the escaped quote sequence in the `playAddr`/`downloadAddr` fallback regex by using a Kotlin raw string literal. This preserves the intended regex while making the source parse correctly.

## Warnings that are not compile errors

- **Room/KSP SQLite query verification warning:** the build environment reports it cannot open an SQLite connection, so Room query verification is disabled there. This is an environment/tooling limitation, not a Kotlin compilation error. Check the DAO queries with a normal Android Gradle build/device environment; do not change DAO SQL just to hide this warning.
- **targetSdk 36 edge-to-edge warning:** `MainActivity` already calls `enableEdgeToEdge()` and wraps the navigation content in the Material 3 `Scaffold` inner padding. Keep target SDK 36 unless a deliberate compatibility decision requires otherwise; do not lower the target SDK merely to silence the generic warning. Check screens with Android 15+ system bars after installing.

## Validation

- Verified the regex literal with the installed Kotlin compiler and checked that it extracts escaped `playAddr` values.
- ZIP integrity is checked after packaging.
- A complete Android Gradle build was not run in this environment because the supplied project does not include `gradle-wrapper.jar` and no system Gradle/Android SDK is available here.
