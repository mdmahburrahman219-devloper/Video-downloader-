# Startup Crash Recovery Notes

The first optimized release enabled R8 minification and resource shrinking. The original project had minification disabled. Because the release APK exits immediately on launch and no Logcat trace was supplied, the exact exception is not yet confirmed.

This recovery package keeps the low-risk source/dependency and launcher-image optimizations, but disables release R8 minification and resource shrinking to remove the most significant newly introduced startup-risk variable.

## Test this package
1. Import this project and build/install the same variant you used for the crashing APK.
2. Try installing as an update first to preserve app data. If Android reports a signature conflict, do not uninstall until the existing downloads/data are backed up.
3. Launch the app. If it still crashes, capture the AndroidRuntime FATAL EXCEPTION block from Logcat (from the first exception line through the Caused by lines) and share it.

This package has been checked for ZIP integrity and Gradle configuration consistency. It has not been compiled or run on an Android device in this environment.
