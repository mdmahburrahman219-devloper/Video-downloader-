# Curved Navigation & Entry Motion Reference Match — 2026-11-07

## Bottom navigation

Updated the existing native Jetpack Compose `AnimatedBrandBottomNavigation` to match the supplied `Curved Nav Demo.html` interaction model while retaining the app's four real destinations (Browse, Downloads, Videos, Settings), localized labels, and live download/completed counters.

- A 44dp circular selection bubble follows the selected destination.
- One spring-animated selection index drives both the bubble X position and the Canvas-drawn notch center.
- Spring parameters now match the reference: damping ratio `0.50`, stiffness `200`.
- The top cradle is a 104dp-wide concave notch with 29dp depth and matching cubic Bézier control points.
- The bubble floats 22dp above the bar's top edge; the added 22dp reserved overhang keeps it from covering page content.
- The previous tab icon fades out in 80ms; inactive icons return with a 100ms delay over 200ms.
- The bubble's previous icon fades out in 100ms; its new icon fades in over 150ms after a 220ms delay. No scale transition is used.
- Selected label color transitions over 200ms; the selected label uses bold weight. Existing count badges remain functional.
- Switching among the four primary tabs is an instant cut. Non-tab destinations retain a short 220ms fade-in / 180ms fade-out navigation transition.
- Android navigation-bar inset continues to use the same surface color.

## Downloads and Settings entry animation

Added reusable native Compose helpers in `ui/components/StaggeredEntry.kt`:

- The first eight eligible content items fade from alpha 0 to 1 and rise from 16dp to their resting position.
- Each item runs for 260ms with a 40ms per-item stagger and FastOutSlowIn easing (the Compose equivalent of the reference cubic-bezier curve).
- Section headings fade in over 250ms, beginning 120ms after the first associated item starts.
- The animation key changes with the active Navigation route, so returning to Downloads or Settings replays the entry sequence.
- Downloads applies this to the empty state or the first eight active/failed cards; active and failed section headings use the corresponding delayed fade.
- Settings applies it to the introductory block, first preference rows, and section headings. Controls and click handlers remain unchanged.

## Scope protection

No HLS/DASH downloader, extractor, WebView detection script, DownloadService, Room entity/schema, storage provider, preference key, or media playback behavior was changed. No additional dependency was added.

## Validation

- ZIP contents and Kotlin source structure were inspected before editing.
- Kotlin compiler parsing completed without syntax/declaration diagnostics for the modified Kotlin files. A standalone compile could not resolve Android/AndroidX/Compose dependencies because this environment has no Gradle installation, Android SDK, or Gradle wrapper JAR.
- A full `:app:assembleDebug` build and device animation/performance test therefore remain to be run in Android Studio or the user's configured build environment.
