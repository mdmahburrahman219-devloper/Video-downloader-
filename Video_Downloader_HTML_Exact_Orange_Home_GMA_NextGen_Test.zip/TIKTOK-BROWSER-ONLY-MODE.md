# TikTok two-phase browser and download detection

This update applies only to TikTok domains. Other sites keep the existing browser, ad-blocking, media-detection and download behavior.

## Phase 1 — browser playback first
- TikTok navigation and HTTP/HTTPS redirects remain inside WebView.
- Ad-domain blocking and redirect filtering are bypassed for the complete TikTok page context, including subresource requests.
- `shouldInterceptRequest` returns to WebView's normal handling for TikTok; the app does not block, replace or inspect those network requests.
- TikTok Extractor/resolver is not started.
- Full media sniffing is not injected, and no download work starts.
- A small TikTok-only playback gate listens for video playback events and confirms that the video is unpaused, ready and its playback time has advanced. It does not inspect stream URLs or patch page APIs.

## Phase 2 — after playback is confirmed
- The native bridge receives a playback-confirmed event.
- Only then is the existing media sniffer injected into the TikTok page.
- The scanner examines video/source elements, TikTok page hydration data, browser Resource Timing, and subsequent fetch/XHR response metadata. It does not read media response bodies or alter response contents.
- Candidate URLs flow through the existing metadata and format-resolution pipeline.
- When candidates are available, the normal Media Selection popup is opened. The user must still choose and confirm a download; playback confirmation never starts a file download.
- Manual rescan is allowed only after playback has been confirmed.

## WebView
JavaScript, DOM storage, cookies, third-party cookies, normal cache behavior and user-gesture-free media playback remain enabled. The mobile UA is derived from the installed System WebView Chromium runtime, with the explicit `wv` and `Version/4.0` markers removed. This is Chrome-style formatting, not an identical Chrome app fingerprint.

## Safety and limits
- No TLS validation bypass, DRM bypass, request rewriting, or download is performed by the playback gate.
- TikTok media detection is best-effort and depends on media URLs being exposed to the page/browser. DRM-protected, encrypted or otherwise unavailable streams are not extracted.
- TikTok behavior can change server-side; this update requires on-device testing against current TikTok pages.
