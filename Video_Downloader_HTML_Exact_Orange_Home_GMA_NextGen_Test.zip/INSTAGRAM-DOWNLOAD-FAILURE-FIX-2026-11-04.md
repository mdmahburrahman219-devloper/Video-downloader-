# Instagram download failure and social filename fix — 4 November 2026

## What the supplied screenshots indicate

The failed-download cards expose a temporary file path under:

`/data/user/0/com.mahabub.downloder/cache/downloads/<task-id>_<post-title>...`

The previous `StorageManager.createTempFile()` included the post title in the temporary filename. `SafeFileName.sanitize()` limited this to 100 characters, not UTF-8 bytes. Long Japanese/CJK titles and emoji can occupy several bytes per character; adding the UUID/task ID and `.part` can exceed common Linux/Android per-filename component limits. A local file-open/create failure is therefore the strongest code-level explanation for the errors shown. The screenshot alone does not expose the underlying exception suffix, so a live Logcat trace would be needed to prove the exact errno.

## Changes

1. Temporary HTTP download files now use only `<sanitized-task-id>.part`; the page title is never part of the cache filename.
2. Temporary-file cleanup now recognizes the new `<task-id>.part` format as well as the legacy `<task-id>_<title>...` format, preserving retryable tasks.
3. `SafeFileName` now limits the base name to 120 UTF-8 bytes and truncates by Unicode code point so it does not split surrogate pairs.
4. Social-platform video downloads other than TikTok receive short default names such as `instagram_1793797068173.mp4`, with a fresh 13-digit random number. Supported prefixes are `instagram`, `facebook`, `twitter_x`, `pinterest`, `reddit`, and `threads`.
5. The selection sheet passes its initial title as a `customFileName`; the repository now recognizes an unchanged default title and applies the social naming rule. If the user explicitly edits the name, the custom name is respected.
6. TikTok naming logic remains unchanged. Social images and audio are not renamed as videos. MP4/HLS outputs use `.mp4`; when a progressive source declares a different container (for example WebM), the matching extension is retained rather than mislabeling the file.
7. Added unit tests for UTF-8 length/surrogate safety and the social filename pattern, including TikTok exclusion.

## Validation

- Compiled `SafeFileName.kt` and `SocialMediaFileName.kt` with `kotlinc` against a small model stub.
- Ran a smoke test verifying the Instagram prefix, exactly 13 digits, TikTok exclusion, image exclusion, and 120-byte UTF-8 filename cap.
- ZIP integrity checked after packaging.
- Full Android Gradle build and live Instagram downloads were not run in this environment. `gradle` is unavailable and the project contains only `gradle-wrapper.properties`, not the wrapper scripts/JAR. The user should rebuild and retry the same three failed items on-device.

## Scope preservation

No TikTok extractor or resolver code was changed. DASH remains disabled as in the supplied project. This patch focuses on local temp-file naming, safe final names, and their tests; it does not attempt to bypass Instagram login, private-content restrictions, or anti-automation controls.
