# Browser crash, search, Settings and tabs fix

## Crash root cause
`WebViewClient.shouldInterceptRequest()` is invoked on a WebView resource worker thread. The previous TikTok-context helper could read `view.url` while checking non-TikTok requests. That accesses a WebView instance from the wrong thread and can cause a WebView thread-affinity exception. The helper now reads only the request URL and a `@Volatile` last-main-frame URL snapshot. The callback is also defensive: detector/filter exceptions fall through to `super.shouldInterceptRequest()` so they cannot cancel ordinary navigation.

## Browser instrumentation
The global document-start JavaScript registration was removed. Non-TikTok pages receive the existing DOM/network sniffer after `onPageFinished`; TikTok still receives only the playback observer until playback is confirmed and then enters its existing second phase.

## Requested behavior
- Home Search / Go navigates or searches only; it never starts a download.
- Search queries use the selected search engine, including a validated custom `%s` URL template.
- Settings toggles for ad blocking, recent websites, Wi-Fi-only downloads and gallery sync remain connected to their underlying behavior. Download location is passed to the final MediaStore save on Android 10+.
- Language selection updates Android's resource locale after Activity recreation. Some hard-coded Compose labels are still English.
- Normal tab metadata and active tab ID are saved to DataStore on tab changes and when the browser enters background. On process restart, saved tab URLs are reloaded. Private tabs are not saved. WebView back/forward history is kept while the ViewModel process survives but is not persisted as a serialized WebView Bundle across process death.

## Validation limits
- Search URL builder compiled with `kotlinc` and all configured engine URL outputs were checked.
- JavaScript parser checks passed for SnifferScript, BrowserPerformanceScript and TikTokPlaybackObserverScript.
- ZIP integrity was checked.
- Full Android Gradle build/device tests were not run because the supplied export has no `gradlew`, `gradle-wrapper.jar`, installed Gradle, or Android SDK in the build environment.
