# Bottom Navigation Click Area Refinement — 2026-11-08

## Scope
Only the tap target around each bottom-navigation destination was adjusted.

## Changes
- Replaced the tight icon-only and text-only click targets with one transparent rounded destination hit area sized **64dp × 60dp**.
- The expanded area surrounds the icon and label with a modest margin, making near-option taps easier to hit.
- The distant blank portions of the bottom navigation bar remain non-clickable; no full-width click handler was added.
- The hit area uses an 18dp rounded clip and the existing Material ripple behavior.
- Kept icon/text visual coordinates, labels, colors, badge behavior, floating selected indicator, curved notch, and spring animation unchanged.

## Validation
- Source-level inspection confirms each destination has one click handler on its local 64dp × 60dp hit area.
- The previous icon and text click handlers were removed to avoid competing or fragmented touch targets.
- No Gradle build result is claimed unless compilation is run successfully in an Android/Gradle-enabled environment.
