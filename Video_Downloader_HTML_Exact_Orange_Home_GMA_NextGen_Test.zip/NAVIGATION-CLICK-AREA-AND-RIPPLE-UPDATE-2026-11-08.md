# Bottom Navigation Click-Area Update — 2026-11-08

## Changes
- Removed the old full-width 50dp transparent hit target that made taps land below the visible controls and also reacted to empty space.
- Added an independent tab click target directly to each navigation icon (24dp circular target).
- Added an independent click target directly to each navigation label; its ripple is clipped to an 8dp rounded shape.
- Left the animated selection bubble, spring motion, notch geometry, colors, spacing, labels, badges, and navigation callbacks unchanged.
- Empty areas around and between the icons and labels no longer trigger tab navigation.

## Scope
Only `AnimatedBrandBottomNavigation.kt` and this change note were updated for this request.
