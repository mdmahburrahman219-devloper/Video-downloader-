# Home Screen Purple UI & Interaction Update

- Main brand color set to `#702CDD`; purple is the default accent and the default home background is a cool ice tint.
- Home header follows the supplied HTML/reference: filled tab counter, “Video Downloader”, Settings, and More.
- Home search/download panel includes URL/search input, actual clipboard paste, focus border/elevation/glow-style animation, and a Download action based on the existing detector/downloader route. The primary color remains `#702CDD` in both light and dark modes unless the user deliberately chooses another Accent Color in Settings.
- Download action analyzes direct media URLs and opens ordinary web pages with the existing auto-detection route.
- Home sections and individual website icons use one-time staggered fade-and-rise entrance animations. Quick Access tiles, Edit, Settings/More and Download have lightweight press-scale/lift feedback. No looping animation is added, to avoid unnecessary load while browsing.
- Bottom navigation is now a rounded floating surface; Browse, Progress, and Finished use a selected purple animated pill, gentle lift and a count badge.
- Quick Access Edit opens a dedicated dialog with only URL-add and remove actions. The shortcut label is derived automatically from the host and favicon is loaded automatically from the website domain. No edit-name, reorder, restore, theme or other action appears in this dialog.
- Quick-link additions/removals use atomic DataStore operations to avoid stale-list overwrites on rapid changes.
- Recently visited stays backed by real browsing history, deduplicated by website host and hidden in private tabs; no demo website is seeded into this section. Website favicons are loaded into circular clipped icons from the actual site host, with a neutral globe fallback when unavailable.

## Validation notes

- Kotlin parser-level syntax check passed for the edited sources (Android/Compose dependencies are not available to standalone `kotlinc`).
- Resource XML and ZIP integrity checks are run during packaging.
- A full Android Gradle build and on-device animation test are not available in this environment; the imported project should be built in Code Assist for final verification.
