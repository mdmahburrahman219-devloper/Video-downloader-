# Facebook Reels DASH Quality Expansion

## Scope

This update is Facebook-only. Instagram and Threads extractor behavior is not changed.

## Changes

- Fixed `HlsDownloader.fetchDashText()` by returning the OkHttp response body's value from the block-bodied Kotlin function. This resolves the reported `Missing return statement` compile error.
- Added Facebook direct DASH MPD expansion when the user opens a single detected Facebook DASH candidate.
- Fetches only an already page-exposed DASH URL, with the candidate's browser User-Agent, Referer, and optional WebView Cookie. The final URL after redirects is retained as the MPD base URL so relative segment URLs resolve against the correct location.
- Parses a static, single-period, non-DRM MPD and creates one filtered MPD per video Representation while retaining audio AdaptationSets. Each filtered manifest is stored under an app-private opaque `vd-inline-dash://` reference and exposed as a quality option.
- Estimates size using declared video bitrate + selected audio bitrate and presentation duration; the value remains marked as estimated.
- Allows Facebook-owned CDN hosts (`fbcdn.net`, `fbsbx.com`) as a base URL for stored Facebook manifests, in addition to Facebook domains.
- Leaves the existing FFmpeg-free `MediaExtractor` / `MediaMuxer` remux path and HLS implementation unchanged.

## Validation

- `FacebookDashVariantParser.kt` compiled standalone with `kotlinc`.
- Synthetic static MPD smoke test produced 480p and 720p choices, retained the audio AdaptationSet, and calculated size estimates.
- Browser Sniffer and Platform Media Overlay JavaScript passed `node --check`.
- Updated `fetchDashText()` now explicitly returns the `execute().use { ... }` result.

A full Android Gradle build and live Facebook account/Reels download test were not run in this environment because the project ZIP does not include `gradle-wrapper.jar` and no Android SDK/Gradle installation is available here. Real Facebook MPDs that are dynamic, multi-period, DRM-protected, or unsupported by Android MediaExtractor/MediaMuxer may still fail.
