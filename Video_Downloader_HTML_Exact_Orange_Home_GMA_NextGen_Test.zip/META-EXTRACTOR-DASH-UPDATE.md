# Meta Platform Media Extractor + DASH Update

Base project: `video-downloader-meta-overlay-stable-buttons.zip`

## Scope

- Facebook, Instagram, and Threads have separate page extractor adapters backed by a shared conservative parser.
- Meta-only document-start and page-start observers monitor page-visible HTML5 media, Resource Timing, and first-party Fetch/XHR JSON/text responses. They do not call private endpoints or read/decrypt media segment bodies.
- Explicit video URL fields, HLS URLs, direct MP4 URLs, DASH MPD URLs, and inline MPD XML exposed by first-party page responses are recognized.
- Video candidates are associated with the specific Story/Reel/post permalink where available. If a permalink is absent, an item-specific poster may be used only when it is not ambiguous.
- A Story/Reel tap resolves that item's video candidates first. If no video stream is exposed, the exact tapped thumbnail is the fallback; candidates from unrelated feed items are not borrowed.
- Multiple media URLs exposed for the same item can be presented together as quality choices.
- Signed-in WebView cookies, page Referer, and browser User-Agent are reused for allowed Meta media requests.

## HLS and DASH

- The existing HLS playlist downloader and FFmpeg-free `MediaExtractor`/`MediaMuxer` remux implementation are preserved; no new HLS merger is introduced.
- DASH support is added for bounded static, single-period, non-DRM MPD presentations.
- DASH supports representations with direct segment indexes and SegmentBase/SIDX indexes loaded with Media3's `DashUtil.loadChunkIndex`.
- Separate audio/video representations are downloaded and passed through the existing native remux implementation.
- Inline MPD text observed in a first-party response is persisted in app-private storage under an opaque reference so queued downloads can resume after process restart.
- DRM/ContentProtection, dynamic MPDs, multi-period DASH presentations, and unsupported codecs/index layouts are rejected rather than bypassed.

## Other websites

The platform-specific observation and resolver paths are gated to Facebook, Instagram, and Threads. Existing generic website detection and HLS routing are retained.

## Validation and known limitations

- The JavaScript payloads pass `node --check`.
- All Android XML files parse successfully.
- ZIP integrity should be checked with `unzip -t` after packaging.
- A full Android Gradle build and real-device Facebook/Instagram/Threads tests were not run in this environment because the Android SDK and Gradle wrapper JAR are not present.
- Story/Reels video extraction is best effort: it succeeds only when the signed-in page or its first-party responses expose a usable media URL/manifest. If they expose only the thumbnail, the exact thumbnail is offered as fallback.
