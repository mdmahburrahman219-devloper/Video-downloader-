# Video detection metadata and quality fixes

This revision addresses the issues visible in the October 25 detection screenshots.

## Changes

- **Resolution belongs to the selected source.** `SnifferScript` now attaches `videoWidth × videoHeight` only to the URL that matches `video.currentSrc`. Alternate `<source>` URLs are not incorrectly labelled with the currently playing source's dimensions.
- **Metadata can improve after the first detection.** The page sniffer records a metadata signature per URL. If the title, duration, poster, resolution, MIME type, or playback state changes, it reports the same URL again rather than silently skipping it.
- **Compound stream filenames are fallbacks.** Names such as `_TPL_.av1.mp4.m3u8` are treated as technical filenames, allowing a page/video title to replace them when that metadata is available.
- **Quality parsing is more conservative.** The detector does not read resolution from page titles or arbitrary parent-directory text. Actual dimensions from the player or HLS manifest take precedence. Inferred labels are limited to common quality heights; a guessed `250p` is not accepted as a confirmed quality without actual dimensions.
- **Same-player grouping is stable.** Metadata appearing later no longer changes a candidate's grouping key and splits alternate sources from the same video element.
- **Duplicate quality buttons are reduced.** Within a video group, multiple URLs labelled with the same known resolution collapse to one selected option; unknown streams remain separate because the app cannot safely compare them.
- **Expanded HLS variants inherit late metadata.** If the master playlist has already been expanded, later page metadata updates are also applied to its child options.

## Verification performed

- JavaScript parser check passed for the injected sniffer.
- Standalone Kotlin smoke checks passed for stable same-player grouping, using actual dimensions ahead of an incorrect inferred label, ignoring title/parent-path numbers, and collapsing duplicate known-quality options.
- Regression tests were added to `app/src/test/java/com/mahabub/downloder/MediaCandidateGroupingTest.kt` for these cases.

A full Android Gradle build and on-device test could not be run in this environment because the export has no Gradle wrapper and this environment has no installed Gradle/Android SDK. Build the project in Code Assist before replacing the installed APK, then re-test the same page. The site still must expose a usable poster/duration or a parseable HLS master playlist for those fields to be filled; the detector cannot infer hidden metadata that the page does not expose.
