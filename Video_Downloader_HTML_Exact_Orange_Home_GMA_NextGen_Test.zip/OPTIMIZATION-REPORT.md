# Source and APK Optimization Report

## Changes applied

1. Enabled R8 code shrinking and resource shrinking for the `release` build type.
2. Enabled AGP optimized resource shrinking (`android.r8.optimizedResourceShrinking=true`).
3. Removed Firebase AI/App Check, Retrofit/Moshi, OkHttp Logging Interceptor, AndroidX WebKit, direct duplicate Coroutines Core, and unused direct Lifecycle Runtime KTX declarations after finding no corresponding source imports or usages.
4. Removed unused Android/instrumentation/UI test dependencies. The project currently contains local JVM tests using JUnit 4 only.
5. Removed the generated `gradle/libs.versions.toml` catalog after confirming no Gradle script referenced any `libs.*` aliases; it contained stale, unused dependency declarations and did not participate in the build.
6. Replaced broad OkHttp/Media3/model keep rules with focused WebView JavaScript bridge and Room database rules. OkHttp and Media3 consumer rules remain supplied by their libraries.
7. Removed the disconnected native `TikTokExtractor` implementation and its test. The app's current architecture explicitly handles TikTok through Browser mode; Browser-mode helpers and tests were retained.
8. Removed an unused `GenericWebExtractor` instance from `AppContainer`; `MediaExtractionRepository` continues to own and use its generic fallback.
9. Resized the launcher foreground artwork from 1024x1024 PNG to 512x512 high-quality WebP without changing its Android resource name or XML reference. The resource changed from 795,920 bytes to 19,856 bytes (776,064 bytes / about 97.5% smaller).

## Intentionally retained

- HLS parser, segment timeline, HLS downloader and direct HTTP downloader.
- Platform extractors still registered in `AppContainer`.
- Generic web extraction fallback in `MediaExtractionRepository`.
- Browser media detector, JavaScript sniffer, TikTok Browser-only gate and its URL/playback heuristics.
- Download service, Room database, DataStore preferences, storage provider, Media3 player, Coil thumbnails, Compose UI and navigation.
- Existing functional JVM test source files other than the obsolete TikTok native-extractor test case.

## Validation status

Static source/reference checks were performed. A Gradle/Android build and device runtime tests could not be executed in this environment because the ZIP has no `gradle-wrapper.jar`, and no Gradle executable or Android SDK is available here. Therefore the optimized release configuration must be built and smoke-tested in the project's Android build environment before publishing. R8/resource shrinking applies to the `release` variant; a normal debug APK will not demonstrate those release-only savings.

Recommended checks: release assemble; launch app; browser navigation and tabs; media detection; direct MP4 download; HLS download including A/V sync; pause/resume; app restart and queue recovery; Room history; offline playback; English/Bangla resources; and WebView JavaScript bridge callbacks.
