# Instagram Downloader stability update — 2026-11-04

## Scope

This update improves the Instagram page-extraction path while keeping the app-wide DASH pause in place. It does not add stealth behavior, proxy rotation, fingerprint spoofing, private endpoint calls, login bypasses, or anti-rate-limit evasion. The extractor only processes the Instagram URL explicitly supplied by the user and media URLs already exposed in an accessible page response or rendered by the app's WebView.

## Changes

- Instagram URL matching now validates HTTP(S), Instagram/instagr.am hostnames, and supported post/reel/reels/TV/story/share routes.
- The Instagram page extractor flushes WebView cookies before reading URL-scoped cookies through the existing request helper.
- Redirects to login, challenge, or checkpoint pages are rejected instead of being parsed as media pages.
- Non-HTML responses and oversized HTML pages are rejected. HTML reads are bounded to 5 MiB to avoid unbounded memory use.
- The Meta page parser ignores DASH candidates while DASH is paused, including DASH candidates found by helper collectors.
- Candidate ordering now prefers a single-file progressive stream (normally MP4), then HLS. A high-ranked manifest field cannot hide an available direct MP4.
- Instagram HTML-extracted video URLs are restricted to Instagram/CDN host suffixes already used by the app's Instagram media allowlist (`instagram.com`, `instagr.am`, `cdninstagram.com`, `fbcdn.net`, `fbsbx.com`).
- Added parser regression tests for MP4-over-HLS selection, DASH-only rejection, HLS fallback, CDN host validation, candidate metadata, and Instagram share-route matching.

## Preserved

- TikTok-specific resolver and browser-mode code was not changed.
- Facebook-specific login/session handling was not changed in this update.
- Existing WebView media overlay, shared HLS downloader, and other platform handlers were not changed.
- DASH implementation files remain in the project but DASH selection remains paused.

## Validation

- Compiled the modified Instagram extractor and Meta media parser with Kotlin 1.9.0 using lightweight Android/OkHttp API stubs to validate Kotlin syntax and API usage.
- Ran parser smoke checks confirming: (1) direct MP4 wins over HLS when both are exposed, (2) DASH-only content does not create a DASH candidate, and (3) HLS is selected when no progressive stream exists.
- The full Android Gradle build and device-level Instagram tests were not run. This project archive contains `gradle-wrapper.properties` but does not contain the Gradle wrapper scripts/JAR, and no system Gradle installation is available in the build environment.

## Operational limits

No downloader can be guaranteed to keep working unchanged for years against a third-party platform that changes its website, media delivery, or access rules. Private, age-restricted, login-gated, or otherwise inaccessible content is not bypassed. If Instagram does not expose a downloadable MP4/HLS URL to the user's authorized WebView session or the page response, the app should show a clear unavailable message rather than fabricate a media file.
