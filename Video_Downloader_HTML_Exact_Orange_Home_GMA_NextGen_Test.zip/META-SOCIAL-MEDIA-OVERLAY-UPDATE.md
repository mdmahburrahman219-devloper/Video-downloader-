# Meta Social Media Per-Item Media Overlay Update

## Scope

This update adds a separate image/video overlay flow for Facebook, Instagram and Threads (`threads.com`, while retaining legacy `threads.net` support). Other websites retain the existing browser detection and download experience.

## What changed

- Injected a platform-scoped JavaScript overlay only on Facebook, Instagram and Threads pages.
- Added a red download control to visible `img`, `video` and supported CSS-background media elements. It follows feed content while scrolling, observes newly visible items, removes off-screen controls, and caps the number of live controls to reduce UI overhead.
- Image actions select the best exposed image rendition and open an image-specific sheet. The sheet identifies the item as an image, offers the original available image URL, and does not display video qualities or unrelated detected media.
- Video actions use the element's current/source URL, the existing page resource cache, or a unique matching detected stream. Ambiguous blob-backed videos are not guessed across multiple feed items.
- Meta pages no longer display the old page-level download FAB or page-wide media picker. The ordinary flow remains active on all non-Meta websites.
- Pasted/shared single-post links try the existing platform extractor first. If that does not yield a direct video, the link opens in the authenticated WebView and the existing DOM/resource scanner attempts one targeted video selection; it does not show all videos from the page. It does not wait for playback to start before running the first extraction/scan.
- Added JSON-LD `VideoObject.contentUrl` and `link[rel=preload][as=video]` as additional standards-based pre-play hints on Meta pages.
- Reused WebView cookies for platform extraction and direct HTTP downloads. HLS playlist/segment/key requests now optionally use URL-scoped WebView cookies only for Facebook, Instagram and Threads. Other sites' HLS requests remain unchanged.
- Added Referer/User-Agent metadata to platform extractor candidates and added image response-type validation to avoid saving HTML/login pages with an image extension.
- Added Threads `.com` recognition while retaining `.net` compatibility.

## Fallbacks used

1. Direct media URL detection.
2. Platform-specific Open Graph and page-visible embedded metadata extraction.
3. HTML video/source and lazy-media attributes.
4. `currentSrc` / `src` / `source` and resource timing.
5. Existing fetch/XHR/performance hooks and WebView request observation.
6. Standard JSON-LD VideoObject and preload-link hints.
7. Existing HLS playlist variant resolver and downloader.
8. The authenticated WebView session as fallback when direct extraction does not resolve the pasted post URL.

No DRM, SAMPLE-AES, private-access bypass, credential harvesting, or anti-bot circumvention was added. Content that the signed-in WebView cannot expose as an ordinary downloadable URL (for example, some blob-only MediaSource streams, protected streams, or expired CDN URLs) can still fail; ambiguous media is not selected automatically.

## Validation performed

- Extracted overlay JavaScript passed `node --check`.
- Updated main Sniffer JavaScript passed `node --check`.
- Platform host/URL/CDN allowlist helper checks passed using a small standalone Kotlin compile/test harness.
- All 12 Android XML files parsed successfully.
- Added JUnit coverage for Meta host recognition, single-post URL recognition, CDN allowlisting, Threads `.com` and legacy `.net`, and Instagram Stories matching.

## Not validated in this environment

A full Android Gradle build, KSP/Room code generation, APK installation, and real-device Facebook/Instagram/Threads login/download tests were not possible here. The source archive has no Gradle wrapper executable/JAR, no system Gradle is installed, and no Android SDK is configured in this environment. The project must still be built and tested on the user's Android build setup.

## Platform terms note

Meta's Automated Data Collection Terms state that automated collection requires Meta's express written permission; Meta also says automated collection without permission violates its terms. This feature is user-initiated per media, but the page observer and automatic discovery may still be treated as automated collection. Review Meta's terms and obtain any required authorization before distributing this functionality.
