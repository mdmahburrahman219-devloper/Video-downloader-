# TikTok download failure visibility fix

## What was wrong
The download service already records failed jobs as `FAILED` with an `errorMessage`, but the Progress screen only observed active states and the Finished screen only observed `COMPLETED`. A quickly rejected TikTok CDN request (for example HTTP 403/404, a stale signed URL, or an invalid media candidate) therefore disappeared from both screens.

## Changes in this update
- Added a DAO query and repository/ViewModel flow for failed downloads.
- Added a Failed Downloads section to the Progress screen.
- Each failed item displays the stored failure reason and provides Retry and Open page actions.
- Kept the queue's active-download query and the MP4/HLS download implementations unchanged.

## How to test
1. Build/install this project and download the same public TikTok video.
2. If it fails, open Progress; the failure should now remain visible with the stored error.
3. Share the exact displayed error (such as Forbidden/HTTP 403, Not found/HTTP 404, network unavailable, or unsupported media) to identify the next targeted fix.

This is a source-level patch. A full Android Gradle build and live TikTok transfer test still need to be run in an Android SDK/Gradle environment.
