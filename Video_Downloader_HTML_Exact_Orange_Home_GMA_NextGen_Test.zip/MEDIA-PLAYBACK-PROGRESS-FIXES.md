# Media duration, HLS remux, progress, and player update

## Changes

- HLS conversion now has a separate `CONVERTING` state. The downloads screen shows a single indeterminate progress bar and the `Converting…` label without a percentage.
- HLS segment samples are mapped to the playlist's cumulative `EXTINF` timeline. Only overlapping leading samples at segment boundaries are discarded rather than shifting later segments forward; intra-segment sample order (including B-frame decode order) is preserved. This avoids cumulative timestamp drift and duration inflation on streams that reset PTS at segment boundaries.
- Invalid/zero HLS segment durations are rejected instead of producing an unusable timeline. The final MP4's duration is read from local media metadata after muxing.
- Direct-file progress uses verified `Content-Length`/`Content-Range` totals when available. HLS totals remain unknown until the resulting MP4 is created; the UI no longer invents total sizes. Downloaded bytes display in B/KB/MB/GB units.
- Finished/download progress thumbnails show a real known duration instead of a hard-coded demo `00:31`. Final duration metadata is read from the local completed media and is cleared when unavailable.
- The offline Media3 player is recreated per URI and enables decoder fallback to reduce stale-player/decoder issues.
- The stability banner requests Android's ignore-battery-optimizations setting and re-checks the setting when the app resumes; it hides after the setting is active.

## Verification boundary

Archive/XML/source checks can be run in this export, but the full Android APK build and actual BongoBD playback/audio-video synchronization test require Code Assist/Android SDK and a physical device. HLS timestamp remuxing is a source-level fix and must be tested against a sample from BongoBD before claiming the reported 34-to-59-minute and A/V sync issues are resolved in practice.
