# TikTok detection/resolution update

## What changed

- TikTok video-page navigation now starts a platform resolver automatically, in parallel with the existing DOM/network sniffer.
- Resolver results enter the existing `MediaDetector` StateFlow, then follow the existing candidate probe, metadata enrichment, selection popup, and download pipeline.
- The native TikTok extractor can parse common `SIGI_STATE`, `__UNIVERSAL_DATA_FOR_REHYDRATION__`, and `__NEXT_DATA__` JSON payloads, recursively inspect video objects, prioritize the page's video ID, and read `playAddr`, `downloadAddr`, and bitrate playback URL lists.
- `og:video` is now only used when it looks like a direct media URL, avoiding a common false positive where the Open Graph value points at a TikTok HTML embed/player.
- The WebView sniffer scans TikTok hydration JSON for direct media addresses when they appear after initial document load, and reports candidates through the pre-existing JavaScript bridge.
- DOM-video candidates now preserve the actual WebView User-Agent, while extractor candidates include the page Referer and extractor User-Agent.
- TikTok detection loading remains active while the platform resolver is working, and a resolver failure can end with a retry-oriented message rather than leaving the FAB loading indefinitely.
- Added regression cases for TikTok short-link hosts and lookalike domains.

## Scope and limitations

This is a best-effort native extractor, not a promise of 90% success across every TikTok video. TikTok's web state is undocumented and changes over time. Some pages may return challenge/login HTML, media URLs may expire, a CDN may require session-specific headers, and some media may be split into separate audio/video streams or otherwise unavailable. Such cases can still require a future `yt-dlp`-based runtime/backend fallback.

No public third-party resolver or proxy is called by this update. This keeps private links/cookies from being sent to an unrelated download service.

## Validation

- The updated JavaScript sniffer block passes `node --check`.
- Full Android Gradle build and device-level TikTok tests must be run in Android Studio / a machine with the project Gradle wrapper, Android SDK, and dependencies configured. This workspace does not contain a Gradle executable/wrapper JAR or Android SDK, so I cannot honestly mark the APK as build-verified here.

## HTTP 403 refresh behavior

The downloader now asks Android WebView's CookieManager only for cookies scoped to the exact media URL, sends a generic media Accept header, and falls back to the original TikTok page URL as Referer when needed. When a progressive TikTok source returns HTTP 403, the service re-fetches the source page and tries up to six distinct, same-stream-type media candidates from the fresh embedded state. The retry path updates the stored candidate URL and clears the partial file before trying another candidate; it does not endlessly retry the same signed URL. If every candidate is denied, the failed task explains that the TikTok/CDN rejected all refreshed alternatives.

This is best-effort: it cannot make private, deleted, restricted, expired-with-no-refreshable-source, or server-denied media downloadable.
