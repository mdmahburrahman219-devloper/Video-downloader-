# TikTok WebView page-availability investigation (2026-10-29)

## Change in this build
- Normal/mobile WebView mode now uses `WebSettings.getDefaultUserAgent(context)` instead of a hard-coded `Android 14 + Chrome 128` UA.
- Switching out of desktop mode restores that actual device WebView UA. Desktop mode remains an explicit desktop-UA override.
- No download engine, detector ranking, storage, or non-TikTok extractors were changed.

## Why
The previous mobile UA claimed Android 14 and Chrome 128 regardless of the actual Android/WebView version. Android's WebSettings docs state that overriding a UA can affect User-Agent Client Hints and `navigator.userAgentData`. TikTok can deliver different page/player paths based on client signals, so aligning the UA is a targeted compatibility test, not a guaranteed fix.

## What this does not prove
The screenshots show a TikTok-rendered “This page isn't available” fallback, not a demonstrated WebView network exception. Other possible causes include TikTok's share/profile route, consent/cookie/session state, redirect handling, a profile-vs-video URL mismatch, or TikTok's current availability policy. We need the exact final URL and sanitized main-frame HTTP/network diagnostics to distinguish them.

## Device test
1. Build and install this ZIP.
2. In normal/mobile mode (not Desktop mode), open the same exact copied URL in your app and the comparison app.
3. Compare the final URL after redirects (copy the address after load), not only the shortened toolbar text.
4. Test a canonical public video URL (`https://www.tiktok.com/@user/video/<id>`) and the profile URL separately.
5. If the page still says unavailable, collect main-frame HTTP status, WebView error code and final URL host/path (redact all query tokens/cookies).
