# Animated Navigation & Screen Motion Update — 2026-11-05

## UI changes
- Replaced the old three-item bottom bar with four primary destinations: Browse, Downloads, Videos, and Settings.
- Added a spring-driven floating selection bubble and a custom curved cradle/notch that follows the active destination.
- Added a short fade/scale transition for the active navigation icon and retained download/completed counters.
- Added a page-entry fade/slide transition to Settings.
- Added an entrance transition to the empty Finished Videos state and staggered fade/slide/scale entry animations for completed video cards.
- Added Bengali and English navigation labels for Browse and Videos.

## Preserved behavior
- Existing Browser, Downloads, Completed, and Settings routes remain in use.
- Existing ViewModels, database, downloader, browser/WebView, extractors, storage, settings actions, and playback/share/delete/rename callbacks were not intentionally changed.
- The tab-switch navigation continues to use the existing save/restore back-stack behavior.

## Build verification
- XML resources were parsed successfully.
- Kotlin source parsing completed without syntax-parser errors.
- A full Android Gradle build could not be run in this environment because this archive does not include `gradlew` and no Gradle installation or Android SDK is configured here. Open the project in Android Studio and run `:app:assembleDebug` to perform the device-toolchain build.

## Reference-matched full-width navigation refinement

- Replaced the inset rounded floating-card shell with an edge-to-edge navigation surface.
- Removed horizontal and vertical outer card margins and removed the rounded card silhouette.
- The selected circular indicator now floats above a full-width bar with a concave cradle cut into the top edge.
- A single spring-animated selection value drives both the circle's horizontal position and the Canvas cradle center, keeping the two motions synchronized.
- The bar background continues through the Android navigation-bar inset so the surface reaches the bottom screen edge.
- Preserved the four existing destinations, route callbacks, counters, icon transition, and screen-level animation work.
