# DASH implementation update

## Changes in this revision

1. Facebook inline MPD storage now accepts HTTPS/HTTP manifest response URLs on `facebook.com`, `fbcdn.net`, and `fbsbx.com` host trees. Matching is label-boundary-safe, so lookalike hosts such as `evilfacebook.com` remain rejected.
2. Facebook DASH quality size estimates now include the selected audio representation bitrate as well as the video bitrate. The estimate remains explicitly approximate because actual segment sizes, container overhead, and variable bitrate can differ.
3. Added host allowlist regression tests for accepted Facebook/CDN hosts and rejected lookalike domains.
4. Updated the DASH documentation to describe the implemented VOD pipeline and its deliberate limitations.

## Muxer decision

This revision retains Android `MediaExtractor` + `MediaMuxer` for the final MP4. The current pipeline downloads DASH initialization data and media segments, then reads their samples and writes a conventional MP4. Media3's `FragmentedMp4Muxer` creates fragmented MP4 output and has a different API/format contract; merely swapping it in would not fix unsupported MPD features, codec incompatibility, bad timestamps, or missing initialization data. A muxer replacement should only be made after fixture-based and physical-device validation, not as an unverified dependency swap.

## Known remaining DASH boundaries

- Static, single-period VOD only; dynamic/live and multi-period MPDs are rejected.
- DRM/ContentProtection is rejected; no DRM bypass is attempted.
- Segment count is bounded to protect memory/storage and avoid runaway manifests.
- Codec/container support depends on Android's `MediaExtractor` and `MediaMuxer` implementation on the device.
- Some uncommon DASH layouts (including unusual timeline/index combinations) may still fail and need captured, non-sensitive MPD fixtures for regression coverage.
- A full Gradle build, full JUnit run, and live Facebook Reel device test were not possible in this environment because the archive has no Gradle wrapper and this environment has no installed Gradle/Android SDK.
