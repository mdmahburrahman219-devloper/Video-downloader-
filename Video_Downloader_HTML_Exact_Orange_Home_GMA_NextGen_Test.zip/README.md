# Video Downloader (Android)

A modern, high-performance native Android media-saving application built with **Kotlin**, **Jetpack Compose**, **Material 3**, **Room Database**, **Android WebView**, and **AndroidX Media3 ExoPlayer**.

- **Package Name:** `com.mahabub.downloder`
- **Application ID:** `com.mahabub.downloder`
- **Min SDK:** 26 (Android 8.0 Oreo)
- **Target SDK:** 36

---

## 1. Architecture Overview

The app follows **Clean Architecture** and **MVVM (Model-View-ViewModel)** with the **Repository pattern**:

```
UI Layer (Jetpack Compose + Material 3)
   ├── HomeBrowserScreen (Address bar, WebView, Floating Detection Badge)
   ├── DownloadsScreen (Active Queue, Segment Progress, Pause/Resume)
   ├── CompletedScreen (Offline Library, Play, Share via FileProvider)
   ├── OfflinePlayerScreen (AndroidX Media3 ExoPlayer)
   ├── BrowserHistoryScreen & BookmarksScreen
   ├── SettingsScreen (Wi-Fi Only, Max Concurrent, Stream Quality)
   └── AboutPrivacyScreen (Legal & Usage Notice)
           │
ViewModels (StateFlow / collectAsStateWithLifecycle)
   ├── BrowserViewModel
   ├── DownloadsViewModel
   ├── CompletedViewModel
   ├── HistoryBookmarksViewModel
   └── SettingsViewModel
           │
Domain / Service Layer
   ├── DownloadService (Foreground Service with DataSync)
   ├── DownloadNotificationManager
   └── MediaDetector (Aggregates Network Interception & DOM Sniffer)
           │
Repositories & Engines
   ├── DownloadRepository (Queue Management, Wi-Fi Verification)
   ├── MediaExtractionRepository (Platform Matching & Probing)
   ├── HttpDownloader (Progressive Streaming, Range-Resume)
   ├── HlsDownloader (Native SDK MediaExtractor + MediaMuxer Remuxing - No FFmpeg)
   └── StorageManager (Android MediaStore + Scoped App Storage)
           │
Data Storage (Room Database & DataStore Preferences)
   ├── AppDatabase (DownloadDao, BookmarkDao, BrowserHistoryDao)
   └── PreferenceManager (DataStore)
```

---

## 2. Why No FFmpeg Was Used (Zero Native .so Bloat)

Traditional video downloaders bundle massive FFmpeg native binaries (`libffmpeg.so`, 30MB–80MB+ per ABI). 

**This app contains no bundled FFmpeg binary.** For supported HLS variants, it uses OkHttp plus Android's `MediaExtractor` and `MediaMuxer` APIs to assemble and remux media without video re-encoding:

1. **Manifest parsing:** Reads master and media playlists, selects a video variant and, when declared separately, a matching audio rendition.
2. **Segment transfer:** Downloads TS or supported fMP4 media segments, honoring explicit/implicit byte ranges and retaining completed segment caches for retries.
3. **Optional AES-128 decryption:** Supports standard HLS `METHOD=AES-128` with `KEYFORMAT=identity` when the key is accessible. DRM and `SAMPLE-AES` are intentionally unsupported.
4. **Remuxing:** Feeds the assembled source to `MediaExtractor`, then writes timestamp-ordered samples via `MediaMuxer`. This is remuxing, not transcoding, and the result depends on the stream's codec/container structure and Android device support.
5. **Cleanup:** Removes temporary HLS cache/source files after a successful export. Completed segment caches are retained after cancellation or failure so retry may reuse them.

---

## 3. Supported Platforms & Media Types

- **Extractor coverage:** Instagram, Facebook, Twitter/X, Pinterest, Reddit, Threads, and generic pages use their existing detection/extraction flows. TikTok is browser-first: its page is left untouched until a video actually plays, then the browser-side scanner looks for page-exposed media candidates. The TikTok native extractor/refresh path is disabled. Site changes, access controls, login requirements, DRM and signed URLs can still prevent a download.
- **Direct media formats:** MP4, WebM, MOV, M4V and common audio formats when a direct media URL is found.
- **HLS:** `.m3u8` playlists within the HLS compatibility boundaries documented below.
- **DASH:** `.mpd` may be detected, but the current custom download service does not implement DASH downloading.

---

## 4. Usage Notice & Legal Scope

This application is designed strictly for personal, fair-use archival of publicly-accessible media:

> *"Download only content that you own or have permission to download, and respect the copyright, privacy, and terms of service of the website you are downloading from."*

**Security and Policy Standards:**
- **No DRM Bypass:** Licensed DRM systems (Widevine, PlayReady, FairPlay) are strictly excluded.
- **HLS encryption boundary:** Standard identity AES-128 HLS can be processed when the playlist key is available. `SAMPLE-AES`, non-identity key formats and DRM-protected streams are not bypassed.
- **No Login / Paywall Circumvention:** Does not bypass private accounts or login gates.
- **Credential handling:** The app does not ask for or store social-media passwords. Existing WebView-managed cookies may be attached to source-page requests by the browser/extraction flow; treat them as sensitive session data and do not share logs containing request headers.
- **Scoped Storage:** Completed files are saved via Android `MediaStore` without requiring broad storage permissions (`MANAGE_EXTERNAL_STORAGE`).

---

## 5. Build and Run Instructions

### Prerequisites
- Android Studio Ladybug (2024.2.1) or newer
- JDK 17 or JDK 21
- Android SDK 36

### Generate the missing Gradle wrapper (export note)
This source archive came from a CodeAssist export and did not include `gradlew`, `gradlew.bat` or `gradle-wrapper.jar`. If you have Gradle 8.13 installed, run once from the project root:
```bash
gradle wrapper --gradle-version 8.13
```
Then build with the generated wrapper. Android Studio can also help regenerate the wrapper after a successful project sync.

### Build Debug APK:
```bash
./gradlew assembleDebug
```
The APK will be generated at `app/build/outputs/apk/debug/app-debug.apk`.

### Run Unit Tests:
```bash
./gradlew test
```

### Create a Signed Release Build:
1. Generate your production release keystore:
   ```bash
   keytool -genkey -v -keystore my-upload-key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias upload
   ```
2. Configure your release signing variables in `.env` or CI environment variables:
   - `KEYSTORE_PATH=/path/to/my-upload-key.jks`
   - `STORE_PASSWORD=your_store_password`
   - `KEY_PASSWORD=your_key_password`
3. Build the release App Bundle (.aab):
   ```bash
   ./gradlew bundleRelease
   ```

---

## 6. Localization (English & Bengali)

Resource-backed strings are available in:
- English: `app/src/main/res/values/strings.xml`
- Bengali: `app/src/main/res/values-bn/strings.xml`

The Settings language choice applies a locale to the Activity and resource-backed UI after recreation. Some Compose screens still contain hard-coded English labels and are not yet fully translated.

## HLS downloader implementation notes

The custom HLS path (`HlsDownloader`) supports:

- Master-playlist variant selection and a matching external audio rendition when one is declared.
- MPEG-TS segments and common fragmented-MP4 HLS with a single stable `EXT-X-MAP` initialization section.
- Explicit and implicit `EXT-X-BYTERANGE` offsets, with range-length verification.
- Standard HLS `METHOD=AES-128` with `KEYFORMAT=identity`, using the playlist IV or media-sequence-derived IV.
- Sample-timestamp based muxing rather than estimating every segment's duration as a fixed offset.
- Resumable reuse of completed segment and initialization-section cache files after cancellation or retry.
- Live playlist refresh until `EXT-X-ENDLIST` or a bounded 30-minute capture limit.
- Localized HLS compatibility notes and actionable unsupported-feature errors in the media selection UI.

Intentional boundaries: this is not a DRM bypass tool. `SAMPLE-AES`, non-identity/DRM key formats, external license systems, and playlists that switch initialization maps within a single media playlist are rejected rather than saved as a potentially corrupt MP4. Complex fMP4, codec changes, and discontinuity-heavy streams still require real-device testing; device codec/container support can vary. HLS live capture preserves already completed segment cache files when canceled, but a restarted live recording can only continue from segments still exposed by the refreshed playlist.

### HLS test coverage added

Unit tests cover quoted master-playlist attributes, separate audio rendition metadata, byte-range offset resolution, initialization maps, AES-128 key metadata/IV, media sequence values, event/live playlist detection, and sequence-derived IV construction. Android playback/remux tests must still be run on real devices and an Android SDK-equipped build agent.

## Browser stability and session persistence update

- `SecureWebViewClient.shouldInterceptRequest()` is a WebView worker-thread callback. It now identifies TikTok from the request URL and a volatile last-page URL only; it never reads `WebView.url` from that background thread. This prevents a WebView thread-affinity crash on ordinary websites.
- The Home primary action is navigation/search only. Actual downloads are started from the in-page media detection flow.
- Search terms now use the selected Settings search engine (Google, Ask, Bing, Yahoo, StartPage, DuckDuckGo, Baidu, Yandex, or a validated custom `%s` template).
- Normal browser tabs and the selected tab ID are persisted in DataStore. On process restart, the tab list and active page URLs are restored; WebView back/forward history is retained while the process remains alive, but is reloaded from the saved URL after a process restart. Private tabs are intentionally not persisted.
- The Block ads switch now controls the WebView filter. TikTok remains exempt from the filter. Clear cache clears WebStorage and the app WebView HTTP cache. Download location and Sync to gallery are now passed to the final save operation.


## Browser crash, search, Settings and session repair

- Fixed `SecureWebViewClient.shouldInterceptRequest()` so it never reads `WebView` properties from the WebView resource worker thread. Detector/filter exceptions now fall through to the normal browser request instead of cancelling page loading.
- Removed the all-site document-start script injection. Ordinary pages receive their normal sniffer only after page load; TikTok keeps the playback-first two-phase gate.
- Home's primary button is Search / Go only and never starts a download. Media downloads remain behind the explicit detection/selection flow.
- Search engine selection is applied to typed search queries, including Ask, Bing, Yahoo, StartPage, DuckDuckGo, Baidu, Yandex and Custom URL.
- The browser persists normal tab URLs, titles, desktop-mode flags and the active tab ID. It also commits the session when the browser moves to the background. Private tabs are deliberately excluded. After process death, each saved tab reloads its last URL; its in-memory WebView back/forward history is not serialized.
- Settings now apply language selection to Android resource-backed UI on Activity recreation. Hard-coded Compose labels remain partially English.
