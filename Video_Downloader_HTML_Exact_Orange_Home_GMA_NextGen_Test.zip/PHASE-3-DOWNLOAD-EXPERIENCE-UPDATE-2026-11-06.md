# Phase 3 — Download Experience & Videos Library — 2026-11-06

This update builds on the Phase 1–2 UI-polish archive. It focuses on the Downloads queue and the completed media library.

## Downloads screen

- Replaced the legacy `PROGRESS` heading with `Downloads` and a live active/failed count summary.
- Removed non-functional Feedback and List toolbar actions.
- Added real Pause All and Resume All actions, shown only when the matching queue state exists.
- Reworked active download cards with a larger thumbnail, filename, explicit state label, animated segmented progress, byte or segment progress, transfer speed, Details, Open Page, Pause, and Resume actions.
- Added a confirmation dialog before cancelling a download.
- Reworked failed-download cards and retained Retry and Open Page behavior; added Details navigation.
- Simplified the battery optimization notice and made it follow the active theme surface colors.
- Corrected content sizing so the empty state/list respects the remaining space beneath the notice.

## Completed Videos / saved media screen

- Replaced the legacy `FINISHED` heading with `Videos`.
- Removed the non-functional Private Safe Vault, fake notification dot, Feedback dialog, and List toast action.
- Added live media count, search, All / Videos / Images / Audio filters, and Newest / Oldest / Largest / Smallest sorting.
- Added an explicit no-results state with a working Clear Filters action.
- Improved media cards with consistent thumbnails, media-type icons, duration, readable file size, and a cleaner overflow menu.
- Added a working Details item in the media overflow menu.
- Retained Play, Share, and Delete behavior.

## Functional rename fix

- Added a StorageManager rename operation for `file://` paths, SAF document URIs, and MediaStore content URIs.
- Preserved the original media extension so a rename cannot silently change the file's extension/format label.
- Updated the Room DAO and repository to save the actual renamed URI and display name.
- The Rename dialog now performs the real storage/database operation and displays errors instead of showing a success toast without changing the file.
- No Room schema migration is required; only an update query was added for existing columns.

## Scope protection

The download service, HTTP/HLS engines, media extraction, platform extractors, browser detection scripts, and download state machine were not edited in Phase 3. Changes are limited to Downloads/Videos UI, the completed-media rename flow, its DAO operation, and a new update note.

## Validation

- Compared the extracted Phase 3 tree against the Phase 1–2 ZIP: exactly six existing source files changed (DownloadsScreen, CompletedScreen, CompletedViewModel, DownloadDao, DownloadRepository, StorageManager).
- Kotlin compiler parser pass reported no syntax-level diagnostics in the modified sources. A full compile could not be performed because this project archive has no `gradlew` executable or wrapper JAR and this environment has no configured Android SDK / Gradle toolchain.
- ZIP integrity is checked separately after packaging.
